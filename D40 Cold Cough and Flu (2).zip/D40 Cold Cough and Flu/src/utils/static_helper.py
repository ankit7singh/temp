from typing import Union
from matplotlib.ticker import FuncFormatter
import numpy as np
import pandas as pd
import os
import json
import logging

import matplotlib.pyplot as plt
from collections import defaultdict
from sklearn.metrics import r2_score
from datetime import datetime
import sys

logger = logging.getLogger(__name__)

if os.path.abspath("../src/config_dir") not in sys.path:
    sys.path.append(os.path.abspath("../src/config_dir"))

# import constants
import importlib
# importlib.reload(constants)
# from constants import modeling_parameters_shared_modeling_stack_path_processed


def check_boolean(value):
    return isinstance(value, bool)

def check_file_exists(path):
    return os.path.isfile(path)

def check_variable_exists_in_stack(variable, stack_vars):
    return variable in stack_vars


def check_date_format(date_str,date_format="%Y-%m-%d"):
    try:
        datetime.strptime(date_str, date_format) 
        return True
    except ValueError:
        return False

def check_date_range(start_date_str, end_date_str, dates, date_format="%Y-%m-%d"):
    if not (check_date_format(start_date_str, date_format) and check_date_format(end_date_str, date_format)):
        return False  # Either start_date_str or end_date_str is not a valid date
    if dates is not None and (start_date_str not in dates or end_date_str not in dates):
        return False
    start_date = datetime.strptime(start_date_str, date_format)
    end_date = datetime.strptime(end_date_str, date_format)
    
    return start_date < end_date
    
def check_media_vars_exists_in_stack(media_vars_raw, media_vars_to_combine, stack_vars):
    granular_media_vars_for_combine =[]
    for i in media_vars_to_combine.values():
        granular_media_vars_for_combine+=i
    for media in media_vars_raw + granular_media_vars_for_combine:
        if media not in stack_vars and media not in media_vars_to_combine:
            return False
    return True
    
def check_simulation_media_spends_dict_exists_in_stack(simulation_media_spends_dict , stack_vars):
    for media in list(simulation_media_spends_dict.keys())[1:]:
        if media not in stack_vars:
            return False
    return True
    
def check_seasonality_terms(terms):
    accepted_terms = ["SARIMAX", "SEASONALITY/TREND", "SEASONALITY","TREND"]  # Add more if needed
    return all(term in accepted_terms for term in terms)


def check_GA(vars, stack_var):
    for var in vars:
        if var not in stack_var:
            return False
    return True

def qc_config(data, modeling_stack_file):
    df = pd.read_csv(modeling_stack_file)
    df["index"] = pd.to_datetime(df["index"]).apply(lambda i: str(i)[:10])
    stack_vars = list(df.columns)
    logger.setLevel(logging.WARNING)
    if not check_boolean(data['GA_pipeline_flag']):
        logger.warning(f"invalid value of GA_pipeline_flag")
    
    if not check_variable_exists_in_stack(data['modeling_parameters']['shared']['default_target_var'],stack_vars) :
        logger.warning(f"invalid value of default_target_var")
    
    if not check_variable_exists_in_stack(data['modeling_parameters']['shared']['target_var_unit'], stack_vars):
        logger.warning(f"invalid value of target_var_unit")

    if not check_variable_exists_in_stack(data['modeling_parameters']['shared']['target_var_new_cust'], stack_vars):
        logger.warning(f"invalid value of target_var_new_cust ")

    if not check_date_format(data['modeling_parameters']['shared']['simulation_start_date']):
        logger.warning("invalid simulation_start_date")

    if not check_date_format(data['modeling_parameters']['shared']['simulation_end_date']):
        logger.warning("invalid simulation_end_date")
    
    if not check_date_range(data['modeling_parameters']['shared']['simulation_start_date'],data['modeling_parameters']['shared']['simulation_end_date'], None):
        logger.warning("invalid simulation_end_date")

    if not check_media_vars_exists_in_stack(data['modeling_parameters']['shared']['media_vars_raw'],data['modeling_parameters']['shared']['media_vars_to_combine'], stack_vars=stack_vars):
        logger.warning("invalid media_var_raw")
    
    # if not check_simulation_media_spends_dict_exists_in_stack(data['modeling_parameters']['shared']['simulation_media_spends_dict'], stack_vars):
    #     logger.warning("invalid simulation_media_spends_dict")
    
    if not check_date_range(data['modeling_parameters']['sales_unit']['train_start'], data['modeling_parameters']['sales_unit']['train_end'], df['index'].values):
        logger.warning("invalid sales_unit train_start or train_end")
    
    if not check_date_range(data['modeling_parameters']['sales_unit']['test_start'], data['modeling_parameters']['sales_unit']['test_end'],df['index'].values):
        logger.warning("invalid sales_unit test_start or test_end")
    
    if not check_date_range(data['modeling_parameters']['new_customer']['headroom_analysis_start_end_date'][0], data['modeling_parameters']['new_customer']['headroom_analysis_start_end_date'][1], None):
        logger.warning("invalid new_customer headroom_analysis_start_end_date")
    
    if not check_date_range(data['modeling_parameters']['sales_unit']['headroom_analysis_start_end_date'][0], data['modeling_parameters']['sales_unit']['headroom_analysis_start_end_date'][1], None):
        logger.warning("invalid sales_unit headroom_analysis_start_end_date")
    
    if not check_date_range(data['modeling_parameters']['new_customer']['train_start'], data['modeling_parameters']['new_customer']['train_end'], df['index'].values):
        logger.warning("invalid new_customer train_start or train_end")
  
    if not check_date_range(data['modeling_parameters']['new_customer']['test_start'], data['modeling_parameters']['new_customer']['test_end'], df['index'].values):
        logger.warning("invalid new_customer test_start or test_end")
     
    if not check_file_exists(data['model_document']['CM_CampaignList_Path']): 
        logger.warning(f"invalid path of CM_CampaignList_Path")  
    
    if not check_seasonality_terms(data['modeling_parameters']['sales_unit']['seasonality_terms']):
        logger.warning("invalid check_seasonality_terms")
    
    if not check_seasonality_terms(data['modeling_parameters']['new_customer']['seasonality_terms']):
        logger.warning("invalid check_seasonality_terms")
    
    if not check_GA(data['modeling_parameters']['sales_unit']['GA_iroas_constraints'],data['modeling_parameters']['shared']['media_vars_raw']):
        logger.warning("invalid sales_unit GA_iroas_constraints")
    
    if not check_GA(data['modeling_parameters']['sales_unit']['GA_high_iroas_constraints'],data['modeling_parameters']['shared']['media_vars_raw']):
        logger.warning("invalid salses_unit GA_high_iroas_constraints")
    
    if not check_GA(data['modeling_parameters']['new_customer']['GA_iroas_constraints'],data['modeling_parameters']['shared']['media_vars_raw']):
        logger.warning("invalid new_customer GA_iroas_constraints")
    
    if not check_GA(data['modeling_parameters']['new_customer']['GA_high_iroas_constraints'],data['modeling_parameters']['shared']['media_vars_raw']):
        logger.warning("invalid new_customer GA_high_iroas_constraints")
    
    if not check_date_range(data['model_document']['WMC_PORTFOLIO_DICT']["1"]['start_date'],data['model_document']['WMC_PORTFOLIO_DICT']["1"]['end_date'], df['index'].values):
        logger.warning("invalid WMC_PORTFOLIO_DICT start_date or end_date")
    
    if not check_date_range(data['model_document']['DUE_TO_OUTCOME_DICT']["due_to_outcome_2019_2020"]['start_date_1'],data['model_document']['DUE_TO_OUTCOME_DICT']["due_to_outcome_2019_2020"]['end_date_1'], df['index'].values):
        logger.warning("invalid DUE_TO_OUTCOME_DICT due_to_outcome_2019_2020 start_date_1 or end_date_1")
    
    if not check_date_range(data['model_document']['DUE_TO_OUTCOME_DICT']["due_to_outcome_2019_2020"]['start_date_2'],data['model_document']['DUE_TO_OUTCOME_DICT']["due_to_outcome_2019_2020"]['end_date_2'],df['index'].values):
        logger.warning("invalid DUE_TO_OUTCOME_DICT due_to_outcome_2019_2020 start_date_2 or end_date_2")
    
    if not check_date_range(data['model_insights_deck']['MODEL_DICT']['sales_unit']['singleOpt_scenarios']['optimization_outputs_v1']['headroom_start_end_date'][0],data['model_insights_deck']['MODEL_DICT']['sales_unit']['singleOpt_scenarios']['optimization_outputs_v1']['headroom_start_end_date'][1], df['index'].values):
        logger.warning("invalid headroom_start_end_date")
    
    return data

# for config file
def read_config(common_config_file , modeling_stack_file=None):
    """
    Read and parse a configuration file.

    Parameters:
    - common_config_file (str): The name of the common configuration file to read.
    - modeling_stack_file (str, optional): The name of the modeling stack file to read.
      Defaults to 'modeling_parameters_shared_modeling_stack_path_processed' for notbook 2 to 10.
      
    Returns:
    - data (dict): A dictionary containing the parsed data from the configuration file.

    This function reads and parses JSON files containing configuration data.
    It takes the path to the common configuration file as a required parameter,
    and an optional path to a modeling stack file. The data from the common
    configuration file is read and validate the common configuration file data.
    """
    path = os.path.abspath(f'../src/config_dir/{common_config_file}')
    file_data = open(path)
    data = json.load(file_data)
    # print(data)
    # get abs path
    # def get_data_with_abs_path(path_dict):
    #     path_keys = list(path_dict.keys())[1:4]
    #     # print(path_keys)
    #     for key in path_keys:
    #         path_dict['key'] = os.path.abspath(key)
    #     return path_dict

    # data = get_data_with_abs_path(data)
    # print(data)
    return qc_config(data, modeling_stack_file)

# static functons
def get_spend_var(var):
    # spend_var = ''
    # if var.startswith('M_') and (var.rsplit('_', 1)[-1].upper() != 'SPEND'):
    #     spend_var = var.replace('VIEW_IMP', 'SPEND')
    #     spend_var = spend_var.replace('CLK', 'SPEND')
    #     spend_var = spend_var.replace('IMP', 'SPEND')
    return var[:var.rfind("_")].replace("_VIEW", "").replace("_DETECTED","").replace("_VIDEO", "") + "_SPEND"

 

def get_rate_var(var):
    rate_var = ''
    if var.startswith('M_'):
        if var.rsplit('_', 1)[-1].upper() == 'IMP':
            rate_var = 'RATE_' + '_'.join(var.split('_')[1:-1])
        elif var.rsplit('_', 1)[-1].upper() == 'CLK':
            rate_var = 'RATE_' + '_'.join(var.split('_')[1:])
    return rate_var


def get_converted_var(spend_var):
    converted_var = ''
    return spend_var.replace('_SPEND', '_CONVERTED')



def s_curve_transformation(non_transformed_var_mean, transformed_var, scale= 1, inflection= 1):
    transformed_var_scaled = transformed_var/non_transformed_var_mean
    saturation_term = scale * (inflection - transformed_var_scaled)
    scurve_var = 1/(1+np.exp(saturation_term))-1/(1+np.exp(scale * inflection))
    s_curve_var_mean = scurve_var.mean()
    return s_curve_var_mean



def c_curve_transformation(var_mean, k_scalar, var):
    transformed_var =  np.log(var/(k_scalar * var_mean) + 1)
    return transformed_var

def get_model_type(final_model_path):
    if 'sale' in final_model_path.lower():
        model_type = 'UNIT_SALES'
    elif 'customer' in final_model_path.lower():
        model_type = 'NEW_CUSTOMER'
    else:
        model_type = 'New Model Type'
    return model_type





# custom_waterfall_chart.py 



def plot_waterfall(index, data, Title="", x_lab="", y_lab="",
              formatting = "{:,.1f}", green_color='#29EA38', red_color='#FB3C62', blue_color='#24CAFF',
             sorted_value = False, threshold=None, other_label='other', net_label='net', 
             rotation_value = 30, blank_color=(0,0,0,0), figsize = (10,10), save_path= None):
    '''
    Given two sequences ordered appropriately, generate a standard waterfall chart.
    Optionally modify the title, axis labels, number formatting, bar colors, 
    increment sorting, and thresholding. Thresholding groups lower magnitude changes
    into a combined group to display as a single entity on the chart.
    '''
    
    #convert data and index to np.array
    index=np.array(index)
    data=np.array(data)
    
    # wip
    #sorted by absolute value 
    if sorted_value: 
        abs_data = abs(data)
        data_order = np.argsort(abs_data)[::-1]
        data = data[data_order]
        index = index[data_order]
    
    #group contributors less than the threshold into 'other' 
    if threshold:
        
        abs_data = abs(data)
        threshold_value = abs_data.max()*threshold
        
        if threshold_value > abs_data.min():
            index = np.append(index[abs_data>=threshold_value],other_label)
            data = np.append(data[abs_data>=threshold_value],sum(data[abs_data<threshold_value]))
    
    changes = {'amount' : data}
    
    #define format formatter
    def money(x, pos):
        'The two args are the value and tick position'
        return formatting.format(x)
    formatter = FuncFormatter(money)
    
    fig, ax = plt.subplots(figsize=figsize)
    ax.yaxis.set_major_formatter(formatter)

    #Store data and create a blank series to use for the waterfall
    trans = pd.DataFrame(data=changes,index=index)
    blank = trans.amount.cumsum().shift(1).fillna(0)
    
    trans['positive'] = trans['amount'] > 0

    #Get the net total number for the final element in the waterfall
    total = trans.sum().amount
    trans.loc[net_label]= total
    blank.loc[net_label] = total

    #The steps graphically show the levels as well as used for label placement
    step = blank.reset_index(drop=True).repeat(3).shift(-1)
    step[1::3] = np.nan

    #When plotting the last element, we want to show the full bar,
    #Set the blank to 0
    blank.loc[net_label] = 0
    
    #define bar colors for net bar
    trans.loc[trans['positive'] > 1, 'positive'] = 99
    trans.loc[trans['positive'] < 0, 'positive'] = 99
    trans.loc[(trans['positive'] > 0) & (trans['positive'] < 1), 'positive'] = 99
    
    trans['color'] = trans['positive']
    
    trans.loc[trans['positive'] == 1, 'color'] = green_color
    trans.loc[trans['positive'] == 0, 'color'] = red_color
    trans.loc[trans['positive'] == 99, 'color'] = blue_color
    
    my_colors = list(trans.color)
    
    #Plot and label
    my_plot = plt.bar(range(0,len(trans.index)), blank, width=0.5, color=blank_color)
    plt.bar(range(0,len(trans.index)), trans.amount, width=0.6,
             bottom=blank, color=my_colors)       
                                   
    
   
    
    #axis labels
    plt.xlabel("\n" + x_lab)
    plt.ylabel(y_lab + "\n")

    #Get the y-axis position for the labels
    y_height = trans.amount.cumsum().shift(1).fillna(0)
    
    temp = list(trans.amount)
    
    # create dynamic chart range
    for i in range(len(temp)):
        if (i > 0) & (i < (len(temp) - 1)):
            temp[i] = temp[i] + temp[i-1]
    
    trans['temp'] = temp
            
    plot_max = trans['temp'].max()
    plot_min = trans['temp'].min()
    
    #Make sure the plot doesn't accidentally focus only on the changes in the data
    if all(i >= 0 for i in temp):
        plot_min = 0
    if all(i < 0 for i in temp):
        plot_max = 0
    
    if abs(plot_max) >= abs(plot_min):
        maxmax = abs(plot_max)   
    else:
        maxmax = abs(plot_min)
        
    pos_offset = maxmax / 40
    
    plot_offset = maxmax / 15 ## needs to me cumulative sum dynamic

    #Start label loop
    loop = 0
    for index, row in trans.iterrows():
        # For the last item in the list, we don't want to double count
        if row['amount'] == total:
            y = y_height[loop]
        else:
            y = y_height[loop] + row['amount']
        # Determine if we want a neg or pos offset
        if row['amount'] > 0:
            y += (pos_offset*2)
            plt.annotate(formatting.format(row['amount']),(loop,y),ha="center", color = 'g', fontsize=11)
        else:
            y -= (pos_offset*4)
            plt.annotate(formatting.format(row['amount']),(loop,y),ha="center", color = 'r', fontsize=11)
        loop+=1

    #Scale up the y axis so there is room for the labels
    plt.ylim(plot_min-round(3.6*plot_offset, 7),plot_max+round(3.6*plot_offset, 7))
    
    #Rotate the labels
    plt.xticks(range(0,len(trans)), trans.index, rotation=rotation_value)
    
    #add zero line and title
    plt.axhline(0, color='black', linewidth = 0.6, linestyle="dashed")
    plt.title(Title)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(os.path.join(save_path, "Waterfall.png"))
        
    plt.show()
    
    

    # save_excel.py

    
def colnum_string(n):
    string = ""
    while n > 0:
        n, remainder = divmod(n - 1, 26)
        string = chr(65 + remainder)+string
    return string

class SaveExcelTemplated:
    
    def __init__(self, path):
        self.path = path
        self.writer = pd.ExcelWriter(self.path, engine='xlsxwriter')
        
        self.header_format_features = {'font': 'Bogle',
                                      'font_color': 'white',
                                      'bold': False,
                                      'text_wrap': True,
                                      'valign': 'center',
                                      'fg_color': '#0071CE',
                                      'font_size': 11,
                                      'border': 1}
        
        self.odd_row_format_features = {'font_size': 11,
                                        'border': 1,
                                        'num_format': '#,##0'}
                                        
        self.odd_row_format_percentage = {'font_size': 11,
                                        'border': 1,
                                        'num_format': '0.0%'}
        
        self.odd_row_format_features_decimal = {'font_size': 11,
                                                'border': 1,
                                                'num_format': '#,##0.000'}
                                                
        self.odd_row_format_features_decimal_5 = {'font_size': 11,
                                                'border': 1,
                                                'num_format': '#,##0.00000'}
                                                
        self.odd_row_format_features_scientific = {'font_size': 11,
                                                'border': 1,
                                                'num_format': '0.00E+00'}
        
        self.even_row_format_features = {'bg_color': '#E6E7E8',
                                         'font_size': 11,
                                         'border': 1,
                                         'num_format': '#,##0'}
                                         
        self.even_row_format_percentage = {'bg_color': '#E6E7E8',
                                         'font_size': 11,
                                         'border': 1,
                                         'num_format': '0.0%'}
        
        self.even_row_format_features_decimal = {'bg_color': '#E6E7E8',
                                                 'font_size': 11,
                                                 'border': 1,
                                                 'num_format': '#,##0.000'}
                                                 
        self.even_row_format_features_decimal_5 = {'bg_color': '#E6E7E8',
                                                 'font_size': 11,
                                                 'border': 1,
                                                 'num_format': '#,##0.00000'}
                                                 
        self.even_row_format_features_scientific = {'bg_color': '#E6E7E8',
                                                 'font_size': 11,
                                                 'border': 1,
                                                 'num_format': '0.00E+00'}
        
        
    def add_worksheet(self, df, sheetname, percent_col_names = [], decimal_col_names = [], scientific_col_names= [],
                      decimal_5_col_names = [], startrow= 0):

        df.to_excel(self.writer, sheet_name= sheetname, index= False, startrow= startrow)
        
        self.workbook  = self.writer.book
        self.worksheet = self.writer.sheets[sheetname]
        
        self.workbook.formats[0].set_font_name('Bogle')
        self.workbook.formats[0].set_font_size(10)
        self.worksheet.hide_gridlines(2)
        self.worksheet.set_zoom(90)
        

        for i, col in enumerate(df.columns):
            width= max(df[col].astype(str).apply(lambda x: len(x)))
            width= max([width+2, len(str(col))+2])
            self.worksheet.set_column(i, i, width)
                        
        header_format = self.workbook.add_format(self.header_format_features)
        
        odd_row_format = self.workbook.add_format(self.odd_row_format_features)
        even_row_format = self.workbook.add_format(self.even_row_format_features)
        
        odd_row_percent_format = self.workbook.add_format(self.odd_row_format_percentage)
        even_row_percent_format = self.workbook.add_format(self.even_row_format_percentage)
        
        odd_row_decimal_format = self.workbook.add_format(self.odd_row_format_features_decimal)
        even_row_decimal_format = self.workbook.add_format(self.even_row_format_features_decimal)
        
        odd_row_decimal_5_format = self.workbook.add_format(self.odd_row_format_features_decimal_5)
        even_row_decimal_5_format = self.workbook.add_format(self.even_row_format_features_decimal_5)
        
        odd_row_scientific_format = self.workbook.add_format(self.odd_row_format_features_scientific)
        even_row_scientific_format = self.workbook.add_format(self.even_row_format_features_scientific)
        
        for col_num, value in enumerate(df.columns.values):
            self.worksheet.write(startrow, col_num, value, header_format)
            
            
        all_cols = [colnum_string(i) for i in range(1 ,df.shape[1]+1)]
        
        percent_cols = []
        for i in range(0 ,df.shape[1]):
            if df.columns.values[i] in percent_col_names:
                percent_cols.append(colnum_string(i+1))
        
        decimal_cols = []
        for i in range(0 ,df.shape[1]):
            if df.columns.values[i] in decimal_col_names:
                decimal_cols.append(colnum_string(i+1))
        
        decimal_5_cols = []
        for i in range(0 ,df.shape[1]):
            if df.columns.values[i] in decimal_5_col_names:
                decimal_5_cols.append(colnum_string(i+1))
                
        scientific_cols = []
        for i in range(0 ,df.shape[1]):
            if df.columns.values[i] in scientific_col_names:
                scientific_cols.append(colnum_string(i+1))

        for row in range(startrow + 2, startrow + df.shape[0]+2):
            for col in all_cols:
                if row%2==0:  
                    if col in percent_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': odd_row_percent_format})
                    elif col in decimal_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': odd_row_decimal_format})
            
                    elif col in decimal_5_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': odd_row_decimal_5_format})
            
                    elif col in scientific_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': odd_row_scientific_format})
            
                    else:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': odd_row_format})
                else: 
                    if col in percent_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': even_row_percent_format})
            
                    elif col in decimal_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': even_row_decimal_format})
                
                    elif col in decimal_5_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': even_row_decimal_5_format})
            
                    elif col in scientific_cols:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': even_row_scientific_format})
                    else:
                        self.worksheet.conditional_format(col + str(row), 
                                                          {'type': 'no_errors',
                                                           'format': even_row_format})
        
                
    def save_worksheet(self):
        self.writer.save()
    
    
def find_mape(df: pd.DataFrame, actual: str, predicted: str):
    
    """
    Finds MAPE 
    """
    perc_error = abs((df[predicted] / df[actual]) - 1)
    
    return perc_error.mean() * 100


def find_r_square(df: pd.DataFrame, actual: str, predicted: str):
    
    """
    Finds r_square
    """

    return r2_score(df[actual], df[predicted]) * 100


def get_worst_prediction(df: pd.DataFrame, actual: str, predicted: str, absolute_percentage_error: bool=False):
    
    """
    Gets the day with the worst prediction.
    absolute_percentage_error flag determines the worst: 
       - If false, worst means the error with the highest absolute value.
            worst = max(Actual - Predicted)
       - If true, worst means the percentage error with the highest absolute value.
            worst = max((Predicted-Actual)/Actual)
    r square sometimes can be negative when absolute percentage error is set True. That means the model, especially
    the validation and/or refresh period data, does not follow the trend of the data.
    
    """
    
    df_processed = df.copy()
    
    if absolute_percentage_error:
        df_processed['Worst Prediction'] = abs((df_processed[predicted] - df_processed[actual])/df_processed[actual])

    else:
        df_processed['Worst Prediction'] = abs(df_processed[actual] - df_processed[predicted])
        
    date_excluded = str(df_processed[df_processed['Worst Prediction'] == max(df_processed['Worst Prediction'])]['index'].iloc[0].date())
    
    return date_excluded
    
    
def calculate_reduced_metric(df: pd.DataFrame, actual: str, predicted: str, metric_function: callable, absolute_percentage_error: bool=False):
    
    """
    Calcuate the desired metric by removing the worst prediction. 
    "Worst" means residual with the highest absolute value.
    
    Returns reduced metric, the date that's removed and the reduced dataframe.
    
    """
    
    date_excluded = get_worst_prediction(df, actual, predicted, absolute_percentage_error)

    df_reduced = df[df['index'] != date_excluded]
    
    metric_reduced = metric_function(df_reduced, actual, predicted)
    
    return metric_reduced, date_excluded, df_reduced
    

def calculate_reduced_metric_for_worst_n(df: pd.DataFrame, actual: str, predicted: str, metric_function: Union[callable, list], period: Union[None, str], n: int = 5, absolute_percentage_error: bool=False):

    """
    Calculates metrics incrementally by removing the worst n predictions.
       
    """
    
    metric_dict = {'Removed Dates': [],
                   'R Square': [],
                   'MAPE': []}

    date_excluded_list = []

    ## Adding metrics for the whole dateframe
    metric_dict['Removed Dates'].append(['No date removed'])
    metric_dict['R Square'].append(find_r_square(df, actual , predicted))
    metric_dict['MAPE'].append(find_mape(df, actual , predicted))

    for i in range(n):
        
        r_square_reduced, date_excluded_1, df_reduced = calculate_reduced_metric(df, actual, predicted, metric_function[0], absolute_percentage_error)
        mape_reduced, date_excluded_2, df_reduced = calculate_reduced_metric(df, actual, predicted, metric_function[1], absolute_percentage_error)
        date_excluded_list.append(date_excluded_1)
        
        if date_excluded_1 != date_excluded_2:
            ## to-do: A more robust check
            raise ValueError('Dates must be equal')
        
        df = df_reduced.copy()
    
        metric_dict['Removed Dates'].append(date_excluded_list.copy())
        metric_dict['R Square'].append(r_square_reduced)
        metric_dict['MAPE'].append(mape_reduced)
    
    df_out = pd.DataFrame.from_dict(metric_dict)
    
    if absolute_percentage_error:
        df_out.rename(columns={'Removed Dates': 'Removed Dates w.r.t. MAPE Improvement ({} period)'.format(period)}, inplace=True)
    else:
        df_out.rename(columns={'Removed Dates': 'Removed Dates w.r.t. R Square Improvement ({} period)'.format(period)}, inplace=True)
        
    return df_out


def create_var_name_mapping(df, wamm_mapping):
    
    """
    
    Creates Display Level - Variable Name mapping.
    Display Level is same with Variable Description in Data Dictionary
    Variable Name is like in Data Dictionary or stack
    
    """
    
    var_name_mapping = defaultdict()
    
    for display_level in df['Display Level']:
        var = get_var_name(wamm_mapping, display_level)
        var_name_mapping[display_level] = var 
        
    return var_name_mapping


def get_var_name(wamm_mapping, display_level):
    
    """
    Retrives Variables Name, like Data Dictionary or stack, from Data Dictionary by using Display Level.
    Display Level is same with Variable Description in Data Dictionary
    
    """

    if display_level in ('Total Incremental', 'Base', 'Total'):
        var = display_level  
    else:
        wamm_mapping_filtered = wamm_mapping[wamm_mapping['Variable Description'] == display_level][['Variable Name', 'Variable Description']]
        var_list_all = [var for var in wamm_mapping_filtered['Variable Name'] if var.endswith('CLK') or var.endswith('IMP') or var.endswith('SPEND') or var.endswith('TRP') or var.endswith('GRP')]
        ## Remove view_imp. That list would have CLK, IMP, SPEND, TRP and/or GRP
        var_list = [var for var in var_list_all if 'view' not in var.lower()]
        ## Variable Name like in Data Dictionary, or stack
        var = list(set([var.rsplit('_', 1)[0] for var in var_list]))[0]


    return var


def get_WMC_contribution(model, start_date, end_date, previous_model_folder_name):
    
    folders_path = f"../models/{model}/"
    base_path = os.path.join(folders_path, previous_model_folder_name)
    sub_path = 'WMC_' + str(start_date) + '_' + str(end_date) + '.csv'
    file_path = os.path.join(base_path, sub_path)
    
    WMC_df_all_columns = pd.read_csv(file_path, thousands=',')
       
    if model == 'new_customer':
        iroas_column = 'Value NCoAS ($)'
    else:
        iroas_column = 'Value RoAS ($)'
        
    WMC_df = WMC_df_all_columns[['Display Level', 'Total Contribution', 'Total Sales ($)', 'Total Spend ($)', iroas_column]]    
    WMC_df['Time Range'] = get_time_range(start_date, end_date)
    WMC_df['Model'] = model
    

    return WMC_df


def combine_WMC_contribution(model, start_end_date_list, previous_model_folder_name):

    WMC_dfs = pd.DataFrame()
    
    for start_end_date in start_end_date_list:
        
        start_date = start_end_date[0]
        end_date = start_end_date[1]
        
        WMC_df = get_WMC_contribution(model, start_date, end_date, previous_model_folder_name)
        WMC_dfs = WMC_dfs.append(WMC_df)

    return WMC_dfs

def get_time_range(start_date_str, end_date_str):
    time_range_ls = []
    for date_str in [start_date_str, end_date_str]:
        date_time_obj = datetime.strptime(date_str, '%Y-%m-%d')
        month = date_time_obj.strftime("%b")
        year = date_time_obj.strftime("%y")
        res = "'".join([month, year])
        time_range_ls.append(res)
    time_range = " - ".join(time_range_ls)
    return time_range
