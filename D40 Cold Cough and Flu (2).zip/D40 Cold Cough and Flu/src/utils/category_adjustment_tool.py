#!/usr/bin/env python
# coding: utf-8
# author: Dhivyadarsan G M

import math
import numpy as np
import pandas as pd
import os
import pyomo.environ as pyo
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

# from lite_non_media_utils_nat_fit import *
from lite_non_media_utils_v3_Nat_Fit import *
# from gcs_utils import load_file_from_gcs, strip_gcs_prefix
import io
import re as _re
date_format = "%Y-%m-%d"


class WAMM_Adj_tool:

    def __init__(
            self,
            data,
            solution,
            config,
            onsite_iroas_bounds,
            offsite_iroas_bounds,
            search_iroas_bounds,
            overall_iroas_bounds,
            overall_iroas_bounds_yoy,
            onsite_iroas_bounds_yoy,
            offsite_iroas_bounds_yoy,
            search_iroas_bounds_yoy,
            onsite_iroas_bounds_l12,
            offsite_iroas_bounds_l12,
            search_iroas_bounds_l12,
            overall_iroas_bounds_l12,
            iroas_constraints,
            non_media_bounds,
            solution_iroas,
            tactic_lb=None,
            tactic_ub=None,
            optimize_l12=False,
            optimize_channel_yoy=False,
            optimize_scurve=False,
            fit_together=False,
            single_sol=False):

        self.data = data
        try:
            self.data['Date'] = pd.to_datetime(self.data['Date'], format='%Y-%m-%d')
        except:
            self.data['Date'] = pd.to_datetime(self.data['Date'], format='mixed')

        self.solution_df = solution
        self.config = config
        self.media_variables = config["media_variables_all"]
        self.non_media_variables = config["non_media_z_k"]
        self.non_media_details = config['non_media_coef']
        self.num_media_vars = len(self.media_variables)
        self.num_non_media_vars = len(self.non_media_variables)
        self.beta_nm = list(self.non_media_details.values())
        self.WMC_PORTFOLIO_DICT = config['wmc_portfolio_dict']
        self.mape_limit = config['mape_limit']
        self.rsq_limit = config['rsq_limit']
        self.optimize_l12 = optimize_l12
        self.optimize_channel_yoy = optimize_channel_yoy
        self.optimize_scurve = optimize_scurve
        self.fit_together = fit_together
        self.single_sol = single_sol
        self.solution_iroas = solution_iroas
        self.spend_vars = []
        self.tactic_lb = tactic_lb
        self.tactic_ub = tactic_ub

        for var in self.media_variables:
            if "_IMP" in var:
                spend_var = var.replace("_IMP", "_SPEND")
            else:
                spend_var = var.replace("_CLK", "_SPEND")
            self.spend_vars.append(spend_var)

        # self.Y_kj_all = np.asarray([[np.loadtxt(config["Y_kj_path"])]])[0][0]
        if config["Y_kj_path"].startswith("gs://"):
            # from gcs_utils import load_file_from_gcs, strip_gcs_prefix

            bucket_name = "category-wamm-model-outputs-stage"
            y_kj_gcs_path = strip_gcs_prefix(config["Y_kj_path"])

            # Load text file from GCS
            text_content = load_file_from_gcs(bucket_name, y_kj_gcs_path, file_type='txt')

            # Convert to numpy array
            self.Y_kj_all = np.asarray([[np.loadtxt(io.StringIO(text_content))]])[0][0]
        else:
            self.Y_kj_all = np.asarray([[np.loadtxt(config["Y_kj_path"])]])[0][0]

        if self.config["priors_info_path"].startswith("gs://"):
            bucket_name = "category-wamm-model-outputs-stage"
            updated_priors_path = self.config["priors_info_path"].replace("priors_info.csv", "priors_info_updated.csv")
            priors_gcs_path = strip_gcs_prefix(updated_priors_path)
            print(f"🔍 DEBUG - priors_gcs_path type: {type(priors_gcs_path)}")
            print(f"🔍 DEBUG - priors_gcs_path value: {priors_gcs_path}")
            # print(f"🔍 DEBUG - Contains %26: {'%26' in priors_gcs_path}")
            # print(f"🔍 DEBUG - Contains &: {'&' in priors_gcs_path}")
            self.priors = pd.read_csv(load_file_from_gcs(bucket_name, priors_gcs_path, file_type='csv'))
        else:
            # Replace priors_info.csv with priors_info_updated.csv for local path
            updated_priors_path = self.config["priors_info_path"].replace("priors_info.csv", "priors_info_updated.csv")
            self.priors = pd.read_csv(updated_priors_path)

        # self.priors_df = pd.read_csv(config["priors_info_path"][:-4]+"_updated.csv")
        self.priors_df = self.priors.copy()
        self.priors_df = self.priors_df.reset_index(drop=True)
        self.priors_df = self.priors_df.sort_values(by='media_variable')
        if self.single_sol:
            print(self.priors_df)

        if not iroas_constraints:
            self.iroas_lb = self.priors_df['iroas_lb_opt'].to_numpy()  # iroas_lb_opt
            self.iroas_ub = self.priors_df['iroas_ub_opt'].to_numpy()
        else:
            assert len(self.media_variables) == len(
                self.solution_iroas), "Provide iRoAS constraints for all media variables"
            self.iroas_lb = []
            self.iroas_ub = []
            for var in self.media_variables:
                var_iroas_prior = self.priors_df[self.priors_df['media_variable'] == var]['iroas_prior'].values[0]
                alpha_lb = self.tactic_lb
                alpha_ub = self.tactic_ub
                if var_iroas_prior < self.solution_iroas[var][0]:
                    self.iroas_lb.append(var_iroas_prior * alpha_lb)
                    self.iroas_ub.append(self.solution_iroas[var][0] * alpha_ub)
                elif var_iroas_prior > self.solution_iroas[var][0] and var_iroas_prior <= self.solution_iroas[var][1]:
                    self.iroas_lb.append(self.solution_iroas[var][0] * alpha_lb)
                    self.iroas_ub.append(self.solution_iroas[var][1] * alpha_ub)
                elif var_iroas_prior > self.solution_iroas[var][1] and var_iroas_prior <= self.solution_iroas[var][2]:
                    self.iroas_lb.append(self.solution_iroas[var][1] * alpha_lb)
                    self.iroas_ub.append(self.solution_iroas[var][2] * alpha_ub)
                elif var_iroas_prior >= self.solution_iroas[var][2]:
                    self.iroas_lb.append(self.solution_iroas[var][2] * alpha_lb)
                    self.iroas_ub.append(var_iroas_prior * alpha_ub)
                else:
                    self.iroas_lb.append(self.solution_iroas[var][0] * alpha_lb)
                    self.iroas_ub.append(self.solution_iroas[var][2] * alpha_ub)

                # print(var)
                # print(var_iroas_prior)
                # print(self.solution_iroas[var])
                # print(self.iroas_lb)
                # print(self.iroas_ub)

        self.iroas_prior = self.priors_df['iroas_prior'].to_numpy()
        self.coef_mean_prior = self.priors_df['coef_mean_prior'].to_numpy()
        self.train_spend = self.priors_df['train_spend'].to_numpy()
        self.train_price = self.priors_df['train_price'].to_numpy()

        self.train_start = config["train_start"]
        self.train_end = config["train_end"]
        self.valid_start = config["valid_start"]
        self.valid_end = config["valid_end"]

        self.st_dt = datetime.strptime(self.train_start, date_format)
        self.train_end_dt = datetime.strptime(self.train_end, date_format)
        self.test_st_dt = datetime.strptime(self.valid_start, date_format)
        self.test_end_dt = datetime.strptime(self.valid_end, date_format)
        self.train_end_index = (self.train_end_dt - self.st_dt).days + 1
        self.valid_start_index = (self.test_st_dt - self.st_dt).days
        self.valid_end_index = (self.test_end_dt - self.st_dt).days + 1
        self.l12_start_index = ((self.train_end_dt - relativedelta(months=12)) - self.st_dt).days + 1
        self.prev_year_start_index = ((self.train_end_dt - relativedelta(months=24)) - self.st_dt).days + 1
        self.prev_year_end_index = ((self.train_end_dt - relativedelta(months=12)) - self.st_dt).days + 1
        if self.prev_year_start_index < 0:
            self.prev_year_start_index = 0

        self.Y_kj = self.Y_kj_all[
                    :self.train_end_index
                    ]
        self.Y_kj_valid = self.Y_kj_all[
                          self.valid_start_index:self.valid_end_index
                          ]

        self.solution_df['media_transformation_string'] = self.solution_df[
            'Media_transformation (hf, inf, sc, lg)'].str.replace('[', '_')
        self.solution_df['media_transformation_string'] = self.solution_df['media_transformation_string'].str.replace(
            ',', '_')
        self.solution_df['media_transformation_string'] = self.solution_df['media_transformation_string'].str.replace(
            ']', '')
        self.solution_df['media_transformation_string'] = self.solution_df['media_transformation_string'].str.replace(
            ' ', '')

        self.solution_df["media_transformation_string"] = self.solution_df["media_transformation_string"].apply(
            lambda x: '_'.join([str(item) for item in x.split('_')[:]]))
        self.solution_df['variable_transformations'] = self.solution_df["Media_tactic"].astype(str) + self.solution_df[
            "media_transformation_string"]
        self.solution_df = self.solution_df.reset_index(drop=True)
        self.solution_df = self.solution_df.sort_values(by='Media_tactic')
        self.initial_coef = self.solution_df['Coefficient'].to_numpy()
        self.lambda_k_nm = np.zeros(self.num_non_media_vars)
        self.lambda_k_m = self.solution_df['Lambda_k'].to_numpy()

        self.lambda_k = np.concatenate((self.lambda_k_nm, self.lambda_k_m))

        self.filter_wmc_media()
        self.data_prep()

        self.onsite_iroas_bounds = onsite_iroas_bounds
        self.offsite_iroas_bounds = offsite_iroas_bounds
        self.search_iroas_bounds = search_iroas_bounds
        self.overall_iroas_bounds = overall_iroas_bounds
        self.overall_iroas_bounds_yoy = overall_iroas_bounds_yoy
        self.onsite_iroas_bounds_yoy = onsite_iroas_bounds_yoy
        self.offsite_iroas_bounds_yoy = offsite_iroas_bounds_yoy
        self.search_iroas_bounds_yoy = search_iroas_bounds_yoy

        self.onsite_iroas_bounds_l12 = onsite_iroas_bounds_l12
        self.offsite_iroas_bounds_l12 = offsite_iroas_bounds_l12
        self.search_iroas_bounds_l12 = search_iroas_bounds_l12
        self.overall_iroas_bounds_l12 = overall_iroas_bounds_l12
        self.non_media_bounds = non_media_bounds

    def data_prep(self):

        (self.df_transformed_new, self.scaling_factor_arr,
         self.hf_arr, self.inf_arr, self.sc_arr, self.lg_arr, self.thresh_arr, self.sat_arr, self.inf_point_arr,
         self.media_transformation_arr, self.thresh_sat_arr, self.days_beyon_sat_res, self.days_below_thresh_res,
         self.sat_acc_arr, self.thresh_acc_arr) = create_missing_media_transformations_new(self.data, self.solution_df[
            'variable_transformations'],
                                                                                           self.solution_df,
                                                                                           self.l12_start_index,
                                                                                           self.train_end_index,
                                                                                           self.optimize_scurve)
        # if self.single_sol:
        # self.df_transformed_new.to_csv("df_transformed_new.csv", index=False)
        self.updated_stack_brand = self.df_transformed_new
        self.updated_stack_brand['L0'] = 'l0'
        self.updated_stack_brand['L1'] = 'l1'
        self.updated_stack_brand['L2'] = 'l2'
        self.updated_stack_brand['STACK_TYPE'] = 'Modeling Stack'

        self.updated_stack_brand = self.updated_stack_brand[
            ['PRICE', 'Date', 'O_SALE', 'O_UNIT', 'STACK_TYPE', 'L0', 'L1', 'L2',
             'SBU'] + self.media_variables + self.non_media_variables + self.spend_vars]

        self.SST = np.sum(
            (self.updated_stack_brand['O_UNIT'] - np.mean(self.updated_stack_brand['O_UNIT']))
            ** 2
        )

        self.SST_train = np.sum(
            (self.updated_stack_brand['O_UNIT'][:self.train_end_index] - np.mean(
                self.updated_stack_brand['O_UNIT'][:self.train_end_index]))
            ** 2
        )

        self.SST_valid = np.sum(
            (self.updated_stack_brand['O_UNIT'][self.valid_start_index:self.valid_end_index] - np.mean(
                self.updated_stack_brand['O_UNIT'][self.valid_start_index:self.valid_end_index]))
            ** 2
        )

        self.non_media_data = np.asarray(self.updated_stack_brand[self.non_media_variables])

        self.transformed_var_actual = np.asarray(
            self.updated_stack_brand[self.media_variables].copy().astype("float64"))

        self.media_length = len(self.transformed_var_actual)

        self.transformed_media = np.zeros((self.num_media_vars, self.train_end_index))
        self.transformed_media_total = np.zeros((self.num_media_vars, self.media_length))
        self.X_tilde = np.zeros((self.num_media_vars, self.train_end_index))
        self.X_tilde_all = np.zeros((self.num_media_vars, self.media_length))
        self.X_tilde_valid = np.zeros((self.num_media_vars, self.valid_end_index - self.valid_start_index))

        for media_var_idx in range(self.num_media_vars):
            transformed_var = self.transformed_var_actual[
                              :, media_var_idx
                              ]
            self.transformed_media_total[media_var_idx] = np.asarray(transformed_var)
            self.transformed_media[media_var_idx] = np.asarray(transformed_var[:self.train_end_index])

            data_upd = self.non_media_data.astype(np.float64).copy()
            trans_med_tot = (
                self.transformed_media_total[media_var_idx].astype(np.float64).copy()
            )
            beta = (
                    np.linalg.inv(data_upd.T @ data_upd)
                    @ data_upd.T
                    @ trans_med_tot.T
            )
            fitted_values = data_upd @ beta

            self.X_tilde_all[media_var_idx] = trans_med_tot - fitted_values

        I = np.identity(self.num_non_media_vars + self.num_media_vars)
        for i in range(self.num_non_media_vars + self.num_media_vars):
            I[i][i] = self.lambda_k[i]

        days_lookback = 365
        self.start_idx_L12 = self.train_end_index - days_lookback
        self.end_idx_L12 = self.train_end_index
        self.X_tilde_L12 = self.X_tilde_all[:, self.start_idx_L12:self.end_idx_L12]

        self.X = np.concatenate((self.updated_stack_brand[self.non_media_variables].astype(np.float64).to_numpy(),
                                 self.transformed_var_actual.astype(np.float64)), axis=1).T
        self.Y = self.updated_stack_brand['O_UNIT'].astype(np.float64).to_numpy()

        self.X_train = self.X[:, :self.train_end_index]
        self.Y_train = self.Y[:self.train_end_index]

        self.X_train_L12 = self.X[:, self.start_idx_L12:self.end_idx_L12]
        self.Y_train_L12 = self.Y[self.start_idx_L12:self.end_idx_L12]

        self.X_valid = self.X[:, self.valid_start_index:self.valid_end_index]
        self.Y_valid = self.Y[self.valid_start_index:self.valid_end_index]

        self.scaled_prior_nm = np.zeros(self.num_non_media_vars)
        self.scaled_prior_m = self.coef_mean_prior * self.scaling_factor_arr
        self.scaled_prior = np.concatenate((self.scaled_prior_nm, self.scaled_prior_m))

        # val_2 = np.dot(
        #     self.X_train , self.X_train.transpose()
        # )

        # P_mkj = inv(I + val_2)

        # Q_mkj = np.dot(self.X_train, self.Y_train) + np.dot(
        #     I, self.scaled_prior
        # )

        # self.Beta_j = np.dot(P_mkj, Q_mkj)

        self.X_tilde = self.X_tilde_all[:, :self.train_end_index]
        self.X_tilde_valid = self.X_tilde_all[:, self.valid_start_index:self.valid_end_index]

        self.train_spend = np.asarray(self.updated_stack_brand[self.spend_vars][:self.train_end_index]).sum(axis=0)
        self.updated_stack_brand_valid = self.updated_stack_brand[self.valid_start_index:self.valid_end_index]
        self.updated_stack_brand = self.updated_stack_brand[:self.train_end_index]

        self.updated_stack_brand['Y_pred'] = 0

        # option 1

        self.X_train_nm = self.X_train[:self.num_non_media_vars, ]

        val_2 = np.linalg.pinv(self.X_train_nm @ self.X_train_nm.T)

        ####################################################################
        # Q_mkj = (self.X_train_nm
        #                 @ self.Y_train
        #                 )

        # self.beta_nm_fit = val_2 @ Q_mkj

        # self.model = sm.OLS(self.Y_train, self.X_train_nm, missing="drop")
        # self.model_result = self.model.fit()
        ####################################################################

        self.Y_train_resid = (self.Y_train - (self.initial_coef * self.transformed_media.T).sum(axis=1))
        Q_mkj = np.dot(self.X_train_nm, self.Y_train_resid)
        self.beta_nm_fit = np.dot(val_2, Q_mkj)

        self.updated_stack_brand['Y_pred'] += ((self.initial_coef * self.transformed_media.T).sum(axis=1))
        self.updated_stack_brand['Y_pred'] += ((self.beta_nm_fit * self.X_train_nm.T).sum(axis=1))

        # option 2
        # for i,j in self.non_media_details.items():
        #     self.updated_stack_brand['Y_pred'] += self.updated_stack_brand[i]*j
        # self.updated_stack_brand['Y_pred'] += ((self.initial_coef*self.X_tilde.T).sum(axis=1))

        # option 3
        #
        # self.updated_stack_brand['Y_pred'] += ((self.Beta_j*self.X_train.T).sum(axis=1))
        if self.single_sol:
            print('Model fit before Adjustment:')
            plot_fig_fit(self.updated_stack_brand, self.updated_stack_brand['O_UNIT'],
                         self.updated_stack_brand['Y_pred'])

        # if self.optimize_l12:

        self.transformed_media_l12 = self.transformed_media[:, self.l12_start_index:self.train_end_index]
        self.train_spend_l12 = np.asarray(
            self.updated_stack_brand[self.spend_vars][self.l12_start_index:self.train_end_index]).sum(axis=0)

        self.transformed_media_p12 = self.transformed_media[:, self.prev_year_start_index:self.prev_year_end_index]
        self.train_spend_p12 = np.asarray(
            self.updated_stack_brand[self.spend_vars][self.prev_year_start_index:self.prev_year_end_index]).sum(axis=0)

        self.SST_train_L12 = np.sum(
            (self.updated_stack_brand['O_UNIT'][self.start_idx_L12:self.end_idx_L12] - np.mean(
                self.updated_stack_brand['O_UNIT'][self.start_idx_L12:self.end_idx_L12]))
            ** 2
        )

    def filter_wmc_media(self):

        self.on_wmc_idx = []
        self.off_wmc_idx = []
        self.search_wmc_idx = []
        self.wmt_idx = []

        for i, var in enumerate(self.media_variables):
            if (
                    var.startswith("M_ON_DIS")
            ):
                self.on_wmc_idx.append(i)
            elif (var.startswith("M_OFF_DIS")):
                self.off_wmc_idx.append(i)
            elif (var.startswith("M_SP")
                  or var.startswith("M_SBA")  ## was missing
                  or var.startswith("M_SV")):
                self.search_wmc_idx.append(i)
            else:

                self.wmt_idx.append(i)

        self.on_wmc_idx = np.asarray(self.on_wmc_idx)
        self.off_wmc_idx = np.asarray(self.off_wmc_idx)
        self.search_wmc_idx = np.asarray(self.search_wmc_idx)
        self.wmt_idx = np.asarray(self.wmt_idx)
        # print(f"All Media variables : {media_variables}")
        # print(f"Onsite WMC indices: {on_wmc_idx}")
        # print(f"Offsite WMC indices: {off_wmc_idx}")
        # print(f"Search WMC indices: {search_wmc_idx}")
        # print(f"WMT indices: {wmt_idx}"
        # )  ## was showing wmc variables itself

    def run_optimizer(self):

        def fb(model, i):

            # if sum(self.transformed_media[i]) != 0:

            bounds = (self.iroas_lb[i] * self.train_spend[i] / (self.transformed_media[i].sum() * self.train_price[i]),
                      self.iroas_ub[i] * self.train_spend[i] / (self.transformed_media[i].sum() * self.train_price[i]))
            # else:
            #     bounds =  (0,
            #             None)
            return bounds

        def intial_sol(model, i):

            return self.iroas_lb[i] * self.train_spend[i] / (self.transformed_media[i].sum() * self.train_price[i])
            # return initial_coef[i]

        def ObjRule(model):

            return sum((sum(((model.beta_onsite[i] * self.transformed_media[i].sum() * self.train_price[i] /
                              self.train_spend[i]) - self.iroas_prior[i]) ** 2 for i in model.onsite_wmc),
                        sum(((model.beta_offsite[i] * self.transformed_media[i].sum() * self.train_price[i] /
                              self.train_spend[i]) - self.iroas_prior[i]) ** 2 for i in model.offsite_wmc),
                        sum(((model.beta_search[i] * self.transformed_media[i].sum() * self.train_price[i] /
                              self.train_spend[i]) - self.iroas_prior[i]) ** 2 for i in model.search_wmc),
                        sum(((model.beta_wmt[i] * self.transformed_media[i].sum() * self.train_price[i] /
                              self.train_spend[i]) - self.iroas_prior[i]) ** 2 for i in model.wmt)))

        def abs_Rule(model, j):
            Beta = [0] * self.num_media_vars
            Beta_nm = [0] * self.num_non_media_vars

            for i in model.onsite_wmc:
                Beta[i] = model.beta_onsite[i]
            for i in model.offsite_wmc:
                Beta[i] = model.beta_offsite[i]
            for i in model.search_wmc:
                Beta[i] = model.beta_search[i]
            for i in model.wmt:
                Beta[i] = model.beta_wmt[i]

            if self.fit_together:

                for i in model.alpha_nm:
                    Beta_nm[i] = self.beta_nm_fit[i] * (1 + model.alpha_nm_var[i])

                Beta_1 = (Beta_nm + Beta)

            else:

                Beta_1 = np.concatenate((self.beta_nm_fit, np.asarray(Beta)))
                # print("1st instance")
                # print(Beta)
            return np.abs((self.Y_train[j] - np.dot(Beta_1, self.X_train)[j])) * 100 == (model.u1_var[j]) * \
                self.updated_stack_brand['O_UNIT'][j]
            # return (self.Y_kj[j]- np.dot(Beta, self.X_tilde)[j]) * 100 == (model.u1_var[j] - model.u2_var[j]) * self.updated_stack_brand['O_UNIT'][j]

        def abs_Rule_l12(model, k):
            Beta = [0] * self.num_media_vars
            Beta_nm = [0] * self.num_non_media_vars

            for i in model.onsite_wmc:
                Beta[i] = model.beta_onsite[i]
            for i in model.offsite_wmc:
                Beta[i] = model.beta_offsite[i]
            for i in model.search_wmc:
                Beta[i] = model.beta_search[i]
            for i in model.wmt:
                Beta[i] = model.beta_wmt[i]

            latest_stack_unit = self.updated_stack_brand.iloc[self.start_idx_L12:self.end_idx_L12].reset_index(
                drop=True)

            if self.fit_together:

                for i in model.alpha_nm:
                    Beta_nm[i] = self.beta_nm_fit[i] * (1 + model.alpha_nm_var[i])
                Beta_2 = (Beta_nm + Beta)

            else:

                Beta_2 = np.concatenate((self.beta_nm_fit, np.asarray(Beta)))
                # print("1st instance")
                # print(Beta)

            return np.abs((self.Y_train_L12[k] - np.dot(Beta_2, self.X_train_L12)[k])) * 100 == (model.u2_var[k]) * \
                latest_stack_unit['O_UNIT'][k]

        # def zero_Rule(model, j):
        #     return (model.u1_var[j]*model.u2_var[j]) == 0

        def mape_Rule(model):
            return sum(model.u1_var[i] for i in model.u1) <= self.mape_limit * len(model.u1)

        def mape_Rule_l12(model):
            return sum(model.u2_var[i] for i in model.u2) <= self.mape_limit * len(model.u2)

        def r2Rule(model):
            Beta = [0] * self.num_media_vars
            Beta_nm = [0] * self.num_non_media_vars

            for i in model.onsite_wmc:
                Beta[i] = model.beta_onsite[i]
            for i in model.offsite_wmc:
                Beta[i] = model.beta_offsite[i]
            for i in model.search_wmc:
                Beta[i] = model.beta_search[i]
            for i in model.wmt:
                Beta[i] = model.beta_wmt[i]

            # return (0.05,np.sum((Y_kj- np.dot(Beta, X_tilde))**2)/SST
            #                 ,0.25)
            if self.fit_together:
                for i in model.alpha_nm:
                    Beta_nm[i] = self.beta_nm_fit[i] * (1 + model.alpha_nm_var[i])
                Beta = (Beta_nm + Beta)

            else:
                Beta = np.concatenate((self.beta_nm_fit, np.asarray(Beta)))
                # print("2")
                # print(Beta)

            return sum((self.Y_train - np.dot(Beta, self.X_train)) ** 2) <= (1 - self.rsq_limit) * self.SST

            # return sum((self.Y_kj- np.dot(Beta, self.X_tilde))**2) <=(1 - self.rsq_limit)*self.SST

        def onsiteRule_l12(model):
            onsite_spend = sum(self.train_spend_l12[i] for i in model.onsite_wmc)
            if onsite_spend <= 0:                       # NEW 5.25
                print("Warning: Cannot apply L12m onsite iROAS constraint. Non-positive L12m onsite Spend")     # NEW 5.25
                return pyo.Constraint.Skip              # NEW 5.25
            onsite_iroas = sum(model.beta_onsite[i] * self.transformed_media_l12[i].sum() * self.train_price[i] for i in
                               model.onsite_wmc) / onsite_spend
            return (self.onsite_iroas_bounds_l12[0], onsite_iroas, self.onsite_iroas_bounds_l12[1])

        def offsiteRule_l12(model):
            offsite_spend = sum(self.train_spend_l12[i] for i in model.offsite_wmc)
            if offsite_spend <= 0:                       # NEW 5.25
                print("Warning: Cannot apply L12m offsite iROAS constraint. Non-positive L12m offsite Spend")     # NEW 5.25
                return pyo.Constraint.Skip              # NEW 5.25
            offsite_iroas = sum(
                model.beta_offsite[i] * self.transformed_media_l12[i].sum() * self.train_price[i] for i in
                model.offsite_wmc) / offsite_spend
            return (self.offsite_iroas_bounds_l12[0], offsite_iroas, self.offsite_iroas_bounds_l12[1])

        def searchRule_l12(model):
            search_spend = sum(self.train_spend_l12[i] for i in model.search_wmc)
            if search_spend <= 0:                       # NEW 5.25
                print("Warning: Cannot apply L12m search iROAS constraint. Non-positive L12m search Spend")     # NEW 5.25
                return pyo.Constraint.Skip               # NEW 5.25
            search_iroas = sum(model.beta_search[i] * self.transformed_media_l12[i].sum() * self.train_price[i] for i in
                               model.search_wmc) / search_spend
            return (self.search_iroas_bounds_l12[0], search_iroas, self.search_iroas_bounds_l12[1])

        def overallRule_l12(model):

            overall_contri = sum((sum(
                model.beta_onsite[i] * self.transformed_media_l12[i].sum() * self.train_price[i] for i in
                model.onsite_wmc),
                                  sum(model.beta_offsite[i] * self.transformed_media_l12[i].sum() * self.train_price[i]
                                      for i in model.offsite_wmc),
                                  sum(model.beta_search[i] * self.transformed_media_l12[i].sum() * self.train_price[i]
                                      for i in model.search_wmc)))

            overall_spend = sum((sum(self.train_spend_l12[i] for i in model.onsite_wmc),
                                 sum(self.train_spend_l12[i] for i in model.offsite_wmc),
                                 sum(self.train_spend_l12[i] for i in model.search_wmc)))

            overall_iroas = overall_contri / overall_spend
            return (self.overall_iroas_bounds_l12[0], overall_iroas, self.overall_iroas_bounds_l12[1])

        def onsiteRule(model):
            onsite_spend = sum(self.train_spend[i] for i in model.onsite_wmc)

            if onsite_spend <= 0:                       # NEW 5.25
                print("Warning: Cannot apply onsite iROAS constraint. Non-positive onsite Spend")     # NEW 5.25
                return pyo.Constraint.Skip              # NEW 5.25
            
            onsite_iroas = sum(model.beta_onsite[i] * self.transformed_media[i].sum() * self.train_price[i] for i in
                               model.onsite_wmc) / onsite_spend
            return (self.onsite_iroas_bounds[0], onsite_iroas, self.onsite_iroas_bounds[1])

        def offsiteRule(model):
            offsite_spend = sum(self.train_spend[i] for i in model.offsite_wmc)

            if offsite_spend <= 0:                      # NEW 5.25
                print("Warning: Cannot apply offsite iROAS constraint. Non-positive offsite Spend")   # NEW 5.25
                return pyo.Constraint.Skip              # NEW 5.25
            
            offsite_iroas = sum(model.beta_offsite[i] * self.transformed_media[i].sum() * self.train_price[i] for i in
                                model.offsite_wmc) / offsite_spend
            return (self.offsite_iroas_bounds[0], offsite_iroas, self.offsite_iroas_bounds[1])

        def searchRule(model):
            search_spend = sum(self.train_spend[i] for i in model.search_wmc)

            if search_spend <= 0:                       # NEW 5.25
                print("Warning: Cannot apply search iROAS constraint. Non-positive search Spend")    # NEW 5.25
                return pyo.Constraint.Skip              # NEW 5.25
        
            search_iroas = sum(model.beta_search[i] * self.transformed_media[i].sum() * self.train_price[i] for i in
                               model.search_wmc) / search_spend
            return (self.search_iroas_bounds[0], search_iroas, self.search_iroas_bounds[1])

        def overallRule(model):

            overall_contri = sum((sum(
                model.beta_onsite[i] * self.transformed_media[i].sum() * self.train_price[i] for i in model.onsite_wmc),
                                  sum(model.beta_offsite[i] * self.transformed_media[i].sum() * self.train_price[i] for
                                      i in model.offsite_wmc),
                                  sum(model.beta_search[i] * self.transformed_media[i].sum() * self.train_price[i] for i
                                      in model.search_wmc)))

            overall_spend = sum((sum(self.train_spend[i] for i in model.onsite_wmc),
                                 sum(self.train_spend[i] for i in model.offsite_wmc),
                                 sum(self.train_spend[i] for i in model.search_wmc)))

            overall_iroas = overall_contri / overall_spend
            return (self.overall_iroas_bounds[0], overall_iroas, self.overall_iroas_bounds[1])

        def overallYoYRule(model):

            overall_contri_p12 = sum((sum(
                model.beta_onsite[i] * self.transformed_media_p12[i].sum() * self.train_price[i] for i in
                model.onsite_wmc),
                                      sum(model.beta_offsite[i] * self.transformed_media_p12[i].sum() *
                                          self.train_price[i] for i in model.offsite_wmc),
                                      sum(model.beta_search[i] * self.transformed_media_p12[i].sum() * self.train_price[
                                          i] for i in model.search_wmc)))

            overall_spend_p12 = sum((sum(self.train_spend_p12[i] for i in model.onsite_wmc),
                                     sum(self.train_spend_p12[i] for i in model.offsite_wmc),
                                     sum(self.train_spend_p12[i] for i in model.search_wmc)))

            overall_iroas_p12 = overall_contri_p12 / overall_spend_p12

            overall_contril12 = sum((sum(
                model.beta_onsite[i] * self.transformed_media_l12[i].sum() * self.train_price[i] for i in
                model.onsite_wmc),
                                     sum(model.beta_offsite[i] * self.transformed_media_l12[i].sum() * self.train_price[
                                         i] for i in model.offsite_wmc),
                                     sum(model.beta_search[i] * self.transformed_media_l12[i].sum() * self.train_price[
                                         i] for i in model.search_wmc)))

            overall_spendl12 = sum((sum(self.train_spend_l12[i] for i in model.onsite_wmc),
                                    sum(self.train_spend_l12[i] for i in model.offsite_wmc),
                                    sum(self.train_spend_l12[i] for i in model.search_wmc)))

            overall_iroas_l12 = overall_contril12 / overall_spendl12
            overall_YoY_perc = (overall_iroas_p12 - overall_iroas_l12) / overall_iroas_l12
            return (self.overall_iroas_bounds_yoy[0], overall_YoY_perc, self.overall_iroas_bounds_yoy[1])

        def onsiteYoYRule(model):

            onsite_contri_p12 = sum(
                model.beta_onsite[i] * self.transformed_media_p12[i].sum() * self.train_price[i] for i in
                model.onsite_wmc)
            onsite_spend_p12 = (sum(self.train_spend[i] for i in model.onsite_wmc))
            onsite_iroas_p12 = onsite_contri_p12 / onsite_spend_p12

            onsite_contril12 = sum(
                model.beta_onsite[i] * self.transformed_media_l12[i].sum() * self.train_price[i] for i in
                model.onsite_wmc)
            onsite_spendl12 = sum(self.train_spend_l12[i] for i in model.onsite_wmc)
            onsite_iroas_l12 = onsite_contril12 / onsite_spendl12
            onsite_YoY_perc = (onsite_iroas_p12 - onsite_iroas_l12) / onsite_iroas_l12

            return (self.onsite_iroas_bounds_yoy[0], onsite_YoY_perc, self.onsite_iroas_bounds_yoy[1])

        def offsiteYoYRule(model):

            offsite_contri_p12 = sum(
                model.beta_offsite[i] * self.transformed_media_p12[i].sum() * self.train_price[i] for i in
                model.offsite_wmc)
            offsite_spend_p12 = (sum(self.train_spend[i] for i in model.offsite_wmc))
            offsite_iroas_p12 = offsite_contri_p12 / offsite_spend_p12
            offsite_contril12 = sum(
                model.beta_offsite[i] * self.transformed_media_l12[i].sum() * self.train_price[i] for i in
                model.offsite_wmc)

            offsite_spendl12 = sum(self.train_spend_l12[i] for i in model.offsite_wmc)
            offsite_iroas_l12 = offsite_contril12 / offsite_spendl12
            offsite_YoY_perc = (offsite_iroas_p12 - offsite_iroas_l12) / offsite_iroas_l12

            return (self.offsite_iroas_bounds_yoy[0], offsite_YoY_perc, self.offsite_iroas_bounds_yoy[1])

        def searchYoYRule(model):

            search_contri_p12 = sum(
                model.beta_search[i] * self.transformed_media_p12[i].sum() * self.train_price[i] for i in
                model.search_wmc)
            search_spend_p12 = (sum(self.train_spend[i] for i in model.search_wmc))
            search_iroas_p12 = search_contri_p12 / search_spend_p12
            search_contril12 = sum(
                model.beta_search[i] * self.transformed_media_l12[i].sum() * self.train_price[i] for i in
                model.search_wmc)

            search_spendl12 = sum(self.train_spend_l12[i] for i in model.search_wmc)
            search_iroas_l12 = search_contril12 / search_spendl12
            search_YoY_perc = (search_iroas_p12 - search_iroas_l12) / search_iroas_l12

            return (self.search_iroas_bounds_yoy[0], search_YoY_perc, self.search_iroas_bounds_yoy[1])

        import shutil as _shutil
        _ipopt_exec = _shutil.which('ipopt') or '/usr/local/bin/ipopt'
        solver = pyo.SolverFactory('ipopt', executable=_ipopt_exec)
        solver.options['max_iter'] = 10000

        self.model = pyo.ConcreteModel()
        self.model.onsite_wmc = pyo.Set(initialize=self.on_wmc_idx)
        self.model.offsite_wmc = pyo.Set(initialize=self.off_wmc_idx)
        self.model.search_wmc = pyo.Set(initialize=self.search_wmc_idx)
        self.model.wmt = pyo.Set(initialize=self.wmt_idx)

        self.model.u1 = pyo.Set(initialize=range(self.X_tilde.shape[1]))
        self.model.u2 = pyo.Set(initialize=range(self.X_tilde_L12.shape[1]))
        # print(f'u2 : {len(self.model.u2)}')
        # print(f'X_tilde_L12 : {(self.X_tilde_L12.shape[1])}')
        # print(f'X_train : {(self.X_train.shape[1])}')
        # print(len(self.updated_stack_brand['O_UNIT'].iloc[self.start_idx_L12:self.end_idx_L12]))
        # print(f'u1 : {len(self.model.u1)}')

        if self.fit_together:
            self.model.alpha_nm = pyo.Set(initialize=range(self.num_non_media_vars))

        self.model.beta_onsite = pyo.Var(self.model.onsite_wmc, domain=pyo.NonNegativeReals, bounds=fb,
                                         initialize=intial_sol)
        self.model.beta_offsite = pyo.Var(self.model.offsite_wmc, domain=pyo.NonNegativeReals, bounds=fb,
                                          initialize=intial_sol)
        self.model.beta_search = pyo.Var(self.model.search_wmc, domain=pyo.NonNegativeReals, bounds=fb,
                                         initialize=intial_sol)
        self.model.beta_wmt = pyo.Var(self.model.wmt, domain=pyo.NonNegativeReals, bounds=fb, initialize=intial_sol)
        self.model.u1_var = pyo.Var(self.model.u1, domain=pyo.NonNegativeReals, initialize=0)
        self.model.u2_var = pyo.Var(self.model.u2, domain=pyo.NonNegativeReals, initialize=0)

        if self.fit_together:
            self.model.alpha_nm_var = pyo.Var(self.model.alpha_nm, domain=pyo.Reals,
                                              bounds=(self.non_media_bounds[0], self.non_media_bounds[1]), initialize=0)

        self.model.obj = pyo.Objective(rule=ObjRule)

        self.model.onsite_cons = pyo.Constraint(rule=onsiteRule)
        self.model.offsite_cons = pyo.Constraint(rule=offsiteRule)
        self.model.search_cons = pyo.Constraint(rule=searchRule)
        self.model.overall_cons = pyo.Constraint(rule=overallRule)
        self.model.overall_cons_yoy = pyo.Constraint(rule=overallYoYRule)

        if self.optimize_l12:
            self.model.onsite_cons_l12 = pyo.Constraint(rule=onsiteRule_l12)
            self.model.offsite_cons_l12 = pyo.Constraint(rule=offsiteRule_l12)
            self.model.search_cons_l12 = pyo.Constraint(rule=searchRule_l12)
            self.model.overall_cons_l12 = pyo.Constraint(rule=overallRule_l12)

        if self.optimize_channel_yoy:
            self.model.onsite_cons_l12 = pyo.Constraint(rule=onsiteYoYRule)
            self.model.offsite_cons_l12 = pyo.Constraint(rule=offsiteYoYRule)
            self.model.search_cons_l12 = pyo.Constraint(rule=searchYoYRule)

        self.model.r2_cons = pyo.Constraint(rule=r2Rule)
        self.model.abs_cons = pyo.Constraint(self.model.u1, rule=abs_Rule)
        self.model.mape_cons = pyo.Constraint(rule=mape_Rule)

        self.model.abs_cons_l12 = pyo.Constraint(self.model.u2, rule=abs_Rule_l12)
        self.model.mape_cons_l12 = pyo.Constraint(rule=mape_Rule_l12)

        # self.model.zero_cons =  pyo.Constraint(self.model.u1, rule=zero_Rule)
        # self.model.pprint()
        # solver.config.stream_solver = False

        # self.result = solver.solve(self.model, tee=True)   
        self.result = solver.solve(self.model, tee=False)                                                           # NEW 4.24 +
                                                    

        # Display results
        if self.single_sol:
            print('Status:', self.result.solver.status)
            print('Termination Condition:', self.result.solver.termination_condition)
            print('Optimal Objective:', pyo.value(self.model.obj))

        solver.options['print_level'] = 12
        solver.options['output_file'] = "/home/your_user/my_ipopt_log.txt"

        # acceptable_conditions = ['optimal', 'locallyOptimal', 'feasible', 'other']
        # acceptable_conditions = ['optimal', 'locallyOptimal', 'feasible', 'other']                        # NEW 4.6 -
        acceptable_conditions = ['optimal']                                                                 # NEW 4.6 +

        if self.result.solver.termination_condition in acceptable_conditions:
            print(f"✓ Accepted termination condition: {self.result.solver.termination_condition}")
            print(f"✓ Solver status: {self.result.solver.status}")                                        
            sol_data = self.display_result()
        else:
            print(f"✗ Rejected termination condition: {self.result.solver.termination_condition}")
            print(f"✗ Solver status: {self.result.solver.status}")
            sol_data = pd.DataFrame()

            if self.single_sol:
                print('Problem Infeasible/Max Iterations have been reached')
                print(
                    'Please re-run by changing iroas/non-media bounds or rsq_limit or mape_limit and by setting optimize_l12 flag as False')

        return sol_data

    def display_result(self):

        Beta = [0] * self.num_media_vars
        Beta_nm = [0] * self.num_non_media_vars

        for i in self.model.onsite_wmc:
            Beta[i] = self.model.beta_onsite[i].value
        for i in self.model.offsite_wmc:
            Beta[i] = self.model.beta_offsite[i].value
        for i in self.model.search_wmc:
            Beta[i] = self.model.beta_search[i].value
        for i in self.model.wmt:
            Beta[i] = self.model.beta_wmt[i].value

        if self.fit_together:
            for i in self.model.alpha_nm:
                Beta_nm[i] = self.beta_nm_fit[i] * (1 + self.model.alpha_nm_var[i].value)
            self.Beta_all = np.asarray((Beta_nm + Beta))

        else:
            self.Beta_all = np.concatenate((self.beta_nm_fit, np.asarray(Beta)))
        self.Beta = np.asarray(Beta)

        self.Train_R_Square_new = (
                1 - (np.sum((self.Y_train - np.dot(self.Beta_all, self.X_train)) ** 2) / self.SST_train))
        self.Train_Mape_new = ((np.abs(self.Y_train - np.dot(self.Beta_all, self.X_train)) / self.updated_stack_brand[
            'O_UNIT']) * 100).mean()
        self.Valid_R_Square_new = (
                1 - (np.sum((self.Y_valid - np.dot(self.Beta_all, self.X_valid)) ** 2) / self.SST_valid))
        self.Valid_Mape_new = ((np.abs(self.Y_valid - np.dot(self.Beta_all, self.X_valid)) /
                                self.updated_stack_brand_valid['O_UNIT']) * 100).mean()
        self.Valid_R_Square_new_L12 = (1 - (
                np.sum((self.Y_train_L12 - np.dot(self.Beta_all, self.X_train_L12)) ** 2) / self.SST_train_L12))
        self.Valid_Mape_new_L12 = ((np.abs(self.Y_train_L12 - np.dot(self.Beta_all, self.X_train_L12)) /
                                    self.updated_stack_brand.iloc[self.start_idx_L12:self.end_idx_L12][
                                        'O_UNIT']) * 100).mean()

        if self.single_sol:

            for key, value in self.WMC_PORTFOLIO_DICT.items():
                start_date = value["start_date"]
                end_date = value["end_date"]
                period = value["Period"]

                print(f'Summary Statistics for {key} : {period}:')

                start_index = self.data[self.data['Date'] == start_date].index[0]
                end_index = self.data[self.data['Date'] == end_date].index[0] + 1

                self.transformed_media = self.transformed_media_total[:, start_index:end_index]
                self.train_spend = np.asarray(self.data[self.spend_vars][start_index:end_index]).sum(axis=0)

                search_spend = sum(self.train_spend[i] for i in self.model.search_wmc)
                search_iroas_old = sum(
                    self.initial_coef[i] * self.transformed_media[i].sum() * self.train_price[i] for i in
                    self.model.search_wmc) / search_spend
                search_iroas_new = sum(self.Beta[i] * self.transformed_media[i].sum() * self.train_price[i] for i in
                                       self.model.search_wmc) / search_spend

                offsite_spend = sum(self.train_spend[i] for i in self.model.offsite_wmc)
                offsite_iroas_old = sum(
                    self.initial_coef[i] * self.transformed_media[i].sum() * self.train_price[i] for i in
                    self.model.offsite_wmc) / offsite_spend
                offsite_iroas_new = sum(self.Beta[i] * self.transformed_media[i].sum() * self.train_price[i] for i in
                                        self.model.offsite_wmc) / offsite_spend

                onsite_spend = sum(self.train_spend[i] for i in self.model.onsite_wmc)
                onsite_iroas_old = sum(
                    self.initial_coef[i] * self.transformed_media[i].sum() * self.train_price[i] for i in
                    self.model.onsite_wmc) / onsite_spend
                onsite_iroas_new = sum(self.Beta[i] * self.transformed_media[i].sum() * self.train_price[i] for i in
                                       self.model.onsite_wmc) / onsite_spend

                result_data = {"Media_tactic": self.media_variables,
                               "Coefficient_new": self.Beta,
                               "Coefficient_old": self.initial_coef,
                               "Total Contribution_new": (self.Beta * self.transformed_media.sum(axis=1)),
                               "Total Sales_new": (self.Beta * self.transformed_media.sum(axis=1) * self.train_price),
                               "Total Spend": self.train_spend,
                               "Tactic_iRoAS_new": np.round((self.Beta * self.transformed_media.sum(
                                   axis=1) * self.train_price / self.train_spend), decimals=6),
                               "Tactic_iRoAS_old": (self.initial_coef * self.transformed_media.sum(
                                   axis=1) * self.train_price / self.train_spend),
                               "Tactic_iRoAS_priors": self.iroas_prior,
                               "Overall_iRoAS_new": sum(
                                   (self.Beta * self.transformed_media.sum(axis=1) * self.train_price)[
                                   :self.num_media_vars - len(self.model.wmt), ]) / sum(
                                   self.train_spend[:self.num_media_vars - len(self.model.wmt)]),
                               "Overall_iRoAS_old": sum(
                                   (self.initial_coef * self.transformed_media.sum(axis=1) * self.train_price)[
                                   :self.num_media_vars - len(self.model.wmt), ]) / sum(
                                   self.train_spend[:self.num_media_vars - len(self.model.wmt)]),
                               "Train_R_Square_new": self.Train_R_Square_new,
                               "Train_R_Square_old": self.solution_df['Train_R_Square'],
                               "Train_Mape_new": self.Train_Mape_new,
                               "Train_Mape_old": self.solution_df['Train_Mape'],
                               "Validation_R_Square_new": self.Valid_R_Square_new,
                               "Validation_R_Square_old": self.solution_df['Validation_R_Square'],
                               "Validation_Mape_new": self.Valid_Mape_new,
                               "Validation_Mape_old": self.solution_df['Validation_Mape'],
                               "L12_Mape": self.Valid_Mape_new_L12,
                               "L12_R_Square": self.Valid_R_Square_new_L12
                               }

                result_data_channel = {"Channel": ["Onsite", "Offsite", "Search"],
                                       "iRoAS_new": [onsite_iroas_new, offsite_iroas_new, search_iroas_new],
                                       "iRoAS_old": [onsite_iroas_old, offsite_iroas_old, search_iroas_old]}

                results = pd.DataFrame.from_dict(result_data)
                results_channel = pd.DataFrame.from_dict(result_data_channel)
                print(results)
                print(results_channel)
                ###### Print WMC Outputs #######

                self.data['Date'] = pd.to_datetime(self.data['Date'])
                raw_media_data = self.data[(self.data['Date'] >= start_date) & (self.data['Date'] <= end_date)][
                    self.media_variables].copy()
                raw_units = self.data[(self.data['Date'] >= start_date) & (self.data['Date'] <= end_date)][
                    ['O_SALE', 'O_UNIT']].copy()

                wmc_result_data = {
                    "Display Level": self.media_variables,
                    "Total Contribution": (self.Beta * self.transformed_media.sum(axis=1)),
                    "Total Sales ($)": (self.Beta * self.transformed_media.sum(axis=1) * self.train_price),
                    "Total Spend ($)": self.train_spend,
                    "Raw Media": raw_media_data.sum(axis=0),
                    "Volume RoAS": (self.Beta * self.transformed_media.sum(axis=1) / self.train_spend),
                    "Value RoAS ($)": (
                            self.Beta * self.transformed_media.sum(axis=1) * self.train_price / self.train_spend)
                }

                wmc_result_data_df = pd.DataFrame.from_dict(wmc_result_data)

                wmc_result_data_df['Contribution Share(%)'] = wmc_result_data_df['Total Contribution'] / \
                                                              wmc_result_data_df['Total Contribution'].sum()
                wmc_result_data_df['Spend Share(%)'] = wmc_result_data_df['Total Spend ($)'] / wmc_result_data_df[
                    'Total Spend ($)'].sum()
                wmc_result_data_df['Raw Media Share(%)'] = wmc_result_data_df['Raw Media'] / wmc_result_data_df[
                    'Raw Media'].sum()

                total_incremental = {"Display Level": "Total Incremental",
                                     "Total Contribution": wmc_result_data_df['Total Contribution'].sum(),
                                     "Total Sales ($)": wmc_result_data_df['Total Sales ($)'].sum(),
                                     "Total Spend ($)": wmc_result_data_df['Total Spend ($)'].sum(),
                                     "Raw Media": wmc_result_data_df['Raw Media'].sum(),
                                     "Volume RoAS": wmc_result_data_df['Total Contribution'].sum() / wmc_result_data_df[
                                         'Total Spend ($)'].sum(),
                                     "Value RoAS ($)": wmc_result_data_df['Total Sales ($)'].sum() / wmc_result_data_df[
                                         'Total Spend ($)'].sum(),
                                     "Contribution Share(%)": wmc_result_data_df['Total Contribution'].sum() /
                                                              raw_units['O_UNIT'].sum(),
                                     "Spend Share(%)": 100,
                                     "Raw Media Share(%)": 100}

                base = {"Display Level": "Base",
                        "Total Contribution": raw_units['O_UNIT'].sum() - wmc_result_data_df[
                            'Total Contribution'].sum(),
                        "Total Sales ($)": raw_units['O_SALE'].sum() - wmc_result_data_df['Total Sales ($)'].sum(),
                        "Total Spend ($)": 0,
                        "Raw Media": 0,
                        "Volume RoAS": 0,
                        "Value RoAS ($)": 0,
                        "Contribution Share(%)": 1 - (
                                wmc_result_data_df['Total Contribution'].sum() / raw_units['O_UNIT'].sum()),
                        "Spend Share(%)": 0,
                        "Raw Media Share(%)": 0}

                total = {"Display Level": "Total",
                         "Total Contribution": raw_units['O_UNIT'].sum(),
                         "Total Sales ($)": raw_units['O_SALE'].sum(),
                         "Total Spend ($)": wmc_result_data_df['Total Spend ($)'].sum(),
                         "Raw Media": wmc_result_data_df['Raw Media'].sum(),
                         "Volume RoAS": 0,
                         "Value RoAS ($)": 0,
                         "Contribution Share(%)": 100,
                         "Spend Share(%)": 0,
                         "Raw Media Share(%)": 0}

                wmc_result_data_df.loc[len(wmc_result_data_df)] = total_incremental
                wmc_result_data_df.loc[len(wmc_result_data_df)] = base
                wmc_result_data_df.loc[len(wmc_result_data_df)] = total

                save_dir = '../model_results'
                os.makedirs(save_dir, exist_ok=True)
                wmc_result_data_df.to_csv('../model_results/WMC_' + start_date + '_' + end_date + '.csv', index=False)

        ## saving solutions after adjustment

        self.transformed_media = self.transformed_media_total[:, :self.train_end_index]
        self.train_spend = np.asarray(self.data[self.spend_vars][:self.train_end_index]).sum(axis=0)

        self.solution_df['Coefficient'] = self.Beta
        self.solution_df['Coefficient_unscaled'] = self.Beta / self.scaling_factor_arr
        self.solution_df['Tactic_iRoAS'] = (
                self.Beta * self.transformed_media.sum(axis=1) * self.train_price / self.train_spend)
        self.solution_df['Overall_iroas'] = sum((self.Beta * self.transformed_media.sum(axis=1) * self.train_price)[
                                                :self.num_media_vars - len(self.model.wmt), ]) / sum(
            self.train_spend[:self.num_media_vars - len(self.model.wmt)])

        self.solution_df['Tactic_iRoAS_dev_from_prior'] = (self.solution_df['Tactic_iRoAS'] - self.iroas_prior) ** 2
        self.solution_df['Sum_deviation_from_prior'] = self.solution_df['Tactic_iRoAS_dev_from_prior'].sum()

        self.solution_df['Tactic_iRoAS_in_bound'] = True

        self.solution_df['Year_1_contrib'] = (self.Beta * self.transformed_media_p12.sum(axis=1))
        self.solution_df['Year_1_iroas'] = (self.solution_df['Year_1_contrib'] * self.train_price) / self.solution_df[
            'Year_1_spend']
        self.solution_df['Year_2_contrib'] = (self.Beta * self.transformed_media_l12.sum(axis=1))
        self.solution_df['Year_2_iroas'] = (self.solution_df['Year_2_contrib'] * self.train_price) / self.solution_df[
            'Year_2_spend']

        self.solution_df['Year_1_overall_contrib'] = self.solution_df['Year_1_contrib'].sum()
        self.solution_df['Year_1_overall_iroas'] = (self.solution_df['Year_1_overall_contrib'] * self.train_price) / \
                                                   self.solution_df['Year_1_overall_spend']
        self.solution_df['Year_2_overall_contrib'] = self.solution_df['Year_2_contrib'].sum()
        self.solution_df['Year_2_overall_iroas'] = (self.solution_df['Year_2_overall_contrib'] * self.train_price) / \
                                                   self.solution_df['Year_2_overall_spend']

        if (self.solution_df['Year_2_overall_spend'].iloc[0] > self.solution_df['Year_1_overall_spend'].iloc[0]) and (
                self.solution_df['Year_2_overall_contrib'].iloc[0] < self.solution_df['Year_1_overall_contrib'].iloc[0]
        ):
            self.solution_df['YoY_Monotonic_overall'] = False
        else:
            self.solution_df['YoY_Monotonic_overall'] = True

        self.solution_df['YoY_Monotonic_overall']

        self.solution_df['Train_R_Square'] = self.Train_R_Square_new
        self.solution_df['Train_Mape'] = self.Train_Mape_new
        self.solution_df['Validation_R_Square'] = self.Valid_R_Square_new
        self.solution_df['Validation_Mape'] = self.Valid_Mape_new
        self.solution_df['Media_transformation (hf, inf, sc, lg)'] = self.media_transformation_arr       
        self.solution_df['Media_transformation (hf, inf, sc, lg)'] = self.solution_df['Media_transformation (hf, inf, sc, lg)'].astype(str)                             # NEW 4.6   +                
        self.solution_df['Halflife'] = self.hf_arr
        self.solution_df['Inflection'] = self.inf_arr
        self.solution_df['Scale'] = self.sc_arr
        self.solution_df['Lag'] = self.lg_arr
        self.solution_df['Threshold_Saturation'] = self.thresh_sat_arr
        self.solution_df['Threshold'] = self.thresh_arr
        self.solution_df['Saturation'] = self.sat_arr
        self.solution_df['Inflection_Point'] = self.inf_point_arr
        self.solution_df['Perc_days_beyond_saturation'] = self.days_beyon_sat_res
        self.solution_df['Perc_days_below_threshold'] = self.days_below_thresh_res
        self.solution_df['Acceptable_saturation'] = self.sat_acc_arr.astype(bool)
        self.solution_df['Acceptable_threshold'] = self.thresh_acc_arr.astype(bool)


        self.solution_df['media_transformation_string'] = self.solution_df['Media_transformation (hf, inf, sc, lg)'].str.replace('[','_')                                                   # NEW 4.6  + >>>>     
        self.solution_df['media_transformation_string'] = self.solution_df['media_transformation_string'].str.replace(',','_')
        self.solution_df['media_transformation_string'] = self.solution_df['media_transformation_string'].str.replace(']','')
        self.solution_df['media_transformation_string'] = self.solution_df['media_transformation_string'].str.replace(' ','')

        self.solution_df["media_transformation_string"] = self.solution_df["media_transformation_string"].apply(lambda x: '_'.join([str(item) for item in x.split('_')[:]])) 
        self.solution_df['variable_transformations'] = self.solution_df["Media_tactic"].astype(str) + self.solution_df["media_transformation_string"]
        self.solution_df  = self.solution_df.reset_index(drop=True)
        self.solution_df = self.solution_df.sort_values(by='Media_tactic')                                                                                                                  # NEW 4.6  + <<<<   



        self.Beta = self.Beta_all

        if self.single_sol:
            self.updated_stack_brand['Y_pred'] = 0
            self.updated_stack_brand['Y_pred'] += ((self.Beta * self.X_train.T).sum(axis=1))
            print('Updated model fit:')
            plot_fig_fit(self.updated_stack_brand, self.updated_stack_brand['O_UNIT'],
                         self.updated_stack_brand['Y_pred'])
            df = pd.DataFrame(np.concatenate(
                ((self.Beta * self.X_train.T), np.asarray(self.updated_stack_brand['O_UNIT']).reshape(-1, 1)), axis=1),
                columns=self.non_media_variables + self.media_variables + ['O_UNIT_actual'],
                index=self.updated_stack_brand['Date'])
            dc_filename = self.config["priors_info_path"][:-15] + "daily_contribution.csv"
            df.to_csv(dc_filename)

            self.save_model_outputs()
            self.save_transformed_media()

        return self.solution_df.drop(['media_transformation_string', 'variable_transformations'], axis=1)

    def save_model_outputs(self, file_name="../model_results/model_outputs.xlsx"):

        # self.Beta = np.asarray(Beta)
        # Add a condition to cater for when fit together and not fit together
        #### Coefficient Summary
        Beta_m = [0] * self.num_media_vars
        Beta_nm = [0] * self.num_non_media_vars

        for i in self.model.onsite_wmc:
            Beta_m[i] = self.model.beta_onsite[i].value
        for i in self.model.offsite_wmc:
            Beta_m[i] = self.model.beta_offsite[i].value
        for i in self.model.search_wmc:
            Beta_m[i] = self.model.beta_search[i].value
        for i in self.model.wmt:
            Beta_m[i] = self.model.beta_wmt[i].value

        if self.fit_together:

            for i in self.model.alpha_nm:
                Beta_nm[i] = self.beta_nm_fit[i] * (1 + self.model.alpha_nm_var[i].value)

            self.Beta_all = np.asarray((Beta_m + Beta_nm))

        self.Beta_m = np.asarray(Beta_m)

        if self.fit_together:

            Coefficient_Summary = {
                "Variables": self.media_variables + self.non_media_variables,
                "Coefficient": self.Beta_all,
                # "Coefficient": np.concatenate([self.Beta, np.array(list(self.config["non_media_coef"].values()))]),# use the calculated non media
                "Variable Actual": np.concatenate([self.solution_df['variable_transformations'],
                                                   np.array(list(self.config["non_media_coef"].keys()))])
            }

        else:
            Coefficient_Summary = {
                "Variables": self.media_variables + self.non_media_variables,
                # "Coefficient" : self.Beta,
                "Coefficient": np.concatenate([self.Beta_m, self.beta_nm_fit]),
                "Variable Actual": np.concatenate([self.solution_df['variable_transformations'],
                                                   np.array(list(self.config["non_media_coef"].keys()))])
            }
        Coefficient_Summary_df = pd.DataFrame.from_dict(Coefficient_Summary)

        print(Coefficient_Summary_df)

        #### Model Stats
        if self.fit_together:

            """Train_R_Square_new = (1 - (np.sum((self.Y- np.dot(self.Beta_all, self.X))**2)/self.SST))
            Train_Mape_new = ((np.abs(self.Y - np.dot(self.Beta_all, self.X))/self.updated_stack_brand['O_UNIT'])*100).mean()
            Valid_R_Square_new = (1 - (np.sum((self.Y_valid- np.dot(self.Beta_all, self.X_valid))**2)/self.SST_valid))
            Valid_Mape_new = ((np.abs(self.Y_valid - np.dot(self.Beta_all, self.X_valid))/self.updated_stack_brand_valid['O_UNIT'])*100).mean()"""
            Model_Stats = {
                "Metric": ['MAPE', 'R Square'],
                "Model Fit": [self.Train_Mape_new, self.Train_R_Square_new],
                "Validation Fit": [self.Valid_Mape_new, self.Valid_R_Square_new]
            }

        else:

            """Train_R_Square_new = (1 - (np.sum((self.Y_kj- np.dot(self.Beta, self.X_tilde))**2)/self.SST))
            Train_Mape_new = ((np.abs(self.Y_kj - np.dot(self.Beta, self.X_tilde))/self.updated_stack_brand['O_UNIT'])*100).mean()
            Valid_R_Square_new = (1 - (np.sum((self.Y_kj_valid- np.dot(self.Beta, self.X_tilde_valid))**2)/self.SST_valid))
            Valid_Mape_new = ((np.abs(self.Y_kj_valid - np.dot(self.Beta, self.X_tilde_valid))/self.updated_stack_brand_valid['O_UNIT'])*100).mean()"""
            Model_Stats = {
                "Metric": ['MAPE', 'R Square'],
                "Model Fit": [self.Train_Mape_new, self.Train_R_Square_new],
                "Validation Fit": [self.Valid_Mape_new, self.Valid_R_Square_new]
            }

        Model_Stats_df = pd.DataFrame.from_dict(Model_Stats)

        print(Model_Stats_df)

        #### Contribution
        # print(self.Beta_m.shape)
        # print(self.transformed_var_actual.sum(axis=1).shape)
        # print(self.transformed_media.sum(axis=1).shape)
        Contribution = {
            "Display Level": self.media_variables,
            "Total Contribution": (self.Beta_m * self.transformed_media_total.sum(axis=1)),
            # taking the entire Beta, we need just the media variable
            "Total Sales ($)": (self.Beta_m * self.transformed_media_total.sum(axis=1) * self.train_price),
            "Total Spend ($)": self.train_spend,
            "Value RoAS ($)": (self.Beta_m * self.transformed_media_total.sum(
                axis=1) * self.train_price * 100 / self.train_spend)
        }

        Contribution_df = pd.DataFrame.from_dict(Contribution)

        Total_Contribution = 0
        Total_Spend = 0

        for i in Contribution_df['Display Level']:
            if (i[0:4] == 'M_SP') | (i[0:5] == 'M_SBA') | (i[0:4] == 'M_ON') | (i[0:5] == 'M_OFF'):
                Total_Contribution = Total_Contribution + Contribution_df.loc[
                    Contribution_df['Display Level'] == i, 'Total Contribution'].values[0]
                Total_Spend = Total_Spend + \
                              Contribution_df.loc[Contribution_df['Display Level'] == i, 'Total Spend ($)'].values[0]

        Contribution_df['Contribution Share(%)'] = Contribution_df['Total Contribution'] / Total_Contribution
        Contribution_df['Spend Share(%)'] = Contribution_df['Total Spend ($)'] / Total_Spend

        print(Contribution_df)

        # Beta_nm will change based on self.fit_together
        """if self.fit_together:
            for i in self.model.alpha_nm:

                Beta_nm[i] = self.beta_nm[i] * (1+self.model.alpha_nm_var[i])
            #print(Beta_nm)
        else:
            Beta_nm = np.concatenate((self.Beta_j[:self.num_non_media_vars], self.Beta))"""

        self.updated_stack_brand['Y_pred'] = 0
        self.updated_stack_brand['Y_pred'] += ((self.Beta * self.X_train.T).sum(axis=1))
        Act_vs_Pred_M = {
            'Date': self.updated_stack_brand['Date'],
            'Actual': self.updated_stack_brand['O_UNIT'],
            'Predicted': self.updated_stack_brand['Y_pred']
        }

        Act_vs_Pred_M_df = pd.DataFrame.from_dict(Act_vs_Pred_M)

        # display(Act_vs_Pred_M_df)

        #### Act vs Pred Validation
        self.updated_stack_brand_valid['Y_pred'] = 0
        self.updated_stack_brand_valid['Y_pred'] += ((self.Beta * self.X_valid.T).sum(axis=1))

        Act_vs_Pred_V = {
            # 'Date' : self.updated_stack_brand[(pd.to_datetime(self.updated_stack_brand['Date'])>=self.valid_start_dt) & (pd.to_datetime(self.updated_stack_brand['Date'])<=self.valid_end_dt)]['Date'],
            # 'Actual' : self.updated_stack_brand[(pd.to_datetime(self.updated_stack_brand['Date'])>=self.valid_start_dt) & (pd.to_datetime(self.updated_stack_brand['Date'])<=self.valid_end_dt)]['O_UNIT'],
            # 'Predicted' : self.updated_stack_brand[(pd.to_datetime(self.updated_stack_brand['Date'])>=self.valid_start_dt) & (pd.to_datetime(self.updated_stack_brand['Date'])<=self.valid_end_dt)]['Y_pred']
            'Date': self.updated_stack_brand_valid['Date'],
            'Actual': self.updated_stack_brand_valid['O_UNIT'],
            'Predicted': self.updated_stack_brand_valid['Y_pred']
        }
        Act_vs_Pred_V_df = pd.DataFrame.from_dict(Act_vs_Pred_V)

        # display(Act_vs_Pred_V_df)

        #### Base - Incremental Contribution
        Base_Incr = pd.DataFrame(self.Beta_m * self.transformed_var_actual,
                                 columns=self.solution_df['variable_transformations'])

        date_range = pd.date_range(self.st_dt, self.test_end_dt, freq='D')

        Base_Incr['Baseline_Sales_Calc'] = Base_Incr.sum(axis=1)
        Base_Incr['Total Sales'] = self.updated_stack_brand['O_UNIT']
        Base_Incr['Baseline Sales'] = Base_Incr['Total Sales'] - Base_Incr['Baseline_Sales_Calc']
        del (Base_Incr['Baseline_Sales_Calc'])
        Base_Incr['index'] = date_range

        Base_Incr_m = Base_Incr.copy()
        Base_Incr_m['index_month'] = Base_Incr_m['index'].to_numpy().astype('datetime64[M]')
        del (Base_Incr_m['index'])
        Base_Incr_monthly = Base_Incr_m.groupby('index_month').sum().reset_index()

        base_incremental = Base_Incr_monthly[self.solution_df['variable_transformations']].copy()
        base_incremental.columns = self.media_variables

        base_vol = Base_Incr_monthly[['index_month', 'Baseline Sales']].copy()
        base_vol.columns = ['index', 'base']

        base_modelling = pd.DataFrame.from_dict({'model_start_date': [self.st_dt],
                                                 'model_end_date': [self.train_end_dt]})

        with pd.ExcelWriter('../model_results/base_incremental.xlsx', engine='xlsxwriter') as WRITER_B:
            base_incremental.to_excel(WRITER_B, sheet_name='base_incremental', index=False)
            base_vol.to_excel(WRITER_B, sheet_name='base_vol', index=False)
            base_modelling.to_excel(WRITER_B, sheet_name='modelling', index=False)

        print('base_incremental saved')

        # display(Base_Incr)

        # WRITER = pd.ExcelWriter('model_outputs.xlsx', engine = 'xlsxwriter')

        with pd.ExcelWriter(file_name, engine='xlsxwriter') as WRITER:
            Coefficient_Summary_df.to_excel(WRITER, sheet_name='Coefficient Summary', index=False)
            Model_Stats_df.to_excel(WRITER, sheet_name='Model Stats', index=False)
            Contribution_df.to_excel(WRITER, sheet_name='Contribution', index=False)
            Act_vs_Pred_M_df.to_excel(WRITER, sheet_name='Act vs Pred Modelling', index=False)
            Act_vs_Pred_V_df.to_excel(WRITER, sheet_name='Act vs Pred Validation', index=False)
            Base_Incr.to_excel(WRITER, sheet_name='Base - Incrmental Contribution', index=False)

            # Coefficient_Summary_df.to_excel(WRITER, sheet_name = 'Coefficient Summary', index = False)
            # Model_Stats_df.to_excel(WRITER, sheet_name = 'Model Stats', index = False)
            # Contribution_df.to_excel(WRITER, sheet_name = 'Contribution', index = False)
            # Act_vs_Pred_M_df.to_excel(WRITER, sheet_name = 'Act vs Pred Modelling', index = False)
            # Act_vs_Pred_V_df.to_excel(WRITER, sheet_name = 'Act vs Pred Validation', index = False)
            # Base_Incr.to_excel(WRITER, sheet_name = 'Base - Incrmental Contribution', index = False)

            print(f"Model Outputs saved to {file_name}")

    def save_transformed_media(self, file_name="../model_results/variables_transformation_summary.xlsx"):
        """
        Saves transformed media variables to an Excel file.

        Params:
            file_name (str): Name of the Excel file (default: transformed_media.xlsx).
        """
        """
        Loads media stack data from the CSV file specified in self.config and 
        computes non-zero averages for media variables, along with actual transformation 
        names, threshold points, and saturation points.

        """
        # Convert transformed media to a DataFrame
        transformed_media_df = pd.DataFrame(self.df_transformed_new, columns=self.media_variables)
        ### 🔹 Fetch Media Stack Path from `self.config` ###
        # media_stack_path = self.config.get("modeling_stack_path")
        # if not media_stack_path or not os.path.exists(media_stack_path):
        #     raise FileNotFoundError(f"Media stack file '{media_stack_path}' not found in self.config.")
        if self.config["modeling_stack_path"].startswith("gs://"):
            bucket_name = "category-wamm-model-outputs-stage"
            modeling_stack_gcs_path = strip_gcs_prefix(self.config["modeling_stack_path"])
            self.modeling_stack = pd.read_csv(
                load_file_from_gcs(bucket_name, modeling_stack_gcs_path, file_type='csv')
            )
        else:
            self.modeling_stack = pd.read_csv(self.config["modeling_stack_path"])

        ### 🔹 Load Media Stack Data ###
        media_stack_df = self.modeling_stack.copy()
        # media_stack_df = pd.read_csv(media_stack_path)

        ### 🔹 Validate Required Columns in `self.solution_df` ###
        required_columns = ["Media_tactic", "Threshold", "Saturation"]
        if not all(col in self.solution_df.columns for col in required_columns):
            raise ValueError(f"Expected columns {required_columns} in self.priors_df.")

        ### 🔹 Extract Data ###
        variables = self.media_variables  # Variables from self.media_variables
        variable_actuals = self.media_variables + self.solution_df[
            "media_transformation_string"]  # Actual Variable Namesself.solution_df["Media_tactic"].astype(str)
        # print(variable_actuals)
        ### 🔹 Extract Threshold & Saturation Points from `self.solution_df` ###
        threshold_points = self.solution_df.set_index("Media_tactic")["Threshold"].to_dict()
        saturation_points = self.solution_df.set_index("Media_tactic")["Saturation"].to_dict()

        ### 🔹 Compute Non-Zero Averages from Media Stack Data ###
        non_zero_avg_data = {}
        for var in variables:
            if var in media_stack_df.columns:
                non_zero_values = media_stack_df[var][media_stack_df[var] > 0]  # Filter non-zero values
                non_zero_avg_data[var] = non_zero_values.sum() / len(non_zero_values) if len(non_zero_values) > 0 else 0
            else:
                non_zero_avg_data[var] = None  # Handle missing variables

        ### 🔹 Create DataFrame for Excel ###
        # print(self.solution_df.head())
        # print(list(self.solution_df.columns))
        ### 🔹 Compute Rate from Media Stack Data ###
        cpi_results = {}
        for var in variables:
            if var in media_stack_df.columns:
                total_imp = media_stack_df[var].sum()
                spend_var = var.replace('VIEW_IMP', 'SPEND').replace('IMP', 'SPEND').replace('CLK', 'SPEND')
                if spend_var in media_stack_df.columns:
                    total_spend = media_stack_df[
                        var.replace('VIEW_IMP', 'SPEND').replace('IMP', 'SPEND').replace('CLK', 'SPEND')].sum()
                    cpi = total_spend / total_imp if total_imp != 0 else float('inf')
                    cpi_results[var] = cpi

        summary_data_points = []
        for var in variables:
            transformation_var = var + self.solution_df.loc[
                self.solution_df["Media_tactic"] == var, "media_transformation_string"].values[0]
            threshold = threshold_points.get(var, None)
            saturation = saturation_points.get(var, None)
            inflection = (
                                 threshold + saturation) / 2 if threshold is not None and saturation is not None else None  # Compute Inflection Point

            summary_data_points.append([
                var,
                threshold,
                inflection,
                saturation,
                non_zero_avg_data.get(var, None),
                transformation_var])
            #### points

        summary_df = pd.DataFrame(summary_data_points,
                                  columns=["Variable", "Threshold Point", "Inflection Point", "Saturation Point",
                                           "Non-Zero Average", "Variable Actuals"])
        summary_data_spend_points = []
        for var in variables:
            transformation_var = var + self.solution_df.loc[
                self.solution_df["Media_tactic"] == var, "media_transformation_string"].values[0]
            threshold = threshold_points.get(var, None)
            saturation = saturation_points.get(var, None)
            inflection = (
                                 threshold + saturation) / 2 if threshold is not None and saturation is not None else None  # Compute Inflection Point
            non_zero_avg = non_zero_avg_data.get(var, None)
            cpi = cpi_results.get(var, None)
            # Multiply CPI with threshold & saturation
            threshold_sp = cpi * threshold if cpi is not None and threshold is not None else None
            saturation_sp = cpi * saturation if cpi is not None and saturation is not None else None
            inflection_sp = cpi * inflection if cpi is not None and saturation is not None else None
            non_zero_avg_sp = cpi * non_zero_avg
            summary_data_spend_points.append([
                var,
                threshold_sp,
                inflection_sp,
                saturation_sp,
                non_zero_avg_sp,
                transformation_var])
            #### points

        summary_df_spend = pd.DataFrame(summary_data_spend_points,
                                        columns=["Variable", "Threshold Point", "Inflection Point", "Saturation Point",
                                                 "Non-Zero Average", "Variable Actuals"])
        # display(summary_df_spend)
        analysis_data = []
        for var in variables:
            if var in media_stack_df.columns:
                data = media_stack_df[var]
                transformation_var = var + self.solution_df.loc[
                    self.solution_df["Media_tactic"] == var, "media_transformation_string"].values[0]
                total_days = len(data)
                on_air_days = (data > 0).sum()
                threshold = threshold_points.get(var, None)
                saturation = saturation_points.get(var, None)
                inflection = (threshold + saturation) / 2 if threshold is not None and saturation is not None else None

                days_above_saturation = (data > saturation).sum() if saturation is not None else None
                days_below_saturation = (data < saturation).sum() if saturation is not None else None
                optimal_range_days = ((data >= threshold) & (
                        data <= saturation)).sum() if threshold is not None and saturation is not None else None
                beyond_saturation_days = (
                        days_above_saturation / total_days * 100) if days_above_saturation is not None else None
                below_inflection_days = (data < inflection).sum() / total_days * 100 if inflection is not None else None

                actual_avg_point = data.mean()
                average = data[data > 0].mean() if on_air_days > 0 else 0

                analysis_data.append([
                    var, transformation_var, total_days, on_air_days, optimal_range_days, beyond_saturation_days,
                    below_inflection_days, days_above_saturation, days_below_saturation,
                    actual_avg_point, average, threshold, inflection, saturation
                ])
            else:
                analysis_data.append([var] + [None] * 12)  # Fill missing data with None

        ### 🔹 Create DataFrame for Excel ###
        analysis_df = pd.DataFrame(analysis_data, columns=[
            "Variable", "Variable Actual", "Total Days", "On Air Days", "Optimal Range Days (%)",
            "Beyond Saturation Days (%)", "Below Inflection Days (%)",
            "Days above Saturation", "Days below Saturation",
            "Actual Average Point", "Average", "Threshold point",
            "Inflection Point", "Saturation Point"
        ])
        analysis_data_spend = []
        for var in variables:
            if var in media_stack_df.columns:
                data = media_stack_df[var]
                transformation_var = var + self.solution_df.loc[
                    self.solution_df["Media_tactic"] == var, "media_transformation_string"].values[0]
                total_days = len(data)
                on_air_days = (data > 0).sum()
                threshold = threshold_points.get(var, None)
                saturation = saturation_points.get(var, None)
                inflection = (threshold + saturation) / 2 if threshold is not None and saturation is not None else None
                cpi = cpi_results.get(var, None)
                threshold_sp = cpi * threshold if cpi is not None and threshold is not None else None
                saturation_sp = cpi * saturation if cpi is not None and saturation is not None else None
                inflection_sp = cpi * inflection if cpi is not None and saturation is not None else None

                days_above_saturation = (data > saturation_sp).sum() if saturation_sp is not None else None
                days_below_saturation = (data < saturation_sp).sum() if saturation_sp is not None else None
                optimal_range_days = ((data >= threshold_sp) & (
                        data <= saturation_sp)).sum() if threshold is not None and saturation is not None else None
                beyond_saturation_days = (
                        days_above_saturation / total_days * 100) if days_above_saturation is not None else None
                below_inflection_days = (
                                                data < inflection_sp).sum() / total_days * 100 if inflection is not None else None

                actual_avg_point_sp = data.mean() * cpi
                average = data[data > 0].mean() if on_air_days > 0 else 0
                average_sp = average * cpi
                analysis_data_spend.append([
                    var, transformation_var, total_days, on_air_days, optimal_range_days, beyond_saturation_days,
                    below_inflection_days, days_above_saturation, days_below_saturation,
                    actual_avg_point_sp, average_sp, threshold_sp, inflection_sp, saturation_sp
                ])
            else:
                analysis_data_spend.append([var] + [None] * 12)  # Fill missing data with None

        ### 🔹 Create DataFrame for Excel ###
        analysis_df_spend = pd.DataFrame(analysis_data_spend, columns=[
            "Variable", "Variable Actual", "Total Days", "On Air Days", "Optimal Range Days (%)",
            "Beyond Saturation Days (%)", "Below Inflection Days (%)",
            "Days above Saturation", "Days below Saturation",
            "Actual Average Point", "Average", "Threshold point",
            "Inflection Point", "Saturation Point"
        ])
        # Save to Excel
        with pd.ExcelWriter(file_name, engine='xlsxwriter') as writer:
            transformed_media_df.to_excel(writer, sheet_name="Transformations", index=False)
            summary_df.to_excel(writer, sheet_name="Points", index=False)
            summary_df_spend.to_excel(writer, sheet_name="Spend Points", index=False)
            analysis_df.to_excel(writer, sheet_name="Airing Analysis", index=False)
            analysis_df_spend.to_excel(writer, sheet_name="Airing Analysis Spends", index=False)

        print(f"Transformed media saved to {file_name}")


def lag_transformation_no_numba(var, lag):
    lag_variable = np.append(np.zeros(int(lag)), var[:-lag])
    return lag_variable


def halflife_transformation_no_numba(var, halflife):
    retention = np.exp(math.log(0.5) / halflife)
    transformed_var = var * (1 - retention)
    transformed_var[np.isnan(transformed_var)] = 0
    transformed_var = recursive_filter_no_numba(transformed_var, retention)
    return transformed_var


def recursive_filter_no_numba(x, ar_coeff):
    n = len(x)
    y = np.zeros(n)
    y[0] = x[0]
    for i in range(1, n):
        y[i] = ar_coeff * y[i - 1] + x[i]
    return y


def create_missing_media_transformations_new(df, media_vars, solution_df, l12_start_index, train_end_index,
                                             optimize_scurve=False, trans_start_date=None, trans_end_date=None):
    '''
    Creates the mising media transformation

    Params
        media_vars : List of all media variables
    '''
    # Creates the missing media transformations
    ## added:09.29.2022, jangho, for sliders

    scaling_factor_arr = np.zeros(len(media_vars))
    media_transformation_arr = []
    thresh_sat_arr = []
    hf_arr = np.zeros(len(media_vars))
    inf_arr = np.zeros(len(media_vars))
    sc_arr = np.zeros(len(media_vars))
    lg_arr = np.zeros(len(media_vars))
    lambda_arr = np.zeros(len(media_vars))
    thresh_arr = np.zeros(len(media_vars))
    sat_arr = np.zeros(len(media_vars))
    inf_point_arr = np.zeros(len(media_vars))
    days_beyon_sat_res = np.zeros(len(media_vars))
    days_below_thresh_res = np.zeros(len(media_vars))
    sat_acc_arr = np.zeros(len(media_vars))
    thresh_acc_arr = np.zeros(len(media_vars))

    if trans_start_date is None:
        trans_start_date = trans_start_date

    if trans_end_date is None:
        trans_end_date = trans_end_date

    for i, var in enumerate(media_vars):

        var = _re.sub(r'np\.float64\(([^)]+)\)', r'\1', str(var))
        lag = int(float(var.split("_")[-2]))
        halflife = float(var.split("_")[-5])
        sscurve_inflection = float(var.split("_")[-4])
        sscurve_scale = float(var.split("_")[-3])
        lambda_k = float(var.split("_")[-1])
        orig_media_var = var.split("_")[:-5]
        orig_media_var = '_'.join([str(elem) for elem in orig_media_var])
        # display("orig_media_var",orig_media_var)
        # display("lag",lag)
        # display("halflife",halflife)
        # display("sscurve_inflection",sscurve_inflection)
        # display("sscurve_scale",sscurve_scale)

        # Saving the numbers on the required period defined by trans_start_date and trans_end_date
        df_filtered = df
        transformed_var = df_filtered[orig_media_var]

        if orig_media_var in (
                solution_df[solution_df['scurve_filter'] == False]['Media_tactic']).tolist() and optimize_scurve:

            target_threshold = transformed_var[transformed_var > 0].quantile(0.05)
            # target_saturation = transformed_var[l12_start_index:train_end_index][transformed_var > 0].quantile(0.95)                                  # NEW: 4.6 -
            target_saturation = transformed_var[transformed_var > 0].quantile(0.95)                                                                     # NEW: 4.6 +

            target_inflection = (target_saturation + target_threshold) / 2

        else:

            target_threshold = solution_df[solution_df['Media_tactic'] == orig_media_var]['Threshold'].values[0]
            target_saturation = solution_df[solution_df['Media_tactic'] == orig_media_var]['Saturation'].values[0]
            target_inflection = (target_saturation + target_threshold) / 2

        days_beyond_saturation = ((transformed_var[transformed_var > 0] > target_saturation).sum()
                                  / (transformed_var > 0).sum())

        days_below_threshold = ((transformed_var[transformed_var > 0] < target_threshold).sum()
                                / (transformed_var > 0).sum())

        if (orig_media_var.startswith("M_SP") or orig_media_var.startswith("M_SBA")):

            sat_acc_arr[i] = (
                True
                if (
                        (
                                (transformed_var > 0).sum() >= 0.20
                                and days_beyond_saturation <= 0.05  # New Guardrails
                        )
                        or (transformed_var > 0).sum() < 0.20
                )
                else False
            )
        else:
            sat_acc_arr[i] = (
                True
                if (
                        (
                                (transformed_var > 0).sum() >= 0.20
                                and days_beyond_saturation <= 0.20  # New Guardrails
                        )
                        or (transformed_var > 0).sum() < 0.20
                )
                else False
            )

        thresh_acc_arr[i] = (
            True
            if (
                    (
                            (transformed_var > 0).sum() >= 0.20
                            and days_below_threshold <= 0.10  # New Guardrails
                    )
                    or (transformed_var > 0).sum() < 0.20
            )
            else False
        )

        # Saving the means on the filtered dataset
        if lag != 0:
            transformed_var = lag_transformation_no_numba(transformed_var, int(lag))

        if halflife != 0:
            transformed_var = halflife_transformation_no_numba(transformed_var, halflife)

        var_mean = transformed_var.mean()

        if orig_media_var in (
                solution_df[solution_df['scurve_filter'] == False]['Media_tactic']).tolist() and optimize_scurve:

            if var_mean > 0:
                sscurve_inflection = (target_saturation + target_threshold) / (2 * var_mean)
            else:
                sscurve_inflection = 0
            if (target_saturation - target_threshold) > 0:
                sscurve_scale = ((2 * var_mean) * 4.59511985013) / (
                        target_saturation - target_threshold
                )
            else:
                sscurve_scale = 0

        if (sscurve_scale != 0) and (sscurve_inflection != 0):
            transformed_var_scaled = transformed_var / var_mean
            saturation_term = sscurve_scale * (sscurve_inflection - transformed_var_scaled)
            scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (1 + np.exp(sscurve_scale * sscurve_inflection))
            scurve_var_mean = scurve_var.mean()
            transformed_var = scurve_var * var_mean / scurve_var_mean

        hf_arr[i] = halflife
        inf_arr[i] = sscurve_inflection
        sc_arr[i] = sscurve_scale
        lg_arr[i] = lag
        lambda_arr[i] = lambda_k
        thresh_arr[i] = target_threshold
        sat_arr[i] = target_saturation
        inf_point_arr[i] = target_inflection
        days_beyon_sat_res[i] = days_beyond_saturation
        days_below_thresh_res[i] = days_below_threshold

        media_transformation_arr.append([halflife, sscurve_inflection, sscurve_scale, lag, lambda_k])
        thresh_sat_arr.append([target_threshold, target_saturation])

        scaling_factor = max(transformed_var) - min(transformed_var)
        scaling_factor_arr[i] = scaling_factor
        transformed_var = (
                                  transformed_var - min(transformed_var)
                          ) / scaling_factor
        df[orig_media_var] = transformed_var

    return (df, scaling_factor_arr, hf_arr, inf_arr, sc_arr, lg_arr,
            thresh_arr, sat_arr, inf_point_arr, media_transformation_arr,
            thresh_sat_arr, days_beyon_sat_res, days_below_thresh_res, sat_acc_arr, thresh_acc_arr)


def create_constraints(solutions_filter, prior_config, alpha_overall= None, beta_overall=None, alpha_channel= None, beta_channel=None,
                       theta_YoY=None):
    overall_iroas_solution = solutions_filter['Overall_iroas'].mean()
    search_iroas_solution = solutions_filter['Search_iRoAS'].mean()
    onsite_iroas_solution = solutions_filter['Onsite_iRoAS'].mean()
    offsite_iroas_solution = solutions_filter['Offsite_iRoAS'].mean()

    overall_iroas_prior = prior_config['runner_settings']['overall_iroas_prior']  # update to overall_iroas_prior
    search_iroas_prior = prior_config['runner_settings']['search_iroas_prior']
    onsite_iroas_prior = prior_config['runner_settings']['onsite_iroas_prior']
    offsite_iroas_prior = prior_config['runner_settings']['offsite_iroas_prior']

    solutions_filter['scurve_filter'] = solutions_filter['Acceptable_threshold'] & solutions_filter[
        'Acceptable_saturation']

    if solutions_filter['CM_flag_overall_iroas'].unique()[0]:
        overall_lb = overall_iroas_solution - overall_iroas_solution * alpha_overall
        overall_ub = overall_iroas_solution + overall_iroas_solution * alpha_overall
        overall_iroas_bounds = np.asarray([overall_lb, overall_ub])
        print(f'Overall iRoAS : CM Passed : Constraints : {overall_lb} {overall_ub}')

    else:
        overall_lb = overall_iroas_prior - overall_iroas_prior * beta_overall
        overall_ub = overall_iroas_prior + overall_iroas_prior * beta_overall
        print(f'Overall iRoAS : CM Failed : Constraints with Priors : {overall_lb} {overall_ub}')

        overall_iroas_bounds = np.asarray([overall_lb, overall_ub])

    if solutions_filter['CM_flag_search_iroas'].unique()[0]:
        search_lb = search_iroas_solution - search_iroas_solution * alpha_channel
        search_ub = search_iroas_solution + search_iroas_solution * alpha_channel
        search_iroas_bounds = np.asarray([search_lb, search_ub])
        print(f'Search iRoAS : CM Passed : Constraints : {search_lb} {search_ub}')

    else:
        search_lb = search_iroas_prior - search_iroas_prior * beta_channel
        search_ub = search_iroas_prior + search_iroas_prior * beta_channel
        print(f'Search iRoAS : CM Failed : Constraints with Priors : {search_lb} {search_ub}')
        search_iroas_bounds = np.asarray([search_lb, search_ub])

    if solutions_filter['CM_flag_onsite_iroas'].unique()[0]:
        onsite_lb = onsite_iroas_solution - onsite_iroas_solution * alpha_channel
        onsite_ub = onsite_iroas_solution + onsite_iroas_solution * alpha_channel
        print(f'Onsite iRoAS : CM Passed : Constraints : {onsite_lb} {onsite_ub}')
        onsite_iroas_bounds = np.asarray([onsite_lb, onsite_ub])
    else:
        onsite_lb = onsite_iroas_prior - onsite_iroas_prior * beta_channel
        onsite_ub = onsite_iroas_prior + onsite_iroas_prior * beta_channel
        print(f'Onsite iRoAS : CM Failed : Constraints with Priors : {onsite_lb} {onsite_ub}')
        onsite_iroas_bounds = np.asarray([onsite_lb, onsite_ub])

    if solutions_filter['CM_flag_offsite_iroas'].unique()[0]:
        offsite_lb = offsite_iroas_solution - offsite_iroas_solution * alpha_channel
        offsite_ub = offsite_iroas_solution + offsite_iroas_solution * alpha_channel
        print(f'Offsite iRoAS : CM Passed : Constraints : {offsite_lb} {offsite_ub}')
        offsite_iroas_bounds = np.asarray([offsite_lb, offsite_ub])
    else:
        offsite_lb = offsite_iroas_prior - offsite_iroas_prior * beta_channel
        offsite_ub = offsite_iroas_prior + offsite_iroas_prior * beta_channel
        print(f'Offsite iRoAS : CM Failed : Constraints with Priors : {offsite_lb} {offsite_ub}')
        offsite_iroas_bounds = np.asarray([offsite_lb, offsite_ub])

    if solutions_filter['YoY_flag_overall_iroas'].unique()[0]:
        print(f'YoY Overall iRoAS : Passed : {theta_YoY} are perc bounds')
        overall_iroas_bounds_yoy = np.asarray(theta_YoY)
    else:
        print(f'YoY Overall iRoAS : Failed : {theta_YoY} are perc bounds')
        overall_iroas_bounds_yoy = np.asarray(theta_YoY)

    return overall_iroas_bounds, search_iroas_bounds, onsite_iroas_bounds, offsite_iroas_bounds, overall_iroas_bounds_yoy