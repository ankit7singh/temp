# importing Libraries here
import matplotlib.ticker as ticker
import pandas as pd
# Load specific forecasting tools
import statsmodels.api as sm
from custom_transformation_functions import ccurve_transformation
from pmdarima import auto_arima  # for determining ARIMA orders
from static_helper import SaveExcelTemplated
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.stattools import adfuller

import sys
import numpy as np
import scipy
import pmdarima

formatter = ticker.StrMethodFormatter("{x:,.0f}")

import warnings

warnings.filterwarnings("ignore")


class VariableSeasonality:

    def __init__(
        self,
        df,
        key_variable,
        file_path=None,
        modelling_start=None,
        modelling_end=None,
        validation_start=None,
        validiation_end=None,
        m=7,
        exog=None,
    ):
        self.df = df
        self.key_variable = key_variable
        if file_path is not None:
            self.excel_obj = SaveExcelTemplated(file_path)
        self.modelling_start = modelling_start
        self.modelling_end = modelling_end
        self.validation_start = validation_start
        self.validiation_end = validiation_end
        self.exog = exog

        self.df_final_rankings = None
        self.df_transformations = None
        self.df_seasonal_decompose = None
        self.df_arma_arima = None

        self.m = m

    def residual_calculation(self, var, exog):
        """
        Returns residuals of var to a regression with exog
        """
        Y = var
        X = exog
        X = sm.add_constant(X)
        model = sm.OLS(Y, X, missing="drop")
        model_result = model.fit()
        outcome_residuals = model_result.resid
        return outcome_residuals

    # Implementation of Dicky Fuller Test
    def adf_test(self, series):
        """
        Pass in a time series and an optional title, returns an ADF report
        """

        print("Augmented Dickey-Fuller")
        result = adfuller(
            series.dropna(), autolag="AIC"
        )  # .dropna() handles differenced data

        labels = ["ADF  Statistic", "P-Value", "#Lags Used", "#Observations"]
        out = pd.Series(result[0:4], index=labels)

        for key, val in result[4].items():
            out[f"critical value ({key})"] = val

        print(out.to_string())  # .to_string() removes the line "dtype: float64"

        if result[1] <= 0.05:
            print("Strong evidence against the null hypothesis")
            print("Reject the null hypothesis")
            print("Data has no unit root and is stationary")
        else:
            print("Weak evidence against the null hypothesis")
            print("Fail to reject the null hypothesis")
            print("Data has a unit root and is non-stationary")

        return result[1]

    # To check for stationarity
    def arma_arima_func(
        self,
        start_p,
        start_q,
        day_start=5,
        day_end=8,
        custom_order=None,
        custom_seasonal_order=None,
    ):
        if self.exog:
            df = self.residual_calculation(
                self.df[self.key_variable], self.df[self.exog]
            )
            df_log = self.residual_calculation(
                ccurve_transformation(self.df[self.key_variable]), self.df[self.exog]
            )

            # df = df.round(5)                                                                                                            # NEW 3.23


            print("NEW: Package Versions:")                                                                                             # NEW 3.23 +++
            print("Python:", sys.version)
            print("numpy:", np.__version__)
            print("pandas:", pd.__version__)
            print("scipy:", scipy.__version__)
            print("statsmodels:", sm.__version__)
            print("pmdarima:", pmdarima.__version__)

            print("df = self.residual_calculation output:\n", df.to_string())                                                           # NEW 3.23

        else:
            df = self.df[self.key_variable]
            df_log = ccurve_transformation(self.df[self.key_variable])
        adf_score = self.adf_test(df)

        m = self.m
        if adf_score <= 0.05:
            print(
                "Since Data is Stationary, we will be using SARIMAX and enforce stationarity"
            )  # performs ARMA when score is <=0.05

            stepwise_fit = auto_arima(
                df,
                start_p=start_p,
                start_q=start_q,
                max_p=6,
                max_q=3,
                m=m,
                d=None,
                error_action="ignore",
                suppress_warnings=True,
                enforce_stationarity=True,
                stepwise=True,
            )

            order = stepwise_fit.to_dict()["order"]  # Best order in ARIMA
            seasonal_order = stepwise_fit.to_dict()["seasonal_order"]

            if custom_order:
                order = custom_order

            if custom_seasonal_order:
                seasonal_order = custom_seasonal_order

            model = SARIMAX(df, order=order, seasonal_order=seasonal_order)                           
            
            # model = SARIMAX(df, order=(1,1,1), seasonal_order=(0,0,1,7))                # NEW 3.24
            # results = model.fit()
            
            results = model.fit(method="powell",
            maxiter=500,
            disp=False,                         # do not print optimizer convergence messages while fitting
            full_output=True)                  # keep the solver’s detailed return info in the fitted results object, specifically in results.mle_retvals.                                  # NEW 3.25

            print(results.summary())                         # NEW 3.23 +++
            print(results.params)
            print(results.bse)
            print(results.llf)
            print(results.aic, results.bic, results.hqic)
            print(results.resid[:10])
            print(results.mle_retvals)                       # NEW 3.23 +++

            self.pred_var_name = (
                self.key_variable + "_SARIMAX " + str(order) + " " + str(seasonal_order)
            )
            predictions = results.predict().rename(
                self.pred_var_name
            )  # predicting on the results

            predictions = pd.concat(
                [df.rename(self.key_variable), predictions], axis=1
            )[self.pred_var_name].fillna(0)

            # Doing same for log data
            stepwise_fit_log = auto_arima(
                df_log,
                start_p=start_p,
                start_q=start_q,
                max_p=6,
                max_q=3,
                m=m,
                d=None,
                error_action="ignore",
                suppress_warnings=True,
                enforce_stationarity=True,
                stepwise=True,
            )

            order_log = stepwise_fit_log.to_dict()["order"]
            seasonal_order_log = stepwise_fit_log.to_dict()["seasonal_order"]

            model_log = SARIMAX(
                df_log, order=order_log, seasonal_order=seasonal_order_log
            )

            # model_log = SARIMAX(df_log, order=(1,1,1), seasonal_order=(0,0,1,7))            # NEW 3.24

            # results_log = model_log.fit()

            results_log = model_log.fit(    method="powell",
            maxiter=500,
            disp=False,
            full_output=True)                                                    # NEW 3.25

            print(results_log.summary())                         # NEW 3.23 +++
            print(results_log.params)
            print(results_log.bse)
            print(results_log.llf)
            print(results_log.aic, results_log.bic, results_log.hqic)
            print(results_log.resid[:10])
            print(results_log.mle_retvals)                       # NEW 3.23 +++

            self.pred_var_name_log = (
                self.key_variable
                + "_SARIMAX_LOG "
                + str(order_log)
                + " "
                + str(seasonal_order_log)
            )
            predictions_log = results_log.predict().rename(
                self.pred_var_name_log
            )  # predicting on the results

        else:
            print(
                "Data is non-stationary, so we will be doing SARIMAX"
            )  # performs ARIMA when score >0.05
            stepwise_fit = auto_arima(
                df,
                start_p=start_p,
                start_q=start_q,
                max_p=6,
                max_q=3,
                m=m,
                d=None,
                error_action="ignore",
                suppress_warnings=True,
                stepwise=True,
            )

            order = stepwise_fit.to_dict()["order"]  # Best order in ARIMA
            seasonal_order = stepwise_fit.to_dict()["seasonal_order"]

            if custom_order:
                order = custom_order

            if custom_seasonal_order:
                seasonal_order = custom_seasonal_order

            model = SARIMAX(
                df, order=order, seasonal_order=seasonal_order
            )  # taking the minimum order given by ARIMA

            # model = SARIMAX(df, order=(1,1,1), seasonal_order=(0,0,1,7))                # NEW 3.24
            # results = model.fit()
            
            results = model.fit(method="powell",
            maxiter=500,
            disp=False,
            full_output=True)                                                    # NEW 3.25

            print(results.summary())                         # NEW 3.23 +++
            print(results.params)
            print(results.bse)
            print(results.llf)
            print(results.aic, results.bic, results.hqic)
            print(results.resid[:10])
            print(results.mle_retvals)                       # NEW 3.23 +++

            self.pred_var_name = (
                self.key_variable + "_SARIMAX " + str(order) + " " + str(seasonal_order)
            )

            # Creating predictions by ARIMA on historical data to create AR_var
            predictions = results.predict(dynamic=False, typ="levels").rename(
                self.pred_var_name
            )

            predictions = pd.concat(
                [df.rename(self.key_variable), predictions], axis=1
            )[self.pred_var_name].fillna(0)

            # Similar for log
            stepwise_fit_log = auto_arima(
                df_log,
                start_p=start_p,
                start_q=start_q,
                max_p=6,
                max_q=3,
                m=m,
                d=None,
                error_action="ignore",
                suppress_warnings=True,
                stepwise=True,
            )

            order_log = stepwise_fit_log.to_dict()["order"]  # Best order in ARIMA
            seasonal_order_log = stepwise_fit_log.to_dict()["seasonal_order"]

            model_log = SARIMAX(
                df_log, order=order_log, seasonal_order=seasonal_order_log
            )  # taking the minimum order given by ARIMA

            # model_log = SARIMAX(df_log, order=(1,1,1), seasonal_order=(0,0,1,7))            # NEW 3.24
            # results_log = model_log.fit()

            results_log = model_log.fit(method="powell",
            maxiter=500,
            disp=False,
            full_output=True)                                                    # NEW 3.25

            print(results_log.summary())                         # NEW 3.23 +++
            print(results_log.params)
            print(results_log.bse)
            print(results_log.llf)
            print(results_log.aic, results_log.bic, results_log.hqic)
            print(results_log.resid[:10])
            print(results_log.mle_retvals)                       # NEW 3.23 +++

            self.pred_var_name_log = (
                self.key_variable
                + "_SARIMAX_LOG "
                + str(order_log)
                + " "
                + str(seasonal_order_log)
            )

            # Creating predictions by ARIMA on historical data to create AR_var
            predictions_log = results_log.predict(dynamic=False, typ="levels").rename(
                self.pred_var_name_log
            )

        predictions_log = pd.concat(
            [df_log.rename(self.key_variable), predictions_log], axis=1
        )[self.pred_var_name_log].fillna(0)

        self.df[self.pred_var_name] = predictions.values
        self.df[self.pred_var_name_log] = predictions_log.values

        # Plot predictions against known values
        ylabel = self.key_variable + " residuals"
        ax = df.plot(legend=True, figsize=(15, 10), title="")
        predictions.plot(legend=True)
        ax.autoscale(axis="x", tight=True)
        ax.set(ylabel=ylabel)
        ax.yaxis.set_major_formatter(formatter)

        self.seasonal_terms = []
        for day in range(day_start, day_end + 1):
            df.index.freq = "D"
            day_str = str(day)
            span = day
            alpha = 2 / (span + 1)

            # Seasonal Moving Average Calculation - SMA
            self.df[self.key_variable + "_SMA_DAY_" + day_str] = (
                df.rolling(window=day, min_periods=1).mean().shift(1).fillna(df)
            )
            self.seasonal_terms.append(self.key_variable + "_SMA_DAY_" + day_str)

    # To create the dataframe for all the variables in a given range
    def creating_var_func(self, additional_period_start_date=None):
        if self.exog:
            df = self.residual_calculation(
                self.df[self.key_variable], self.df[self.exog]
            )
        else:
            df = self.df[self.key_variable]

        if additional_period_start_date is not None:
            df_filtered_1 = self.df[
                (self.df.index < additional_period_start_date)
            ].copy()
            df_filtered_2 = self.df[
                (self.df.index >= additional_period_start_date)
            ].copy()

            if self.exog:
                df = self.residual_calculation(
                    df_filtered_1[self.key_variable], df_filtered_1[self.exog]
                )
                df_added = self.residual_calculation(
                    df_filtered_2[self.key_variable], df_filtered_2[self.exog]
                )
            else:
                df = df_filtered_1[self.key_variable]
                df_added = df_filtered_2[self.key_variable]

            df_added.index.freq = "D"

        df.index.freq = "D"

        result = seasonal_decompose(df, model="additive")  # model='mul' also works
        result.plot()

        df_seasonal_decompose = (
            pd.concat(
                [
                    pd.DataFrame(result.seasonal),
                    pd.DataFrame(result.trend),
                    pd.DataFrame(result.resid),
                ],
                axis=1,
            )
            .reset_index()
            .fillna(0)
        )

        df_seasonal_decompose.columns = ["Date", "SEASONALITY", "TREND", "RESIDUAL"]

        if additional_period_start_date is not None:
            result_added = seasonal_decompose(df_added, model="additive")
            df_seasonal_decompose_added = (
                pd.concat(
                    [
                        pd.DataFrame(result_added.seasonal),
                        pd.DataFrame(result_added.trend),
                        pd.DataFrame(result_added.resid),
                    ],
                    axis=1,
                )
                .reset_index()
                .fillna(0)
            )
            df_seasonal_decompose_added.columns = [
                "Date",
                "SEASONALITY",
                "TREND",
                "RESIDUAL",
            ]

            df_seasonal_decompose = pd.concat(
                [df_seasonal_decompose, df_seasonal_decompose_added], axis=0
            ).reset_index(drop=False)

        # Creating similar transformations after applying log transformation on the target variable
        if self.exog:
            df_log = self.residual_calculation(
                ccurve_transformation(self.df[self.key_variable]), self.df[self.exog]
            )
        else:
            df_log = ccurve_transformation(self.df[self.key_variable])

        if additional_period_start_date is not None:
            df_filtered_1 = self.df[
                (self.df.index < additional_period_start_date)
            ].copy()
            df_filtered_2 = self.df[
                (self.df.index >= additional_period_start_date)
            ].copy()

            if self.exog:
                df_log = self.residual_calculation(
                    ccurve_transformation(df_filtered_1[self.key_variable]),
                    df_filtered_1[self.exog],
                )
                df_added_log = self.residual_calculation(
                    ccurve_transformation(df_filtered_2[self.key_variable]),
                    df_filtered_2[self.exog],
                )
            else:
                df_log = ccurve_transformation(df_filtered_1[self.key_variable])
                df_added_log = ccurve_transformation(df_filtered_2[self.key_variable])

            df_added_log.index.freq = "D"

        df_log.index.freq = "D"
        result_log = seasonal_decompose(df_log, model="additive")

        df_seasonal_decompose_log = (
            pd.concat(
                [
                    pd.DataFrame(result_log.seasonal),
                    pd.DataFrame(result_log.trend),
                    pd.DataFrame(result_log.resid),
                ],
                axis=1,
            )
            .reset_index()
            .fillna(0)
        )

        df_seasonal_decompose_log.columns = [
            "Date",
            "SEASONALITY_LOG",
            "TREND_LOG",
            "RESIDUAL_LOG",
        ]

        if additional_period_start_date is not None:
            result_added_log = seasonal_decompose(df_added_log, model="additive")
            df_seasonal_decompose_added_log = (
                pd.concat(
                    [
                        pd.DataFrame(result_added_log.seasonal),
                        pd.DataFrame(result_added_log.trend),
                        pd.DataFrame(result_added_log.resid),
                    ],
                    axis=1,
                )
                .reset_index()
                .fillna(0)
            )
            df_seasonal_decompose_added_log.columns = [
                "Date",
                "SEASONALITY_LOG",
                "TREND_LOG",
                "RESIDUAL_LOG",
            ]

            df_seasonal_decompose_log = pd.concat(
                [df_seasonal_decompose_log, df_seasonal_decompose_added_log], axis=0
            ).reset_index(drop=False)

        self.df[self.key_variable + "_SEASONALITY"] = df_seasonal_decompose[
            "SEASONALITY"
        ].values
        self.df[self.key_variable + "_TREND"] = df_seasonal_decompose["TREND"].values
        self.df[self.key_variable + "_RESIDUAL"] = df_seasonal_decompose[
            "RESIDUAL"
        ].values

        # Adding log terms
        self.df[self.key_variable + "_SEASONALITY_LOG"] = df_seasonal_decompose_log[
            "SEASONALITY_LOG"
        ].values
        self.df[self.key_variable + "_TREND_LOG"] = df_seasonal_decompose_log[
            "TREND_LOG"
        ].values
        self.df[self.key_variable + "_RESIDUAL_LOG"] = df_seasonal_decompose_log[
            "RESIDUAL_LOG"
        ].values

    def _create_SARIMAX_dict(self, sarimax_columns):
        """
        Creates SARIMAX dictionary from a list of SARIMAX columns.

        input:
            ['O_NEW_CUSTOMER_SARIMAX (1, 1, 1) (1, 0, 2, 7)',
             'O_NEW_CUSTOMER_SARIMAX_LOG (3, 1, 1) (2, 0, 2, 7)',
             'O_UNIT_SARIMAX (0, 1, 0) (1, 0, 2, 7)',
             'O_UNIT_SARIMAX_LOG (2, 1, 1) (2, 0, 2, 7)'
            ]

        output:
            {'O_NEW_CUSTOMER_SARIMAX': {'order': (1, 1, 1),
                                        'seasonal_order': (1, 0, 2, 7)
                                        ,
             'O_NEW_CUSTOMER_SARIMAX_LOG': {'order': (3, 1, 1),
                                            'seasonal_order': (2, 0, 2, 7)
                                           },
             'O_UNIT_SARIMAX': {'order': (0, 1, 0),
                                'seasonal_order': (1, 0, 2, 7)
                                },
             'O_UNIT_SARIMAX_LOG': {'order': (2, 1, 1),
                                    'seasonal_order': (2, 0, 2, 7)}
                                    }

        """

        sarimax_dict = {}
        for col in sarimax_columns:
            col_without_days = col.split("(", 1)[0][:-1]
            sarimax_parameters = [int(char) for char in col if char.isdigit()]
            order = tuple(sarimax_parameters[:3])
            seasonal_order = tuple(sarimax_parameters[3:])
            sarimax_dict[col_without_days] = {
                "order": order,
                "seasonal_order": seasonal_order,
            }

        return sarimax_dict

    def _extract_SARIMAX_parameters(self, sarimax_dict, key):
        """
        Extracts order and seasonal order from SARIMAX dictionary to use while fitting the SARIMAX model.

        input:
            {'O_NEW_CUSTOMER_SARIMAX': {'order': (1, 1, 1),
                                        'seasonal_order': (1, 0, 2, 7)
                                        ,
             'O_NEW_CUSTOMER_SARIMAX_LOG': {'order': (3, 1, 1),
                                            'seasonal_order': (2, 0, 2, 7)
                                           },
             'O_UNIT_SARIMAX': {'order': (0, 1, 0),
                                'seasonal_order': (1, 0, 2, 7)
                                },
             'O_UNIT_SARIMAX_LOG': {'order': (2, 1, 1),
                                    'seasonal_order': (2, 0, 2, 7)}
                                    }
            key: 'O_UNIT_SARIMAX'

        output:
            order: (0, 1, 0)
            seasonal_order: (1, 0, 2, 7)

        """

        order = sarimax_dict[key]["order"]
        seasonal_order = sarimax_dict[key]["seasonal_order"]

        return order, seasonal_order

    def _extract_SMA_parameters(self, sma_columns, key):
        """
        Extracts a list of days from a list of SMA columns for key, i.e O_UNIT or O_NEW_CUSTOMER.

        input:
            sma_columns: ['O_NEW_CUSTOMER_SMA_DAY_5',
                          'O_NEW_CUSTOMER_SMA_DAY_6',
                          'O_NEW_CUSTOMER_SMA_DAY_7',
                          'O_NEW_CUSTOMER_SMA_DAY_8',
                          'O_UNIT_SMA_DAY_5',
                          'O_UNIT_SMA_DAY_6',
                          'O_UNIT_SMA_DAY_7',
                          'O_UNIT_SMA_DAY_8'
                         ]
            key: 'O_UNIT'

        output:
            [5, 6, 7, 8]

        """

        self.seasonal_terms = sorted(
            [col for col in sma_columns if "SMA" in col.upper() and key in col.upper()]
        )

        sma_days = sorted([int(col.rpartition("_")[2]) for col in self.seasonal_terms])

        return sma_days

    def _fit_SARIMAX(self, sarimax_columns, log=False):
        """
        Fits the SARIMAX model. If log=Ture, the function takes the log of data and fit SARIMAX on that data.

        """

        key = self.key_variable + "_SARIMAX"

        if not log:
            df = self.df[self.key_variable]
        else:
            key = key + "_LOG"
            df = ccurve_transformation(self.df[self.key_variable])

        sarimax_dict = self._create_SARIMAX_dict(sarimax_columns)
        order, seasonal_order = self._extract_SARIMAX_parameters(sarimax_dict, key)

        # If exog is passed, fit the SARIMAX to the residual
        if self.exog:
            df = self.residual_calculation(df, self.df[self.exog])

        if log:
            self.pred_var_name_log = key + " " + str(order) + " " + str(seasonal_order)
            pred_var_name = self.pred_var_name_log
        else:
            self.pred_var_name = key + " " + str(order) + " " + str(seasonal_order)
            pred_var_name = self.pred_var_name

        model = SARIMAX(df, order=order, seasonal_order=seasonal_order)
        results = model.fit()
        predictions = results.predict()

        self.df[pred_var_name] = predictions.values

    def _fit_SARIMAX_models(self, sarimax_columns):
        """
        Fits both regular and log SARIMAX model.

        """

        self._fit_SARIMAX(sarimax_columns)
        self._fit_SARIMAX(sarimax_columns, log=True)

    def _fit_sma(self, day):
        """
        Generate simple moving average columns.


        """

        df = self.df[self.key_variable]
        df.index.freq = "D"
        self.df[self.key_variable + "_SMA_DAY_" + str(day)] = (
            df.rolling(window=day, min_periods=1).mean().shift(1).fillna(df)
        )

    def _generate_sma_columns(self, sma_columns):
        """
        Generates simple moving average columns that exist in the original data but not in the refresh data
        by using the sma_days list, which is created by comparing the original data and refresh data.

        """

        sma_days = self._extract_SMA_parameters(sma_columns, self.key_variable)

        for day in sma_days:
            self._fit_sma(day)

    def generate_required_columns(self, sarimax_columns, sma_columns):
        """
        Generates columns for the refresh data. These are the columns that exist in the original data but not in the refresh data.


        input:
            sarimax_columns: ['O_NEW_CUSTOMER_SARIMAX (1, 1, 1) (1, 0, 2, 7)',
                              'O_NEW_CUSTOMER_SARIMAX_LOG (3, 1, 1) (2, 0, 2, 7)',
                              'O_UNIT_SARIMAX (0, 1, 0) (1, 0, 2, 7)',
                              'O_UNIT_SARIMAX_LOG (2, 1, 1) (2, 0, 2, 7)'
                             ]

            sma_columns: ['O_NEW_CUSTOMER_SMA_DAY_5',
                          'O_NEW_CUSTOMER_SMA_DAY_6',
                          'O_NEW_CUSTOMER_SMA_DAY_7',
                          'O_NEW_CUSTOMER_SMA_DAY_8',
                          'O_UNIT_SMA_DAY_5',
                          'O_UNIT_SMA_DAY_6',
                          'O_UNIT_SMA_DAY_7',
                          'O_UNIT_SMA_DAY_8'
                         ]

         output:
          - The following columns for new customer model: 'O_NEW_CUSTOMER_SARIMAX (1, 1, 1) (1, 0, 2, 7)',
                                                          'O_NEW_CUSTOMER_SARIMAX_LOG (3, 1, 1) (2, 0, 2, 7)',
                                                          'O_NEW_CUSTOMER_SMA_DAY_5', 'O_NEW_CUSTOMER_SMA_DAY_6',
                                                          'O_NEW_CUSTOMER_SMA_DAY_7', 'O_NEW_CUSTOMER_SMA_DAY_8',
                                                          'O_NEW_CUSTOMER_SEASONALITY', 'O_NEW_CUSTOMER_TREND',
                                                          'O_NEW_CUSTOMER_RESIDUAL', 'O_NEW_CUSTOMER_SEASONALITY_LOG',
                                                          'O_NEW_CUSTOMER_TREND_LOG', 'O_NEW_CUSTOMER_RESIDUAL_LOG'

          - The following columns for sales model: 'O_UNIT_SARIMAX (0, 1, 0) (1, 0, 2, 7)',
                                                   'O_UNIT_SARIMAX_LOG (2, 1, 1) (2, 0, 2, 7)',
                                                   'O_UNIT_SMA_DAY_5', 'O_UNIT_SMA_DAY_6',
                                                   'O_UNIT_SMA_DAY_7', 'O_UNIT_SMA_DAY_8',
                                                   'O_UNIT_SEASONALITY', 'O_UNIT_TREND',
                                                   'O_UNIT_RESIDUAL', 'O_UNIT_SEASONALITY_LOG',
                                                   'O_UNIT_TREND_LOG', 'O_UNIT_RESIDUAL_LOG'

        """

        print("Generating SARIMAX columns.")
        self._fit_SARIMAX_models(sarimax_columns)
        print("End of SARIMAX columns genertion.")
        print("Generating SMA columns.")
        self._generate_sma_columns(sma_columns)
        print("End of SMA columns generation.")
        print("Generating decomposition columns (seasonality, trend, residual).")
        self.creating_var_func()
        print("End of decomposition columns generation.")

    def combine_previous_and_refresh_data(
        self, df_prev_seasonality, refresh_start, refresh_end
    ):
        """
        Combines previous data with the refresh data.

        Methodology:
           - SARIMAX, SMA, trend seasonality and residual colums are calculated for the data starting from modeling_start and ending with refresh_end.
           - However, since the values had already been calculated in the previous study, the code gets these values from the previous study to be consistent. In other words, data starting from modeling_start and ending with modeling_end, or validation_end if exists, is retrieved from the previous study.
           - Then, newly calculated values for the refresh study is retrived for the period between refresh_start and refresh_end.
           - Lastly, these two dataframes are combined.

        """

        self.refresh_start = refresh_start
        self.refresh_end = refresh_end

        ## Retriving original data from previous modelling stack
        df_model_original = df_prev_seasonality[
            (df_prev_seasonality.index >= self.modelling_start)
            & (df_prev_seasonality.index <= self.modelling_end)
        ]

        ## Retrieving refresh data
        df_refresh = self.df[
            (self.df.index >= self.refresh_start) & (self.df.index <= self.refresh_end)
        ]

        ## Retriving validation data from previous modelling stack
        if self.validation_start:
            df_valid_original = df_prev_seasonality[
                (df_prev_seasonality.index >= self.validation_start)
                & (df_prev_seasonality.index <= self.validiation_end)
            ]
        else:
            df_valid_original = pd.DataFrame(columns=df_model_original.columns)

        ## Combining all data
        if df_valid_original.shape[0] != 0:
            df_model_valid_refresh = pd.concat(
                [df_model_original, df_valid_original, df_refresh], axis=0
            )
        else:
            df_model_valid_refresh = pd.concat([df_model_original, df_refresh], axis=0)

        self.df_model_original = df_model_original.copy()
        self.df_valid_original = df_valid_original.copy()
        self.df_refresh = df_refresh.copy()
        ## Keeping df (new columns created but not combined with the original data)
        self.df_all_not_combined_with_previous_data = self.df.copy()
        self.df = df_model_valid_refresh.copy()

        print(
            "Modeling period (df_model from previous data) min and max date: ",
            self.df_model_original.index.min(),
            self.df_model_original.index.max(),
        )
        if self.validation_start:
            print(
                "Validation period (df_valid from previous data) min and max date: ",
                self.df_valid_original.index.min(),
                self.df_valid_original.index.max(),
            )
        print(
            "Refresh period (df_refresh from refresh study) min and max date: ",
            self.df_refresh.index.min(),
            self.df_refresh.index.max(),
        )

        return df_model_valid_refresh