# author: Shiv Kumar Ganesh (IG)
# Modified: 3/11/2025 on previous code
# removed spend_rate_fix function
# added scaling factor based on HB modeling
# added function to get imp variables from model
# bypassed imp calculation when forward_opt is false to get value added imp 

import pandas as pd
import numpy as np
import statsmodels.tsa.filters.filtertools
import statsmodels.api as sm
import math
import re
import glob
import os
import sys
module_path = os.path.abspath(os.path.join('../../src/utils'))
if module_path not in sys.path:
    sys.path.append(module_path)

from scipy.optimize import differential_evolution, NonlinearConstraint
from scipy.optimize import minimize
from datetime import datetime, date, timedelta
from utils.save_excel import SaveExcelTemplated
import warnings
warnings.filterwarnings('ignore')

from dataclasses import dataclass, field
from typing import List

#preprocessing class
class ReadData:

    def read_stack(self, path_avg, path_cl, cluster, modeling_start_end_date):
        
        try:
            self.cluster=int(cluster)
        except:
            self.cluster=0
        
        cluster_filter=list(str(self.cluster))
        cluster_filter.append(self.cluster)
        
        df_AVG = pd.read_csv(path_avg)
        df_AVG['index'] = pd.to_datetime(df_AVG['index']) 
        df_AVG.set_index("index", inplace = True, drop= False)
        
        SARIMAX=[]
        for i in df_AVG.columns:
            if (re.match('O_UNIT_SARIMAX',i)):
                SARIMAX.append(i)
                
        if self.cluster in range(1,5):
            modeling_start_date_str, modeling_end_date_str = modeling_start_end_date
            model_start = datetime.strptime(modeling_start_date_str, '%Y-%m-%d').date()
            model_end = datetime.strptime(modeling_end_date_str, '%Y-%m-%d').date()
            days = model_end-model_start+timedelta(1)
            datelist = pd.date_range(model_end+timedelta(1), periods=days.days).tolist()
            new_dates = [i.strftime("%Y-%m-%d") for i in datelist]
            
            df_CL = pd.read_csv(path_cl)
            df_CL['index'] = pd.to_datetime(df_CL['index']) 
            df_CL.set_index("index", inplace = True, drop= False)
            df_CL_filtered = df_CL[df_CL['cluster'].isin(cluster_filter)]
            df_CL_filtered.reset_index(drop=True, inplace=True)
            df_AVG = df_AVG[(df_AVG['index'] >= pd.to_datetime(model_start)) & (df_AVG['index'] <= pd.to_datetime(model_end))]
            df_CL_filtered = df_CL_filtered[(df_CL_filtered['index'] >= pd.to_datetime(model_start)) & (df_CL_filtered['index'] <= pd.to_datetime(model_end))]
            df_CL_filtered['index']=new_dates
            for i in df_CL_filtered.columns:
                for j in SARIMAX:
                    if (re.match('O_UNIT_SARIMAX ',i) and re.match('O_UNIT_SARIMAX ',j)):
                        df_CL_filtered.rename({i:j})
                    if (re.match('O_UNIT_SARIMAX_LOG ',i) and re.match('O_UNIT_SARIMAX_LOG ',j)):
                        df_CL_filtered.rename({i:j})
            df_AVG=df_AVG.append(df_CL_filtered)
            df_AVG=df_AVG.replace(np.nan, 0)
            df_AVG['index'] = pd.to_datetime(df_AVG['index']) 
            df_AVG.set_index("index", inplace = True, drop= False)
            
        return df_AVG
        
# each of the variable (media driver) used in the model has the below attributes
@dataclass
class ModelVariable:
    
    # the model results attributes for each variable
    model_var: str = ''
    spend_var: str = ''
    rate_var: str = ''
    converted_var: str = ''
    model_var_full: str = ''
    var_source: str = ''
    var_comps: List[float] = field(default_factory=list)
    var_head: str = '' 
        
    # the coeff and transformaiton values for each variable 
    var_coef: np.float64 = 0
    lag: int = 0
    halflife: float = 0
    inflection: float = 0
    scale: float = 0
    log: int = 0
    
    # means after transformation
    var_mean: float = 0 # var_mean
    s_curve_var_mean: float = 0 # for s_curve transformation
    k_scalar: float = 0 # for c_curve transformation
    
    # add the var_spend_sum
    var_spend_sum: float = 0 # the spend sum of the variable    
    opt_var_spend_sum: float = 0 # the optimized spend sum of the variable
    opt_multiplier: float = 0 # the optimized multiplier of spend for each variable
        
    # about contribution
    og_var_contribution: float = 0 # the original contribution for each variable 
    opt_var_contribution: float = 0 # the optimized contribution for each variable 
    media_budget_range: List[float] = field(default_factory=list) # the budget limits for each variable
    media_multiplier_idx: int = 999
        
# the model used in the model has the below attributes       
@dataclass
class ModelData:
    
    model_type: str = ''
    final_model_path: str = ''
    trans_path: str = ''
    granular_media_dict: dict = field(default_factory=dict)
    inc_contribution: float = 0
    asp_fpv: float = 0   
    opt_var_ls: list = field(default_factory=list)
    model_var_ls: list = field(default_factory=list)
    media_spend_sum_before: float = 0
    opt: float = 0 
    model_var_dict: ModelVariable = field(default_factory=lambda: ModelVariable())
        
class Optimizer:
    
    def __init__(self,
                df,
                forward_opt,
                transformation_method,
                final_model_path,
                trans_path,
                opt_start_end_date,
                modeling_start_end_date,
                granular_media_dict,
                media_range_dict,
                perc,
                asp_fpv,
                target_var,
                actual_df,
                cluster=None
                ):
        
        self.df = df
        
        #self.spend_rate_fix()
       
        self.forward_opt = forward_opt
        self.transformation_method = transformation_method 
        
        self.final_model_path = final_model_path
        self.trans_path = trans_path
        self.perc = perc
        self.asp_fpv = asp_fpv
        self.granular_media_dict = granular_media_dict
        self.media_range_dict = media_range_dict
        self.target_var = target_var
        try:
            self.cluster=int(cluster)
        except:
            self.cluster=0
        
        if cluster in range(1,5):
            self.cluster_opt = True
        else:
            self.cluster_opt = False
        self.actual_df=pd.DataFrame()
        
        self.DEFAULT_INC_CONTRIBUTION = 175985
        self.DEFAULT_K_CONSTANT = 0.2
        self.inc_contribution=self.DEFAULT_INC_CONTRIBUTION
        #update the self.df to the simulated future dataframe if forward_opt = True
        self.update_df()
        
        # reformat the optimization start and end dates
        self.opt_start_date_str, self.opt_end_date_str = opt_start_end_date
        self.opt_start_date = pd.to_datetime(self.opt_start_date_str)
        
        self.opt_end_date = pd.to_datetime(self.opt_end_date_str)
        
        # get the index of the optimization start, end dates from the df

        # reformat the transformation start and end dates
        self.modeling_start_date_str, self.modeling_end_date_str = modeling_start_end_date
        self.modeling_start_date = pd.to_datetime(self.modeling_start_date_str)
        self.modeling_end_date = pd.to_datetime(self.modeling_end_date_str)
        
        
        
        
        
        # initiate the model_var_dict, which includes the attributes for all variables in the modeling
        self.model_var_dict = {}
        
        # create the folder to export all the optimization results
        self.result_folder = self.create_results_folder()
        self.create_optimization_log()
        
        # construct and update the dict to save all the data for the model
        self.OPTIMIZATION_DICT = self.construct_model_data_dict()
        
        # if cluster opt = True then only scaling is done
        if self.cluster_opt==True:
            self.get_ratio(model_data = self.OPTIMIZATION_DICT['1'])
            self.min_max_scaling(model_data = self.OPTIMIZATION_DICT['1'])
            self.scaled_spends_imps_rates(model_data = self.OPTIMIZATION_DICT['1'])
            
        
         # init the dataframes for the optimization and transformation
        self.custom_df, self.trans_df = self.initiate_custom_trans_dataframes(model_data = self.OPTIMIZATION_DICT['1'])
        if self.cluster_opt==False:
            self.get_opt_start_end_row(self.trans_df)
                    
        
        self.update_model_data_dict(model_data = self.OPTIMIZATION_DICT['1'])
        
       
        
        
            
      

        # init the multiplier for the budget for each media driver
        self.x0 = [1] * len(self.OPTIMIZATION_DICT['1'].model_var_ls)
        self.bnds = self.get_bnds()
        
        # calculate the incremental contribution from model
        self.inc_model = self.calculate_model_contribution()  
        # display historical dataframe for reference, only calculate the historical attributes
        self.get_optimization_df(only_calculate_hist_attributes = True)
        
        # update the lower and upper limits
        self.total_lower_limit, self.total_upper_limit = self.display_total_budget_lower_upper_limits()

        self.cons = {'type' : 'ineq', 'fun' : self.media_sum_before_after}
        
    #1 make function
    def get_opt_start_end_row(self,df_x):
        self.opt_start_row = df_x.index.get_loc(self.opt_start_date)
        self.opt_end_row = df_x.index.get_loc(self.opt_end_date)
        
        
    #1 end function
    # fixing spends and rates
    '''def spend_rate_fix(self):
        #fixing spends
        for i in self.df.columns:
            for j in self.df.index:
                if (re.match('RATE',i)):
                    if(re.match('ON',i[5:])or re.match('OFF',i[5:]) or re.match('IN',i[5:])):
                        if (self.df.loc[j,"M"+i[4:]+'_SPEND']==0):
                            if(self.df.loc[j,"M"+i[4:]+'_IMP']!=0):
                                self.df.loc[j,"M"+i[4:]+'_SPEND']=self.df.loc[j,"M"+i[4:]+'_SPEND_CALC']
                    else:
                        if(i[-3:]=='CLK'):
                            x="M"+i[4:]
                            if (self.df.loc[j,x[:-3]+'SPEND']==0):
                                if(self.df.loc[j,"M"+i[4:]]!=0):
                                    self.df.loc[j,x[:-3]+'SPEND']=self.df.loc[j,x[:-3]+'SPEND_CALC']
                                
        #fixing rates
        for i in self.df.columns:
            if re.match(r'RATE', i):
                suffix = i[5:]  # Extract everything after "RATE_"
                
                if re.match(r'ON', suffix) or re.match(r'OFF', suffix) or re.match(r'IN', suffix):
                    base_col = "M" + suffix  # Base name (e.g., M_OFF_DIS_DSP_CTV_SUM_IMP)
                    spend_col = base_col.replace("_IMP", "_SPEND")  # Replace _IMP with _SPEND
                    
                    if spend_col in self.df.columns and base_col in self.df.columns:
                        new_col_name = "RATE" + suffix.replace("_IMP", "")  # Remove _IMP from the new column name
                        self.df[new_col_name] = self.df[spend_col] / self.df[base_col]

                elif i.endswith('CLK'):
                    base_col = "M" + i[4:]  # Construct base column name
                    spend_col = base_col[:-3] + 'SPEND'  # Replace 'CLK' with 'SPEND'
                    
                    if spend_col in self.df.columns and base_col in self.df.columns:
                        self.df[i] = self.df[spend_col] / self.df[base_col]

        self.df = self.df.fillna(0)'''

    
    
    # function to create cluster dates (future dates with same number of months as modeling time frame)
    def cluster_dates(self):
        # creating cluster start and end dates
#         if cluster_opt == True:
        self.model_start = datetime.strptime(self.modeling_start_date_str, '%Y-%m-%d').date()
        self.model_end = datetime.strptime(self.modeling_end_date_str, '%Y-%m-%d').date()
        self.cluster_start_date=self.model_end+timedelta(1)
        days= self.model_end-self.model_start+timedelta(1)
        self.cluster_end_date=self.model_end+days
        # reformat cluster start and end date
        self.cluster_start_date=pd.to_datetime(self.cluster_start_date)
        self.cluster_end_date=pd.to_datetime(self.cluster_end_date)
        
        df_train = self.df[(self.df['index'] >= self.modeling_start_date) & (self.df['index'] <= self.modeling_end_date)]
        df_test = self.df[(self.df['index'] >= self.cluster_start_date) & (self.df['index'] <= self.cluster_end_date)]
        
        
        return df_train, df_test
    
    
    # get ratios to scale the cluster data
    def get_ratio(self,model_data):
        media=[]
        model_results_df = self.get_model_result_df(model_data)
        self.df['M_TOTAL_MEDIA_SPEND']=0
        for i in model_results_df['Variable Actual']:
            a=re.search(r'\d',i)
            media.append(i[0:a.start()])
        for i in media:
            self.df['M_TOTAL_MEDIA_SPEND']=self.df['M_TOTAL_MEDIA_SPEND']+self.df[i[:-4]+'SPEND']
        total_spends='M_TOTAL_MEDIA_SPEND'
        media.append(total_spends)
        media.append(self.target_var)
        df_train, df_test= self.cluster_dates()
        
        df_trans=pd.DataFrame(df_test[total_spends])
        df_trans[total_spends]=df_test[total_spends]
        for i in media:
            if (i==total_spends):
                continue
            else:
                if(i==self.target_var):
                    df_trans[i+'_ratio']=df_test[i]/df_test[self.target_var]
                else:
                    df_trans[i[:-4]+'ratio']=df_test[i[:-4]+'SPEND']/df_test[total_spends]
#         df_test.index=df_train.index
        df_trans.index=df_train.index
        return total_spends , df_trans,media
   

        
        
    #minmax scaling the cluster spends to average brand spends
    def min_max_scaling(self,model_data):
        df_temp=pd.DataFrame()
        df_train, df_test= self.cluster_dates()
        total_spends , df_trans,media=self.get_ratio(model_data)
        for i in df_test.columns:
            if (i!=total_spends and i!=self.target_var):
                continue
            else:
                slope = (df_train[i].max() - df_train[i].min()) / (df_test[i].max() - df_test[i].min())
                scaled_var=df_train[i].min()+slope*(df_test[i]-df_test[i].min())      
                df_temp[i]=scaled_var
        #app 1.2 
        CL_og_sp_sale_ratio=df_test[total_spends].mean()/df_test[self.target_var].mean()
        CL_scaled_sp_sale_ratio=df_temp[total_spends].mean()/df_temp[self.target_var].mean()
        df_temp[total_spends]=(df_temp[total_spends]*CL_og_sp_sale_ratio)/CL_scaled_sp_sale_ratio
        #app 1.2 end
        df_temp.index=df_train.index
        df_test.index=df_train.index
        df_test['index'] = df_train['index']
        self.get_opt_start_end_row(df_test)
        
        
        
        # slicing of  cluster dataframe in optimization time frame
        self.actual_df = df_test[((df_test['index'] >= self.opt_start_date) & (df_test['index'] <= self.opt_end_date))]
#         df_trans.index=df_train.index
        
        return df_temp, df_test
        
    # creating dataframe with scaled spends, rates and impressions           
    def scaled_spends_imps_rates(self,model_data):
        total_spends , df_trans,media=self.get_ratio(model_data)
        df_temp,df_test=self.min_max_scaling(model_data)
        
        for i in df_trans.columns:
            if (i==total_spends):
                continue
            else:
                if(i==self.target_var+'_ratio'):
                    df_temp[i[:-6]]=df_trans[i]*df_temp[self.target_var]
                else:
                    df_temp[i[:-5]+'SPEND']=df_trans[i]*df_temp[total_spends]
            
        #adding rates to stack; rates have been kept the same as that of the cluster
        for i in df_test.columns:
            if (re.match('RATE',i)):
                df_temp[i]=df_test[i]
        media.remove(total_spends)
        media.remove(self.target_var)
        #adding impression to stack; rates have been kept the same as that of the cluster
        for i in media:
            if(i[-4:-1]=='CLK'):
                df_temp[i[:-1]]=df_temp[i[:-4]+'SPEND']/df_temp['RATE'+i[1:-1]]
            else:
                df_temp[i[:-1]]=df_temp[i[:-4]+'SPEND']/df_temp['RATE'+i[1:-5]]
        df_temp=df_temp.fillna(0)
        #display(df_temp)
        return df_temp
    
    def construct_model_data_dict(self):
        model_data_dict = {}
        model_data_obj = ModelData()
        model_data_obj.final_model_path = self.final_model_path
        model_data_obj.trans_path = self.trans_path
        model_data_obj.model_type = Optimizer.get_model_type(self.final_model_path)
        model_data_obj.granular_media_dict = self.granular_media_dict
        model_data_obj.inc_contribution = self.inc_contribution
        model_data_obj.asp_fpv = self.asp_fpv
        model_data_obj.model_var_dict = self.model_var_dict
        model_data_dict['1'] = model_data_obj
        return model_data_dict
    
    def update_model_data_dict(self, model_data):
        model_results_df = self.get_model_result_df(model_data)
        self.update_model_result_variables(model_results_df, model_data)
        #print(model_results_df)
        self.update_inc_contribution(model_data)
        self.update_asp_fpv(model_data)
        self.update_granular_media_variables(model_data)
        model_data.opt_var_ls = self.get_opt_variable_ls(model_data)
        model_data.model_var_ls = self.get_model_variable_ls(model_data)
        self.update_media_multiplier_idx(model_data)
        self.update_variable_transformation_values(model_data)
        #display(model_data)
        model_data.media_spend_sum_before =  sum([model_data.model_var_dict[var].var_spend_sum for var in model_data.model_var_ls]) * self.perc
        
    def get_per_model_simulated_dataframe(self, final_model_path):
        model_type = Optimizer.get_model_type(final_model_path)
        simulation_folder = final_model_path.rsplit('/', 2)[0]
        simulation_path = os.path.join(simulation_folder, 'simulation_results', 'Updated_Stack_df.csv') 
        if os.path.isfile(simulation_path):
            simulation_df = pd.read_csv(simulation_path)
            return simulation_df
        else:
            raise NameError('Future dataframe for {} model is not available, please run simulator first!\n'.format(model_type))
    
    def update_df(self):
        if self.forward_opt:
            print('Forward optimization is in use!\n')
            simulation_df = self.get_per_model_simulated_dataframe(self.final_model_path) 
            simulation_df['index'] = pd.to_datetime(simulation_df['index']) 
            simulation_df.set_index('index', inplace = True, drop= False)
            self.df = simulation_df
        else:
            print('Backward optimization is in use!\n')
    
    def get_bnds(self):
        spend_var_ls = []
        for var in self.OPTIMIZATION_DICT['1'].model_var_ls:
            spend_var =  self.OPTIMIZATION_DICT['1'].model_var_dict[var].spend_var
            spend_var_ls.append(spend_var)
        bnds = [tuple(self.media_range_dict[spend_var]) for spend_var in spend_var_ls]
        return bnds
        
    @staticmethod
    def parse_var_str(var_str):
        model_var_obj = ModelVariable()
        model_var_obj.model_var = var_str
        parts = var_str.split("_")
        if len(parts) >= 5:
            model_var_obj.lag = int(float(parts[-1]))
            model_var_obj.halflife = float(parts[-4])
            model_var_obj.inflection = float(parts[-3])
            model_var_obj.scale = float(parts[-2])
            model_var_obj.log = 0  
            model_var_obj.model_var = "_".join(parts[:-4])
            model_var_obj.spend_var = Optimizer.get_spend_var(model_var_obj.model_var)
            model_var_obj.imp_var = Optimizer.get_imp_var(model_var_obj.model_var)
                    
        return model_var_obj
            
    @staticmethod
    def get_spend_var(var):
        spend_var = ''
        if var.startswith('M_') and (var.rsplit('_', 1)[-1].upper() != 'SPEND'):
            spend_var = var.replace('VIEW_IMP', 'SPEND')
            spend_var = spend_var.replace('CLK', 'SPEND')
            spend_var = spend_var.replace('IMP', 'SPEND')
        return spend_var
    @staticmethod
    def get_imp_var(var):
        imp_var = ''
        if var.startswith('M_') and (var.rsplit('_', 1)[-1].upper() != 'SPEND'):
          imp_var = var           
        return imp_var 
        
    @staticmethod
    def get_rate_var(var):
        rate_var = ''
        parts = var.split('_')

        if var.startswith('M_'):
            if parts[-1].upper() == 'IMP':  # Handles *_IMP cases
                rate_var = 'RATE_' + '_'.join(parts[1:-1])  # Remove 'M_' and 'IMP'
            elif parts[-1].upper() == 'CLK':  # Handles *_CLK cases
                rate_var = 'RATE_' + '_'.join(parts[1:])  # Remove 'M_' but keep full name
            else:
                rate_var = 'RATE_' + '_'.join(parts[1:])  # Default case (if no IMP/CLK suffix)
        
        return rate_var
    @staticmethod
    def get_converted_var(spend_var):
        converted_var = ''
        return spend_var.replace('_SPEND', '_CONVERTED')

    @staticmethod
    def lag_transformation(var, lag = 1):
        lag_variable = var.shift(lag)
        lag_variable = lag_variable.fillna(0)
        return lag_variable

    @staticmethod
    def halflife_transformation(var, halflife= 1):
        retention = np.exp(math.log(0.5)/halflife)        
        transformed_var = var * (1 - retention)
        transformed_var = transformed_var.fillna(0)
        transformed_var = statsmodels.tsa.filters.filtertools.recursive_filter(transformed_var, retention)
        return transformed_var
    
    @staticmethod
    def s_curve_transformation(var_mean,transformed_var, scale= 1, inflection= 1):
        transformed_var_scaled = transformed_var/var_mean
        saturation_term = scale * (inflection - transformed_var_scaled)
        scurve_var = 1/(1+np.exp(saturation_term))-1/(1+np.exp(scale * inflection))
        s_curve_var_mean = scurve_var.mean()
        return s_curve_var_mean
    @staticmethod
    def s_curve_transformation_inverse(var_mean, scurve_var_mean, transformed_var, scale= 1, inflection= 1):
        transformed_var_scaled = transformed_var/var_mean
        saturation_term = scale * (inflection - transformed_var_scaled)
        scurve_var = 1/(1+np.exp(saturation_term))-1/(1+np.exp(scale * inflection))
        transformed_var = scurve_var * var_mean / scurve_var_mean
        return transformed_var
    
    def get_k_scalar(self, var_mean, var):
        # get the k_scalar required for the c_curve transformation
        k_scalar = (max(var) * self.DEFAULT_K_CONSTANT)/var_mean
        return k_scalar
        
    @staticmethod
    def c_curve_transformation(var_mean, k_scalar, var):
        transformed_var =  np.log(var/(k_scalar * var_mean) + 1)
        return transformed_var
    
    @staticmethod
    def get_model_type(final_model_path):
        if 'sale' in final_model_path.lower():
            model_type = 'UNIT_SALES'
        elif 'customer' in final_model_path.lower():
            model_type = 'NEW_CUSTOMER'
        else:
            model_type = 'New Model Type'
        return model_type

    def update_asp_fpv(self, model_data):
        asp_fpv = model_data.asp_fpv
        model_type = model_data.model_type
        if not asp_fpv:
            if model_type == 'NEW_CUSTOMER':
                price_col = 'PRICE_NEW_CUSTOMER_OMNI'
            else:
                price_col = 'PRICE'
            if price_col in self.custom_df.columns.str.upper():
                asp_fpv = round((self.custom_df[price_col].loc[self.custom_df[price_col] != 0]).mean(), 2)
                if asp_fpv > 0:
                    print('asp_fpv = average of {} during optimization period: {}, please overwrite if necessary!\n'.format(price_col, asp_fpv))
                else:
                    asp_fpv = round((self.trans_df[price_col].loc[self.trans_df[price_col] != 0]).mean(), 2)
                    print('asp_fpv = average of {} during modeling period: {}, please overwrite if necessary!\n'.format(price_col, asp_fpv))
                model_data.asp_fpv = asp_fpv
            else:
                raise NameError('column {} does not exist at stack dataset! Please provide asp_fpv value!\n'.format(price_col))
                
    def update_inc_contribution(self, model_data):
        inc_contribution = model_data.inc_contribution
        model_type = model_data.model_type
        if not inc_contribution:
            model_folder = model_data.final_model_path.rsplit('/', 2)[0]
            model_path = os.path.join(model_folder, 'WMC_{}_{}.csv'.format(self.opt_start_date_str, self.opt_end_date_str))
            if os.path.isfile(model_path):
                model_result_df = pd.read_csv(model_path)
                model_data.inc_contribution = int(model_result_df[model_result_df['Display Level'] == 'Total Incremental']['Total Contribution'].values[0].replace(',', ''))
                print('inc_contribution is read from model_obj.visualize_ROAS between {} and {}: {}, please overwrite if necessary!\n'.format(self.opt_start_date_str, self.opt_end_date_str, model_data.inc_contribution))
            else:
                simulation_folder = os.path.join(model_folder, 'simulation_results')
                if os.path.isdir(simulation_folder):
                    simulator_result_path = os.path.join(simulation_folder, 'Simulation_Model_result.xlsx')
                    simulation_log_path = os.path.join(simulation_folder, 'Simulation_log.xlsx')
                    if os.path.isfile(simulator_result_path) and os.path.isfile(simulation_log_path):
                        simulator_result_df = pd.read_excel(simulator_result_path)
                        model_data.inc_contribution = int(simulator_result_df[simulator_result_df['Media'] == 'Total']['New Contribution'].values[0])
                        simulation_log_df = pd.read_excel(simulation_log_path) 
                        simulation_start = simulation_log_df['simulation_start_date'].values[0]
                        simulation_end = simulation_log_df['simulation_end_date'].values[0]
                        print('inc_contribution is the total contribution from simulation between {} and {}: {}, please overwrite if necessary!\n'.format(simulation_start, simulation_end, model_data.inc_contribution))
                else:
                    model_data.inc_contribution = self.DEFAULT_INC_CONTRIBUTION
                    print('inc_contribution = {} by default, please overwrite if necessary!\n'.format(self.DEFAULT_INC_CONTRIBUTION))
            
    # get the dataframe for the model results including the variable coefficients
    def get_model_result_df(self, model_data):
        final_model_path = model_data.final_model_path
        try:    
            model_results_df = pd.read_excel(final_model_path)[['Variable Actual', 'Coefficient']]
            
        except:
            model_results_df = pd.read_excel("\\\\?\\"+os.path.abspath(final_model_path))[['Variable Actual', 'Coefficient']]
        WMC_vars = model_results_df[model_results_df['Variable Actual'].str.startswith('M_')].reset_index(drop= True)
        WMC_vars.set_index('Variable Actual', inplace = True, drop= True)
        WMT_vars = model_results_df[model_results_df['Variable Actual'].str.startswith('M_WMT')].reset_index(drop= True)
        for i in WMT_vars['Variable Actual']:
            WMC_vars.drop(index=i,axis=0,inplace=True)
        WMC_vars.reset_index(drop=False, inplace=True)
        return WMC_vars

    def get_media_budget_range(self, spend_var):
        if spend_var in self.media_range_dict:
            media_budget_range = self.media_range_dict[spend_var]
            return media_budget_range
    
    def get_var_spend_sum(self, spend_var):
        if spend_var in self.custom_df.columns.str.upper():
            return self.custom_df[spend_var].sum()
     
    def update_media_multiplier_idx(self, model_data):
        model_var_dict = model_data.model_var_dict
        model_var_ls = model_data.model_var_ls
        for var in model_var_ls:
            model_var_dict[var].media_multiplier_idx = model_var_ls.index(var) + 1
            
    def get_opt_variable_ls(self, model_data):
        """
        The purpoes of this function is to get the list of variables which will be used for optimization
        it includes all or the subset of model variables
        """
        model_var_dict = model_data.model_var_dict
        opt_var_ls = [var for var in model_var_dict if ((model_var_dict[var].spend_var in self.media_range_dict) or (var in self.granular_media_dict)) and model_var_dict[var].var_source != 'singular']
        return opt_var_ls
    
    def get_model_variable_ls(self, model_data):
        """
        The purpoes of this function is to get the list of variables which will be used for optimization
        it includes model variables and granular variables, but not the combined variable/s
        """
        model_var_dict = model_data.model_var_dict
        model_var_ls = [var for var in model_var_dict if model_var_dict[var].spend_var in self.media_range_dict and model_var_dict[var].var_source != 'combined']
        return model_var_ls
    
    def create_results_folder(self):
        #this function uses sets for maintaining versions. Sets are unordered by nature but in python implementation converting lists to sets results in ordered sets, this may change in the future
        folder = os.path.abspath(os.path.join(self.final_model_path.rsplit('/', 2)[0], 'optimization_results'))
        if not os.path.isdir(folder):
            os.mkdir(folder)
        subdirs = [os.path.join(folder, o) for o in os.listdir(folder) if os.path.isdir(os.path.join(folder,o))]
        if not subdirs:
            if self.cluster_opt==True:
                result_folder = os.path.abspath(os.path.join(folder, 'optimization_outputs_'+str(self.cluster)+'_v1'))
            else:
                result_folder = os.path.abspath(os.path.join(folder, 'optimization_outputs_v1'))
        else:
            max_version=[0]
            if self.cluster_opt==True:
                for folder_name in subdirs:
                    try:
                        cl_ver = int(folder_name.split('_'+str(self.cluster)+'_')[-1].replace("v", ""))
                        max_version.append(cl_ver)
                    except:
                        continue
            else:
                max_version = [int(folder_name.split('_')[-1].replace("v", "")) for folder_name in subdirs]
            if self.cluster_opt==True:
                max_version = 'optimization_outputs_'+str(self.cluster)+'_v' + str(list(set(max_version))[-1] + 1)
            else:
                max_version = 'optimization_outputs_v' + str(list(set(max_version))[-1] + 1)
            result_folder = os.path.abspath(os.path.join(folder, max_version))
        result_folder = os.path.abspath(result_folder)
        if not os.path.isdir(result_folder):
            os.mkdir(result_folder)
        return result_folder

    def create_optimization_log(self):
        # create the dataframe for the optimization duration, start date, end_date
        optimization_log_df = pd.DataFrame({'optimization_start_date':[self.opt_start_date_str], 
                                            'optimization_end_date':[self.opt_end_date_str],
                                             'transformation_start_date': [self.modeling_start_date_str],
                                             'transformation_end_date': [self.modeling_end_date_str]}, index = [0])
        result_folder = self.result_folder
        if not os.path.isdir(result_folder):
            os.mkdir(result_folder)
        excel_obj = SaveExcelTemplated(os.path.join(result_folder, "Optimization_Log.xlsx"))   
        excel_obj.add_worksheet(optimization_log_df, 'Optimization Log', optimization_log_df.columns)
        excel_obj.save_worksheet()
        
    def initiate_custom_trans_dataframes(self,model_data):
        # setting the condition of cluster opt to create custom df and trans df
        if self.cluster_opt==True:
            df_temp=self.scaled_spends_imps_rates(model_data)
            df_temp=df_temp.reset_index()
            
            custom_df = df_temp[((df_temp['index'] >= self.opt_start_date) & (df_temp['index'] <= self.opt_end_date))]
            trans_df = df_temp[((df_temp['index'] >= self.modeling_start_date) & (df_temp['index'] <= self.modeling_end_date))]
        else:
            custom_df = self.df[((self.df['index'] >= self.opt_start_date) & (self.df['index'] <= self.opt_end_date))]
            trans_df = self.df
       
        return custom_df, trans_df
    
    
    # update the dict of all variable attributes from model_results_df
    def update_model_result_variables(self, model_results_df, model_data):
        model_var_dict = model_data.model_var_dict
        for var_str in model_results_df['Variable Actual'].values:
            model_var_obj = Optimizer.parse_var_str(var_str)
            model_var = model_var_obj.model_var
            if model_var not in model_var_dict:
                model_var_dict[model_var] = model_var_obj
            spend_var = model_var_dict[model_var].spend_var
            imp_var = model_var_dict[model_var].imp_var
            var_coef = model_results_df[model_results_df['Variable Actual'] == var_str]['Coefficient'].values[0]
            model_var_dict[model_var].var_coef = var_coef
            model_var_dict[model_var].model_var_full = var_str
            model_var_dict[model_var].rate_var = Optimizer.get_rate_var(model_var)
            model_var_dict[model_var].var_source = 'model'
            model_var_dict[model_var].media_budget_range = self.get_media_budget_range(spend_var)
            model_var_dict[model_var].var_spend_sum = self.get_var_spend_sum(spend_var)
        
    # update the dict of all variables from the granular_media_dict
    def update_granular_media_variables(self, model_data):
        model_var_dict = model_data.model_var_dict
        granular_media_dict = model_data.granular_media_dict
        for var in granular_media_dict:
            var_comps = granular_media_dict[var]
            for comp in var_comps:
                if comp not in model_var_dict:
                    model_var_obj = ModelVariable()
                    model_var_obj.model_var = comp
                    model_var_obj.rate_var = Optimizer.get_rate_var(comp)
                    spend_var = Optimizer.get_spend_var(comp)
                    model_var_obj.spend_var = spend_var
                    model_var_obj.converted_var = Optimizer.get_converted_var(spend_var)
                    model_var_obj.var_source = 'singular'
                    model_var_obj.media_budget_range = self.get_media_budget_range(spend_var)
                    model_var_obj.var_spend_sum = self.get_var_spend_sum(spend_var)
                    model_var_dict[comp] = model_var_obj
                model_var_dict[comp].var_head = var
            if var not in model_var_dict:
                model_var_obj = ModelVariable()
                model_var_obj.model_var = var
                model_var_obj.rate_var = Optimizer.get_rate_var(var)
                spend_var = Optimizer.get_spend_var(var)
                model_var_obj.spend_var = spend_var
                model_var_obj.imp_var = imp_var
                model_var_obj.converted_var = Optimizer.get_converted_var(spend_var)
                model_var_obj.var_source = 'combined'
                model_var_obj.media_budget_range = self.get_media_budget_range(spend_var)
                model_var_obj.var_spend_sum = sum([model_var_dict[comp].var_spend_sum for comp in var_comps])
                model_var_dict[var] = model_var_obj 
            elif var in model_var_dict:
                model_var_dict[var].var_source = 'combined'
            model_var_dict[var].var_comps = var_comps

    # display the lower and upper boundary for the optimized results
    def display_total_budget_lower_upper_limits(self):
        model_data = self.OPTIMIZATION_DICT['1']
        model_var_dict = model_data.model_var_dict
        opt_var_ls = model_data.opt_var_ls
        model_var_ls = model_data.model_var_ls
        if self.bnds:
            lower_limit = sum([model_var_dict[var].var_spend_sum * model_var_dict[var].media_budget_range[0] for var in model_var_ls])
            upper_limit = sum([model_var_dict[var].var_spend_sum * model_var_dict[var].media_budget_range[1] for var in model_var_ls])
            
            
        else:
            lower_limit = sum([model_var_dict[var].var_spend_sum for var in model_var_ls])
            upper_limit = sum([model_var_dict[var].var_spend_sum for var in model_var_ls])
        print('Optimized budget should be between ${:,.2f} and ${:,.2f}\n'.format(lower_limit, upper_limit))
        return lower_limit * self.perc , upper_limit * self.perc
    
    def validate_optimized_budget(self, total_opt_spend):
        if self.cluster_opt==False:
            if total_opt_spend >= self.total_lower_limit and total_opt_spend <= self.total_upper_limit:
                print('OPTIMIZED BUDGET of ${:,.2f} is within the lower, upper range of (${:,.2f}, ${:,.2f})\n'.format(total_opt_spend, self.total_lower_limit, self.total_upper_limit))

            else:
                print('WARNING! OPTIMIZED BUDGET of ${:,.2f} is out of the range of (${:,.2f}, ${:,.2f}), please decrease/increase the media bounds from media_range_dict\n'.format(total_opt_spend, self.total_lower_limit, self.total_upper_limit))


 # update var_mean, and s_curve_var_mean for variables from model 
 # we are calculating var_mean and s_curve_var_mean
    def update_variable_transformation_values(self, model_data):
        model_var_dict = model_data.model_var_dict
        opt_var_ls = model_data.opt_var_ls
        #og_imp_data = {}
        for var in opt_var_ls:
            lag = model_var_dict[var].lag
            halflife = model_var_dict[var].halflife
            scale = model_var_dict[var].scale
            inflection = model_var_dict[var].inflection
            var_comps = model_var_dict[var].var_comps
            # if the variable is a combined var, it has var_comps
            if not self.forward_opt:
                transformed_var_orig = self.trans_df[model_var_dict[var].imp_var]
            elif var_comps:
                transformed_var_orig = 0
                for comp in var_comps:
                    term = self.trans_df[model_var_dict[comp].spend_var]/self.trans_df[model_var_dict[comp].rate_var]
                    term = term.fillna(0)
                    transformed_var_orig += term

            else:
                if self.cluster_opt==False:
                    df_filtered = self.trans_df.copy()

                    transformed_var_orig = df_filtered[model_var_dict[var].spend_var]/df_filtered[model_var_dict[var].rate_var]

                else:
                    transformed_var_orig = self.trans_df[model_var_dict[var].spend_var]/self.trans_df[model_var_dict[var].rate_var]
                transformed_var_orig = transformed_var_orig.fillna(0)

            if lag != 0:
                transformed_var_orig = lag_transformation_no_numba(transformed_var_orig, int(lag))


            if halflife != 0:
                transformed_var_orig = halflife_transformation_no_numba(transformed_var_orig, halflife)
            
            var_mean = transformed_var_orig.mean()
            model_var_dict[var].var_mean = var_mean

            if self.transformation_method.upper() == 'S_CURVE':
                if (scale != 0) and (inflection != 0):
                    s_curve_var_mean = Optimizer.s_curve_transformation(var_mean, transformed_var_orig, scale, inflection)
                    model_var_dict[var].s_curve_var_mean = s_curve_var_mean
                    
            elif self.transformation_method.upper() == 'C_CURVE':
                k_scalar = self.get_k_scalar(var_mean, transformed_var_orig)
                model_var_dict[var].k_scalar = k_scalar


    
        
    def optimization_fn(self, x):
        total_contribution = 0
        model_data = self.OPTIMIZATION_DICT['1']
        model_var_dict = model_data.model_var_dict
        inc_contribution = model_data.inc_contribution
        opt_var_ls = model_data.opt_var_ls
        scaling_factor_arr = np.zeros(len(opt_var_ls))
        trans_df = self.trans_df
        scaled_df = pd.DataFrame()
        scaled_df['Date'] = trans_df['Date']
        scaled_df['Date'] = pd.to_datetime(trans_df['Date'])
        
    
        scaling_factor_arr = np.zeros(len(opt_var_ls))
        for i, var in enumerate(opt_var_ls):
            model_var = model_var_dict[var].model_var
            spend_var = model_var_dict[var].spend_var
            imp_var = model_var_dict[var].imp_var
            rate_var = model_var_dict[var].rate_var
            var_coef = model_var_dict[var].var_coef
            # transformation values
            lag = model_var_dict[var].lag
            halflife = model_var_dict[var].halflife
            inflection = model_var_dict[var].inflection
            scale = model_var_dict[var].scale
            var_comps = model_var_dict[var].var_comps
            media_multiplier_idx = model_var_dict[var].media_multiplier_idx
            if self.og_calculation == 1:
                transformed_var_solver = trans_df[model_var_dict[var].imp_var]
                transformed_var_orig = trans_df[spend_var].copy()
                
            elif var_comps:
                spend_vars = [model_var_dict[comp].spend_var for comp in var_comps]
                rate_vars = [model_var_dict[comp].rate_var for comp in var_comps]
                converted_vars = [model_var_dict[comp].converted_var for comp in var_comps]
                media_multiplier_idx_ls = [model_var_dict[comp].media_multiplier_idx for comp in var_comps]
                multipliers = [x[media_multiplier_idx - 1] for media_multiplier_idx in media_multiplier_idx_ls]
                
                self.trans_df[converted_vars] = self.trans_df[spend_vars].div(self.trans_df[rate_vars]).fillna(0)
                transformed_var_solver = np.dot(self.trans_df[converted_vars].values, multipliers)
                transformed_var_orig = self.trans_df[spend_vars].sum(axis=0)
            else:
                transformed_var_solver = (trans_df[spend_var].values * x[media_multiplier_idx - 1]) / trans_df[rate_var].values
                transformed_var_solver = np.nan_to_num(transformed_var_solver)
                transformed_var_orig = trans_df[spend_var].values
            #og_contribution_data[var] = transformed_var_solver
            if lag != 0:
                transformed_var_solver = lag_transformation_no_numba(transformed_var_solver, int(lag))

            if halflife != 0:
                transformed_var_solver = halflife_transformation_no_numba(transformed_var_solver, halflife)
            
            if self.transformation_method.upper() == 'S_CURVE':
                if (scale != 0) and (inflection != 0):
                    var_mean = model_var_dict[var].var_mean
                    scurve_var_mean = model_var_dict[var].s_curve_var_mean
                    transformed_var_solver = Optimizer.s_curve_transformation_inverse(var_mean, scurve_var_mean, transformed_var_solver, scale, inflection)
                    
            elif self.transformation_method.upper() == 'C_CURVE':
                var_mean = model_var_dict[var].var_mean
                k_scalar = model_var_dict[var].k_scalar
                transformed_var_solver = Optimizer.c_curve_transformation(var_mean, k_scalar, transformed_var_solver)
             # Vectorized scaling
            transf_var = transformed_var_solver
            min_val, max_val = np.min(transf_var), np.max(transf_var)
            scaling_factor = max_val - min_val if max_val > min_val else 1  # Prevent division by zero
            scaling_factor_arr[i] = scaling_factor
            transf_var_scaled = (transf_var - min_val) / scaling_factor
            transf_var_scaled = transf_var_scaled * var_coef
            scaled_df[var] = transf_var_scaled

        subset_df = scaled_df[((scaled_df['Date'] >= self.opt_start_date) & (scaled_df['Date'] <= self.opt_end_date))]

        for var in opt_var_ls:
            var_contribution = subset_df[var].sum()
        
            if self.og_calculation == 1:
                model_var_dict[var].og_var_contribution = var_contribution
            else:
                model_var_dict[var].opt_var_contribution = var_contribution
        
            total_contribution += var_contribution

        return -total_contribution / inc_contribution
    
    def actual_optimized_value(self, val):
        model_data = self.OPTIMIZATION_DICT['1']
        inc_contribution = model_data.inc_contribution
        return -inc_contribution * val
            
    def media_sum_before_after(self, x):
        sum_after = 0
        model_data = self.OPTIMIZATION_DICT['1']
        media_spend_sum_before = model_data.media_spend_sum_before
        model_var_dict = model_data.model_var_dict
        model_var_ls = model_data.model_var_ls
        for var in model_var_ls:
            var_spend_sum = model_var_dict[var].var_spend_sum
            spend_var = model_var_dict[var].spend_var
            multiplier = x[model_var_dict[var].media_multiplier_idx -1]
            var_sum_after = (self.custom_df[spend_var].copy() * multiplier).sum()
            sum_after += var_sum_after
        return media_spend_sum_before - sum_after

    def run_optimizer(self, global_opt, num_cores):
        if global_opt:
            # constraint: the result for the media_sum_before_after func will be between -0.1 and inf
            nlc = NonlinearConstraint(self.media_sum_before_after, -0.1, np.inf)
            solution = differential_evolution(self.optimization_fn, self.bnds, constraints = (nlc), seed = 1, workers = num_cores, tol = 0.01) 
        else:
            solution = minimize(self.optimization_fn, self.x0, bounds = self.bnds, method = 'SLSQP', constraints = [self.cons]) 
        print(solution['message'])
        return solution
    
    # calculate the spend, contribution, etc. for the modeling result
    def calculate_model_contribution(self):
        self.og_calculation = 1
        if not self.x0:
            model_data = self.OPTIMIZATION_DICT['1']
            opt_var_ls = model_data.opt_var_ls
            self.x0 = [1] * len(opt_var_ls)
        inc_model = self.actual_optimized_value(self.optimization_fn(self.x0))
        return inc_model
    
    # calculate the spend, contribution, etc. for the optimization results
    def calculate_optimization_contribution(self, global_opt, num_cores):
        self.og_calculation = 0
        solution = self.run_optimizer(global_opt, num_cores)
        inc_solver = self.actual_optimized_value(self.optimization_fn(solution['x']))
        self.update_optimization_results(solution)
        return inc_solver

    # update the opt spend, and other variables to the dict after running the optimization
    def update_optimization_results(self, solution):
        model_data = self.OPTIMIZATION_DICT['1']
        model_var_dict = model_data.model_var_dict
        model_var_ls = model_data.model_var_ls
        for var in model_var_ls:
            media_multiplier_idx = model_var_dict[var].media_multiplier_idx
            var_comps = model_var_dict[var].var_comps
            if media_multiplier_idx:
                opt_multiplier = solution['x'][media_multiplier_idx - 1]
                opt_var_spend_sum = model_var_dict[var].var_spend_sum * opt_multiplier
                model_var_dict[var].opt_multiplier = opt_multiplier
                model_var_dict[var].opt_var_spend_sum = opt_var_spend_sum
            
    # private function to get the file: contrib_df.csv
    def get_overall_contribution_df(self, inc_solver):

        inc_diff = inc_solver - self.inc_model
        pct_change = 100 * inc_diff/self.inc_model
        contrib_df = pd.DataFrame({'Incremental from model': [self.inc_model],
                                  'Maximized from Solver': [inc_solver],
                                  'Difference':[inc_diff],
                                   '%age change':[pct_change]
                                  })

        #file_path = os.path.join(self.result_folder, 'contrib_df.csv')   
        #contrib_df.to_csv(file_path)
#         print('Contribution result saved to: {}'.format(file_path))
#         display(contrib_df) 
        return contrib_df
    
    # private function to generate the optimization result including the singular variables for reference
    def get_singular_variable_optimization_df(self):
        
        model_data = self.OPTIMIZATION_DICT['1']
        model_var_dict = model_data.model_var_dict
        asp_fpv = model_data.asp_fpv
        model_var_ls = model_data.model_var_ls
        
        # values for og and opt
        spend_var_ls = [model_var_dict[var].spend_var for var in model_var_ls]
        og_spend_ls = [model_var_dict[var].var_spend_sum for var in model_var_ls]
        opt_spend_ls = [model_var_dict[var].opt_var_spend_sum for var in model_var_ls]
        pct_change = [(opt_spend_ls[i] - og_spend_ls[i])/og_spend_ls[i] * 100 for i in range(len(model_var_ls))]
        recommended_change_ls = [model_var_dict[var].opt_multiplier for var in model_var_ls]

        singular_optimization_df = pd.DataFrame({'Variable': spend_var_ls,
                                                 'Og Spends': og_spend_ls,
                                                 'Recommended Change':recommended_change_ls,
                                                 'Change %': pct_change,
                                                 'Opt Spends': opt_spend_ls,
                                                })
        
        singular_optimization_df.sort_values(by = ['Change %', 'Og Spends'], ascending = [False, False], ignore_index = True, inplace = True)
        singular_optimization_overall = pd.DataFrame({'Variable': ['Total'],
                                                      'Og Spends': sum(og_spend_ls),
                                                      'Opt Spends': sum(opt_spend_ls)})
        
        singular_optimization_df = singular_optimization_df.append(singular_optimization_overall, ignore_index = True).fillna('-')
        
        
        
        file_path = os.path.join(self.result_folder, 'singular_optimization_df.csv')   
        singular_optimization_df.to_csv(file_path)
#         print('Singular Optimization result saved to: {}\n'.format(file_path))
#         display(singular_optimization_df)
        return singular_optimization_df
    
     # private function to get the file: df_new.csv
    def get_optimization_df(self, only_calculate_hist_attributes): 
        model_data = self.OPTIMIZATION_DICT['1']
        model_var_dict = model_data.model_var_dict
        asp_fpv = model_data.asp_fpv
        opt_var_ls = model_data.opt_var_ls
        opt_spend_var_ls = [model_var_dict[var].spend_var for var in opt_var_ls]
        
        model_var_ls = model_data.model_var_ls
        model_spend_var_ls = [model_var_dict[var].spend_var for var in model_var_ls]
        # values for Og 
        og_spend_ls = [model_var_dict[var].var_spend_sum for var in opt_var_ls]
        og_contrib_ls = [model_var_dict[var].og_var_contribution for var in opt_var_ls]
        og_roas_ls = [(og_contrib_ls[i]/og_spend_ls[i]) * asp_fpv for i in range(len(opt_var_ls))]
        og_rev_ls = [og_contrib_ls[i] * asp_fpv for i in range(len(opt_var_ls))]
        # create the dataframe for df_new
        df_og_contribution = pd.DataFrame({'Variable': opt_spend_var_ls,
                                            'Og Spends': og_spend_ls,
                                            'Og Spends Share' : (og_spend_ls/(sum(og_spend_ls)))*100,
                                            'Og Contri.': og_contrib_ls,
                                            'Og RoAS': og_roas_ls,
                                            'Og Rev': og_rev_ls,
                                             })

        df_og_overall = pd.DataFrame({'Variable': ['Total'], 
                                    'Og Spends': sum(og_spend_ls)})
        # optimization_df = df_og_contribution.append(df_og_overall, ignore_index = True).fillna('-')
        optimization_df = pd.concat([df_og_contribution, df_og_overall], ignore_index = True).fillna('-')

        if not only_calculate_hist_attributes:   
            # values for Opt
            # variables exist in both opt_var_ls and model_var_ls
            non_singular_var_ls = list(set(opt_var_ls) & set(model_var_ls))
            opt_spend_ls = [model_var_dict[var].opt_var_spend_sum for var in non_singular_var_ls]
            opt_constrib_ls = [model_var_dict[var].opt_var_contribution for var in non_singular_var_ls]
            opt_roas_ls = [(opt_constrib_ls[i]/opt_spend_ls[i]) * asp_fpv for i in range(len(non_singular_var_ls))]
            opt_rev_ls = [opt_constrib_ls[i] * asp_fpv for i in range(len(non_singular_var_ls))]
            recommended_change_ls = [model_var_dict[var].opt_multiplier for var in non_singular_var_ls]
            pct_change_ls = [(recommended_change - 1) * 100 for recommended_change in recommended_change_ls]
            
            # 2. combined variables
            # variables exist in opt_var_ls, but not model_var_ls
            combined_var_ls = list(set(opt_var_ls) - set(model_var_ls))
            for var in combined_var_ls:
                var_comps = model_var_dict[var].var_comps
                opt_spend = sum([model_var_dict[var].opt_var_spend_sum for var in var_comps])
                opt_contrib = model_var_dict[var].opt_var_contribution
                opt_roas = (opt_contrib/opt_spend) * asp_fpv
                opt_rev = opt_contrib * asp_fpv
                og_spend = og_spend_ls[opt_spend_var_ls.index(model_var_dict[var].spend_var)]
                pct_change = (opt_spend - og_spend)/og_spend * 100
                recommended_change = 1 + pct_change/100
                opt_spend_ls.append(opt_spend)
                opt_constrib_ls.append(opt_contrib)
                opt_roas_ls.append(opt_roas)
                opt_rev_ls.append(opt_rev)
                pct_change_ls.append(pct_change)
                recommended_change_ls.append(recommended_change)
                
            # update variables with singular variables
            var_ls = non_singular_var_ls + combined_var_ls
            spend_var_ls = [model_var_dict[var].spend_var for var in var_ls]
            model_upper_ls = [model_var_dict[var].media_budget_range[1] for var in var_ls]
            model_lower_ls = [model_var_dict[var].media_budget_range[0] for var in var_ls]
            opt_contribution = pd.DataFrame({'Variable': spend_var_ls,
                                                'Recommended Change':recommended_change_ls,
                                                'Change %': pct_change_ls,
                                                'Opt Spends': opt_spend_ls,
                                                'Opt Spends Share' : (opt_spend_ls/(sum(opt_spend_ls)))*100,
                                                'Opt Contri.':opt_constrib_ls,
                                                'Opt RoAS': opt_roas_ls,
                                                'Opt Rev': opt_rev_ls,
                                                'Lower Bound': model_lower_ls,
                                                'Upper Bound': model_upper_ls
                                                 })
            opt_overall = pd.DataFrame({'Variable': ['Total'],
                                        'Opt Spends': sum(opt_spend_ls)})

            opt_contribution = pd.concat([opt_contribution, opt_overall], ignore_index = True)
            optimization_df = optimization_df.merge(opt_contribution, how = 'inner', left_on = 'Variable', right_on = 'Variable')

            optimization_df.sort_values(by = ['Change %','Og Spends'], ascending = [False, False], ignore_index = True, inplace = True)
            optimization_df = optimization_df.fillna('-')
            
            #file_path = os.path.join(self.result_folder, 'df_new.csv')   
            #optimization_df.to_csv(file_path)
            #print('Optimization result saved to: {}\n'.format(file_path))
            
            self.validate_optimized_budget(sum(opt_spend_ls)) 
#         display(optimization_df)
        return optimization_df
    
    # private function to get the file: roas_df.csv
    def get_roas_df(self, contrib_df, optimization_df): 
        model_data = self.OPTIMIZATION_DICT['1']
        asp_fpv = model_data.asp_fpv
        roas_df = pd.DataFrame()
        roas_df['Actual Sales'] = contrib_df['Incremental from model'] * asp_fpv
        roas_df['Optimized Sales'] = contrib_df['Maximized from Solver'] * asp_fpv
        roas_df['Actual RoAS'] = roas_df['Actual Sales'] / (optimization_df['Og Spends'].sum()/2)
        roas_df['Optimized RoAS'] = roas_df['Optimized Sales'] / (optimization_df['Opt Spends'].sum()/2)
        roas_df['% change RoAS'] = ((roas_df['Optimized RoAS'] - roas_df['Actual RoAS'])/roas_df['Actual RoAS'])*100
        #file_path = os.path.join(self.result_folder, 'roas_df.csv')   
        #roas_df.to_csv(file_path)
#         print('Overall Optimization result saved to: {}\n'.format(file_path))
#         display(roas_df)
        return roas_df
    
    # initiate the bound_custom dataframe for the bound, and head analysis
    def get_bound_custom_df(self, bound_start_end_date):
        ba_start_date, ba_end_date = bound_start_end_date
        ba_start_date = pd.to_datetime(ba_start_date)
        ba_end_date = pd.to_datetime(ba_end_date)
        # get the dataframe for the bound_head_analysis
        bound_df = self.df.copy()
        bound_custom_df = bound_df[((bound_df['index'] <= ba_end_date) & (bound_df['index'] >= ba_start_date))]
        return bound_custom_df

    # private function to get the statistics for the model variables, e.g. M_ON_DIS_AT_IMP
    def get_media_raw_df(self, bound_custom_df):
        model_data = self.OPTIMIZATION_DICT['1']
        model_var_dict = model_data.model_var_dict
        opt_var_ls = model_data.opt_var_ls
        spend_var_ls = [model_var_dict[var].spend_var for var in opt_var_ls]
        df_raw_media = bound_custom_df[opt_var_ls]
        raw_media_df = pd.DataFrame(df_raw_media.transpose().sum(axis = 1), columns = ['Total Media'])
        raw_media_df['Variable'] = spend_var_ls
        raw_media_df['Minimum'] = df_raw_media[df_raw_media !=0].transpose().min(axis = 1)
        raw_media_df['Maximum'] = df_raw_media.transpose().max(axis=1)
        raw_media_df['Average'] = df_raw_media.transpose().mean(axis=1)
        raw_media_df['Non-Zero Average'] = df_raw_media[df_raw_media != 0].transpose().mean(axis=1)
        raw_media_df['On Air Days'] = df_raw_media[df_raw_media != 0].transpose().count(axis=1)
        raw_media_df['Off-Air Days'] = df_raw_media[df_raw_media == 0].transpose().count(axis=1)
        raw_media_df.set_index( ['Variable'], inplace = True)
        return raw_media_df  

    ## private function to get the statistics for the spend variables, e.g. M_ON_DIS_AT_SPEND
    def get_media_spend_df(self, bound_custom_df):
        model_data = self.OPTIMIZATION_DICT['1']
        model_var_dict = model_data.model_var_dict
        opt_var_ls = model_data.opt_var_ls
        spend_var_ls = [model_var_dict[var].spend_var for var in opt_var_ls]
        df_spends = bound_custom_df[spend_var_ls]
        spend_df = pd.DataFrame(df_spends.transpose().sum(axis = 1), columns = ['Total Media'])
        spend_df.index.name = 'Variable'
        spend_df['Minimum'] = df_spends[df_spends != 0].transpose().min(axis=1)
        spend_df['Maximum'] = df_spends.transpose().max(axis = 1)
        spend_df['Average'] = df_spends.transpose().mean(axis = 1)
        spend_df['Non-Zero Average'] = df_spends[df_spends != 0].transpose().mean(axis = 1)  
        return spend_df

    # private function to get the CPI for each variable
    def get_cpi_df(self, raw_media_df, spend_df):
        cpi_df = pd.DataFrame()
        cpi_df['cpi'] = spend_df['Total Media'] / raw_media_df['Total Media']
        return cpi_df
    
    # get the s_curve_spend_point dataframe
    def get_s_curve_spend_point_df(self):
        try:    
            spend_point_df = pd.read_excel(self.trans_path, 'Spends Points')

        except:
            spend_point_df = pd.read_excel("\\\\?\\" + os.path.abspath(self.trans_path), 'Spends Points')

        spend_point_df['Variable'] = spend_point_df['Variable'].apply(lambda x: x.rsplit('_', 5)[0]).apply(Optimizer.get_spend_var)
        spend_point_df = spend_point_df[['Variable', 'Threshold Point', 'Inflection Point', 'Saturation Point']]
        spend_point_df.index = spend_point_df['Variable']
        return spend_point_df

    # private function to combine the dataframe required for the bound, headroom analysis
    def get_bound_analysis_df(self, spend_df, spend_point_df, raw_media_df, cpi_df, spend):
        model_data = self.OPTIMIZATION_DICT['1']
        model_var_dict = model_data.model_var_dict
        opt_var_ls = model_data.opt_var_ls
        spend_var_ls = [model_var_dict[var].spend_var for var in opt_var_ls] 
        if spend:
            bound_df = pd.merge(spend_point_df, spend_df, how = 'left', left_index = True, right_index = True)
            bound_df = pd.merge(bound_df, raw_media_df[['On Air Days','Off-Air Days']], how='left', left_index= True, right_index= True)
        else:
            bound_df = pd.merge(spend_point_df, raw_media_df, how = 'left', left_index = True, right_index = True)
        bound_df = pd.merge(bound_df, cpi_df, how = 'left', left_index = True, right_index = True)
        bound_df = bound_df.loc[bound_df['Variable'].isin(spend_var_ls)]
        return bound_df 

    # private function to display and export the head_analysis dataframe
    def display_headroom_analysis(self, bound_df, display_zero_for_neg):
        
        headroom_analysis_df = pd.DataFrame()
        headroom_analysis_df['Variable'] = bound_df['Variable']
        headroom_analysis_df['Actuals'] = bound_df['Total Media']
        headroom_analysis_df['Head Room for On-Air'] = (bound_df['Saturation Point'] - bound_df['Non-Zero Average']) * bound_df['On Air Days']
        headroom_analysis_df['Head Room for Off-Air'] = bound_df['Saturation Point'] * bound_df['Off-Air Days']
        headroom_analysis_df['On Air Days'] = bound_df['On Air Days']
        headroom_analysis_df['Off-Air Days'] = bound_df['Off-Air Days']
        headroom_analysis_df['Saturation Point'] = bound_df['Saturation Point']
        headroom_analysis_df['Non-Zero Average'] = bound_df['Non-Zero Average']
        if display_zero_for_neg == True:
            negative_cols = [col for col in headroom_analysis_df.columns if col != 'Variable' ]
            for col in negative_cols:
                headroom_analysis_df[col] = headroom_analysis_df[col].mask(headroom_analysis_df[col].lt(0),0)
        headroom_analysis_df['Total Head Room'] = headroom_analysis_df['Head Room for On-Air'] + headroom_analysis_df['Head Room for Off-Air']
        headroom_analysis_df['Total Head Room Ratio'] = headroom_analysis_df['Total Head Room'] / headroom_analysis_df['Actuals']
        
        # add the row of Total
        headroom_overall = headroom_analysis_df.sum()[-9:]
        #headroom_analysis_df = headroom_analysis_df.append(headroom_overall, ignore_index = True).fillna(np.nan)
        headroom_analysis_df = pd.concat([headroom_analysis_df,headroom_overall]).fillna(np.nan)
        headroom_analysis_df['Variable'].fillna(value = 'Total', inplace = True)
        
        # display and export the headroom analysis result
        file_path = os.path.join(self.result_folder, 'headroom_analysis.csv') 
        headroom_analysis_df.to_csv(file_path)
        print('Headroom Analysis result saved to: {}\n'.format(file_path))
        #display(headroom_analysis_df)
        return headroom_analysis_df

    # private function to display and export the bound_analysis dataframe
    def display_bound_analysis(self, bound_df):
        df_bound_analysis = pd.DataFrame()
        df_bound_analysis['Minimum'] = bound_df['Minimum'] * bound_df['On Air Days'] / bound_df['Total Media']
        df_bound_analysis['Average'] = bound_df['Average'] * bound_df['On Air Days'] / bound_df['Total Media']
        df_bound_analysis['Non-Zero Average'] = bound_df['Non-Zero Average'] * bound_df['On Air Days'] / bound_df['Total Media']
        df_bound_analysis['Threshold Point'] = bound_df['Threshold Point'] * bound_df['On Air Days'] / bound_df['Total Media']
        df_bound_analysis['Inflection Point'] = bound_df['Inflection Point'] * bound_df['On Air Days'] / bound_df['Total Media']
        df_bound_analysis['Saturation Point'] = bound_df['Saturation Point'] * bound_df['On Air Days'] / bound_df['Total Media']
        df_bound_analysis['Maximum'] = bound_df['Maximum'] * bound_df['On Air Days'] / bound_df['Total Media']
        # display and export the bound analysis result
        file_path = os.path.join(self.result_folder, 'bound_analysis.csv') 
        df_bound_analysis.to_csv(file_path)
        print('Bound Analysis result saved to: {}\n'.format(file_path))
        df_bound_analysis.to_csv(file_path) 
        #display(df_bound_analysis)
        return df_bound_analysis

    # public function 1. export and display the optimization results
    def export_and_display_optimization_results(self, method, num_cores):
        model_data = self.OPTIMIZATION_DICT['1']
        opt_var_ls = model_data.opt_var_ls
        model_var_ls = model_data.model_var_ls

        # update the spend, contribution, etc. for the optimization results
        inc_solver = self.calculate_optimization_contribution(method, num_cores)
        # private function to get the file: contrib_df.csv
        contrib_df = self.get_overall_contribution_df(inc_solver)
        # export the singular_optimization_df if the there are singular variables
        if len(opt_var_ls) != len(model_var_ls):
            # private function to get the file: singular_optimization_df.csv
            singular_optimization_df = self.get_singular_variable_optimization_df()
        # private function to get the file: df_new.csv
        optimization_df = self.get_optimization_df(only_calculate_hist_attributes = False)
        file_path = os.path.join(self.result_folder, 'df_new.csv')   
        optimization_df.to_csv(file_path)
        # private function to get the file: roas_df.csv
        roas_df = self.get_roas_df(contrib_df, optimization_df)
        display(contrib_df)
        display(optimization_df)
        display(roas_df)
        
        #saving dataframes
        print('Optimization result saved to: {}\n'.format(self.result_folder))
        file_path = os.path.join(self.result_folder, 'df_new.csv')   
        optimization_df.to_csv(file_path)
        file_path = os.path.join(self.result_folder, 'roas_df.csv') 
        roas_df.to_csv(file_path)
        file_path = os.path.join(self.result_folder, 'contrib_df.csv') 
        contrib_df.to_csv(file_path)
        
        
        

    # public function 2. export and display the back scaled optimization results
    def back_scaled_results_display(self,method,num_cores,show_scaled_results):
        model_data = self.OPTIMIZATION_DICT['1']
        opt_var_ls = model_data.opt_var_ls
        model_var_ls = model_data.model_var_ls
        inc_solver = self.calculate_optimization_contribution(method, num_cores)
        contrib_df = self.get_overall_contribution_df(inc_solver)
        # export the singular_optimization_df if the there are singular variables
        if len(opt_var_ls) != len(model_var_ls):
            # private function to get the file: singular_optimization_df.csv
            singular_optimization_df = self.get_singular_variable_optimization_df()
        # private function to get the file: df_new.csv
        optimization_df = self.get_optimization_df(only_calculate_hist_attributes = False)
        roas_df = self.get_roas_df(contrib_df, optimization_df)
        #optimization_df = self.get_optimization_df(only_calculate_hist_attributes = False)
        new_optimization_df=optimization_df[:-1]
        contri_ratio=[]
        c_ratio=new_optimization_df['Og Contri.']/new_optimization_df['Og Contri.'].sum()
        contri_ratio.append(c_ratio)
#         print(contri_ratio)
        unit_ratio=contrib_df['Incremental from model']/self.custom_df['O_UNIT'].sum()
#         print(unit_ratio)
        act_total_contri=unit_ratio*self.actual_df['O_UNIT'].sum()
        act_contri=[(i*act_total_contri[0]) for i in contri_ratio]
        act_rev=[(i*self.asp_fpv) for i in act_contri]
#         print(act_rev)
        act_spends= self.actual_df[new_optimization_df['Variable']].sum(axis=0).values
        act_spends_share = (act_spends/(act_spends.sum()))*100
        
        act_roas = act_rev[0]/act_spends
        
        
        act_opt_total_contri = act_total_contri * (contrib_df['%age change']/100+1)
        act_opt_contri = [(i * act_opt_total_contri[0]) for i in contri_ratio]
        act_opt_rev = [(i * self.asp_fpv) for i in act_opt_contri]
        
        act_opt_spends=[]
        for i in range(0,len(act_spends)):
            act_opt_spends.append(new_optimization_df['Recommended Change'][i]*(act_spends[i]))
        act_opt_spends_share = (act_opt_spends/(sum(act_opt_spends)))*100
        act_opt_roas=act_opt_rev[0]/act_opt_spends
        
        # creating optimization dataframe
        back_scaled_optimization_df= pd.DataFrame({'Variable': new_optimization_df['Variable'],
                                                 'Og Spends': act_spends,
                                                  'Og Spends Share' :act_spends_share,
                                                 'Og Contri.':act_contri[0],
                                                 'Og RoAS':act_roas,
                                                 'Og Rev': act_rev[0],
                                                 'Recommended Change':new_optimization_df['Recommended Change'],
                                                 'Change %':new_optimization_df['Change %'],
                                                 'Opt Spends': act_opt_spends,
                                                 'Opt Spends Share' :act_opt_spends_share,
                                                 'Opt Contri:':act_opt_contri[0],
                                                 'Opt RoAS': act_opt_roas,
                                                 'Opt Rev': act_opt_rev[0],
                                                 'Lower Bound': new_optimization_df['Lower Bound'],
                                                 'Upper Bound': new_optimization_df['Upper Bound']
                                                })
        
        
        og_opt_total_spends = pd.DataFrame({'Variable' : ['Total'],
                                           'Og Spends' : sum(act_spends),
                                           'Opt Spends' : sum(act_opt_spends)})
        
        back_scaled_optimization_df = back_scaled_optimization_df.append(og_opt_total_spends, ignore_index = True).fillna(np.nan)
        
        
        # creating contribution dataframe
        
        back_scaled_inc_model = back_scaled_optimization_df['Og Contri.'].sum()
        back_scaled_inc_solver = back_scaled_inc_model *(contrib_df['%age change']/100+1)
        Diff = back_scaled_inc_solver - back_scaled_inc_model
        change_percent = contrib_df['%age change']
        
        back_scaled_contrib_df = pd.DataFrame({'Incremental from model': back_scaled_inc_model,
                                              'Maximized from Solver':back_scaled_inc_solver,
                                              'Difference': Diff,
                                              '%age change':change_percent})
        
        
        
        # creating Roas dataframe
        back_scaled_roas_df = pd.DataFrame()
        back_scaled_roas_df['Actual Sales']=back_scaled_contrib_df['Incremental from model'] * self.asp_fpv
        back_scaled_roas_df['Optimized Sales'] = back_scaled_contrib_df['Maximized from Solver'] * self.asp_fpv
        back_scaled_roas_df['Actual RoAS'] =  back_scaled_roas_df['Actual Sales'] / (back_scaled_optimization_df['Og Spends'].sum()/2)
        back_scaled_roas_df['Optimized RoAS']= back_scaled_roas_df['Optimized Sales'] / (back_scaled_optimization_df['Opt Spends'].sum()/2)
        back_scaled_roas_df['% change RoAS'] = ((back_scaled_roas_df['Optimized RoAS'] -back_scaled_roas_df['Actual RoAS'])/back_scaled_roas_df['Actual RoAS'])*100
        
        # replacing nans with blanks
        back_scaled_optimization_df = back_scaled_optimization_df.fillna('-')
        
        if(show_scaled_results==True):
            print('\nScaled Results\n')
            display(contrib_df)
            display(optimization_df)
            display(roas_df)
        
        # displaying dataframes
        print('\nBack Scaled Results\n')
        display(back_scaled_contrib_df)
        display(back_scaled_optimization_df)
        display(back_scaled_roas_df)
        

        #saving dataframes
        print('Optimization result saved to: {}\n'.format(self.result_folder))
        file_path = os.path.join(self.result_folder, 'df_new.csv')   
        back_scaled_optimization_df.to_csv(file_path)
        file_path = os.path.join(self.result_folder, 'roas_df.csv') 
        back_scaled_roas_df.to_csv(file_path)
        file_path = os.path.join(self.result_folder, 'contrib_df.csv') 
        back_scaled_contrib_df.to_csv(file_path)

    def display_and_export_results(self,global_opt, num_cores,show_scaled_results):
        
        if self.cluster_opt==True:
            self.back_scaled_results_display(global_opt, num_cores, show_scaled_results)
        else:
            self.export_and_display_optimization_results(global_opt, num_cores)
            
   # public function 3. export and display the bound, headroom analysis results
    def export_and_display_bound_headroom_analysis(self, bound_start_end_date, spend, headroom_analysis, bound_analysis, display_zero_for_neg):
        bound_custom_df = self.get_bound_custom_df(bound_start_end_date)
        # get media_raw_df
        raw_media_df = self.get_media_raw_df(bound_custom_df)
        # get media_spend_df
        spend_df = self.get_media_spend_df(bound_custom_df)
        # get cpi_df
        cpi_df = self.get_cpi_df(raw_media_df, spend_df)
        # get three s_curve spend points for each media driver
        spend_point_df = self.get_s_curve_spend_point_df()
        
        bound_df = self.get_bound_analysis_df(spend_df, spend_point_df, raw_media_df, cpi_df, spend)

        if headroom_analysis:
            headroom_analysis_df = self.display_headroom_analysis(bound_df, display_zero_for_neg)
        if bound_analysis:
            bound_analysis_df = self.display_bound_analysis(bound_df)
            
def lag_transformation_no_numba(var, lag):
    lag_variable = np.append(np.zeros(int(lag)), var[:-lag])
    return lag_variable

def halflife_transformation_no_numba(var, halflife):
    retention = np.exp(math.log(0.5)/halflife)        
    transformed_var_orig = var * (1 - retention)
    transformed_var_orig[np.isnan(transformed_var_orig)] = 0
    transformed_var_orig = recursive_filter_no_numba(transformed_var_orig, retention)
    return transformed_var_orig 
def recursive_filter_no_numba(x, ar_coeff):
    n = len(x)
    y = np.zeros(n)
    y[0] = x[0]
    for i in range(1,n):
        y[i] = ar_coeff * y[i-1] + x[i]
    return y            