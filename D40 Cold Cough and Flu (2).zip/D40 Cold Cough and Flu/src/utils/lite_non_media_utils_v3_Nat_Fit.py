#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# author: Mayukh Maitra
"""
Created on Sun Feb  4 00:24:43 2024
@author: m0m0tc7
"""
import math
import re

# Computation of Spearman correlation clusters
import matplotlib.pyplot as plt
import numpy as np
# Dataframe and array manipulation
import pandas as pd
import plotly.graph_objects as go
import pmdarima as pm
# Linear regression
import statsmodels.api as sm
from custom_seasonality_analysis import VariableSeasonality
# from hierarchicalforecast.utils import aggregate
from numpy.linalg import inv, pinv
from sklearn.metrics import mean_absolute_percentage_error as mape
from sklearn.metrics import mean_squared_error, r2_score
# from statsforecast import StatsForecast
# from statsforecast.models import AutoARIMA, HoltWinters
from statsmodels.stats.outliers_influence import variance_inflation_factor
# from statsmodels.tsa.holtwinters import ExponentialSmoothing as es
from statsmodels.tsa.seasonal import STL, seasonal_decompose
from statsmodels.tsa.statespace.sarimax import SARIMAX as smx
from statsmodels.tsa.stattools import grangercausalitytests

# MSedits START MS-00 : rescue loop used by feature_selection (see MSEDITS_CHANGELOG.md)
from ms_dummy_selection import run_mape_rescue as ms_run_mape_rescue
from ms_dummy_selection import compute_mape_percent as ms_mape_percent               # MSedits MS-12 +
# MSedits END MS-00

plt.rcParams["figure.dpi"] = 300
plt.rcParams["figure.figsize"] = (20, 20)


import warnings

warnings.filterwarnings("ignore")

spec = [["L3_CATEGORY_NAME"], ["L3_CATEGORY_NAME", "BRAND"]]

forecasting_method = ["HoltWinters", "AutoARIMA"]

essential_vars = []

weekend_vars = []

sd_r_sq = {}


def _safe_vif(exog_values, idx):
    """variance_inflation_factor wrapper: exact linear dependencies, zero variance, or
    singular/rank-deficient design matrices raise (or return non-finite values) from
    statsmodels -- treat all of those as maximal collinearity (np.inf) instead of letting
    the exception propagate and crash the caller."""
    try:
        val = variance_inflation_factor(exog_values, idx)
    except Exception:
        return np.inf
    if not np.isfinite(val):
        return np.inf
    return val


def backward_eliminate_vif(X_initial, y, essential_non_media_for_brand, br):
    """
    Stepwise backward elimination with VIF=inf priority handling.

    Starting from every column in X_initial, iteratively drops the worst offender until only
    a clean, non-collinear, statistically-supported feature set remains (or nothing more can
    be safely removed). Runs two priority passes each iteration:

    Priority 1 -- drop ONE non-essential VIF=inf column before anything else. An exact linear
    dependency among k columns (e.g. a pooled holiday dummy vs. its own year-splits) makes ALL
    k of them report VIF=inf simultaneously. Removing just one is enough to break the
    dependency, so only one is dropped per iteration -- removing all k at once would wipe out
    real, distinct signal instead of just deduplicating the redundant representation. Essential
    /protected columns that still show VIF=inf are never removed, only logged as a warning.

    Priority 2 -- standard p-value (>0.05) / VIF (>3) backward elimination once no inf-VIF
    columns remain. The worst-p and worst-VIF candidates (tie-broken alphabetically) are each
    evaluated and removed INDEPENDENTLY: one candidate being protected no longer blocks removal
    of the other, genuinely-removable offender (the original bug this function fixes -- the old
    logic broke the whole loop the moment either candidate was protected).

    The loop terminates (without further removal) once both thresholds are satisfied for every
    remaining column, or once every remaining offender is protected.

    Parameters
    ----------
    X_initial : pd.DataFrame
        Candidate feature columns (post-Granger-screen) for one brand/SBU.
    y : pd.Series
        Outcome variable for the same rows as X_initial.
    essential_non_media_for_brand : list[str]
        Forced-include/protected feature names for this brand.
    br : str
        Brand/SBU name, used only for log messages.

    Returns
    -------
    list[str]
        The surviving column names after elimination (sorted).
    """
    cols = sorted(list(X_initial.columns))
    iteration = 0
    while len(cols) > 0:
        iteration += 1
        X_1 = X_initial[cols]
        X_1 = sm.add_constant(X_1)
        model = sm.OLS(y, X_1).fit()
        p = pd.Series(model.pvalues.values[1:], index=cols).sort_index()

        vif = pd.DataFrame()
        vif["variables"] = X_1.columns[1:]
        vif["VIF"] = [
            _safe_vif(X_1.values, i) for i in range(1, X_1.shape[1])
        ]
        vif = vif.sort_values("variables", kind="mergesort").reset_index(drop=True)
        max_vif = max(vif["VIF"])
        pmax = max(p)

        pmax_candidates = sorted(p[p == p.max()].index.tolist())
        feature_with_p_max = pmax_candidates[0]
        vifmax_candidates = sorted(vif.loc[vif["VIF"] == max_vif, "variables"].tolist())
        feature_with_vif_max = vifmax_candidates[0]

        # ---------------- LOG: condition-by-condition trace, remove when done ----------------
        p_is_essential = feature_with_p_max in essential_non_media_for_brand
        vif_is_essential = feature_with_vif_max in essential_non_media_for_brand

        all_vars_log = vif.set_index("variables").copy()
        all_vars_log["p-value"] = p
        all_vars_log = all_vars_log.reset_index().rename(columns={"index": "variables"})
        all_vars_log["p_fail (p>0.05)"] = all_vars_log["p-value"] > 0.05 + 1e-10
        all_vars_log["vif_fail (VIF>3 or inf)"] = all_vars_log["VIF"] > 3 + 1e-10
        all_vars_log["in_essential_non_media"] = all_vars_log["variables"].isin(essential_non_media_for_brand)
        all_vars_log = all_vars_log[["variables", "p-value", "VIF", "p_fail (p>0.05)", "vif_fail (VIF>3 or inf)", "in_essential_non_media"]]
        all_vars_log = all_vars_log.sort_values("variables", kind="mergesort").reset_index(drop=True)
        print(f"LOG: SBU={br} iter={iteration} cols_remaining={len(cols)} -- per-variable status:")
        print(all_vars_log.to_string(index=False))
        print(f"LOG: SBU={br} iter={iteration} pmax={pmax:.6g} feature_with_p_max={feature_with_p_max!r} "
              f"in_essential_non_media={p_is_essential}")
        print(f"LOG: SBU={br} iter={iteration} max_vif={max_vif:.6g} feature_with_vif_max={feature_with_vif_max!r} "
              f"in_essential_non_media={vif_is_essential}")
        # ------------------------------------------------------------------------------------

        # ---- Priority 1: drop ONE non-essential VIF=inf column before anything else ----
        inf_vif_cols = vif.loc[vif["VIF"] == np.inf, "variables"].tolist()
        inf_vif_removable = sorted([c for c in inf_vif_cols if c not in essential_non_media_for_brand])
        inf_vif_protected = sorted([c for c in inf_vif_cols if c in essential_non_media_for_brand])

        if inf_vif_protected:
            for c in inf_vif_protected:
                print(f"LOG: SBU={br} iter={iteration} WARNING: essential/protected feature "
                      f"{c!r} has VIF=inf and cannot be removed (essential_non_media)")

        if inf_vif_removable:
            feature_to_drop = inf_vif_removable[0]
            print(f"LOG: SBU={br} iter={iteration} -> removing on VIF=inf (priority): "
                  f"{feature_to_drop!r} (other inf-tied candidates this round: "
                  f"{inf_vif_removable[1:]})")
            cols.remove(feature_to_drop)
            continue  # re-fit next iteration -- some/all of the remaining inf ties may now be finite

        # ---- Priority 2: standard p-value / VIF>3 backward elimination ----
        removed_this_round = False
        if pmax > 0.05 + 1e-10 and feature_with_p_max not in essential_non_media_for_brand and feature_with_p_max in cols:
            print(f"LOG: SBU={br} iter={iteration} -> removing on p-value: {feature_with_p_max!r}")
            cols.remove(feature_with_p_max)
            removed_this_round = True
        if max_vif > 3 + 1e-10 and feature_with_vif_max not in essential_non_media_for_brand and feature_with_vif_max in cols:
            print(f"LOG: SBU={br} iter={iteration} -> removing on VIF: {feature_with_vif_max!r}")
            cols.remove(feature_with_vif_max)
            removed_this_round = True

        if not removed_this_round:
            reason = []
            if not (pmax > 0.05 + 1e-10 or max_vif > 3 + 1e-10):
                reason.append("both thresholds satisfied (pmax<=0.05 and max_vif<=3)")
            if p_is_essential:
                reason.append(f"feature_with_p_max {feature_with_p_max!r} is protected (essential_non_media)")
            if vif_is_essential:
                reason.append(f"feature_with_vif_max {feature_with_vif_max!r} is protected (essential_non_media)")
            print(f"LOG: SBU={br} iter={iteration} -> STOP: "
                  f"{' ; '.join(reason) if reason else 'no removable offenders remain'}")
            break

    return cols


def feature_selection(
    data, brands_tst, outcome_vars, essential_non_media, exclude_non_media,
    ms_ctx=None,                                                                # MSedits MS-04 +
):
    print("********* Feature Selection Granger **********", "\n")
    res_lst = []
    outcome = outcome_vars[0]
    for month in range(1, 13):
        column_name = f"Month_{month}"
        data[column_name] = (data["Date"].dt.month == month).astype(int)

    df_processed = data.copy()
    # -----------------------------------------------------------------------------------   # NEW 3.20
    # df_processed = data.copy()
    # for month in range(1, 13):
    #     column_name = f"Month_{month}"
    #     df_processed[column_name] = (df_processed["Date"].dt.month == month).astype(int)

    essential_media_dict = {}
    for br in brands_tst:
        print(br)
        # Define maximum lag for Granger test
        maxlag = 4
        # dummies = [
        #     col
        #     for col in df_processed.columns
        #     if col.startswith("D_") or col.startswith("Month_")  # WMT Media as Base Update
        # ]
    # -----------------------------------------------------------------------------------   # NEW 3.20
        dummies = sorted([
        col
        for col in df_processed.columns
        if col.startswith("D_") or col.startswith("Month_")])

        print('dummies')
        print(dummies)
        # ref_df = df_processed[df_processed.SBU == br]
        # X = ref_df[dummies]
        # if "D_January" in X.columns:
        #     X.drop(columns=["D_January"], inplace=True)
    # -----------------------------------------------------------------------------------   # NEW 3.20
        ref_df = df_processed[df_processed.SBU == br].copy()
        X = ref_df[dummies].copy()
        if "D_January" in X.columns:
            X = X.drop(columns=["D_January"])

        for media in [outcome]:
            res_dict = {}
            for col in X.columns:
                print(col)
                if (
                    ref_df[col].nunique() <= 1
                ):  # Skip this column if it has 1 unique value (constant)
                    continue
                try:
                    test_result = grangercausalitytests(
                        ref_df[[media, col]], maxlag=maxlag, verbose=False
                    )

                    # p_values = [
                    #     round(test_result[i + 1][0]["ssr_ftest"][1], 4)
                    #     for i in range(maxlag)
                    # ]
                    # if (min(p_values) < 0.001 or col in essential_non_media) and (
                    #         col not in exclude_non_media
                    # ):  # set significance level
                    #     res_dict[col] = min(p_values)
    # -----------------------------------------------------------------------------------           NEW 3.20
                    p_values = [
                        test_result[i + 1][0]["ssr_ftest"][1]
                        for i in range(maxlag)
                    ]
                    min_p = min(p_values)
                    if ((min_p < 0.001 - 1e-10) or (col in essential_non_media)) and (
                        col not in exclude_non_media
                    ):
                        res_dict[col] = min_p
                except Exception as e:
                    # Skip variables that become constant after lagging or cause other test issues
                    print(f"  Skipping {col}: {type(e).__name__}")
                    continue
            coef_df = pd.DataFrame(
                list(res_dict.items()), columns=["Feature", "P-Value"]
            )

            # coef_df = coef_df.sort_values("P-Value")[
            #           : X.shape[1]
            #           ]  # Select top 3 months
                # -----------------------------------------------------------------------------------           NEW 3.20
            coef_df = coef_df.sort_values(
                ["P-Value", "Feature"], kind="mergesort"
            ).iloc[: X.shape[1]]
            coef_df["SBU"] = [br] * coef_df.shape[0]

        res_lst.append(coef_df)

    report_df = pd.concat(res_lst)

    tp_lst = []
    print("SBUs", report_df.SBU.unique(), "\n")
    # for br in report_df.SBU.unique():
    # -----------------------------------------------------------------------------------           NEW 3.20
    for br in sorted(report_df.SBU.unique()):
        df_tp = df_processed[df_processed.SBU == br]
        # X_initial = df_tp[report_df[report_df.SBU == br]["Feature"].values.tolist()]
        # -----------------------------------------------------------------------------------           NEW 3.20
        selected_features = sorted(
            report_df.loc[report_df.SBU == br, "Feature"].tolist()
        )
        X_initial = df_tp[selected_features].copy()

        y = df_tp["O_UNIT"]

        # Stepwise backward elimination (VIF=inf priority pass, then p-value/VIF>3 pass) --
        # see backward_eliminate_vif() above.
        selected_features_BE = backward_eliminate_vif(X_initial, y, essential_non_media, br)
        X_initial = df_tp[selected_features_BE]
        X = sm.add_constant(X_initial[selected_features_BE])
        model = sm.OLS(y, X).fit()
        print(f"******* nonmedia r2: {model.rsquared}", "\n")

        # MSedits START MS-05 : iterative high-MAPE rescue with event-aware naming
        # Same point in the same function at which brand-level LITE calls
        # add_ets_dummies_for_mape (lite_non_media_utils.py:305-309). Gated: a fit
        # that already passes MAPE/R2 returns untouched, so this costs one mape()
        # call on the healthy path. New columns are written to `data` -- NOT to
        # df_processed, which is a copy made at line 62, so writes there would be
        # silently lost and the new dummies would never reach the 10 bases.
        # Names land in essential_media_dict[br] for free via :231 below, because
        # that is derived from the refitted model's params.
        if ms_ctx is not None:
            (
                selected_features_BE,
                model,
                X,
                data,
                _ms_new_names,
                _ms_log,
            ) = ms_run_mape_rescue(
                data, model, X, y, selected_features_BE, ms_ctx, sbu=br,
            )
        # MSedits END MS-05

        coefficients = model.params[1:]
        positive_coefficients = coefficients

        vif = pd.DataFrame()
        vif["variables"] = X.columns[1:]
        vif["VIF"] = [
            _safe_vif(X.values, i) for i in range(1, X.shape[1])
        ]

        remaining_inf = sorted(vif.loc[vif["VIF"] == np.inf, "variables"].tolist())
        if remaining_inf:
            print(f"LOG: SBU={br} WARNING: final selected feature set still contains VIF=inf "
                  f"for protected/essential feature(s) {remaining_inf} "
                  f"(cannot be removed because they are in essential_non_media)")

        results_df = pd.DataFrame(
            {
                "Feature": positive_coefficients.index,
                "Coefficient": positive_coefficients.values,
                "p-value": model.pvalues[positive_coefficients.index],
                "VIF": vif.set_index("variables").loc[
                    positive_coefficients.index, "VIF"
                ],
            }
        )
        results_df["SBU"] = [br] * results_df.shape[0]
        tp_lst.append(results_df)
        essential_media_dict[br] = sorted(list(set(positive_coefficients.index)))

    # final_df = pd.concat(tp_lst)
    final_df = pd.concat(tp_lst, ignore_index=True)
    final_df = final_df.sort_values(["SBU", "Feature"], kind="mergesort").reset_index(drop=True)
    display(final_df)

    return essential_media_dict


def national_media_transform(data, brands_tst, outcome_vars, media_vars_national,custom_s_curve_bounds,lag_hf_media_national):
    outcome = outcome_vars[0]
    df_processed = data.copy()
    df_processed["Date"] = pd.to_datetime(df_processed["Date"])
    df_processed.set_index("Date", inplace=True)
    df_processed.index = pd.to_datetime(df_processed.index)

    national_params = {}

    target_threshold = []
    target_saturation = []
    national_media_df = {}
    def lag_transformation(var, lag):
        lag_variable = np.append(np.zeros(int(lag)), var[:-lag])
        return lag_variable

    def halflife_transformation(var, halflife):
        retention = np.exp(math.log(0.5)/halflife)        
        transformed_var = var * (1 - retention)
        transformed_var[np.isnan(transformed_var)] = 0
        transformed_var = recursive_filter(transformed_var, retention)
        return transformed_var

    def recursive_filter(x, ar_coeff):
        n = len(x)
        y = np.zeros(n)
        y[0] = x[0]
        for i in range(1,n):
            y[i] = ar_coeff * y[i-1] + x[i]
        return y

    for brand in df_processed["SBU"].unique():
        national_media_df[brand] = {}
        for nat_var in media_vars_national:
            if custom_s_curve_bounds and nat_var in custom_s_curve_bounds:            
                lb = custom_s_curve_bounds[nat_var][0]
                ub = custom_s_curve_bounds[nat_var][1]

            threshold_point = df_processed[df_processed["SBU"] == brand][df_processed[nat_var] > 0][
                nat_var
            ].quantile(lb)
            target_threshold.append(threshold_point)
            saturation_point = df_processed[df_processed["SBU"] == brand][df_processed[nat_var] > 0][
                nat_var
            ].quantile(ub)
            target_saturation.append(saturation_point)

            if lag_hf_media_national and nat_var in lag_hf_media_national:            
                lg = int(lag_hf_media_national[nat_var][0])
                hf = lag_hf_media_national[nat_var][1]

            #National Media Transformation
            transformed_var = df_processed[df_processed["SBU"] == brand][nat_var]

            if lg != 0:
                transformed_var = lag_transformation(transformed_var, lg)
            if hf != 0:
                transformed_var = halflife_transformation(
                    transformed_var, hf
                )

            var_mean = transformed_var.mean()

            # calculate scale and inflection
            if var_mean > 0:
                inflection = (saturation_point + threshold_point) / (2 * var_mean)
            else:
                inflection = 0
            if (saturation_point - threshold_point) > 0:
                scale = ((2 * var_mean) * 4.59511985013) / (
                    saturation_point - threshold_point
                )
            else:
                scale = 0
            if (scale != 0) and (inflection != 0):
                transformed_var_scaled = transformed_var / var_mean
                saturation_term = scale * (inflection - transformed_var_scaled)
                scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (
                    1 + np.exp(scale * inflection)
                )
                scurve_var_mean = scurve_var.mean()
                transformed_var = scurve_var * var_mean / scurve_var_mean
            national_media_df[brand][nat_var] = transformed_var.copy()
            national_params[nat_var] = [lg,hf,inflection,scale]
            df_processed.drop(nat_var, axis=1, inplace=True)

    frames = []
    for key, d in national_media_df.items():
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    result_df['Date'] = df_processed.index               # Order of Transformation is intact
    df_processed = df_processed.merge(result_df, on=("SBU", "Date"))
    df_processed["Date"] = pd.to_datetime(df_processed["Date"])  # Formatting the date
    # df_processed.set_index("Date", inplace=True, drop=False)
    # df_processed.drop("Date", axis=1, inplace=True)
    df_processed.to_csv('df_processed.csv')
    try:
        
        df_processed.drop("O_UNIT.1", axis=1, inplace=True)

    except:
        pass
    df_processed.fillna(value=0, inplace=True)
    return df_processed, national_params


def residual_calculation(df, var, exog, is_pandas = True, add_const=True):
    """
    Returns residuals of var to a regression with exog
    """
    if is_pandas:
        Y = df[var]
        X = df[exog]
        if add_const:
            X = sm.add_constant(X)
    else:
        X = df
        Y = var
    model = sm.OLS(Y, X, missing="drop")
    model_result = model.fit()
    outcome_residuals = model_result.resid
    return outcome_residuals


def model_pred(df_testing, model_result, outcome_variable, essential_vars):
    Y_test = df_testing[outcome_variable]
    X_test = df_testing[essential_vars]
    X_test = sm.add_constant(X_test, has_constant="add")
    Y_pred = model_result.predict(X_test)

    perc_error = abs((model_result.predict(X_test) / Y_test) - 1)
    mape_v1 = perc_error.mean() * 100
    return X_test, Y_test, Y_pred


def update_layout(
    fig,
    title,
    legend_orientation="h",
    height=500,
    width=1000,
    title_x=0.46,
    title_y=0.8,
    legend_x=0.05,
    legend_y=-0.15,
    show_yaxis=True,
    tickformat=",.1f",
    tickangle=30,
    label_fontsize=14,
    legend_fontsize=14,
    title_fontsize=20,
):

    fig.update_layout(
        dict(
            xaxis=dict(
                showgrid=False,
                ticks="outside",
                mirror=False,
                showline=False,
                linecolor="#CED0D2",
                linewidth=1,
                tickangle=tickangle,
            ),
            yaxis=dict(
                showgrid=False,
                mirror=True,
                ticks="",
                showline=False,
                showticklabels=show_yaxis,
                linecolor="black",
                linewidth=1,
                tickformat=tickformat,
                rangemode="tozero",
            ),
            yaxis2=dict(
                overlaying="y",
                side="right",
                tickformat=tickformat,
                showticklabels=show_yaxis,
                tickmode="auto",
                rangemode="tozero",
            ),
            font=dict(size=label_fontsize),
        ),
        autosize=True,
        width=width,
        height=height,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        title={
            "text": title,
            "y": title_y,
            "x": title_x,
            "xanchor": "center",
            "yanchor": "top",
            "font": dict(size=title_fontsize),
        },
        legend_orientation=legend_orientation,
        legend=dict(x=legend_x, y=legend_y, font=dict(size=legend_fontsize)),
    )
    return fig


def plot_fig(df_testing, Y_test, Y_pred):
    data = []
    line1 = go.Scatter(
        x=df_testing.index,
        y=Y_test,
        line=dict(color="#0071CE"),
        name="Modeling Actual",
        yaxis="y1",
    )
    data.append(line1)

    line3 = go.Scatter(
        x=df_testing.index,
        y=Y_pred,
        line=dict(color="#FFC220"),
        name="Modeling Predicted",
        yaxis="y1",
    )
    data.append(line3)

    fig = go.Figure(data)
    fig = update_layout(
        fig,
        title="Actual vs Predicted Modeling Period",
        legend_y=-0.25,
        legend_x=0.25,
        show_yaxis=True,
    )
    fig.show()

def plot_fig_fit(df_testing, Y_test, Y_pred):
    data = []
    line1 = go.Scatter(
        x=df_testing['Date'],
        y=Y_test,
        line=dict(color="#0071CE"),
        name="Modeling Actual",
        yaxis="y1",
    )
    data.append(line1)

    line3 = go.Scatter(
        x=df_testing['Date'],
        y=Y_pred,
        line=dict(color="#FFC220"),
        name="Modeling Predicted",
        yaxis="y1",
    )
    data.append(line3)

    fig = go.Figure(data)
    fig = update_layout(
        fig,
        title="Actual vs Predicted Modeling Period",
        legend_y=-0.25,
        legend_x=0.25,
        show_yaxis=True,
    )
    fig.show()


def get_test_fit(df_testing, model_result, outcome_variable, essential_vars):

    X_test, Y_test, Y_pred = model_pred(
        df_testing, model_result, outcome_variable, essential_vars
    )
    r2 = r2_score(Y_test, Y_pred)

    wape_val = (
        np.abs(Y_test - Y_pred).sum() / np.abs(Y_test).sum()) * 100
    print("r2:", r2)
    print("MAPE:", mape(Y_test, Y_pred) * 100)
    print("WAPE:", wape_val)

    plot_fig(df_testing, Y_test, Y_pred)


def generate_trend_seasonality_arima(data, essential_non_media, outcome="O_UNIT"):

    # brand_stack = data.copy()
    # brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    # brand_stack.set_index("Date", inplace=True)
    # brand_stack.index = pd.to_datetime(brand_stack.index)
    # ----------------------------------------------------------------------
    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack = brand_stack.sort_values(["SBU", "Date"]).reset_index(drop=True)
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    # for brand in brand_stack["SBU"].unique():
    # ----------------------------------------------------------------------
    for brand in sorted(brand_stack["SBU"].unique()):
        print(f"**** SBU: {brand} Set 7 sarimax ****")
        # brand_level_df = brand_stack[brand_stack["SBU"] == brand][
        #     [outcome] + essential_non_media
        #     ]
    # ----------------------------------------------------------------------
        brand_level_df = brand_stack.loc[
            brand_stack["SBU"] == brand, [outcome] + essential_non_media
        ].copy()
        brand_level_df = brand_level_df.sort_index()

        # brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        brand_level_df[outcome] = brand_level_df[outcome].astype(float)
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        test_brand_df = brand_level_df.copy()
        seas_obj_cust = VariableSeasonality(
            test_brand_df.copy(), key_variable=outcome, exog=essential_non_media
        )
        seas_obj_cust.arma_arima_func(start_p=1, start_q=1, day_start=5, day_end=8)
        # additional_period_start_date is optional parameter. for this period, ETS terms would be created separately
        seas_obj_cust.creating_var_func()

        test_brand_df = seas_obj_cust.df.copy()
        seasonality_terms_units = []
        regex_seasonality_units = [
            "_" + i + "$" for i in seasonality_terms_units if "SARIMAX" not in i
        ] + ["_" + i + " \(" for i in seasonality_terms_units if "SARIMAX" in i]

        regex_seasonality_units = "|".join(regex_seasonality_units)

        seasonality_vars_units = [
            c
            for c in test_brand_df.columns
            if outcome in c and re.search(regex_seasonality_units, c) is not None
        ]
        test_brand_df["sarimax"] = test_brand_df[
            [var for var in seasonality_vars_units if var.startswith("O_UNIT_SARIMAX ")]
        ]
        test_brand_df["sarimax_log"] = test_brand_df[
            [
                var
                for var in seasonality_vars_units
                if var.startswith("O_UNIT_SARIMAX_LOG")
            ]
        ]

        test_brand_df.fillna(value=0, inplace=True)
        y = test_brand_df[outcome]


        ### Set 1
        # X = test_brand_df[essential_non_media + ["sarimax"]]
            # ----------------------------------------------------------------------
        X = test_brand_df[sorted(essential_non_media) + ["sarimax"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()


        print(f"NEW: def generate_trend_seasonality_arima()")                                                    # NEW 3.22 +++
        coefficients = model.params[1:]
        positive_coefficients = coefficients

        vif = pd.DataFrame()
        vif["variables"] = X.columns[1:]
        vif["VIF"] = [
            variance_inflation_factor(X.values, i) for i in range(1, X.shape[1])
        ]

        results_df = pd.DataFrame(
            {
                "Feature": positive_coefficients.index,
                "Coefficient": positive_coefficients.values,
                "p-value": model.pvalues[positive_coefficients.index],
                "VIF": vif.set_index("variables").loc[
                    positive_coefficients.index, "VIF"
                ],
            }
        )
        results_df["SBU"] = ['br'] * results_df.shape[0]
        tp_lst = []
        tp_lst.append(results_df)

        final_df = pd.concat(tp_lst)
        display(final_df)                                                                             # NEW 3.22 +++


        print(
            f"****** sarimax with variable O_UNIT_SARIMAX: R_sq: {model.rsquared}",
            " ******\n",
        )
        ### Set 2
        # X = test_brand_df[essential_non_media + ["sarimax_log"]]
        # ----------------------------------------------------------------------
        X = test_brand_df[sorted(essential_non_media) + ["sarimax_log"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        print(
            f"****** sarimax with variable O_UNIT_SARIMAX_LOG: R_sq: {model.rsquared}",
            " ******\n",
        )
        ### Set 3
        # X = test_brand_df[
        #     essential_non_media
        #     + [str(outcome) + "_TREND", str(outcome) + "_SEASONALITY"]
        #     ]
        # ----------------------------------------------------------------------
        X = test_brand_df[
            sorted(essential_non_media)
            + [str(outcome) + "_TREND", str(outcome) + "_SEASONALITY"]
        ]

        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        print(
            f"****** sarimax with variable trend and seasonality: R_sq: {model.rsquared}",
            " ******\n",
        )
        ### Set 4
        # X = test_brand_df[
        #     essential_non_media
        #     + [str(outcome) + "_TREND_LOG", str(outcome) + "_SEASONALITY_LOG"]
        #     ]
        # ----------------------------------------------------------------------
        X = test_brand_df[
            sorted(essential_non_media)
            + [str(outcome) + "_TREND_LOG", str(outcome) + "_SEASONALITY_LOG"]
        ]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        print(
            f"****** sarimax with variable trend log and seasonality log: R_sq: {model.rsquared}",
            " ******\n",
        )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["SARIMAX"] = test_brand_df["sarimax"].copy()
        seasonality_dict[brand]["SARIMAX_LOG"] = test_brand_df["sarimax_log"].copy()
        seasonality_dict[brand][str(outcome) + "_TREND"] = test_brand_df[
            str(outcome) + "_TREND"
            ].copy()
        seasonality_dict[brand][str(outcome) + "_SEASONALITY"] = test_brand_df[
            str(outcome) + "_SEASONALITY"
            ].copy()
        seasonality_dict[brand][str(outcome) + "_TREND_LOG"] = test_brand_df[
            str(outcome) + "_TREND_LOG"
            ].copy()
        seasonality_dict[brand][str(outcome) + "_SEASONALITY_LOG"] = test_brand_df[
            str(outcome) + "_SEASONALITY_LOG"
            ].copy()

    frames = []
    # for key, d in seasonality_dict.items():
    # ------------------------------------------------------
    for key in sorted(seasonality_dict):
        d = seasonality_dict[key]
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    # data = data.merge(result_df, on=("SBU", "Date"))
    # ------------------------------------------------------
    data = data.merge(result_df, on=("SBU", "Date"))
    data = data.sort_values(["SBU", "Date"]).reset_index(drop=True)
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    data.fillna(value=0, inplace=True)
    return data


def generate_trend_seasonality(data, essential_non_media, outcome="O_UNIT"):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["SBU"].unique():
        print(f"**** SBU: {brand} Set 1 moving average 7 ****")
        brand_level_df = brand_stack[brand_stack["SBU"] == brand][
            [outcome] + essential_non_media
        ]
        # brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        brand_level_df[outcome] = brand_level_df[outcome].astype(float)
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        test_brand_df = brand_level_df.copy()
        trend_val = outcome_residuals.rolling(window=7, center=True).mean()
        test_brand_df["trend_val"] = trend_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        detrend = outcome_residuals - test_brand_df["trend_val"].astype(float)
        test_brand_df["detrend"] = detrend.copy()
        test_brand_df["month"] = test_brand_df.index.month
        seasonal_val = test_brand_df.groupby("month")["detrend"].transform("mean")
        test_brand_df["seasonal_val"] = seasonal_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        print(
            "\n****** trend and seasonality: MV 7; R_sq: ", model.rsquared, " ******\n"
        )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_1"] = trend_val.copy()
        seasonality_dict[brand]["MV_seasonality_1"] = seasonal_val.copy()

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("SBU", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    data.fillna(value=0, inplace=True)
    return data


def generate_trend_seasonality_hw(data, essential_non_media, outcome="O_UNIT"):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["SBU"].unique():
        print(f"**** SBU: {brand} Set 2 moving average 15 ****")
        brand_level_df = brand_stack[brand_stack["SBU"] == brand][
            [outcome] + essential_non_media
        ]
        # brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        brand_level_df[outcome] = brand_level_df[outcome].astype(float)
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        test_brand_df = brand_level_df.copy()
        trend_val = outcome_residuals.rolling(window=15, center=True).mean()
        test_brand_df["trend_val"] = trend_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        detrend = outcome_residuals - test_brand_df["trend_val"].astype(float)
        test_brand_df["detrend"] = detrend.copy()
        test_brand_df["month"] = test_brand_df.index.month
        seasonal_val = test_brand_df.groupby("month")["detrend"].transform("mean")
        test_brand_df["seasonal_val"] = seasonal_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        print(
            "\n****** trend and seasonality: MV 15; R_sq: ", model.rsquared, " ******\n"
        )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_2"] = trend_val.copy()
        seasonality_dict[brand]["MV_seasonality_2"] = seasonal_val.copy()

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("SBU", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    data.fillna(value=0, inplace=True)
    return data


def generate_trend_seasonality_stl(data, essential_non_media, outcome="O_UNIT"):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["SBU"].unique():
        print(f"**** SBU: {brand} Set 3 moving average 30 ****")
        brand_level_df = brand_stack[brand_stack["SBU"] == brand][
            [outcome] + essential_non_media
        ]
        # brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        brand_level_df[outcome] = brand_level_df[outcome].astype(float)
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        test_brand_df = brand_level_df.copy()
        trend_val = outcome_residuals.rolling(window=30, center=True).mean()
        test_brand_df["trend_val"] = trend_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        detrend = outcome_residuals - test_brand_df["trend_val"].astype(float)
        test_brand_df["detrend"] = detrend.copy()
        test_brand_df["month"] = test_brand_df.index.month
        seasonal_val = test_brand_df.groupby("month")["detrend"].transform("mean")
        test_brand_df["seasonal_val"] = seasonal_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        print(
            "\n****** trend and seasonality: MV 30; R_sq: ", model.rsquared, " ******\n"
        )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_3"] = trend_val.copy()
        seasonality_dict[brand]["MV_seasonality_3"] = seasonal_val.copy()

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("SBU", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    data.fillna(value=0, inplace=True)
    return data


def generate_trend_seasonality_v1(data, essential_non_media, outcome="O_UNIT"):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)
    essential_non_media_wk = sorted(list(set(essential_non_media) - set(weekend_vars)))
    seasonality_dict = {}
    for brand in brand_stack["SBU"].unique():
        print(f"**** SBU: {brand} Set 4 seasonal decompose period 52 ****")
        brand_level_df = brand_stack[brand_stack["SBU"] == brand][
            [outcome] + essential_non_media_wk
        ]
        # brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        brand_level_df[outcome] = brand_level_df[outcome].astype(float)
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media_wk
        )
        result_additive = seasonal_decompose(
            x=outcome_residuals.copy(),
            extrapolate_trend="freq",
            model="additive",
            period=52,
        )

        test_brand_df = brand_level_df.copy()
        test_brand_df["trend_val"] = result_additive.trend.copy()
        test_brand_df["seasonal_val"] = result_additive.seasonal.copy()
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        print(
            "\n****** trend and seasonality: seasonal decompose period 52; R_sq: ",
            model.rsquared,
            " ******\n",
        )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_4"] = result_additive.trend
        seasonality_dict[brand]["MV_seasonality_4"] = result_additive.seasonal

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("SBU", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    return data


def generate_trend_seasonality_hw_v1(data, essential_non_media, outcome="O_UNIT"):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["SBU"].unique():
        print(f"**** SBU: {brand} Set 5 seasonal decompose period 12 ****")
        brand_level_df = brand_stack[brand_stack["SBU"] == brand][
            [outcome] + essential_non_media
        ]
        # brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        brand_level_df[outcome] = brand_level_df[outcome].astype(float)
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        n = 7
        filter = np.ones(n) / n
        result_additive = seasonal_decompose(
            x=outcome_residuals.copy(),
            extrapolate_trend="freq",
            model="additive",
            period=12,
        )

        test_brand_df = brand_level_df.copy()
        test_brand_df["trend_val"] = result_additive.trend.copy()
        test_brand_df["seasonal_val"] = result_additive.seasonal.copy()
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        print(
            "\n****** trend and seasonality: seasonal decompose period 12; R_sq: ",
            model.rsquared,
            " ******\n",
        )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_5"] = result_additive.trend
        seasonality_dict[brand]["MV_seasonality_5"] = result_additive.seasonal

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("SBU", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    return data


def generate_trend_seasonality_stl_v1(data, essential_non_media, outcome="O_UNIT"):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["SBU"].unique():
        print(f"**** SBU: {brand} Set 6 seasonal decompose period 4 ****")
        brand_level_df = brand_stack[brand_stack["SBU"] == brand][
            [outcome] + essential_non_media
        ]
        # brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        brand_level_df[outcome] = brand_level_df[outcome].astype(float)
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        n = 7
        filter = np.ones(n) / n
        result_additive = seasonal_decompose(
            x=outcome_residuals.copy(),
            extrapolate_trend="freq",
            model="additive",
            period=4,
        )

        test_brand_df = brand_level_df.copy()
        test_brand_df["trend_val"] = result_additive.trend.copy()
        test_brand_df["seasonal_val"] = result_additive.seasonal.copy()
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        print(
            "\n****** trend and seasonality: seasonal decompose period 4; R_sq: ",
            model.rsquared,
            " ******\n",
        )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_6"] = result_additive.trend
        seasonality_dict[brand]["MV_seasonality_6"] = result_additive.seasonal

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("SBU", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    return data


def OLS_func(
    data,
    indep_var,
    outcome,
    brand=None,
    train_start=None,
    train_end=None,
    valid_start=None,
):
    train_data = data[(data.index >= train_start) & (data.index <= train_end)].copy()
    test_data = data[(data.index >= valid_start)].copy()

    Y = train_data[train_data["SBU"] == brand][outcome]
    X = train_data[train_data["SBU"] == brand][indep_var]
    X = sm.add_constant(X)
    model = sm.OLS(Y, X, missing="drop")
    model_result = model.fit()
    return model_result, train_data, test_data


def vif_essential(df_X):
    """
    Finds VIF of the regressors of outcome_variable~essential_vars
    """
    from statsmodels.stats.outliers_influence import variance_inflation_factor

    # Calculate the VIF for each feature of df_X (a Pandas DataFrame).
    vif_data = [variance_inflation_factor(df_X.values, i) for i in range(df_X.shape[1])]
    return pd.Series(vif_data, index=df_X.columns)


# OLS_func(data, indep_var, outcome, brand=None, train_start=None, train_end=None, valid_start=None):


#### eliminating variables with high p-value and vif
def upd_shortlist_variables(
    data,
    essential_vars,
    shortlist_vars,
    brand,
    outcome_var,
    r_sq_adj,
    target_rsq,
    p_val_thresh=0.05,
    vif_thresh=1.1,
    train_start=None,
    train_end=None,
    valid_start=None,
    essential_non_media_with_outliers = None
):
    forward = True
    # curr_rsq = target_rsq

    # while forward:
    #     flag = True
    inp_var = shortlist_vars.copy()
    model_result, train_data, test_data = OLS_func(
        data.copy(),
        inp_var,
        outcome_var,
        brand=brand,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_start,
    )

    curr_rsq = model_result.rsquared_adj

    vif_val = vif_essential(data[data["SBU"] == brand][inp_var]).to_dict()

    # Sort keys to ensure deterministic iteration order
    for media in sorted(vif_val.keys()):
        vif = vif_val[media]

        if (
            float(vif_val[media]) >= vif_thresh or math.isnan(vif_val[media])
        # ) and curr_rsq > target_rsq:                                                                      # NEW 3.30
        ) and curr_rsq > target_rsq and (media not in essential_non_media_with_outliers):                   # NEW 3.30
            shortlist_vars.remove(media)
            inp_var_upd = essential_vars + shortlist_vars
            model_result, train_data, test_data = OLS_func(
                data.copy(),
                inp_var_upd.copy(),
                outcome_var,
                brand=brand,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
            )
            upd_rsq = model_result.rsquared
            if model_result.rsquared < target_rsq:
                shortlist_vars.append(media)
                upd_rsq = curr_rsq
                # forward = False
                # break
            curr_rsq = upd_rsq
        # if math.isnan(vif_val[media]) or vif_val[media] == math.inf:                                      # NEW 3.30
        if math.isnan(vif_val[media]) or vif_val[media] == math.inf and (media not in essential_non_media_with_outliers):       # NEW 3.30
            try:
                shortlist_vars.remove(media)
            except:
                continue

        # flag = True
        # if flag:
        #     forward = False

    final_shortlist = shortlist_vars
    model_result, train_data, test_data = OLS_func(
        data.copy(),
        final_shortlist.copy(),
        outcome_var,
        brand=brand,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_start,
    )

    print("\n**********TRAIN FIT************")
    get_test_fit(train_data, model_result, outcome_var, final_shortlist.copy())

    print("\n**********TEST FIT************")
    get_test_fit(test_data, model_result, outcome_var, final_shortlist.copy())

    brand_r_sq_adj = model_result.rsquared
    return final_shortlist, brand_r_sq_adj


def find_minimum_features(
    data,
    essential_vars,
    shortlist_vars,
    brand,
    outcome_var,
    vif_thresh=1.1,
    train_start=None,
    train_end=None,
    valid_start=None,
    target_r2=0.75,
):
    best_r2 = 0
    selected_features = shortlist_vars.copy()
    potential_features = essential_vars.copy()
    inp_var = essential_vars + shortlist_vars

    # selected_features = list(set(selected_features) - set(essential_vars))
    model_result, train_data, test_data = OLS_func(
        data.copy(),
        selected_features + essential_vars,
        outcome_var,
        brand=brand,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_start,
    )
    return selected_features, best_r2


def get_non_media_coefs(
    brand_list,
    updated_stack,
    non_media_set,
    non_media_z_k,
    outcome="O_UNIT",
    train_start=None,
    train_end=None,
    valid_start=None,
):
    brand_non_media_coef = {}
    fit_metrics = []                                                                 # MSedits MS-12 +
    fit_residuals = {}                                                               # MSedits MS-14 +
    for brand in brand_list:
        brand_non_media_coef[brand] = []
        for i in non_media_set:
            model_result, train_data, test_data = OLS_func(
                updated_stack,
                non_media_z_k[brand][i],
                outcome=outcome,
                brand=brand,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
            )
            # Use OrderedDict or sort keys to ensure deterministic order
            non_media_coefs = {k: model_result.params[k] for k in sorted(model_result.params.index)}
            brand_non_media_coef[brand].append(non_media_coefs)

            # MSedits START MS-12 : per-base R2/MAPE for the >=5-of-10 guardrail.
            # This loop already fits one OLS per base, so R2 is free and MAPE is
            # two extra lines -- no new fitting. IN-SAMPLE ON TRAIN by necessity:
            # test_data is unusable as a holdout because the caller at :1869
            # passes valid_start=valid_end, so it starts at the LAST validation
            # date and is near-empty. Left as-is; changing it is behaviour, not
            # logging. ms_mape_percent is the rescue gate's own MAPE, so this
            # verdict cannot contradict the GATE lines printed earlier.
            _ms_y_pred = model_result.fittedvalues        # index = rows kept by missing="drop"
            _ms_y_true = train_data[train_data["SBU"] == brand][outcome].reindex(_ms_y_pred.index)
            fit_metrics.append({
                "base": f"{brand}/z_{i}",                 # matches the ms_base_usage key convention
                "r2": float(model_result.rsquared),
                "mape": ms_mape_percent(_ms_y_true, _ms_y_pred),
            })
            # MSedits MS-14: keep the residual series too -- run_base_rescue
            # scores days from the candidate bases' own misses, so it needs the
            # per-day residual, not just the aggregate MAPE. Indexed by Date.
            fit_residuals[f"{brand}/z_{i}"] = _ms_y_true - _ms_y_pred
            # MSedits END MS-12
    return brand_non_media_coef, fit_metrics, fit_residuals                          # MSedits MS-14 ~


def get_non_media_matrix(
    data,
    dummy_var_lst,
    essential_non_media,
    brand_list,
    outcome_vars,
    non_media_set,
    train_start,
    train_end,
    valid_start,
    valid_end,
    target_r2=0.8,
    essential_non_media_with_outliers=None,
    ms_ctx=None,                        # MSedits MS-12 + : optional, so the two non-MSedits
                                        # call sites stay untouched and the 5-tuple return
                                        # below keeps its shape (3 positional unpack sites).
):

    essential_vars_og = sorted(list(set(dummy_var_lst) - set(essential_non_media)))
    seasonality_cols = ["MV_trend_1", "MV_seasonality_1"]
    seasonality_cols_hw = ["MV_trend_2", "MV_seasonality_2"]
    seasonality_cols_stl = ["MV_trend_3", "MV_seasonality_3"]
    seasonality_cols_v1 = ["MV_trend_4", "MV_seasonality_4"]
    seasonality_cols_hw_v1 = ["MV_trend_5", "MV_seasonality_5"]
    seasonality_cols_stl_v1 = ["MV_trend_6", "MV_seasonality_6"]
    seasonality_cols_sarimax = ["SARIMAX"]
    seasonality_cols_sarimax_log = ["SARIMAX_LOG"]
    seasonality_cols_out_trnd_seasn = [
        str(outcome_vars[0]) + "_TREND",
        str(outcome_vars[0]) + "_SEASONALITY",
    ]
    seasonality_cols_out_trnd_seasn_log = [
        str(outcome_vars[0]) + "_TREND_LOG",
        str(outcome_vars[0]) + "_SEASONALITY_LOG",
    ]

    # essential_vars_sd = essential_non_media + seasonality_cols
    essential_vars_sd = (
        sorted(list(set(essential_non_media) - set(weekend_vars))) + seasonality_cols
    )  ## Ignore weekends for weekly
    essential_vars_hw = essential_non_media + seasonality_cols_hw
    essential_vars_stl = essential_non_media + seasonality_cols_stl

    essential_vars_sd_v1 = (
        sorted(list(set(essential_non_media) - set(weekend_vars))) + seasonality_cols_v1
    )  ## Ignore weekends for weekly
    essential_vars_hw_v1 = essential_non_media + seasonality_cols_hw_v1
    essential_vars_stl_v1 = essential_non_media + seasonality_cols_stl_v1
    essential_vars_sarimax = essential_non_media + seasonality_cols_sarimax
    essential_vars_sarimax_log = essential_non_media + seasonality_cols_sarimax_log
    essential_vars_out_trnd_seasn = (
        essential_non_media + seasonality_cols_out_trnd_seasn
    )
    essential_vars_out_trnd_seasn_log = (
        essential_non_media + seasonality_cols_out_trnd_seasn_log
    )
    # updated_shortlist_hw, r_sq_adj_hw, updated_shortlist_ar, r_sq_adj_ar, updated_shortlist_sd, r_sq_adj_sd = {}, {}, {}, {}, {}, {}
    (
        updated_shortlist_hw,
        r_sq_adj_hw,
        updated_shortlist_stl,
        r_sq_adj_stl,
        updated_shortlist_sd,
        r_sq_adj_sd,
        updated_shortlist_hw_v1,
        r_sq_adj_hw_v1,
        updated_shortlist_stl_v1,
        r_sq_adj_stl_v1,
        updated_shortlist_sd_v1,
        r_sq_adj_sd_v1,
        updated_shortlist_sarimax,
        r_sq_adj_sarimax,
        updated_shortlist_sarimax_log,
        r_sq_adj_sarimax_log,
        updated_shortlist_out_trnd_seasn,
        r_sq_adj_out_trnd_seasn,
        updated_shortlist_out_trnd_seasn_log,
        r_sq_adj_out_trnd_seasn_log,
    ) = ({}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {})
    print(
        "*********** Performing seasonality analysis to get non media variables ***********"
    )
    for outcome in outcome_vars:
        seasonal_stack = generate_trend_seasonality(
            data.copy(), essential_non_media, outcome
        )
        seasonal_stack_hw = generate_trend_seasonality_hw(
            data.copy(), essential_non_media, outcome
        )
        seasonal_stack_stl = generate_trend_seasonality_stl(
            data.copy(), essential_non_media, outcome
        )

        seasonal_stack_v1 = generate_trend_seasonality_v1(
            data.copy(), essential_non_media, outcome
        )
        seasonal_stack_hw_v1 = generate_trend_seasonality_hw_v1(
            data.copy(), essential_non_media, outcome
        )
        seasonal_stack_stl_v1 = generate_trend_seasonality_stl_v1(
            data.copy(), essential_non_media, outcome
        )
        seasonal_stack_sarimax = generate_trend_seasonality_arima(
            data.copy(), essential_non_media, outcome
        )

    print(
        "*********** Performing backward elimination to only retain essential variables ***********\n"
    )
    outcome = outcome_vars[0]
    for brand in brand_list:
        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack.copy(),
            sorted(list(set(essential_vars_og.copy()) - set(weekend_vars))),
            essential_vars_sd.copy(),
            brand,
            outcome,
            vif_thresh=1.1,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_sd[brand], r_sq_adj_sd[brand] = upd_shortlist_variables(
            seasonal_stack.copy(),
            essential_vars_sd.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            essential_non_media_with_outliers = essential_non_media_with_outliers,
        )
        print(
            f"********* R_Sq_Adj Set 1 (trend+seasonality, using MV period: 7 or period 52) brand {brand} *********",
            r_sq_adj_sd[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack_v1.copy(),
            sorted(list(set(essential_vars_og.copy()) - set(weekend_vars))),
            essential_vars_sd_v1.copy(),
            brand,
            outcome,
            vif_thresh=1.1,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_sd_v1[brand], r_sq_adj_sd_v1[brand] = upd_shortlist_variables(
            seasonal_stack_v1.copy(),
            essential_vars_sd_v1.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            essential_non_media_with_outliers = essential_non_media_with_outliers,
        )
        print(
            f"********* R_Sq_Adj Set 2 (trend+seasonality, using seasonal decompose period 52) brand {brand} *********",
            r_sq_adj_sd_v1[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack_hw.copy(),
            essential_vars_og.copy(),
            essential_vars_hw.copy(),
            brand,
            outcome,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_hw[brand], r_sq_adj_hw[brand] = upd_shortlist_variables(
            seasonal_stack_hw.copy(),
            essential_vars_hw.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            essential_non_media_with_outliers = essential_non_media_with_outliers,
        )
        print(
            f"********* R_Sq_Adj Set 3 (trend+seasonality using MV period:15 or period 12) brand {brand} *********",
            r_sq_adj_hw[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack_hw_v1.copy(),
            essential_vars_og.copy(),
            essential_vars_hw_v1.copy(),
            brand,
            outcome,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_hw_v1[brand], r_sq_adj_hw_v1[brand] = upd_shortlist_variables(
            seasonal_stack_hw_v1.copy(),
            essential_vars_hw_v1.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            essential_non_media_with_outliers = essential_non_media_with_outliers,
        )
        print(
            f"********* R_Sq_Adj Set 4 (trend+seasonality using seasonal decompose period 12) brand {brand} *********",
            r_sq_adj_hw_v1[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack_stl.copy(),
            essential_vars_og.copy(),
            essential_vars_stl.copy(),
            brand,
            outcome,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_stl[brand], r_sq_adj_stl[brand] = upd_shortlist_variables(
            seasonal_stack_stl.copy(),
            essential_vars_stl.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            essential_non_media_with_outliers = essential_non_media_with_outliers,
        )
        print(
            f"********* R_Sq_Adj Set 5 (trend+seasonality using MV period 30 or period 4) brand {brand} *********",
            r_sq_adj_stl[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack_stl_v1.copy(),
            essential_vars_og.copy(),
            essential_vars_stl_v1.copy(),
            brand,
            outcome,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_stl_v1[brand], r_sq_adj_stl_v1[brand] = (
            upd_shortlist_variables(
                seasonal_stack_stl_v1.copy(),
                essential_vars_stl_v1.copy(),
                updated_shortlist.copy(),
                brand,
                outcome,
                r_sq_adj,
                target_r2,
                p_val_thresh=0.05,
                vif_thresh=3.5,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
                essential_non_media_with_outliers = essential_non_media_with_outliers,
            )
        )
        print(
            f"********* R_Sq_Adj Set 6 (trend+seasonality using seasonal decompose period 4) brand {brand} *********",
            r_sq_adj_stl_v1[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack_sarimax.copy(),
            essential_vars_og.copy(),
            essential_vars_sarimax.copy(),
            brand,
            outcome,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_sarimax[brand], r_sq_adj_sarimax[brand] = (
            upd_shortlist_variables(
                seasonal_stack_sarimax.copy(),
                essential_vars_sarimax.copy(),
                updated_shortlist.copy(),
                brand,
                outcome,
                r_sq_adj,
                target_r2,
                p_val_thresh=0.05,
                vif_thresh=3.5,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
                essential_non_media_with_outliers = essential_non_media_with_outliers,
            )
        )
        print(
            f"********* R_Sq_Adj Set 7 (sarimax) brand {brand} *********",
            r_sq_adj_sarimax[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack_sarimax.copy(),
            essential_vars_og.copy(),
            essential_vars_sarimax_log.copy(),
            brand,
            outcome,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_sarimax_log[brand], r_sq_adj_sarimax_log[brand] = (
            upd_shortlist_variables(
                seasonal_stack_sarimax.copy(),
                essential_vars_sarimax_log.copy(),
                updated_shortlist.copy(),
                brand,
                outcome,
                r_sq_adj,
                target_r2,
                p_val_thresh=0.05,
                vif_thresh=3.5,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
                essential_non_media_with_outliers = essential_non_media_with_outliers,
            )
        )
        print(
            f"********* R_Sq_Adj Set 8 (sarimax log) brand {brand} *********",
            r_sq_adj_sarimax_log[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack_sarimax.copy(),
            essential_vars_og.copy(),
            essential_vars_out_trnd_seasn.copy(),
            brand,
            outcome,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_out_trnd_seasn[brand], r_sq_adj_out_trnd_seasn[brand] = (
            upd_shortlist_variables(
                seasonal_stack_sarimax.copy(),
                essential_vars_out_trnd_seasn.copy(),
                updated_shortlist.copy(),
                brand,
                outcome,
                r_sq_adj,
                target_r2,
                p_val_thresh=0.05,
                vif_thresh=3.5,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
                essential_non_media_with_outliers = essential_non_media_with_outliers,
            )
        )
        print(
            f"********* R_Sq_Adj Set 9 (sarimax trend, seasonality) brand {brand} *********",
            r_sq_adj_out_trnd_seasn[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack_sarimax.copy(),
            essential_vars_og.copy(),
            essential_vars_out_trnd_seasn_log.copy(),
            brand,
            outcome,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        (
            updated_shortlist_out_trnd_seasn_log[brand],
            r_sq_adj_out_trnd_seasn_log[brand],
        ) = upd_shortlist_variables(
            seasonal_stack_sarimax.copy(),
            essential_vars_out_trnd_seasn_log.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            essential_non_media_with_outliers = essential_non_media_with_outliers,
        )
        print(
            f"********* R_Sq_Adj Set 10 (sarimax trend log, seasonality log) brand {brand} *********",
            r_sq_adj_out_trnd_seasn_log[brand],
            "\n",
        )

    print("*********** Creating processed non media matrix ***********")
    combined_data = seasonal_stack.merge(
        seasonal_stack_hw[["SBU", "MV_trend_2", "MV_seasonality_2"]],
        on=["Date", "SBU"],
        how="left",
    )
    combined_data = combined_data.merge(
        seasonal_stack_stl[["SBU", "MV_trend_3", "MV_seasonality_3"]],
        on=["Date", "SBU"],
        how="left",
    )
    combined_data = combined_data.merge(
        seasonal_stack_v1[["SBU", "MV_trend_4", "MV_seasonality_4"]],
        on=["Date", "SBU"],
        how="left",
    )
    combined_data = combined_data.merge(
        seasonal_stack_hw_v1[["SBU", "MV_trend_5", "MV_seasonality_5"]],
        on=["Date", "SBU"],
        how="left",
    )
    combined_data = combined_data.merge(
        seasonal_stack_stl_v1[["SBU", "MV_trend_6", "MV_seasonality_6"]],
        on=["Date", "SBU"],
        how="left",
    )
    combined_data = combined_data.merge(
        seasonal_stack_sarimax[
            [
                "SBU",
                "SARIMAX",
                "SARIMAX_LOG",
                str(outcome) + "_TREND",
                str(outcome) + "_SEASONALITY",
                str(outcome) + "_TREND_LOG",
                str(outcome) + "_SEASONALITY_LOG",
            ]
        ],
        on=["Date", "SBU"],
        how="left",
    )

    """
    combined_data = seasonal_stack.merge(
        seasonal_stack_hw.merge(
            seasonal_stack_stl[["BRAND", "MV_trend_3", "MV_seasonality_3"]],
            on=["Date", "BRAND"],
            how="left",
        )[
            [
                "BRAND",
                "MV_trend_3",
                "MV_seasonality_3",
                "MV_trend_2",
                "MV_seasonality_2",
            ]
        ],
        on=["Date", "BRAND"],
        how="left",
    )
    """

    combined_data["INTERCEPT"] = 1

    non_media_z_k = {}
    for key, value in updated_shortlist_hw.items():
        # non_media_z_k[key] = [updated_shortlist_hw[key]+['INTERCEPT'], updated_shortlist_ar[key]+['INTERCEPT'], updated_shortlist_sd[key]+['INTERCEPT']]
        non_media_z_k[key] = [
            updated_shortlist_sd[key] + ["INTERCEPT"],
            updated_shortlist_hw[key] + ["INTERCEPT"],
            updated_shortlist_stl[key] + ["INTERCEPT"],
            updated_shortlist_sd_v1[key] + ["INTERCEPT"],
            updated_shortlist_hw_v1[key] + ["INTERCEPT"],
            updated_shortlist_stl_v1[key] + ["INTERCEPT"],
            updated_shortlist_sarimax[key] + ["INTERCEPT"],
            updated_shortlist_sarimax_log[key] + ["INTERCEPT"],
            updated_shortlist_out_trnd_seasn[key] + ["INTERCEPT"],
            updated_shortlist_out_trnd_seasn_log[key] + ["INTERCEPT"],
        ]

    num_non_media = len(non_media_z_k[brand_list[0]])
    print("\n non_media_set", non_media_set, "\n")
    print("\n final non media set created", non_media_z_k, "\n")

    # Round seasonality and trend columns to 5 decimal places to eliminate floating-point noise
    seasonality_trend_cols = [
        "MV_trend_1", "MV_seasonality_1",
        "MV_trend_2", "MV_seasonality_2",
        "MV_trend_3", "MV_seasonality_3",
        "MV_trend_4", "MV_seasonality_4",
        "MV_trend_5", "MV_seasonality_5",
        "MV_trend_6", "MV_seasonality_6",
        "SARIMAX", "SARIMAX_LOG",
        str(outcome) + "_TREND", str(outcome) + "_SEASONALITY",
        str(outcome) + "_TREND_LOG", str(outcome) + "_SEASONALITY_LOG"
    ]
    for col in seasonality_trend_cols:
        if col in combined_data.columns:
            combined_data[col] = combined_data[col].round(5)

    pre_processed_matrix_U_kj, pre_processed_matrix_Y_kj = [], []
    for idx in range(len(brand_list)):
        matrix_U_kj, matrix_Y_kj = [], []
        for j in non_media_set:
            Z_k_j = combined_data[combined_data["SBU"] == brand_list[idx]][
                non_media_z_k[brand_list[idx]][j]
            ].to_numpy()
            Z_k_j_transpose = Z_k_j.transpose()
            try:
                Z_k_j_inv = inv(Z_k_j_transpose.dot(Z_k_j))
            except:
                Z_k_j_inv = pinv(Z_k_j_transpose.dot(Z_k_j))

            P_k_j = np.dot(Z_k_j, np.dot(Z_k_j_inv, Z_k_j_transpose))
            # Z_k_j.dot(Z_k_j_inv.dot(Z_k_j_transpose))

            I = np.identity(P_k_j.shape[0])
            U_k_j = I - P_k_j

            Y_k = combined_data[
                combined_data["SBU"] == brand_list[idx]
            ]  # .to_numpy()
            Y_k_j = np.asarray(
                residual_calculation(
                    Y_k.copy(),
                    "O_UNIT",
                    non_media_z_k[brand_list[idx]][j],
                    add_const=False,
                )
            )
            matrix_U_kj.append(U_k_j)
            matrix_Y_kj.append(Y_k_j)
        pre_processed_matrix_U_kj.append(np.asarray(matrix_U_kj))
        pre_processed_matrix_Y_kj.append(np.asarray(matrix_Y_kj))

    #### fetch non media coefficients
    non_media_coef, _ms_fit_metrics, _ms_fit_residuals = get_non_media_coefs(         # MSedits MS-14 ~
        brand_list,
        combined_data,
        non_media_set,
        non_media_z_k,
        outcome=outcome,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_end,
    )
    # MSedits START MS-12 : hand the per-base metrics out via the registry rather
    # than a 6th return value -- this function's 5-tuple is positionally unpacked
    # at three call sites, two of them outside MSedits.
    if ms_ctx is not None:
        _ms_reg = ms_ctx.setdefault("registry", {})
        _ms_reg["fit_metrics"] = _ms_fit_metrics            # latest pass
        _ms_reg["base_residuals"] = _ms_fit_residuals       # latest pass   MS-14 +
        # MS-14: APPEND, never overwrite. Under the rebuild loop this function
        # runs more than once, and assigning would silently discard pass 1 --
        # making the verdict's progression line report a history that never
        # happened.
        _ms_reg.setdefault("fit_metrics_history", []).append(_ms_fit_metrics)
    # MSedits END MS-12
    print("**************** selected non media ****************")
    for idx in range(len(brand_list)):
        print("brand: ", brand_list[idx])
        for j in non_media_set:
            print("\n set: ", j)
            print(non_media_z_k[brand_list[idx]][j])

    return (
        np.asarray(pre_processed_matrix_U_kj),
        np.asarray(pre_processed_matrix_Y_kj),
        combined_data,
        non_media_z_k,
        non_media_coef,
    )