#!/usr/bin/env python
# coding: utf-8
# author: Shiv Ganesh
import math
import numpy as np
import pandas as pd
import os
from datetime import datetime, timedelta

from lite_non_media_utils_v3_Nat_Fit import *
from dateutil.relativedelta import relativedelta

date_format = "%Y-%m-%d"


class Model_Object:
    
    def __init__(
        self,
        data,
        solution,
        config):
        
        self.data = data
        try:
            self.data['Date'] = pd.to_datetime(self.data['Date'], format='%Y-%m-%d')
        except:
            self.data['Date'] = pd.to_datetime(self.data['Date'], format='mixed')
        self.solution_df = solution
        self.config = config
        self.media_variables = config["media_variables_all"]
        self.non_media_variables = config["non_media_z_k"]
        self.non_media_details = config['non_media_coef']
        self.num_media_vars = len(self.media_variables)
        self.num_non_media_vars = len(self.non_media_variables)
        self.beta_nm = list(self.non_media_details.values())
        self.WMC_PORTFOLIO_DICT = config['wmc_portfolio_dict']
        self.spend_vars = []

        for var in self.media_variables:
            if "_IMP" in var:
                spend_var = var.replace("_IMP", "_SPEND")
            else:
                spend_var = var.replace("_CLK", "_SPEND")
            self.spend_vars.append(spend_var)

        self.Y_kj_all = np.asarray([[np.loadtxt(config["Y_kj_path"])]])[0][0]

        self.priors_df = pd.read_csv(config["priors_info_path"][:-4]+"_updated.csv")
        self.priors_df  = self.priors_df.reset_index(drop=True)
        self.priors_df = self.priors_df.sort_values(by='media_variable')
        display(self.priors_df)
        self.iroas_lb = self.priors_df['iroas_lb_opt'].to_numpy() #iroas_lb_opt
        self.iroas_ub = self.priors_df['iroas_ub_opt'].to_numpy()
        self.iroas_prior = self.priors_df['iroas_prior'].to_numpy()
        self.coef_mean_prior = self.priors_df['coef_mean_prior'].to_numpy()
        self.train_spend = self.priors_df['train_spend'].to_numpy()
        self.train_price = self.priors_df['train_price'].to_numpy()

        self.train_start = config["train_start"]
        self.train_end = config["train_end"]
        self.valid_start = config["valid_start"]
        self.valid_end = config["valid_end"]

        self.st_dt = datetime.strptime(self.train_start, date_format)
        self.train_end_dt = datetime.strptime(self.train_end, date_format)
        self.test_st_dt = datetime.strptime(self.valid_start, date_format)
        self.test_end_dt = datetime.strptime(self.valid_end, date_format)
        self.train_end_index = (self.train_end_dt - self.st_dt).days + 1
        self.l12_start_index = ((self.train_end_dt - relativedelta(months=12)) - self.st_dt).days + 1
        self.prev_year_start_index = ((self.train_end_dt - relativedelta(months=24)) - self.st_dt).days + 1
        self.prev_year_end_index = ((self.train_end_dt - relativedelta(months=12)) - self.st_dt).days
        self.valid_start_index = (self.test_st_dt - self.st_dt).days
        self.valid_end_index = (self.test_end_dt - self.st_dt).days + 1
        
        self.test_start_index = ((self.train_end_dt - relativedelta(months=3)) - self.st_dt).days + 1
        self.test_end_index = (self.train_end_dt - self.st_dt).days
        
        self.valid_start_dt = datetime.strptime(self.valid_start, date_format)
        self.valid_end_dt = datetime.strptime(self.valid_end, date_format)

        self.Y_kj = self.Y_kj_all[
                        :self.train_end_index
                    ]
        '''self.Y_kj_valid = self.Y_kj_all[
                        self.train_end_index:
                    ]'''
        self.Y_kj_valid = self.Y_kj_all[self.test_start_index:self.test_end_index+1]
        
        self.solution_df['media_transformation_string'] = self.solution_df['Media_transformation (hf, inf, sc, lg)'].str.replace('[','_')
        self.solution_df['media_transformation_string'] = self.solution_df['media_transformation_string'].str.replace(',','_')
        self.solution_df['media_transformation_string'] = self.solution_df['media_transformation_string'].str.replace(']','')
        self.solution_df['media_transformation_string'] = self.solution_df['media_transformation_string'].str.replace(' ','')

        self.solution_df["media_transformation_string"] = self.solution_df["media_transformation_string"].apply(lambda x: '_'.join([str(item) for item in x.split('_')[:-1]])) 
        self.solution_df['variable_transformations'] = self.solution_df["Media_tactic"].astype(str) + self.solution_df["media_transformation_string"]
        self.solution_df  = self.solution_df.reset_index(drop=True)
        self.solution_df = self.solution_df.sort_values(by='Media_tactic')
        self.initial_coef = self.solution_df['Coefficient'].to_numpy()
        self.lambda_k_nm = np.zeros(self.num_non_media_vars)
        self.lambda_k_m = self.solution_df['Lambda_k'].to_numpy()

        self.lambda_k = np.concatenate((self.lambda_k_nm, self.lambda_k_m))
        
        self.filter_wmc_media()
        self.data_prep()
        
    def data_prep(self):

        self.df_transformed_new, self.scaling_factor_arr = create_missing_media_transformations_new(self.data, self.solution_df['variable_transformations'])
        self.df_transformed_new.to_csv("df_transformed_new.csv", index=False)
        self.updated_stack_brand = self.df_transformed_new
        
        self.updated_stack_brand = self.updated_stack_brand[['PRICE','Date','O_SALE','O_UNIT','STACK_TYPE','L0', 'L1', 'L2', 'SBU']+self.media_variables+self.non_media_variables+self.spend_vars]


        self.SST = np.sum(
                    (self.updated_stack_brand['O_UNIT'] - np.mean(self.updated_stack_brand['O_UNIT']))
                    ** 2
                )
        
        self.SST_train = np.sum(
            (self.updated_stack_brand['O_UNIT'][:self.train_end_index] - np.mean(self.updated_stack_brand['O_UNIT'][:self.train_end_index]))
            ** 2
        )

        self.SST_valid = np.sum( 
            (self.updated_stack_brand['O_UNIT'][self.valid_start_index:self.valid_end_index] - np.mean(self.updated_stack_brand['O_UNIT'][self.valid_start_index:self.valid_end_index]))
            ** 2
        )

        self.non_media_data = np.asarray(self.updated_stack_brand[self.non_media_variables])

        self.transformed_var_actual = np.asarray(self.updated_stack_brand[self.media_variables].copy().astype("float64"))

        self.media_length = len(self.transformed_var_actual)

        self.transformed_media = np.zeros((self.num_media_vars, self.train_end_index))
        self.transformed_media_total = np.zeros((self.num_media_vars, self.media_length))
        self.X_tilde = np.zeros((self.num_media_vars, self.train_end_index))
        self.X_tilde_all = np.zeros((self.num_media_vars, self.media_length))
        self.X_tilde_valid = np.zeros((self.num_media_vars, self.valid_end_index-self.valid_start_index))

        for media_var_idx in range(self.num_media_vars):

            transformed_var = self.transformed_var_actual[
                :, media_var_idx
            ]
            self.transformed_media_total[media_var_idx] = np.asarray(transformed_var)
            self.transformed_media[media_var_idx] = np.asarray(transformed_var[:self.train_end_index])

            data_upd = self.non_media_data.astype(np.float64).copy()
            trans_med_tot = (
                                        self.transformed_media_total[media_var_idx].astype(np.float64).copy()
                                        )
            beta = (
                        np.linalg.inv(data_upd.T @ data_upd)
                        @ data_upd.T
                        @ trans_med_tot.T
                        )
            fitted_values = data_upd @ beta
            
            self.X_tilde_all[media_var_idx] = trans_med_tot - fitted_values

        I = np.identity(self.num_non_media_vars+self.num_media_vars)
        for i in range(self.num_non_media_vars+self.num_media_vars):

            I[i][i] = self.lambda_k[i]

        self.X = np.concatenate((self.updated_stack_brand[self.non_media_variables].astype(np.float64).to_numpy(), self.transformed_var_actual.astype(np.float64)), axis = 1).T
        self.Y = self.updated_stack_brand['O_UNIT'].astype(np.float64).to_numpy()

        self.X_train = self.X[:,:self.train_end_index]
        self.Y_train = self.Y[:self.train_end_index]

        self.X_valid = self.X[:,self.valid_start_index:self.valid_end_index]
        self.Y_valid = self.Y[self.valid_start_index:self.valid_end_index]

        self.scaled_prior_nm = np.zeros(self.num_non_media_vars)
        self.scaled_prior_m = self.coef_mean_prior * self.scaling_factor_arr
        self.scaled_prior = np.concatenate((self.scaled_prior_nm, self.scaled_prior_m))

        val_2 = np.dot(
            self.X_train , self.X_train.transpose()
        )

        P_mkj = inv(I + val_2)

        Q_mkj = np.dot(self.X_train, self.Y_train) + np.dot(
            I, self.scaled_prior
        )

        self.Beta_j = np.dot(P_mkj, Q_mkj)


        self.X_tilde = self.X_tilde_all[:, :self.train_end_index]
        self.X_tilde_valid = self.X_tilde_all[:, self.valid_start_index:self.valid_end_index]

        self.train_spend = np.asarray(self.updated_stack_brand[self.spend_vars][:self.train_end_index]).sum(axis=0)
        self.updated_stack_brand_valid = self.updated_stack_brand[self.valid_start_index:self.valid_end_index]
        self.updated_stack_brand = self.updated_stack_brand[:self.train_end_index]

        self.updated_stack_brand['Y_pred'] = 0
        self.updated_stack_brand_valid['Y_pred'] = 0

        # option 1

        self.X_train_nm = self.X_train[:self.num_non_media_vars,]
        self.X_valid_nm = self.X_valid[:self.num_non_media_vars,]

        val_2 = np.linalg.pinv(self.X_train_nm @ self.X_train_nm.T)

        ####################################################################
        # Q_mkj = (self.X_train_nm
        #                 @ self.Y_train
        #                 )
        
        # self.beta_nm_fit = val_2 @ Q_mkj
        
        # self.model = sm.OLS(self.Y_train, self.X_train_nm, missing="drop")
        # self.model_result = self.model.fit()
        ####################################################################

        self.Y_train_resid = (self.Y_train-(self.initial_coef*self.transformed_media.T).sum(axis=1))
        Q_mkj = np.dot(self.X_train_nm, self.Y_train_resid)
        self.beta_nm_fit = np.dot(val_2, Q_mkj)

        self.updated_stack_brand['Y_pred'] += ((self.initial_coef*self.transformed_media.T).sum(axis=1))
        self.updated_stack_brand['Y_pred'] += ((self.beta_nm_fit*self.X_train_nm.T).sum(axis=1)) 

        self.updated_stack_brand_valid['Y_pred'] += ((self.initial_coef*self.transformed_media.T[self.valid_start_index:self.valid_end_index]).sum(axis=1))
        self.updated_stack_brand_valid['Y_pred'] += ((self.beta_nm_fit*self.X_valid_nm.T).sum(axis=1))

        self.SSE = np.sum(
                    (self.updated_stack_brand['O_UNIT'] - self.updated_stack_brand['Y_pred'])
                    ** 2
                )
        
        self.SSE_train = np.sum(
            (self.updated_stack_brand['O_UNIT'][:self.train_end_index] - self.updated_stack_brand['Y_pred'][:self.train_end_index])
            ** 2
        )

        self.SSE_valid = np.sum( 
            (self.updated_stack_brand['O_UNIT'][self.valid_start_index:self.valid_end_index] - self.updated_stack_brand['Y_pred'][self.valid_start_index:self.valid_end_index])
            ** 2
        )

        self.R_Square = 1 - (self.SSE/self.SST)
        self.Train_R_Square = 1 - (self.SSE_train/self.SST_train)
        self.Valid_R_Square = 1 - (self.SSE_valid/self.SST_valid)

        self.Mape = np.mean(np.abs((self.updated_stack_brand['O_UNIT'] - self.updated_stack_brand['Y_pred']) / self.updated_stack_brand['O_UNIT'])) * 100
        self.Train_Mape = np.mean(np.abs((self.updated_stack_brand['O_UNIT'][:self.train_end_index] - self.updated_stack_brand['Y_pred'][:self.train_end_index]) / self.updated_stack_brand['O_UNIT'][:self.train_end_index])) * 100
        self.Valid_Mape = np.mean(np.abs((self.updated_stack_brand['O_UNIT'][self.valid_start_index:self.valid_end_index] - self.updated_stack_brand['Y_pred'][self.valid_start_index:self.valid_end_index]) / self.updated_stack_brand['O_UNIT'][self.valid_start_index:self.valid_end_index])) * 100
    
        print('Model fit:')
        plot_fig_fit(self.updated_stack_brand, self.updated_stack_brand['O_UNIT'], self.updated_stack_brand['Y_pred'])
        
    def filter_wmc_media(self):

        self.on_wmc_idx= []
        self.off_wmc_idx = []
        self.search_wmc_idx = []
        self.wmt_idx = []

        for i, var in enumerate(self.media_variables):
            if (
                var.startswith("M_ON_DIS")
            ):
                self.on_wmc_idx.append(i)
            elif (var.startswith("M_OFF_DIS")):
                self.off_wmc_idx.append(i)
            elif (var.startswith("M_SP")
                or var.startswith("M_SBA")  ## was missing
                or var.startswith("M_SV")):
                self.search_wmc_idx.append(i)
            else:

                self.wmt_idx.append(i)

        self.on_wmc_idx =np.asarray(self.on_wmc_idx)
        self.off_wmc_idx =np.asarray(self.off_wmc_idx)
        self.search_wmc_idx =np.asarray(self.search_wmc_idx)
        self.wmt_idx =np.asarray(self.wmt_idx)
        
    def save_model_outputs(self, file_name="../model_results/model_outputs_05.xlsx"):
            
        for key, value in self.WMC_PORTFOLIO_DICT.items():

            start_date = value["start_date"]
            end_date = value["end_date"]
            period = value["Period"]

            print(f'Summary Statistics for {key} : {period}:')

            start_index = self.data[self.data['Date']==start_date].index[0]
            end_index = self.data[self.data['Date']==end_date].index[0] + 1

            self.transformed_media = self.transformed_media_total[:, start_index:end_index]
            self.train_spend = np.asarray(self.data[self.spend_vars][start_index:end_index]).sum(axis=0)

            ###### Print WMC Outputs #######

            self.data['Date'] = pd.to_datetime(self.data['Date'])
            #raw_media_data = self.data[(self.data['Date']>=start_date) & (self.data['Date']<=end_date)][self.media_variables].copy()
            raw_units = self.data[(self.data['Date']>=start_date) & (self.data['Date']<=end_date)][['O_SALE', 'O_UNIT']].copy()
            media_stack_path = self.config.get("modeling_stack_path")
            media_stack_df = pd.read_csv(media_stack_path)
            media_stack_df['INDEX'] = pd.to_datetime(media_stack_df['INDEX'])
            media_stack_df = media_stack_df[(media_stack_df['INDEX'] >= pd.to_datetime(start_date)) &
                                (media_stack_df['INDEX'] <= pd.to_datetime(end_date))]
            variables = self.media_variables
            missing_vars = set(self.media_variables) - set(media_stack_df.columns)
            if missing_vars:
                print(f"Missing columns in media_stack_df: {missing_vars}")
            media_stack_df = media_stack_df[variables]
            wmc_result_data = {
                                "Display Level" : self.media_variables,
                                "Total Contribution" : (self.initial_coef * self.transformed_media.sum(axis=1)),
                                "Total Sales ($)" : (self.initial_coef * self.transformed_media.sum(axis=1) * self.train_price),
                                "Total Spend ($)" : self.train_spend,
                                #"Raw Media" : raw_media_data.sum(axis=0),
                                "Raw Media" : media_stack_df.sum(axis=0),
                                "Volume RoAS" : (self.initial_coef * self.transformed_media.sum(axis=1)/ self.train_spend),
                                "Value RoAS ($)" : (self.initial_coef * self.transformed_media.sum(axis=1) * self.train_price/ self.train_spend)
            }

            wmc_result_data_df = pd.DataFrame.from_dict(wmc_result_data)
        
            wmc_result_data_df['Contribution Share(%)'] = wmc_result_data_df['Total Contribution']/wmc_result_data_df['Total Contribution'].sum()
            wmc_result_data_df['Spend Share(%)'] = wmc_result_data_df['Total Spend ($)']/wmc_result_data_df['Total Spend ($)'].sum()
            wmc_result_data_df['Raw Media Share(%)'] = wmc_result_data_df['Raw Media']/wmc_result_data_df['Raw Media'].sum()

            total_incremental = {"Display Level": "Total Incremental",
                                     "Total Contribution": wmc_result_data_df['Total Contribution'].sum(),
                                     "Total Sales ($)": wmc_result_data_df['Total Sales ($)'].sum(),
                                     "Total Spend ($)": wmc_result_data_df['Total Spend ($)'].sum(),
                                     "Raw Media": wmc_result_data_df['Raw Media'].sum(),
                                     "Volume RoAS": wmc_result_data_df['Total Contribution'].sum()/wmc_result_data_df['Total Spend ($)'].sum(),
                                     "Value RoAS ($)": wmc_result_data_df['Total Sales ($)'].sum()/wmc_result_data_df['Total Spend ($)'].sum(),
                                     "Contribution Share(%)": wmc_result_data_df['Total Contribution'].sum()/raw_units['O_UNIT'].sum(),
                                     "Spend Share(%)": 100,
                                     "Raw Media Share(%)": 100}

            base = {"Display Level": "Base",
                        "Total Contribution": raw_units['O_UNIT'].sum() - wmc_result_data_df['Total Contribution'].sum(),
                        "Total Sales ($)": raw_units['O_SALE'].sum() - wmc_result_data_df['Total Sales ($)'].sum(),
                        "Total Spend ($)": 0,
                        "Raw Media": 0,
                        "Volume RoAS": 0,
                        "Value RoAS ($)": 0,
                        "Contribution Share(%)": 1 - (wmc_result_data_df['Total Contribution'].sum()/raw_units['O_UNIT'].sum()),
                        "Spend Share(%)": 0,
                        "Raw Media Share(%)": 0}

            total = {"Display Level": "Total",
                        "Total Contribution": raw_units['O_UNIT'].sum(),
                        "Total Sales ($)": raw_units['O_SALE'].sum(),
                        "Total Spend ($)": wmc_result_data_df['Total Spend ($)'].sum(),
                        "Raw Media": wmc_result_data_df['Raw Media'].sum(),
                        "Volume RoAS": 0,
                        "Value RoAS ($)": 0,
                        "Contribution Share(%)": 100,
                        "Spend Share(%)": 0,
                        "Raw Media Share(%)": 0}

            wmc_result_data_df.loc[len(wmc_result_data_df)] = total_incremental
            wmc_result_data_df.loc[len(wmc_result_data_df)] = base
            wmc_result_data_df.loc[len(wmc_result_data_df)] = total

            display(wmc_result_data_df)
            wmc_result_data_df.to_csv('../model_results/WMC_'+start_date+'_'+end_date+'_'+'05'+'.csv', index=False)
           


        Coefficient_Summary = {
                           "Variables" : self.media_variables + self.non_media_variables,
                           #"Coefficient" : self.Beta,
                           "Coefficient": np.concatenate([self.initial_coef, np.array(list(self.beta_nm_fit))]), 
                           "Variable Actual" : np.concatenate([self.solution_df['variable_transformations'], np.array(list(self.non_media_variables))])
        }
        Coefficient_Summary_df = pd.DataFrame.from_dict(Coefficient_Summary)

        display(Coefficient_Summary_df)

        #### Model Stats
        
        Model_Stats = {
            "Metric" : ['MAPE', 'R Square'],
            "Model Fit" : [self.Train_Mape, self.Train_R_Square], 
            "Validation Fit" : [self.Valid_Mape, self.Valid_R_Square ] 
        }


        Model_Stats_df = pd.DataFrame.from_dict(Model_Stats)

        display(Model_Stats_df)


        #### Contribution
        media_stack_path = self.config.get("modeling_stack_path")
        media_stack_df = pd.read_csv(media_stack_path)
        variables = self.media_variables
        media_stack_df = media_stack_df[variables]
        raw_media_data = self.data[self.media_variables].copy()
        self.start_index1 = self.data[self.data['Date']==self.train_start].index[0]
        self.end_index1 = self.data[self.data['Date']==self.train_end].index[0] + 1

        self.train_spend = np.asarray(self.data[self.spend_vars][self.start_index1:self.end_index1]).sum(axis=0)
        
        Contribution = {
                        "Display Level" : self.media_variables,
                        "Total Contribution" : (self.initial_coef * self.transformed_media_total.sum(axis=1)),# taking the entire Beta, we need just the media variable
                        "Total Sales ($)" : (self.initial_coef * self.transformed_media_total.sum(axis=1) * self.train_price),
                        "Total Spend ($)" : self.train_spend,
                        #"Raw Media" : raw_media_data.sum(axis=0),
                        "Raw Media" : media_stack_df.sum(axis=0),
                        "Volume RoAS" : (self.initial_coef * self.transformed_media_total.sum(axis=1)/ self.train_spend),
                        "Value RoAS ($)" : (self.initial_coef * self.transformed_media_total.sum(axis=1) * self.train_price/ self.train_spend)
        }
        

        Contribution_df = pd.DataFrame.from_dict(Contribution)
        
        Contribution_df['Contribution Share(%)'] = Contribution_df['Total Contribution']/Contribution_df['Total Contribution'].sum()
        Contribution_df['Spend Share(%)'] = Contribution_df['Total Spend ($)']/Contribution_df['Total Spend ($)'].sum()
        Contribution_df['Raw Media Share(%)'] = Contribution_df['Raw Media']/Contribution_df['Raw Media'].sum()

        total_incremental = {"Display Level": "Total Incremental",
                             "Total Contribution": Contribution_df['Total Contribution'].sum(),
                             "Total Sales ($)": Contribution_df['Total Sales ($)'].sum(),
                             "Total Spend ($)": Contribution_df['Total Spend ($)'].sum(),
                             "Raw Media": Contribution_df['Raw Media'].sum(),
                             "Volume RoAS": Contribution_df['Total Contribution'].sum()/Contribution_df['Total Spend ($)'].sum(),
                             "Value RoAS ($)": Contribution_df['Total Sales ($)'].sum()/Contribution_df['Total Spend ($)'].sum(),
                             "Contribution Share(%)": Contribution_df['Total Contribution'].sum()/self.data['O_UNIT'].sum(),
                             "Spend Share(%)": 100,
                             "Raw Media Share(%)": 100}

        base = {"Display Level": "Base",
                "Total Contribution": self.data['O_UNIT'].sum() - Contribution_df['Total Contribution'].sum(),
                "Total Sales ($)": self.data['O_SALE'].sum() - Contribution_df['Total Sales ($)'].sum(),
                "Total Spend ($)": 0,
                "Raw Media": 0,
                "Volume RoAS": 0,
                "Value RoAS ($)": 0,
                "Contribution Share(%)": 1 - (Contribution_df['Total Contribution'].sum()/self.data['O_UNIT'].sum()),
                "Spend Share(%)": 0,
                "Raw Media Share(%)": 0}

        total = {"Display Level": "Total",
                "Total Contribution": self.data['O_UNIT'].sum(),
                "Total Sales ($)": self.data['O_SALE'].sum(),
                "Total Spend ($)": Contribution_df['Total Spend ($)'].sum(),
                "Raw Media": Contribution_df['Raw Media'].sum(),
                "Volume RoAS": 0,
                "Value RoAS ($)": 0,
                "Contribution Share(%)": 100,
                "Spend Share(%)": 0,
                "Raw Media Share(%)": 0}

        Contribution_df.loc[len(Contribution_df)] = total_incremental
        Contribution_df.loc[len(Contribution_df)] = base
        Contribution_df.loc[len(Contribution_df)] = total

        display(Contribution_df)


        # self.updated_stack_brand['Y_pred'] = 0 
        # self.updated_stack_brand['Y_pred'] += ((self.Beta_j*self.X_train.T).sum(axis=1))
        Act_vs_Pred_M = {
                        'Date' : self.updated_stack_brand['Date'],
                        'Actual' : self.updated_stack_brand['O_UNIT'],
                        'Predicted' : self.updated_stack_brand['Y_pred']
        }

        Act_vs_Pred_M_df = pd.DataFrame.from_dict(Act_vs_Pred_M)
        Act_vs_Pred_M_df['Residual'] = (Act_vs_Pred_M_df['Predicted']/Act_vs_Pred_M_df['Actual'])-1

        # display(Act_vs_Pred_M_df)


        #### Act vs Pred Validation
        # self.updated_stack_brand_valid['Y_pred'] = 0
        # self.updated_stack_brand_valid['Y_pred'] += ((self.Beta_j*self.X_valid.T).sum(axis=1))
        
        Act_vs_Pred_V = {
                        'Date' : self.updated_stack_brand_valid['Date'],
                        'Actual' : self.updated_stack_brand_valid['O_UNIT'],
                        'Predicted' : self.updated_stack_brand_valid['Y_pred']
        }
        Act_vs_Pred_V_df = pd.DataFrame.from_dict(Act_vs_Pred_V)
        Act_vs_Pred_V_df['Residual'] = (Act_vs_Pred_V_df['Predicted']/Act_vs_Pred_V_df['Actual'])-1


        # display(Act_vs_Pred_V_df)

        #### Base - Incremental Contribution
        Base_Incr = pd.DataFrame(self.initial_coef * self.transformed_var_actual, columns=self.solution_df['variable_transformations'])

        date_range = pd.date_range(self.st_dt, self.valid_end_dt, freq='D')
        print(date_range)
        Base_Incr['Baseline_Sales_Calc'] = Base_Incr.sum(axis=1)
        Base_Incr['Total Sales'] = self.updated_stack_brand['O_UNIT']
        Base_Incr['Baseline Sales'] = Base_Incr['Total Sales'] - Base_Incr['Baseline_Sales_Calc']
        del(Base_Incr['Baseline_Sales_Calc'])
        #print(Base_Incr)
        Base_Incr['index'] = date_range

        Base_Incr_m = Base_Incr.copy()
        Base_Incr_m['index_month'] = Base_Incr_m['index'].to_numpy().astype('datetime64[M]')
        del(Base_Incr_m['index'])
        Base_Incr_monthly = Base_Incr_m.groupby('index_month').sum().reset_index()

        base_incremental = Base_Incr_monthly[self.solution_df['variable_transformations']].copy()
        base_incremental.columns = self.media_variables

        base_vol = Base_Incr_monthly[['index_month', 'Baseline Sales']].copy()
        base_vol.columns = ['index', 'base']

        base_modelling = pd.DataFrame.from_dict({'model_start_date': [self.st_dt],
                                       'model_end_date': [self.train_end_dt]})

        with pd.ExcelWriter('../model_results/base_incremental_05.xlsx', engine='xlsxwriter') as WRITER_B:
                base_incremental.to_excel(WRITER_B, sheet_name = 'base_incremental', index = False)
                base_vol.to_excel(WRITER_B, sheet_name = 'base_vol', index = False)
                base_modelling.to_excel(WRITER_B, sheet_name = 'modelling', index = False)

        print('base_incremental saved')


        # display(Base_Incr)

        # WRITER = pd.ExcelWriter('model_outputs.xlsx', engine = 'xlsxwriter')

        with pd.ExcelWriter(file_name, engine='xlsxwriter') as WRITER:
                Coefficient_Summary_df.to_excel(WRITER, sheet_name = 'Coefficient Summary', index = False)
                Model_Stats_df.to_excel(WRITER, sheet_name = 'Model Stats', index = False)
                Contribution_df.to_excel(WRITER, sheet_name = 'Contribution', index = False)
                Act_vs_Pred_M_df.to_excel(WRITER, sheet_name = 'Act vs Pred Modelling', index = False)
                Act_vs_Pred_V_df.to_excel(WRITER, sheet_name = 'Act vs Pred Validation', index = False)
                Base_Incr.to_excel(WRITER, sheet_name = 'Base - Incrmental Contribution', index = False)

                print(f"Model Outputs saved to {file_name}")   

    def save_transformed_media(self, file_name="../model_results/variables_transformation_summary_05.xlsx"):
            """
            Saves transformed media variables to an Excel file.
    
            Params:
                file_name (str): Name of the Excel file (default: transformed_media.xlsx).
            """
            """
            Loads media stack data from the CSV file specified in self.config and 
            computes non-zero averages for media variables, along with actual transformation 
            names, threshold points, and saturation points.
    
            """
            # Convert transformed media to a DataFrame
            transformed_media_df = pd.DataFrame(self.transformed_var_actual, columns=self.media_variables)
            ### 🔹 Fetch Media Stack Path from `self.config` ###
            media_stack_path = self.config.get("modeling_stack_path")
            if not media_stack_path or not os.path.exists(media_stack_path):
                raise FileNotFoundError(f"Media stack file '{media_stack_path}' not found in self.config.")
    
            ### 🔹 Load Media Stack Data ###
            media_stack_df = pd.read_csv(media_stack_path)
    
            ### 🔹 Validate Required Columns in `self.solution_df` ###
            required_columns = ["Media_tactic", "Threshold", "Saturation"]
            if not all(col in self.solution_df.columns for col in required_columns):
                raise ValueError(f"Expected columns {required_columns} in self.priors_df.")
    
            ### 🔹 Extract Data ###
            variables = self.media_variables  # Variables from self.media_variables
            variable_actuals = self.media_variables  + self.solution_df["media_transformation_string"] # Actual Variable Namesself.solution_df["Media_tactic"].astype(str)
            #print(variable_actuals)
            ### 🔹 Extract Threshold & Saturation Points from `self.solution_df` ###
            threshold_points = self.solution_df.set_index("Media_tactic")["Threshold"].to_dict()
            saturation_points = self.solution_df.set_index("Media_tactic")["Saturation"].to_dict()

            
    
            ### 🔹 Compute Non-Zero Averages from Media Stack Data ###
            non_zero_avg_data = {}
            for var in variables:
                if var in media_stack_df.columns:
                    non_zero_values = media_stack_df[var][media_stack_df[var] > 0]  # Filter non-zero values
                    non_zero_avg_data[var] = non_zero_values.sum() / len(non_zero_values) if len(non_zero_values) > 0 else 0
                else:
                    non_zero_avg_data[var] = None  # Handle missing variables
                                    
            ### 🔹 Compute Rate from Media Stack Data ###
            cpi_results = {}
            for var in variables:
                if var in media_stack_df.columns:
                    total_imp = media_stack_df[var].sum()
                    spend_var = var.replace('VIEW_IMP', 'SPEND').replace('IMP', 'SPEND').replace('CLK', 'SPEND')
                    if spend_var in media_stack_df.columns:
                        total_spend = media_stack_df[var.replace('VIEW_IMP', 'SPEND').replace('IMP', 'SPEND').replace('CLK', 'SPEND')].sum()
                        cpi = total_spend / total_imp if total_imp != 0 else float('inf')
                        cpi_results[var] = cpi
            #display(cpi_results)
            ### 🔹 Create DataFrame for Excel ###
            summary_data_points = []
            for var in variables:
                transformation_var = var + self.solution_df.loc[self.solution_df["Media_tactic"] == var, "media_transformation_string"].values[0]
                threshold = threshold_points.get(var, None)
                saturation = saturation_points.get(var, None)
                inflection = (threshold + saturation) / 2 if threshold is not None and saturation is not None else None  # Compute Inflection Point
                
                summary_data_points.append([
                        var,
                        threshold,   
                        inflection,
                        saturation,  
                        non_zero_avg_data.get(var, None),
                        transformation_var])
                #### points
                                        
                
            summary_df = pd.DataFrame(summary_data_points, columns=["Variable", "Threshold Point","Inflection Point","Saturation Point", "Non-Zero Average","Variable Actuals"])
            summary_data_spend_points = []
            for var in variables:
                transformation_var = var + self.solution_df.loc[self.solution_df["Media_tactic"] == var, "media_transformation_string"].values[0]
                threshold = threshold_points.get(var, None)
                saturation = saturation_points.get(var, None)
                inflection = (threshold + saturation) / 2 if threshold is not None and saturation is not None else None  # Compute Inflection Point
                non_zero_avg = non_zero_avg_data.get(var, None)
                cpi = cpi_results.get(var, None)
                # Multiply CPI with threshold & saturation
                threshold_sp = cpi * threshold if cpi is not None and threshold is not None else None
                saturation_sp = cpi * saturation if cpi is not None and saturation is not None else None
                inflection_sp = cpi * inflection if cpi is not None and saturation is not None else None
                non_zero_avg_sp = cpi * non_zero_avg
                summary_data_spend_points.append([
                        var,
                        threshold_sp,   
                        inflection_sp, 
                        saturation_sp,  
                        non_zero_avg_sp,
                        transformation_var])
                #### points
                                        
                
            summary_df_spend = pd.DataFrame(summary_data_spend_points, columns=["Variable", "Threshold Point","Inflection Point","Saturation Point", "Non-Zero Average","Variable Actuals"])
            #display(summary_df_spend)
            analysis_data = []
            for var in variables:
                if var in media_stack_df.columns:
                    data = media_stack_df[var]
                    transformation_var = var + self.solution_df.loc[self.solution_df["Media_tactic"] == var, "media_transformation_string"].values[0]
                    total_days = len(data)
                    on_air_days = (data > 0).sum()
                    threshold = threshold_points.get(var, None)  
                    saturation = saturation_points.get(var, None)  
                    inflection = (threshold + saturation) / 2 if threshold is not None and saturation is not None else None  
    
                    days_above_saturation = (data > saturation).sum() if saturation is not None else None
                    days_below_saturation = (data < saturation).sum() if saturation is not None else None
                    optimal_range_days = ((data >= threshold) & (data <= saturation)).sum() if threshold is not None and saturation is not None else None
                    beyond_saturation_days = (days_above_saturation / total_days * 100) if days_above_saturation is not None else None
                    below_inflection_days = (data < inflection).sum() / total_days * 100 if inflection is not None else None
    
                    actual_avg_point = data.mean()
                    average = data[data > 0].mean() if on_air_days > 0 else 0
    
                    analysis_data.append([
                        var, transformation_var, total_days, on_air_days, optimal_range_days, beyond_saturation_days,
                        below_inflection_days, days_above_saturation, days_below_saturation,
                        actual_avg_point, average, threshold, inflection, saturation
                    ])
                else:
                    analysis_data.append([var] + [None] * 12)  # Fill missing data with None
    
            ### 🔹 Create DataFrame for Excel ###
            analysis_df = pd.DataFrame(analysis_data, columns=[
                "Variable", "Variable Actual","Total Days", "On Air Days", "Optimal Range Days (%)",
                "Beyond Saturation Days (%)", "Below Inflection Days (%)",
                "Days above Saturation", "Days below Saturation",
                "Actual Average Point", "Average", "Threshold point",
                "Inflection Point", "Saturation Point"
            ])
            analysis_data_spend = []
            for var in variables:
                if var in media_stack_df.columns:
                    data = media_stack_df[var]
                    transformation_var = var + self.solution_df.loc[self.solution_df["Media_tactic"] == var, "media_transformation_string"].values[0]
                    total_days = len(data)
                    on_air_days = (data > 0).sum()
                    threshold = threshold_points.get(var, None)  
                    saturation = saturation_points.get(var, None)  
                    inflection = (threshold + saturation) / 2 if threshold is not None and saturation is not None else None  
                    cpi = cpi_results.get(var, None)
                    threshold_sp = cpi * threshold if cpi is not None and threshold is not None else None
                    saturation_sp = cpi * saturation if cpi is not None and saturation is not None else None
                    inflection_sp = cpi * inflection if cpi is not None and saturation is not None else None
                    
                    days_above_saturation = (data > saturation_sp).sum() if saturation_sp is not None else None
                    days_below_saturation = (data < saturation_sp).sum() if saturation_sp is not None else None
                    optimal_range_days = ((data >= threshold_sp) & (data <= saturation_sp)).sum() if threshold is not None and saturation is not None else None
                    beyond_saturation_days = (days_above_saturation / total_days * 100) if days_above_saturation is not None else None
                    below_inflection_days = (data < inflection_sp).sum() / total_days * 100 if inflection is not None else None
    
                    actual_avg_point_sp = data.mean()*cpi
                    average = data[data > 0].mean() if on_air_days > 0 else 0
                    average_sp = average * cpi
                    analysis_data_spend.append([
                        var, transformation_var, total_days, on_air_days, optimal_range_days, beyond_saturation_days,
                        below_inflection_days, days_above_saturation, days_below_saturation,
                        actual_avg_point_sp, average_sp, threshold_sp, inflection_sp, saturation_sp
                    ])
                else:
                    analysis_data_spend.append([var] + [None] * 12)  # Fill missing data with None
    
            ### 🔹 Create DataFrame for Excel ###
            analysis_df_spend = pd.DataFrame(analysis_data_spend, columns=[
                "Variable", "Variable Actual","Total Days", "On Air Days", "Optimal Range Days (%)",
                "Beyond Saturation Days (%)", "Below Inflection Days (%)",
                "Days above Saturation", "Days below Saturation",
                "Actual Average Point", "Average", "Threshold point",
                "Inflection Point", "Saturation Point"
            ])
            # Save to Excel
            with pd.ExcelWriter(file_name, engine='xlsxwriter') as writer:
                transformed_media_df.to_excel(writer, sheet_name="Transformations", index=False)
                summary_df.to_excel(writer, sheet_name="Points", index=False)
                summary_df_spend.to_excel(writer, sheet_name="Spend Points", index=False)
                analysis_df.to_excel(writer, sheet_name="Airing Analysis", index=False)
                analysis_df_spend.to_excel(writer, sheet_name="Airing Analysis Spends", index=False)
            
            print(f"Transformed media saved to {file_name}")        


def lag_transformation_no_numba(var, lag):
    lag_variable = np.append(np.zeros(int(lag)), var[:-lag])
    return lag_variable

def halflife_transformation_no_numba(var, halflife):
    retention = np.exp(math.log(0.5)/halflife)        
    transformed_var = var * (1 - retention)
    transformed_var[np.isnan(transformed_var)] = 0
    transformed_var = recursive_filter_no_numba(transformed_var, retention)
    return transformed_var

def recursive_filter_no_numba(x, ar_coeff):
    n = len(x)
    y = np.zeros(n)
    y[0] = x[0]
    for i in range(1,n):
        y[i] = ar_coeff * y[i-1] + x[i]
    return y

def create_missing_media_transformations_new(df, media_vars,refresh_flag = False, model_end_idx = -1, trans_start_date= None, trans_end_date= None): #c0p0ii4
    ''' 
    Creates the mising media transformation 
    
    Params
        media_vars : List of all media variables 
    '''
    # Creates the missing media transformations
    ## added:09.29.2022, jangho, for sliders

    scaling_factor_arr = np.zeros(len(media_vars))


    if trans_start_date is None:
        trans_start_date = trans_start_date
        
    if trans_end_date is None:
        trans_end_date = trans_end_date
        
    for i, var in enumerate(media_vars):
        
        if refresh_flag:
            lag = int(float(var.rsplit("_",5)[4]))
            #print(lag)
            halflife = float(var.rsplit("_",5)[1])
            #print(halflife)
            sscurve_inflection = float(var.rsplit("_",5)[2])
            #print(sscurve_inflection)
            sscurve_scale = float(var.rsplit("_",5)[3])
            #print(sscurve_scale)
            orig_media_var = var.rsplit("_",5)[0]
            #print(orig_media_var)
            
        if not refresh_flag:
            lag = int(float(var.split("_")[-1]))
            halflife = float(var.split("_")[-4])
            sscurve_inflection = float(var.split("_")[-3])
            sscurve_scale = float(var.split("_")[-2])
            orig_media_var = var.split("_")[:-4]
            orig_media_var = '_'.join([str(elem) for elem in orig_media_var])
        
        # Saving the numbers on the required period defined by trans_start_date and trans_end_date
        df_filtered = df
        transformed_var = df_filtered[orig_media_var]

        # Saving the means on the filtered dataset
        if lag != 0: 
            transformed_var = lag_transformation_no_numba(transformed_var, int(lag))

        if halflife != 0:
            transformed_var = halflife_transformation_no_numba(transformed_var, halflife)

        if model_end_idx > -1: #c0p0ii4
            var_mean = transformed_var[:model_end_idx].mean()
        else:
            var_mean = transformed_var.mean()

        if (sscurve_scale != 0) and (sscurve_inflection != 0):
            transformed_var_scaled = transformed_var/var_mean
            saturation_term = sscurve_scale * (sscurve_inflection - transformed_var_scaled)
            scurve_var = 1/(1+np.exp(saturation_term))-1/(1+np.exp(sscurve_scale * sscurve_inflection))
            if model_end_idx > -1:
                scurve_var_mean = scurve_var[:model_end_idx].mean() #c0p0ii4 - confirm with Janhavi
            else:
                scurve_var_mean = scurve_var.mean()
        
            transformed_var = scurve_var * var_mean / scurve_var_mean
            
        #if not refresh_flag:
        if model_end_idx > -1: #c0p0ii4 
            scaling_factor = max(transformed_var[:model_end_idx]) - min(transformed_var[:model_end_idx]) 
            scaling_factor_arr[i] = scaling_factor
            
            transformed_var = (transformed_var - min(transformed_var[:model_end_idx])) / scaling_factor 
            transformed_var[model_end_idx:] = np.clip(transformed_var[model_end_idx:], a_min=0, a_max=None)

        else:
            scaling_factor = max(transformed_var) - min(transformed_var)
            scaling_factor_arr[i] = scaling_factor
            transformed_var = (transformed_var - min(transformed_var)) / scaling_factor 
        df[orig_media_var] = transformed_var
        
    if refresh_flag:
        df.columns = df.columns+ "_TF" 
        return df
    else:   
        return df, scaling_factor_arr 