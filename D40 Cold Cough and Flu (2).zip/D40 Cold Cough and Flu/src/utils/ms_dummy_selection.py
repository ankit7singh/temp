"""
ms_dummy_selection.py
=====================

MSedits dummy-selection extensions for the Category WAMM pipeline.

Scope (per the approved implementation plan):
  * Thanksgiving stack fill                     -> fill_thanksgiving_dummies
  * Item 5: iterative high-MAPE rescue loop     -> run_mape_rescue (+ helpers)
  * Item 6: back-to-school grouped dummy        -> group_window_clusters

Design contract
---------------
Everything except ``run_mape_rescue`` / ``write_rescue_log`` / ``build_ms_context``
is a PURE function: inputs in, value out, no file I/O, no globals, no mutation of
caller state. ``materialize_dummies`` is the ONLY function that writes columns and
``register_dummy_names`` is the ONLY function that registers names.

This module intentionally does NOT import either helper module
(``category_wamm_helper_functions_updated`` / ``lite_non_media_utils_v3_Nat_Fit``)
so the dependency arrow points one way only.

MSedits change IDs referencing this file are recorded in
``Category_WAMM/MSEDITS_CHANGELOG.md``.
"""

import json
import os
from datetime import datetime

import numpy as np
import pandas as pd
import statsmodels.api as sm

# ---------------------------------------------------------------------------
# Settings. THIS IS THE SINGLE SOURCE OF TRUTH (MS-13) -- these used to live in
# a ``ms_dummy_selection`` block inside each category_config.json, but configs are
# imported differently per category and only two of them ever carried the block,
# so the whole feature silently stayed off everywhere else. Any such block still
# present in a JSON config is now IGNORED; edit the values here instead.
# ---------------------------------------------------------------------------

THANKSGIVING_DATES = {
    2023: "2023-11-23",
    2024: "2024-11-28",
    2025: "2025-11-27",
}

DEFAULT_DEDUPE_ALIASES = {"NEW_YEARS_DAY": "NEW_YEAR"}

# Resolved from this module's own location, so the calendar is found no matter
# what the notebook's working directory is or how the package gets imported.
_MODULE_EVENTS_JSON = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "config_dir", "events.json"
)

DEFAULTS = {
    "enabled": True,                      # MS-13: the .py decides, not the JSON
    "mape_limit": 15.0,
    "target_r2": 0.75,
    "residual_sd_threshold": 2.5,
    "max_new_dummies_per_pass": 5,
    "max_iterations": 3,
    "existing_dummy_max_support": 7,
    "default_window_days": 1,
    "window_days_by_event": {"CHRISTMAS": 2, "THANKSGIVINGDAY": 2},
    "window_events": {"BACK_TO_SCHOOL": {"min_cluster": 3, "prefix": "D_BTS"}},
    "event_name_aliases": {
        "THANKSGIVING_DAY": "THANKSGIVINGDAY",
        "VALENTINES_DAY": "VALENTINE_DAY",
        "FATHERS_DAY": "FATHER_DAY",
        "MOTHERS_DAY": "MOTHER_DAY",
        "EASTER_DAY": "EASTER",
        "JULY4TH": "INDEPENDENCE_DAY",
    },
    "rejected_columns": (),               # consumed by run_mape_rescue; was undeclared
    "unresolvable_event_action": "fallback_to_mape",
    "event_calendar_path": _MODULE_EVENTS_JSON,
    "log_dir": None,                      # None -> the caller's own output_path
    # MS-14: the rescue is judged on the 10 non-media bases, not on the
    # SBU-level non-media OLS. Those are different models -- gating on the
    # latter meant the thing that spent dummies was not the thing that decided
    # release. "sbu" restores the old behaviour.
    "rescue_scope": "bases",
    "min_passing_bases": 3,               # release needs this many of the 10
    "base_rescue_targets": 3,             # top-ranked bases that supply residuals
    "max_base_rebuilds": 3,               # outer passes; each is a FULL, SLOW rebuild
}

# Ordering rank used when several events could explain the same day.
# exact (0) beats PRE (1) beats POST (2); see classify_days_by_event.
_KIND_RANK = {"exact": 0, "pre": 1, "post": 2}

# Candidate date columns, most-preferred first. The RAW stack CSV has no "Date"
# column -- it carries DELIVERY_DATE and INDEX, and "Date" is derived inside
# load_data (category_wamm_helper_functions_updated.py:151-167) from index/INDEX.
# So the repair script sees DELIVERY_DATE while the in-pipeline frame sees Date.
_DATE_COLUMN_CANDIDATES = ("Date", "DELIVERY_DATE", "INDEX", "index")


def resolve_date_column(data, date_col=None):
    """Return the usable date column, tolerating raw-stack vs in-pipeline shapes."""
    if date_col is not None and date_col in data.columns:
        return date_col
    for candidate in _DATE_COLUMN_CANDIDATES:
        if candidate in data.columns:
            return candidate
    raise KeyError(
        f"no date column found; looked for {list(_DATE_COLUMN_CANDIDATES)} "
        f"in {list(data.columns)[:12]}..."
    )


# ===========================================================================
# 1. Thanksgiving fill                                            (MS-01/MS-02)
# ===========================================================================

def fill_thanksgiving_dummies(data, dates_by_year=None, date_col=None):
    """Populate exact-day Thanksgiving dummy columns that are present-but-empty.

    The columns ``D_HOL_THANKSGIVINGDAY_<year>`` exist in ``modeling_stack.csv``
    but every value is 0, so Thanksgiving is completely unmodelled and the
    outlier detector invents ``D_LOW_SALES_<YYYY-MM>`` in its place. This fills
    the exact-day columns only -- ``PRE_``/``POST_`` are deliberately untouched.

    Idempotent: an already-populated column is left alone, so calling this from
    both the repair script (MS-01) and ``load_data`` (MS-02) cannot double-apply.

    Parameters
    ----------
    data : DataFrame
        Modeling stack. Must contain ``date_col``.
    dates_by_year : dict[int, str], optional
        ``{year: "YYYY-MM-DD"}``. Defaults to ``THANKSGIVING_DATES``.
    date_col : str, optional
        Date column. Auto-detected when omitted, so the same function works on
        the raw stack (``DELIVERY_DATE``) and the in-pipeline frame (``Date``).

    Returns
    -------
    (data, fill_log)
        ``fill_log`` has one record per year with ``action`` in
        {filled, already_populated, column_absent, date_out_of_range}.
    """
    if dates_by_year is None:
        dates_by_year = THANKSGIVING_DATES

    fill_log = []
    date_col = resolve_date_column(data, date_col)
    dates = pd.to_datetime(data[date_col])

    for year in sorted(dates_by_year):
        column = f"D_HOL_THANKSGIVINGDAY_{year}"
        target = pd.to_datetime(dates_by_year[year])
        record = {"column": column, "date": target.strftime("%Y-%m-%d")}

        if column not in data.columns:
            record["action"] = "column_absent"
            record["detail"] = "column not in stack; nothing filled"
            fill_log.append(record)
            continue

        if int(pd.to_numeric(data[column], errors="coerce").fillna(0).sum()) > 0:
            record["action"] = "already_populated"
            record["detail"] = "column already carries 1s; left untouched"
            fill_log.append(record)
            continue

        match = dates == target
        if not match.any():
            record["action"] = "date_out_of_range"
            record["detail"] = "date not present in the stack's date range"
            fill_log.append(record)
            continue

        data[column] = match.astype(int)
        record["action"] = "filled"
        record["detail"] = f"set 1 on {int(match.sum())} row(s)"
        fill_log.append(record)

    return data, fill_log


# ===========================================================================
# 2. Event calendar                                                    (MS-10)
# ===========================================================================

def load_event_calendar(path, name_aliases=None, dedupe_aliases=None):
    """Read ``events.json`` into one normalised shape, in the STACK's vocabulary.

    Fixes four defects in the reference implementation
    (``Agent Modelling/Agent/nodes/dummys.py:147``):

    1. ``BACK_TO_SCHOOL`` year values are dicts (``START_DATE``/``END_DATE``),
       not date strings. The reference calls ``fromisoformat`` on them inside a
       bare ``except Exception: pass``, so the entry is silently dropped. Here
       dict values are routed to an explicit ``window`` branch.
    2. ``NEW_YEAR`` / ``NEW_YEARS_DAY`` are duplicate entries; the reference
       tie-break depends on dict order. Collapsed via ``dedupe_aliases``.
    3. Calendar event names do not match stack column names
       (``THANKSGIVING_DAY`` vs ``THANKSGIVINGDAY``, ``VALENTINES_DAY`` vs
       ``VALENTINE_DAY``, ...). Translated via ``name_aliases`` so everything
       downstream works in the stack's spelling.
    4. A malformed value raises here rather than being swallowed.

    Returns
    -------
    dict
        ``{"point":  {(event, year): Timestamp},
           "window": {(event, year): (Timestamp, Timestamp)}}``
    """
    name_aliases = dict(name_aliases or {})
    dedupe_aliases = DEFAULT_DEDUPE_ALIASES if dedupe_aliases is None else dict(dedupe_aliases)

    with open(path) as handle:
        events = json.load(handle).get("events", {})

    calendar = {"point": {}, "window": {}}

    # Sorted so that a genuine duplicate resolves deterministically rather than
    # by dict insertion order (defect 2).
    for raw_event in sorted(events):
        event = dedupe_aliases.get(raw_event, raw_event)
        event = name_aliases.get(event, event)

        for raw_year, value in sorted(events[raw_event].items()):
            year = int(raw_year)

            if isinstance(value, dict):
                start = value.get("START_DATE")
                end = value.get("END_DATE")
                if start is None or end is None:
                    raise ValueError(
                        f"{path}: window event {raw_event}/{raw_year} needs both "
                        f"START_DATE and END_DATE, got {value!r}"
                    )
                calendar["window"].setdefault(
                    (event, year), (pd.to_datetime(start), pd.to_datetime(end))
                )
            elif isinstance(value, str):
                calendar["point"].setdefault((event, year), pd.to_datetime(value))
            else:
                raise ValueError(
                    f"{path}: {raw_event}/{raw_year} must be a date string or a "
                    f"START_DATE/END_DATE object, got {type(value).__name__}"
                )

    return calendar


def assert_calendar_resolves(calendar, data):
    """Report which POINT calendar events actually have a matching stack column.

    Fails fast on a calendar/stack name mismatch instead of discovering it three
    steps later as a duplicate column. An event named by the calendar but absent
    from the stack (``BLACK_FRIDAY``, ``CYBER_MONDAY``) is reported here and its
    days later fall back to ``D_MAPE_<date>`` rather than creating a speculative
    ``D_HOL_*`` column beside an existing one under a different spelling.

    Window events are deliberately EXCLUDED from this check: they materialise as
    a brand-new grouped column (``D_BTS_<year>``) by design, so the absence of a
    ``D_HOL_BACK_TO_SCHOOL_*`` column is expected, not a mismatch.

    Returns
    -------
    (resolvable, unresolvable)
        Two sorted lists of point-event names. Never raises on a mismatch.
    """
    columns = set(data.columns)
    resolvable, unresolvable = set(), set()

    for (event, year) in calendar.get("point", {}):
        if f"D_HOL_{event}_{year}" in columns or f"D_HOL_{event}" in columns:
            resolvable.add(event)
        else:
            unresolvable.add(event)

    # An event resolvable in any year counts as resolvable.
    unresolvable -= resolvable
    return sorted(resolvable), sorted(unresolvable)


# ===========================================================================
# 3-4. Residual scoring and shortlisting                          (steps 2, 3)
# ===========================================================================

def compute_residual_scores(y, y_pred, dates, train_mask, sd=None):
    """Score every day by how badly the model missed it: ``|resid| / sd``.

    ``sd`` is a parameter, not a computed value, so the caller can hold it fixed
    at the first pass. Every dummy added shrinks the residual sd, so a
    recomputed 2.5-sigma bar keeps falling and the loop chases its own tail.

    Returns
    -------
    (scores, sd_used)
        ``scores`` is a Series indexed by date.
    """
    resid = pd.Series(np.asarray(y, dtype=float) - np.asarray(y_pred, dtype=float))
    resid.index = pd.to_datetime(pd.Series(dates).reset_index(drop=True))
    mask = pd.Series(np.asarray(train_mask, dtype=bool))
    mask.index = resid.index

    if sd is None:
        train_resid = resid[mask.values]
        sd = float(train_resid.std(ddof=1)) if len(train_resid) > 1 else 0.0

    if not sd or not np.isfinite(sd):
        return pd.Series(dtype=float), 0.0

    return (resid.abs() / sd), float(sd)


def shortlist_bad_days(scores, threshold=2.5, train_mask=None):
    """Days whose miss exceeds ``threshold`` sigma, worst first, training only.

    A dummy must never be placed on a validation day -- that is leakage, and it
    makes the validation MAPE meaningless.
    """
    if scores is None or len(scores) == 0:
        return []

    candidates = scores
    if train_mask is not None:
        mask = pd.Series(np.asarray(train_mask, dtype=bool))
        mask.index = scores.index
        candidates = scores[mask.values]

    bad = candidates[candidates > threshold]
    # Sorted worst-first; date breaks ties so the order is deterministic.
    bad = bad.sort_values(ascending=False, kind="mergesort")
    seen, ordered = set(), []
    for day in bad.index:
        if day not in seen:
            seen.add(day)
            ordered.append(day)
    return ordered


def filter_days_covered_by_dummies(bad_days, data, date_col="Date", max_support=7):
    """Drop bad days already covered by a short existing dummy column.

    This is the check that stops us re-creating a column that already covers the
    day -- the exact failure where ``D_HIGH_SALES_2024-11`` came out an exact
    copy of ``D_HOL_POST_HALLOWEEN_2024``.

    Scans EVERY ``D_*`` column with ``0 < sum <= max_support``, which is wider
    than the LITE reference (``lite_non_media_utils.py:126``) -- that one only
    inspects columns named ``dummy_*``, so a pre-existing ``D_HOL_*`` does not
    count as coverage there.

    Returns
    -------
    (kept, dropped)
        ``dropped`` is a list of ``(date, covering_column)`` pairs.
    """
    if not bad_days:
        return [], []

    dates = pd.to_datetime(data[resolve_date_column(data, date_col)])
    coverage = {}

    for column in [c for c in data.columns if c.startswith("D_")]:
        values = pd.to_numeric(data[column], errors="coerce").fillna(0)
        support = int((values == 1).sum())
        if 0 < support <= max_support:
            for day in dates[values == 1]:
                coverage.setdefault(pd.Timestamp(day), column)

    kept, dropped = [], []
    for day in bad_days:
        day = pd.Timestamp(day)
        if day in coverage:
            dropped.append((day, coverage[day]))
        else:
            kept.append(day)

    return kept, dropped


# ===========================================================================
# 5. Event-aware naming                                               (step 5)
# ===========================================================================

def classify_days_by_event(
    bad_days,
    point_calendar,
    window_days_by_event=None,
    default_window_days=1,
):
    """Ask the calendar what each bad day IS before deciding what to call it.

    One day gets exactly ONE name. Precedence is exact > PRE > POST, nearest
    wins within PRE/POST, and the event name breaks any remaining tie
    alphabetically -- deterministic, unlike the reference at
    ``dummys.py:174`` which resolves ties by dict order. This is what prevents
    manufacturing the Juneteenth / Father's-Day collision seen on
    2023-06-18/19, where each event's side-flag landed on the other's own day.

    ``days_diff`` keeps the reference's sign convention:
    ``event_date - bad_day``, so positive means the event is still ahead (PRE).

    Naming (already in the stack's spelling, see load_event_calendar):
        days_diff == 0 -> D_HOL_<EVENT>_<YYYY>
        days_diff  > 0 -> D_HOL_PRE_<EVENT>_<YYYY>
        days_diff  < 0 -> D_HOL_POST_<EVENT>_<YYYY>
        no match       -> D_MAPE_<YYYY-MM-DD>

    Returns
    -------
    dict[Timestamp, dict]
        Each value has ``name, event, days_diff, kind`` where ``kind`` is one of
        {exact, pre, post, unmatched}.
    """
    window_days_by_event = dict(window_days_by_event or {})
    classified = {}

    for day in bad_days:
        day = pd.Timestamp(day)
        candidates = []

        for (event, year), event_date in point_calendar.items():
            window = window_days_by_event.get(event, default_window_days)
            diff = (pd.Timestamp(event_date) - day).days
            if abs(diff) > window:
                continue
            kind = "exact" if diff == 0 else ("pre" if diff > 0 else "post")
            candidates.append((abs(diff), _KIND_RANK[kind], event, year, diff, kind))

        if not candidates:
            classified[day] = {
                "name": f"D_MAPE_{day.strftime('%Y-%m-%d')}",
                "event": None,
                "days_diff": None,
                "kind": "unmatched",
            }
            continue

        _, _, event, year, diff, kind = sorted(candidates)[0]
        if kind == "exact":
            name = f"D_HOL_{event}_{year}"
        elif kind == "pre":
            name = f"D_HOL_PRE_{event}_{year}"
        else:
            name = f"D_HOL_POST_{event}_{year}"

        classified[day] = {
            "name": name,
            "event": event,
            "days_diff": diff,
            "kind": kind,
        }

    return classified


# ===========================================================================
# 6. Window grouping -- back-to-school                        (step 6, item 6)
# ===========================================================================

def group_window_clusters(
    classified,
    window_calendar,
    min_cluster=3,
    window_events=None,
):
    """Collapse a year's clustered unexplained days into one named seasonal dummy.

    Five per-day dummies become one column a person can read. Two corrections to
    the FY27 reference (``dummys.py:391``):

    * It counts years having ANY candidate day in the window rather than any BAD
      day, so with three years of data it always passes and does nothing useful.
      Here the test is ``len(bad days in that year's window) >= min_cluster``.
    * It hard-codes Jul 15 - Sep 15 and ignores the ``START_DATE``/``END_DATE``
      already sitting in ``events.json``. Here the window comes from the config.

    Only ``unmatched`` days are eligible, so a named holiday inside the window
    (``LABOR_DAY`` falls in it every year) keeps its own name instead of being
    absorbed. Flags only the bad days, never the whole 60-day window -- a full
    window would soak up real advertising effect and overlap almost completely
    with the July and August month flags.

    MUST be called before the cap, or all 5 slots go to single days.

    Returns
    -------
    (groups, remaining)
        ``groups`` maps ``"<prefix>_<year>" -> [dates]``;
        ``remaining`` is ``classified`` minus the grouped days.
    """
    window_events = dict(window_events or {})
    groups, grouped_days = {}, set()

    for (event, year), (start, end) in sorted(window_calendar.items()):
        settings = window_events.get(event)
        if settings is None:
            # Window event present in the calendar but not switched on in config.
            continue

        threshold = int(settings.get("min_cluster", min_cluster))
        prefix = settings.get("prefix", "D_BTS" if event == "BACK_TO_SCHOOL" else f"D_{event}")

        in_window = [
            day
            for day, info in classified.items()
            if info["kind"] == "unmatched"
            and day not in grouped_days
            and pd.Timestamp(start) <= pd.Timestamp(day) <= pd.Timestamp(end)
        ]

        if len(in_window) >= threshold:
            days = sorted(in_window)
            groups[f"{prefix}_{year}"] = days
            grouped_days.update(days)

    remaining = {day: info for day, info in classified.items() if day not in grouped_days}
    return groups, remaining


# ===========================================================================
# 7. Name resolution                                                  (step 7)
# ===========================================================================

def resolve_dummy_name(
    name,
    dates,
    data,
    rejected_columns=None,
    unresolvable_events=None,
    event=None,
    unresolvable_action="fallback_to_mape",
):
    """Resolve a generated name against the columns that already exist.

    Branches, in order:

    b) column exists but is ALL ZERO -> ``populate`` + ``is_config_error=True``.
       The calendar knows the event, the column was never filled. This is the
       Thanksgiving failure caught generically, and catching it here is what
       stops the three fake ``D_LOW_SALES_*`` dummies being born.
    c) column exists and was rejected earlier -> ``readmit``: reuse it rather
       than spending a new degree of freedom.
    d) no such column -> ``create``, unless the event was reported unresolvable
       by ``assert_calendar_resolves``, in which case ``fallback_to_mape``. We
       never create a ``D_HOL_*`` for an event whose spelling the stack does not
       use, because that manufactures a duplicate of an existing column.

    (Branch (a) -- column exists and is already 1 on that day -- cannot reach
    here; ``filter_days_covered_by_dummies`` removed those days at step 4.)
    """
    rejected_columns = set(rejected_columns or ())
    unresolvable_events = set(unresolvable_events or ())
    dates = [pd.Timestamp(d) for d in dates]

    if name in data.columns:
        values = pd.to_numeric(data[name], errors="coerce").fillna(0)
        if int((values == 1).sum()) == 0:
            return {
                "action": "populate",
                "column": name,
                "dates": dates,
                "is_config_error": True,
                "detail": "column exists but is all-zero; the calendar knows this event",
            }
        return {
            "action": "readmit",
            "column": name,
            "dates": dates,
            "is_config_error": False,
            "detail": "column already exists and is populated; re-admitted, no new column",
        }

    if event is not None and event in unresolvable_events and unresolvable_action == "fallback_to_mape":
        fallback = f"D_MAPE_{dates[0].strftime('%Y-%m-%d')}" if dates else name
        return {
            "action": "create",
            "column": fallback,
            "dates": dates,
            "is_config_error": True,
            "detail": (
                f"event {event} has no column in the stack under this spelling; "
                f"fell back to {fallback} instead of creating {name}"
            ),
        }

    return {
        "action": "create",
        "column": name,
        "dates": dates,
        "is_config_error": False,
        "detail": "no such column; created",
    }


# ===========================================================================
# 8-10. Materialise, register                                     (steps 8, 9)
# ===========================================================================

def materialize_dummies(data, plan, cap=5, date_col="Date"):
    """Write the resolved plan into ``data``. The ONLY function that adds columns.

    Writes to the ``data`` object it is handed. Inside ``feature_selection`` that
    must be the caller's frame, not the local ``df_processed`` copy -- see
    ``lite_non_media_utils_v3_Nat_Fit.py:62``, which copies, so writes to the
    copy are silently lost and the new dummies never reach the 10 bases.

    Grouped dummies are expected first in ``plan`` so they count against the cap
    before single days do.

    Returns
    -------
    (data, created, skipped_over_cap)
    """
    dates = pd.to_datetime(data[resolve_date_column(data, date_col)])
    created, skipped = [], []

    for entry in plan:
        column = entry["column"]
        if entry["action"] == "readmit":
            # No new column and no new degree of freedom, so it is free of the cap.
            created.append(column)
            continue

        if len(created) >= cap:
            skipped.append(column)
            continue

        flag = dates.isin([pd.Timestamp(d) for d in entry["dates"]])
        data[column] = flag.astype(int)
        created.append(column)

    return data, created, skipped


def register_dummy_names(new_names, selected_features, registry):
    """Register new dummy names. The ONLY registration path, so it can't be half-done.

    A name must end up in ``selected_features`` AND in ``essential_non_media``,
    ``essential_media_dict[sbu]`` and ``essential_non_media_with_outliers``. Miss
    one and the code crashes later looking for a name it only half-knows, or the
    column silently loses its VIF protection.

    This function owns the first half (``selected_features`` plus the registry);
    MS-08 in ``preprocess_data`` folds the registry into the other three, because
    ``essential_non_media_with_outliers`` is frozen at
    ``category_wamm_helper_functions_updated.py:315`` -- BEFORE
    ``feature_selection`` runs -- so appending inside the loop is not enough.
    """
    selected_features = list(selected_features)
    registry = registry if registry is not None else {}
    registered = registry.setdefault("new_dummies", [])

    for name in new_names:
        if name not in selected_features:
            selected_features.append(name)
        if name not in registered:
            registered.append(name)

    return selected_features, registry


# ===========================================================================
# 11. Orchestrator                                                     (MS-05)
# ===========================================================================

def _mape(y_true, y_pred):
    """MAPE in percent, guarding the zero-denominator the LITE version ignores."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    keep = y_true != 0
    if not keep.any():
        return np.inf
    return float(np.mean(np.abs((y_true[keep] - y_pred[keep]) / y_true[keep])) * 100)


# Public name for the rescue's own MAPE. The base-pass guardrail must use the
# SAME definition the gate used -- _mape drops zero-denominator rows, whereas
# sklearn's mean_absolute_percentage_error epsilon-clamps them and can return a
# hugely inflated number on identical data. Two definitions would let the final
# verdict contradict the GATE lines printed directly above it.
compute_mape_percent = _mape


def _ms_print(sbu, iteration, message):
    """Single formatting point for the rescue trace, so every line is greppable."""
    head = f"[MSedits] {sbu}" + (f" | iter {iteration}" if iteration else "")
    print(f"{head} | {message}")


def _score_of(scores, day):
    """Residual score for one day as a plain float, tolerating a missing/dup index."""
    try:
        value = scores.get(pd.Timestamp(day), np.nan)
    except Exception:
        return float("nan")
    if isinstance(value, pd.Series):
        value = value.iloc[0] if len(value) else np.nan
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _resolve_config(ms_config):
    cfg = dict(DEFAULTS)
    cfg.update(ms_config or {})
    return cfg


def build_ms_context(ms_config, data, train_end, config_dir=None, sbu=None):
    """Assemble the context ``feature_selection`` needs (MS-07).

    ``feature_selection`` has no date parameters today, but the rescue loop must
    restrict itself to training rows, so ``train_end`` is threaded in here rather
    than by changing that signature.

    Returns ``None`` when the feature is disabled, which makes the whole change a
    no-op at every call-site.
    """
    cfg = _resolve_config(ms_config)
    if not cfg.get("enabled"):
        return None

    calendar_path = cfg["event_calendar_path"]
    if config_dir and not os.path.isabs(calendar_path):
        candidate = os.path.join(config_dir, os.path.basename(calendar_path))
        if os.path.exists(candidate):
            calendar_path = candidate

    # MS-13: degrade instead of aborting. load_event_calendar opens the file
    # directly, so a missing calendar raised FileNotFoundError straight out of
    # here and killed preprocess_data. That was survivable while only two
    # categories were enabled; now that every category is, an unresolvable path
    # would break every run. A malformed calendar still raises -- that is a real
    # config error worth surfacing loudly, and this change does not make it more
    # likely.
    if os.path.exists(calendar_path):
        calendar = load_event_calendar(
            calendar_path,
            name_aliases=cfg.get("event_name_aliases"),
        )
    else:
        print(
            f"[MSedits] WARNING event calendar not found at {calendar_path}; "
            "every rescued day will be named D_MAPE_<date>"
        )
        calendar = {"point": {}, "window": {}}
    resolvable, unresolvable = assert_calendar_resolves(calendar, data)

    if unresolvable:
        print(
            "[MSedits] calendar events with no matching stack column "
            f"(their days fall back to D_MAPE_): {unresolvable}"
        )

    return {
        "config": cfg,
        "calendar": calendar,
        "calendar_path": calendar_path,
        "resolvable_events": resolvable,
        "unresolvable_events": unresolvable,
        "train_end": pd.to_datetime(train_end),
        # base_summary accumulates one record per SBU across the whole
        # feature_selection loop, so report_rescue_summary can answer
        # "for how many bases was MAPE high" at the end (MS-11).
        "registry": {"new_dummies": [], "log_records": [], "fill_log": [], "base_summary": []},
        "sbu": sbu,
    }


def run_mape_rescue(
    data,
    model,
    X,
    y,
    selected_features,
    ms_ctx,
    sbu=None,
    dates=None,
    date_col=None,
):
    """Iterative, gated, event-aware high-MAPE rescue (item 5, steps 1-11).

    Called from ``lite_non_media_utils_v3_Nat_Fit.py:208``, immediately after the
    backward-elimination OLS -- the same point at which brand-level LITE calls
    ``add_ets_dummies_for_mape`` (``lite_non_media_utils.py:305-309``). Return
    shape mirrors that function so the call-site stays a three-line change.

    Returns
    -------
    (selected_features, model, X, data, new_names, log_records)
    """
    if ms_ctx is None or not ms_ctx["config"].get("enabled"):
        return selected_features, model, X, data, [], []

    # MS-14: this gate judges the SBU-level non-media OLS, which is NOT the model
    # the release criterion is about. Under the default "bases" scope the rescue
    # is driven by run_base_rescue instead, after the 10 z_k bases exist. Set
    # rescue_scope="sbu" to restore the old behaviour.
    if ms_ctx["config"].get("rescue_scope", "bases") != "sbu":
        return selected_features, model, X, data, [], []

    cfg = ms_ctx["config"]
    registry = ms_ctx["registry"]
    calendar = ms_ctx["calendar"]

    rows = y.index
    date_col = resolve_date_column(data, date_col)
    if dates is None:
        dates = pd.to_datetime(data.loc[rows, date_col])
    train_mask = pd.to_datetime(dates) <= ms_ctx["train_end"]

    sd = None                     # fixed at the first pass, see step 10
    new_names, log_records = [], []
    rejected = set(cfg.get("rejected_columns", ()))

    # MSedits MS-11: trace bookkeeping. None until the first iteration measures
    # the incoming fit, so a disabled/short-circuited run records nothing.
    mape_initial = r2_initial = mape_last = r2_last = None
    iterations_done = 0
    stop_reason = "max_iterations"

    for iteration in range(1, int(cfg["max_iterations"]) + 1):
        y_pred = model.predict(X)
        mape_now = _mape(y, y_pred)
        r2_now = float(model.rsquared)
        if mape_initial is None:
            mape_initial, r2_initial = mape_now, r2_now
        mape_last, r2_last = mape_now, r2_now

        # --- step 1: GATE. Never spend dummies on a fit that already passes.
        _ms_print(
            sbu, iteration,
            f"GATE: MAPE {mape_now:.2f} vs limit {cfg['mape_limit']} | "
            f"R2 {r2_now:.4f} vs target {cfg['target_r2']}"
        )
        if mape_now <= cfg["mape_limit"] and r2_now >= cfg["target_r2"]:
            # Distinguish "never needed rescue" from "rescue worked": both exit
            # here, but a row reading `add 4 ... gate_passed` misreads as a no-op.
            if iterations_done:
                _ms_print(sbu, iteration, "GATE PASSED -> fit now passes, rescue converged")
                stop_reason = "converged"
            else:
                _ms_print(sbu, iteration, "GATE PASSED -> no dummies spent, rescue stopped")
                stop_reason = "gate_passed"
            break
        _ms_print(sbu, iteration, "GATE BREACHED -> rescue runs")

        # --- step 2: SCORE
        scores, sd = compute_residual_scores(y, y_pred, dates, train_mask, sd=sd)
        if not sd:
            _ms_print(sbu, iteration, "residual sd is zero/undefined; rescue stopped")
            stop_reason = "sd_zero"
            break
        _ms_print(sbu, iteration, f"residual sd = {sd:.4f} (frozen from first pass)")

        # --- step 3: SHORTLIST
        bad_days = shortlist_bad_days(scores, cfg["residual_sd_threshold"], train_mask)
        _ms_print(
            sbu, iteration,
            f"{len(bad_days)} day(s) above {cfg['residual_sd_threshold']} sigma (train rows only)"
        )

        # --- step 4: DE-DUPE
        bad_days, covered = filter_days_covered_by_dummies(
            bad_days, data, date_col=date_col, max_support=cfg["existing_dummy_max_support"]
        )
        for day, column in covered:
            _ms_print(
                sbu, iteration,
                f"SKIP {pd.Timestamp(day).strftime('%Y-%m-%d')} "
                f"(score {_score_of(scores, day):.2f}) already covered by {column}"
            )
            log_records.append({
                "sbu": sbu, "iteration": iteration,
                "date": pd.Timestamp(day).strftime("%Y-%m-%d"),
                "score": round(_score_of(scores, day), 4),
                "assigned_name": None, "days_diff": None,
                "branch": "skipped_already_covered", "covering_column": column,
                "mape_before": round(mape_now, 4), "r2_before": round(r2_now, 6),
            })

        _ms_print(sbu, iteration, f"{len(bad_days)} day(s) remain after de-dupe")
        if not bad_days:
            _ms_print(sbu, iteration, "no uncovered bad days left; rescue stopped")
            stop_reason = "no_uncovered_days"
            break

        # --- step 5: CLASSIFY
        classified = classify_days_by_event(
            bad_days,
            calendar["point"],
            window_days_by_event=cfg["window_days_by_event"],
            default_window_days=cfg["default_window_days"],
        )

        # --- step 6: GROUP (must precede the cap, or all 5 slots go to singles)
        groups, remaining = group_window_clusters(
            classified,
            calendar["window"],
            window_events=cfg["window_events"],
        )
        _ms_print(
            sbu, iteration,
            f"classified: {len(groups)} grouped cluster(s), {len(remaining)} single day(s)"
        )
        if not groups and cfg["window_events"]:
            _ms_print(sbu, iteration, "no window cluster found (back-to-school stayed dormant)")

        # --- step 7: RESOLVE, groups first so they count against the cap first
        plan = []
        for column, days in sorted(groups.items()):
            resolved = resolve_dummy_name(
                column, days, data, rejected_columns=rejected,
                unresolvable_events=ms_ctx["unresolvable_events"],
            )
            resolved["source"] = "grouped"
            resolved["days_diff"] = None
            plan.append(resolved)

        for day in sorted(remaining, key=lambda d: -float(scores.get(d, 0))):
            info = remaining[day]
            resolved = resolve_dummy_name(
                info["name"], [day], data,
                rejected_columns=rejected,
                unresolvable_events=ms_ctx["unresolvable_events"],
                event=info["event"],
                unresolvable_action=cfg["unresolvable_event_action"],
            )
            resolved["source"] = info["kind"]
            resolved["days_diff"] = info["days_diff"]
            plan.append(resolved)

        # --- step 8: CREATE
        _ms_print(
            sbu, iteration,
            f"PLAN {len(plan)} dummy(s), cap={int(cfg['max_new_dummies_per_pass'])}"
        )
        data, created, skipped = materialize_dummies(
            data, plan, cap=int(cfg["max_new_dummies_per_pass"]), date_col=date_col
        )
        if not created:
            _ms_print(sbu, iteration, "nothing left to create; rescue stopped")
            stop_reason = "nothing_to_create"
            break

        for entry in plan:
            if entry["column"] in skipped:
                branch = "skipped_over_cap"
            else:
                branch = entry["action"]

            # One trace line per planned dummy: what is being added, on which
            # day(s), and which resolve branch justified the name.
            marker = "x" if branch == "skipped_over_cap" else ("+" if branch == "create" else "~")
            entry_dates = list(entry["dates"])
            if len(entry_dates) == 1:
                when = (
                    f"{pd.Timestamp(entry_dates[0]).strftime('%Y-%m-%d')} "
                    f"(score {_score_of(scores, entry_dates[0]):.2f})"
                )
            else:
                when = f"{len(entry_dates)} day(s)"
            _ms_print(
                sbu, iteration,
                f"  {marker} {entry['column']} <- {when} branch={branch} "
                f"src={entry.get('source')} days_diff={entry.get('days_diff')}"
            )

            for day in entry["dates"]:
                log_records.append({
                    "sbu": sbu, "iteration": iteration,
                    "date": pd.Timestamp(day).strftime("%Y-%m-%d"),
                    "score": round(_score_of(scores, day), 4),
                    "assigned_name": entry["column"],
                    "days_diff": entry.get("days_diff"),
                    "branch": branch,
                    "source": entry.get("source"),
                    "is_config_error": entry.get("is_config_error"),
                    "detail": entry.get("detail"),
                    "mape_before": round(mape_now, 4), "r2_before": round(r2_now, 6),
                })
            if entry.get("is_config_error"):
                _ms_print(
                    sbu, iteration,
                    f"    CONFIG/DATA ERROR: {entry['detail']} ({entry['column']})"
                )

        # --- step 9: REGISTER
        selected_features, registry = register_dummy_names(created, selected_features, registry)
        new_names.extend(n for n in created if n not in new_names)

        # --- step 10: REFIT
        X = sm.add_constant(data.loc[rows, selected_features].astype(float))
        model = sm.OLS(y, X).fit()
        mape_after = _mape(y, model.predict(X))
        _ms_print(
            sbu, iteration,
            f"REFIT: added {created} | MAPE {mape_now:.2f} -> {mape_after:.2f} | "
            f"R2 {r2_now:.4f} -> {model.rsquared:.4f}"
        )
        iterations_done += 1
        mape_last, r2_last = mape_after, float(model.rsquared)
        for record in log_records:
            if record["iteration"] == iteration:
                record["mape_after"] = round(mape_after, 4)
                record["r2_after"] = round(float(model.rsquared), 6)

    # MSedits MS-11: one summary record per base, consumed by report_rescue_summary.
    if mape_initial is not None:
        registry.setdefault("base_summary", []).append({
            "sbu": sbu,
            "mape_before": mape_initial, "mape_after": mape_last,
            "r2_before": r2_initial, "r2_after": r2_last,
            "breached": bool(
                mape_initial > cfg["mape_limit"] or r2_initial < cfg["target_r2"]
            ),
            "iterations": iterations_done,
            "dummies_added": len(new_names),
            "new_names": list(new_names),
            "stop_reason": stop_reason,
        })

    registry.setdefault("log_records", []).extend(log_records)
    return selected_features, model, X, data, new_names, log_records


# ===========================================================================
# 11b. Base-driven rescue                                              (MS-14)
# ===========================================================================

def run_base_rescue(data, ms_ctx, sbu=None, date_col=None, pass_no=None):
    """Add dummies for the days the *candidate bases* miss (MS-14).

    The counterpart to ``run_mape_rescue``, differing in exactly two ways:

    * Scores come from the 10 non-media bases, not from the SBU-level OLS -- and
      specifically from the ``base_rescue_targets`` bases with the LOWEST MAPE.
      Release needs ``min_passing_bases`` of them, so pushing the nearest few
      over the line is the cheapest route there, and it targets days those
      particular bases actually miss.
    * There is no refit here. The caller rebuilds the bases, which is the refit.

    Every other step -- de-dupe, classify, group, resolve, materialise, register
    -- is the same shared code path ``run_mape_rescue`` uses, so a dummy created
    here is indistinguishable from one created there.

    Returns
    -------
    (data, new_names, log_records)
    """
    if ms_ctx is None or not ms_ctx["config"].get("enabled"):
        return data, [], []

    cfg = ms_ctx["config"]
    registry = ms_ctx["registry"]
    calendar = ms_ctx["calendar"]

    fit_metrics = registry.get("fit_metrics", [])
    residuals = registry.get("base_residuals", {})
    if not fit_metrics or not residuals:
        _ms_print(sbu, pass_no, "no base metrics available; base rescue skipped")
        return data, [], []

    # --- pick the targets: lowest MAPE first, name breaking ties deterministically
    n_targets = int(cfg.get("base_rescue_targets", 3))
    ranked = sorted(fit_metrics, key=lambda m: (float(m["mape"]), str(m["base"])))
    targets = [m for m in ranked if m["base"] in residuals][:n_targets]
    if not targets:
        _ms_print(sbu, pass_no, "no target base has residuals; base rescue skipped")
        return data, [], []

    _ms_print(
        sbu, pass_no,
        "targets: " + ", ".join(f"{m['base'].split('/')[-1]} (MAPE {m['mape']:.2f})"
                                for m in targets)
    )

    date_col = resolve_date_column(data, date_col)
    rejected = set(cfg.get("rejected_columns", ()))

    # --- score each target on its OWN sd, then average the sigma scores.
    # Per-base normalisation first is what makes the average meaningful: the
    # bases have different residual scales, so averaging raw residuals would let
    # the noisiest base dominate. A day must hurt the candidates generally.
    per_base, sd_bits = [], []
    for metric in targets:
        resid = pd.Series(residuals[metric["base"]]).dropna()
        if resid.empty:
            continue
        dates = pd.to_datetime(pd.Series(resid.index))
        train_mask = dates <= ms_ctx["train_end"]
        # Same arithmetic as the SBU path: compute_residual_scores subtracts
        # y_pred from y, so handing it (resid, 0) yields |resid| / sd exactly.
        scores, sd_used = compute_residual_scores(
            resid.values, np.zeros(len(resid)), dates, train_mask.values
        )
        if not sd_used or scores.empty:
            continue
        per_base.append(scores)
        sd_bits.append(f"{metric['base'].split('/')[-1]}={sd_used:.1f}")

    if not per_base:
        _ms_print(sbu, pass_no, "residual sd zero/undefined on every target; base rescue stopped")
        return data, [], []

    _ms_print(sbu, pass_no, "residual sd per target: " + " ".join(sd_bits))

    combined = pd.concat(per_base, axis=1).mean(axis=1).dropna()
    combined_dates = pd.Series(combined.index)
    combined_mask = (pd.to_datetime(combined_dates) <= ms_ctx["train_end"]).values

    # --- from here on: the same steps 3-9 the SBU path runs
    bad_days = shortlist_bad_days(combined, cfg["residual_sd_threshold"], combined_mask)
    _ms_print(
        sbu, pass_no,
        f"{len(bad_days)} day(s) above {cfg['residual_sd_threshold']} sigma "
        f"(mean of {len(per_base)} target(s), train rows only)"
    )

    bad_days, covered = filter_days_covered_by_dummies(
        bad_days, data, date_col=date_col, max_support=cfg["existing_dummy_max_support"]
    )
    log_records = []
    for day, column in covered:
        _ms_print(
            sbu, pass_no,
            f"SKIP {pd.Timestamp(day).strftime('%Y-%m-%d')} "
            f"(score {_score_of(combined, day):.2f}) already covered by {column}"
        )
        log_records.append({
            "sbu": sbu, "iteration": pass_no, "scope": "bases",
            "date": pd.Timestamp(day).strftime("%Y-%m-%d"),
            "score": round(_score_of(combined, day), 4),
            "assigned_name": None, "days_diff": None,
            "branch": "skipped_already_covered", "covering_column": column,
        })

    _ms_print(sbu, pass_no, f"{len(bad_days)} day(s) remain after de-dupe")
    if not bad_days:
        registry.setdefault("log_records", []).extend(log_records)
        return data, [], log_records

    classified = classify_days_by_event(
        bad_days, calendar["point"],
        window_days_by_event=cfg["window_days_by_event"],
        default_window_days=cfg["default_window_days"],
    )
    groups, remaining = group_window_clusters(
        classified, calendar["window"], window_events=cfg["window_events"],
    )
    _ms_print(
        sbu, pass_no,
        f"classified: {len(groups)} grouped cluster(s), {len(remaining)} single day(s)"
    )

    plan = []
    for column, days in sorted(groups.items()):
        resolved = resolve_dummy_name(
            column, days, data, rejected_columns=rejected,
            unresolvable_events=ms_ctx["unresolvable_events"],
        )
        resolved["source"] = "grouped"
        resolved["days_diff"] = None
        plan.append(resolved)

    for day in sorted(remaining, key=lambda d: -float(_score_of(combined, d))):
        info = remaining[day]
        resolved = resolve_dummy_name(
            info["name"], [day], data,
            rejected_columns=rejected,
            unresolvable_events=ms_ctx["unresolvable_events"],
            event=info["event"],
            unresolvable_action=cfg["unresolvable_event_action"],
        )
        resolved["source"] = info["kind"]
        resolved["days_diff"] = info["days_diff"]
        plan.append(resolved)

    _ms_print(
        sbu, pass_no,
        f"PLAN {len(plan)} dummy(s), cap={int(cfg['max_new_dummies_per_pass'])}"
    )
    data, created, skipped = materialize_dummies(
        data, plan, cap=int(cfg["max_new_dummies_per_pass"]), date_col=date_col
    )

    for entry in plan:
        branch = "skipped_over_cap" if entry["column"] in skipped else entry["action"]
        marker = "x" if branch == "skipped_over_cap" else ("+" if branch == "create" else "~")
        entry_dates = list(entry["dates"])
        if len(entry_dates) == 1:
            when = (f"{pd.Timestamp(entry_dates[0]).strftime('%Y-%m-%d')} "
                    f"(score {_score_of(combined, entry_dates[0]):.2f})")
        else:
            when = f"{len(entry_dates)} day(s)"
        _ms_print(
            sbu, pass_no,
            f"  {marker} {entry['column']} <- {when} branch={branch} "
            f"src={entry.get('source')} days_diff={entry.get('days_diff')}"
        )
        for day in entry["dates"]:
            log_records.append({
                "sbu": sbu, "iteration": pass_no, "scope": "bases",
                "date": pd.Timestamp(day).strftime("%Y-%m-%d"),
                "score": round(_score_of(combined, day), 4),
                "assigned_name": entry["column"],
                "days_diff": entry.get("days_diff"),
                "branch": branch,
                "source": entry.get("source"),
                "is_config_error": entry.get("is_config_error"),
                "detail": entry.get("detail"),
            })
        if entry.get("is_config_error"):
            _ms_print(
                sbu, pass_no,
                f"    CONFIG/DATA ERROR: {entry['detail']} ({entry['column']})"
            )

    if not created:
        _ms_print(sbu, pass_no, "nothing left to create; base rescue stopped")

    # Registry only -- selected_features belongs to feature_selection, which is
    # not re-run; the caller folds these names into the essential lists instead.
    _, registry = register_dummy_names(created, [], registry)
    registry.setdefault("log_records", []).extend(log_records)
    return data, list(created), log_records


# ===========================================================================
# 12-13. Logging and the release guardrail                     (step 11, MS-09)
# ===========================================================================

def write_rescue_log(log_records, out_dir, sbu=None):
    """Persist the per-day audit trail (step 11).

    A day named after an event is a claim about cause, so it has to be
    auditable: score, name assigned, which resolve branch it took, and the
    ``days_diff`` that justified the name.
    """
    if not log_records:
        return None

    os.makedirs(out_dir, exist_ok=True)
    suffix = f"_{sbu}" if sbu else ""
    path = os.path.join(out_dir, f"ms_rescue_log{suffix}.csv")
    pd.DataFrame(log_records).to_csv(path, index=False)
    print(f"[MSedits] rescue log written to {path}")
    return path


def report_rescue_summary(ms_ctx):
    """Console roll-up across every base the rescue loop saw (MS-11).

    Answers, in one block at the end of the run: how many bases were evaluated,
    for how many the MAPE was actually high, on how many the rescue logic ran,
    and which dummies it added. Reads the records ``run_mape_rescue`` appends to
    ``registry["base_summary"]`` -- it re-computes nothing, so it cannot disagree
    with the per-iteration trace above it.

    Returns the summary list so a caller can assert on it; prints nothing when
    the feature is disabled or no base was seen.
    """
    if ms_ctx is None:
        return []

    summary = ms_ctx.get("registry", {}).get("base_summary", [])
    if not summary:
        return []

    cfg = ms_ctx.get("config", {})
    mape_limit = cfg.get("mape_limit", DEFAULTS["mape_limit"])
    target_r2 = cfg.get("target_r2", DEFAULTS["target_r2"])

    high_mape = [r for r in summary if r["mape_before"] > mape_limit]
    breached = [r for r in summary if r["breached"]]
    ran = [r for r in summary if r["iterations"] > 0]
    all_names = []
    for record in summary:
        all_names.extend(n for n in record["new_names"] if n not in all_names)

    width = max([len(str(r["sbu"])) for r in summary] + [len("SBU")])

    print("[MSedits] ============== HIGH-MAPE RESCUE SUMMARY ==============")
    print(f"[MSedits] bases evaluated        : {len(summary)}")
    print(f"[MSedits] high MAPE (> {mape_limit})     : {len(high_mape)}"
          + (f" -> {[r['sbu'] for r in high_mape]}" if high_mape else ""))
    print(f"[MSedits] gate breached          : {len(breached)}"
          f"  (MAPE > {mape_limit} or R2 < {target_r2})")
    print(f"[MSedits] rescue actually ran    : {len(ran)}")
    print(f"[MSedits] dummies added (total)  : {len(all_names)}"
          + (f" -> {all_names}" if all_names else ""))
    print("[MSedits] " + "-" * 54)
    print(
        f"[MSedits] {'SBU':<{width}}  {'MAPE_b':>8} {'MAPE_a':>8} "
        f"{'R2_b':>7} {'R2_a':>7} {'it':>3} {'add':>4}  stop_reason"
    )
    for record in summary:
        print(
            f"[MSedits] {str(record['sbu']):<{width}}  "
            f"{record['mape_before']:>8.2f} {record['mape_after']:>8.2f} "
            f"{record['r2_before']:>7.4f} {record['r2_after']:>7.4f} "
            f"{record['iterations']:>3} {record['dummies_added']:>4}  "
            f"{record['stop_reason']}"
        )
    print("[MSedits] " + "=" * 54)
    return summary


def evaluate_bases(fit_metrics, rsq_limit=0.75, mape_limit=15.0):
    """Score the bases, quietly (MS-14). No output.

    Split out of ``report_base_pass_rate`` so the rebuild loop can ask "how many
    pass?" on every pass while the guardrail line is still printed only once.
    Both callers share this one definition, so the loop's decision can never
    disagree with the verdict that gets printed.

    Returns
    -------
    DataFrame with ``base``, ``r2``, ``mape`` and a ``passed`` column.
    """
    if not fit_metrics:
        return pd.DataFrame(columns=["base", "r2", "mape", "passed"])

    summary = pd.DataFrame(fit_metrics)
    summary["passed"] = (summary["r2"] >= rsq_limit) & (summary["mape"] <= mape_limit)
    return summary


def count_passing_bases(fit_metrics, rsq_limit=0.75, mape_limit=15.0):
    """Convenience for the loop: just the count."""
    summary = evaluate_bases(fit_metrics, rsq_limit=rsq_limit, mape_limit=mape_limit)
    return 0 if summary.empty else int(summary["passed"].sum())


def report_base_pass_rate(fit_metrics, rsq_limit=0.75, mape_limit=15.0, min_passing=3):
    """The 'at least N of 10 bases must pass' release guardrail -- REPORTING ONLY.

    Under MS-14 the rebuild loop acts on this criterion via ``evaluate_bases``;
    this function is the printed report of the final state.

    Parameters
    ----------
    fit_metrics : list[dict]
        One record per base with ``base``, ``r2`` and ``mape``.

    Returns
    -------
    (n_passing, released, summary)
    """
    summary = evaluate_bases(fit_metrics, rsq_limit=rsq_limit, mape_limit=mape_limit)
    if summary.empty:
        return 0, False, summary

    n_passing = int(summary["passed"].sum())
    released = n_passing >= min_passing

    print(
        f"[MSedits] guardrail: {n_passing} of {len(summary)} bases pass "
        f"(R2 >= {rsq_limit}, MAPE <= {mape_limit}) -> "
        f"{'RELEASED' if released else 'NOT RELEASED'} (need {min_passing})"
    )
    return n_passing, released, summary


def resolve_panel_mape_limit(ms_ctx, current_limit):
    """The MAPE bar handed to panel_config.json -- relaxed on give-up (MS-15).

    The rebuild loop gets ``max_base_rebuilds`` passes to pull ``min_passing_bases``
    of the 10 bases under ``mape_limit``. If it could not, those bases are not going
    to clear that bar, and holding the panel stage to it only yields an infeasible
    or empty solution set -- so the bar forwarded downstream becomes 20.

    The gate and ``report_final_verdict`` are untouched and keep judging at
    ``mape_limit`` (15.0), so the logs still report the real fit. This value is
    consumed only by ``generate_panel_data`` when it writes each panel_config.json.

    Derived entirely from the registry, so it does not depend on the caller's loop
    variables and is correct whichever way the rebuild loop exited. The count comes
    from ``count_passing_bases`` -- the same function the gate itself uses -- so this
    decision can never disagree with the verdict that gets printed.

    Returns ``current_limit`` unchanged when the gate passed, the rescue is
    disabled, or no bases were built.
    """
    if ms_ctx is None:
        return current_limit

    registry = ms_ctx.get("registry", {})
    fit_metrics = registry.get("fit_metrics", [])
    if not fit_metrics:
        return current_limit

    cfg = ms_ctx.get("config", {})
    strict = cfg.get("mape_limit", DEFAULTS["mape_limit"])
    target_r2 = cfg.get("target_r2", DEFAULTS["target_r2"])
    need = int(cfg.get("min_passing_bases", DEFAULTS["min_passing_bases"]))

    n_passing = count_passing_bases(fit_metrics, rsq_limit=target_r2, mape_limit=strict)
    if n_passing >= need:
        return current_limit

    passes = len(registry.get("fit_metrics_history", [])) or 1
    print(
        f"[MSedits MS-15] gate not met after {passes} pass(es) "
        f"({n_passing} of {need} bases at MAPE <= {strict}) | "
        f"panel_config mape_limit {current_limit} -> 20"
    )
    return 20


def relax_config_mape_limit(config_path, previous_limit, resolved_limit, outcome=None):
    """Mirror the MS-15 relaxation into category_config.json (MS-16).

    MS-15 relaxes the bar forwarded into every panel_config.json, but the
    solution-selection notebooks never read panel_config. 03/05/06.0 re-open the
    SAME category_config.json this run was configured from, take
    ``runner_settings["mape_limit"]`` and hand it to ``filter_solutions_lite``,
    which drops every row with ``Train_Mape > mape_limit``. A give-up run
    therefore solved the panels at 20 and then filtered at 15 -- which is how a
    category ends up with zero surviving solutions and no visible reason why.

    This does NOT re-evaluate the gate. It is handed the value
    ``resolve_panel_mape_limit`` went in with and the value it came out with, and
    writes only when those differ, so the file can never disagree with the
    ``[MSedits MS-15]`` line printed one statement earlier -- whichever way the
    rebuild loop exited, and without a second copy of the passing-base count.
    Gate passed, rescue disabled, ms_ctx absent, no bases built: all four arrive
    here as an equal pair and write nothing.

    Only ``runner_settings.mape_limit`` is read by python;
    ``modeling_parameters.<outcome>.mape_limit`` is written by CategoryEDA and
    read by no module, but it is kept in step so the file does not contradict
    itself for whoever opens it next.

    Re-runs are a no-op by construction: run 2 loads 20, MS-15 returns 20, the
    pair is equal, nothing is written. The gate itself cannot drift with the file
    -- every gate site reads ``mape_limit`` out of ``ms_ctx["config"]``, i.e. from
    ``DEFAULTS`` merged with ``CategoryPreprocess.ms_config``, which has been a
    literal ``{}`` since MS-13, never from the JSON.

    The file is re-read from disk on purpose -- ``CategoryPreprocess.config`` is
    NOT a clean image of it. ``self.essential_non_media`` IS the list object
    inside ``config["modeling_parameters"][outcome]["category_essential_vars"]``,
    and ``update_essential_non_media`` and ``_ms_register`` append to it in place,
    so dumping ``self.config`` would quietly persist every ``D_HIGH_SALES_*`` and
    every rescue dummy into the config as if an analyst had chosen them.

    Parameters
    ----------
    config_path : str or None
        The category_config.json ``CategoryPreprocess`` was built from. ``None``
        (older pickles, callers predating MS-16) -> warn loudly and return.
    previous_limit, resolved_limit : float
        ``self.mape_limit`` before and after ``resolve_panel_mape_limit``.
    outcome : str, optional
        Outcome key whose ``modeling_parameters`` block is kept in step; falls
        back to the file's own ``outcome_var``.

    Returns
    -------
    str or None
        The path written, or ``None`` when there was nothing to do or the write
        could not be completed. NEVER raises: a read-only, vanished or malformed
        config must not take down a run whose panel_config.json files are already
        on disk.
    """
    if resolved_limit == previous_limit:
        return None

    if not config_path:
        print(
            "[MSedits MS-16] WARNING no config path recorded on the preprocessor; "
            f"category_config.json still filters at {previous_limit} while the "
            f"panels were solved at {resolved_limit} -- solution selection may "
            "return nothing"
        )
        return None

    if not os.path.exists(config_path):
        print(f"[MSedits MS-16] WARNING config not found at {config_path}; not updated")
        return None

    try:
        with open(config_path) as fp:
            cfg = json.load(fp)

        cfg.setdefault("runner_settings", {})["mape_limit"] = resolved_limit

        outcome_key = outcome or cfg.get("outcome_var")
        params = cfg.get("modeling_parameters", {}).get(outcome_key)
        if isinstance(params, dict) and "mape_limit" in params:
            params["mape_limit"] = resolved_limit

        with open(config_path, "w") as fp:
            json_dumps_str = json.dumps(cfg, indent=4)
            print(json_dumps_str, file=fp)
    except Exception as exc:
        print(
            f"[MSedits MS-16] WARNING could not update {config_path} ({exc}); "
            f"solution selection will still filter Train_Mape at {previous_limit} "
            f"-- set runner_settings[\"mape_limit\"] to {resolved_limit} by hand"
        )
        return None

    print(
        f"[MSedits MS-16] category_config mape_limit {previous_limit} -> "
        f"{resolved_limit} written to {config_path} "
        "(notebooks 03/05/06.0 filter Train_Mape on this value)"
    )
    return config_path


def report_final_verdict(ms_ctx, min_passing=None):
    """Closing verdict: what the rescue did, and where the 10 bases landed (MS-12).

    Two halves, always printed together:

    1. Did the rescue run? If so, which dummies did it add; if not, say plainly
       that MAPE was already within threshold.
    2. The release criterion -- at least ``min_passing`` of the 10 non-media
       bases must pass -- evaluated through ``report_base_pass_rate``, which
       already owns that logic. Nothing is re-derived here.

    ``fit_metrics`` is stashed into the registry by ``get_non_media_matrix``
    (``lite_non_media_utils_v3_Nat_Fit.py``), so this runs after the 10 bases
    exist -- the rescue itself happens earlier, inside ``feature_selection``.

    Returns ``(n_passing, released, summary)`` or ``None`` when there is nothing
    to report, so the disabled path stays silent.
    """
    if ms_ctx is None:
        return None

    registry = ms_ctx.get("registry", {})
    fit_metrics = registry.get("fit_metrics", [])
    if not fit_metrics:
        return None

    cfg = ms_ctx.get("config", {})
    mape_limit = cfg.get("mape_limit", DEFAULTS["mape_limit"])
    target_r2 = cfg.get("target_r2", DEFAULTS["target_r2"])
    if min_passing is None:
        min_passing = int(cfg.get("min_passing_bases", DEFAULTS["min_passing_bases"]))

    # Dummies can come from either scope: base_summary is the SBU path's record,
    # new_dummies is every name registered by whichever path ran.
    added = list(registry.get("new_dummies", []))
    for record in registry.get("base_summary", []):
        added.extend(n for n in record["new_names"] if n not in added)

    history = registry.get("fit_metrics_history", [])
    passes = len(history)

    print("[MSedits] ============== FINAL MAPE VERDICT ==============")
    if added:
        rebuilds = f"{passes} base-build pass(es), " if passes > 1 else ""
        print(f"[MSedits] rescue RAN -> {rebuilds}added {len(added)} dummy(s): {added}")
    else:
        print(
            "[MSedits] rescue NOT NEEDED -> no dummies added; bases already "
            f"within threshold (MAPE <= {mape_limit}, R2 >= {target_r2})"
        )

    if passes > 1:
        steps = " | ".join(
            f"pass {i}: {count_passing_bases(m, target_r2, mape_limit)}/{len(m)}"
            for i, m in enumerate(history, start=1)
        )
        print(f"[MSedits] progression: {steps}")

    n_passing, released, summary = report_base_pass_rate(
        fit_metrics,
        rsq_limit=target_r2,
        mape_limit=mape_limit,
        min_passing=min_passing,
    )
    if not added:
        if released:
            print(
                f"[MSedits] MAPE already within threshold for {n_passing} base(s) "
                f"(>= {min_passing} required)"
            )
        else:
            # Never let "already within threshold" stand next to NOT RELEASED.
            print(
                f"[MSedits] WARNING only {n_passing} base(s) within threshold "
                f"(>= {min_passing} required) and the rescue added nothing"
            )

    # Ranked by MAPE so the contenders are obvious; `base` breaks ties under a
    # stable mergesort so repeated runs print the same order. NOTE rank is by
    # MAPE alone, while `passed` needs BOTH bars -- a base can rank 1 and still
    # read NO on a failing R2. Do not conflate the two columns.
    ranked = summary.sort_values(["mape", "base"], kind="mergesort").reset_index(drop=True)
    n_targets = min(int(min_passing), len(ranked))
    if n_targets:
        best = ranked.head(n_targets)
        print(
            f"[MSedits] best {n_targets} bases: MAPE {best['mape'].min():.2f} - "
            f"{best['mape'].max():.2f} (spread {best['mape'].max() - best['mape'].min():.2f}), "
            f"{int(best['passed'].sum())} of {n_targets} pass"
        )

    width = max([len(str(b)) for b in ranked["base"]] + [len("base")])
    print(f"[MSedits] {'rank':>4} {'base':<{width}}  {'r2':>7} {'mape':>8}  passed")
    for pos, row in enumerate(ranked.itertuples(index=False), start=1):
        marker = "  <-- target" if pos <= n_targets else ""
        print(
            f"[MSedits] {pos:>4} {str(row.base):<{width}}  "
            f"{row.r2:>7.4f} {row.mape:>8.2f}  {'YES' if row.passed else 'NO':<3}{marker}"
        )
    print("[MSedits] " + "=" * 48)
    return n_passing, released, ranked
