
# Final scaling and de-scaling approach is broken down into functions in this code
# last modified: 17th June, 2022, author:Aishwarya Kukrety (ADT)
# Read the 'ReadMe_custom_scaling_V3' before proceeding


import pandas as pd
import numpy as np
import re
import glob
import os
import sys
from datetime import datetime , date, timedelta

module_path = os.path.abspath(os.path.join('../../src/utils'))

#preprocessing class
class ReadData:
    def __init__(self,
                target_var,
                input_file_path_AVG,
                input_file_path_CL,
                final_model_path,
                trans_path_AVG,
                modeling_start_end_date,
                cluster
                ):
        
        self.target_var=target_var
        self.input_file_path_AVG=input_file_path_AVG
        self.input_file_path_CL=input_file_path_CL
        self.final_model_path=final_model_path
        self.trans_path_AVG=trans_path_AVG
        self.modeling_start_end_date=modeling_start_end_date
        self.cluster=cluster
        self.count=0
    
        self.read_stack()
    
    #appends cluster data below average brand data as future dates, also initializes model and cluster dates
    def read_stack(self):
        
        cluster_filter=list(str(self.cluster))
        cluster_filter.append(self.cluster)
        
        df_AVG = pd.read_csv(self.input_file_path_AVG)
        df_AVG['index'] = pd.to_datetime(df_AVG['index']) 
        df_AVG.set_index("index", inplace = True, drop= False)
        
        SARIMAX=[]
        for i in df_AVG.columns:
            if (re.match('O_UNIT_SARIMAX',i)):
                SARIMAX.append(i)
        self.AVG_DF=df_AVG      
        if self.cluster in range(1,5):
            df_CL = pd.read_csv(self.input_file_path_CL)
            df_CL['index'] = pd.to_datetime(df_CL['index']) 
            df_CL.set_index("index", inplace = True, drop= False)
            df_CL_filtered = df_CL[df_CL['cluster'].isin(cluster_filter)]
            df_CL_filtered.reset_index(drop=True, inplace=True)
            
            for i in df_CL_filtered.columns:
                for j in SARIMAX:
                    if (re.match('O_UNIT_SARIMAX ',i) and re.match('O_UNIT_SARIMAX ',j)):
                        df_CL_filtered.rename(columns={i:j}, inplace=True)
                    elif (re.match('O_UNIT_SARIMAX_LOG ',i) and re.match('O_UNIT_SARIMAX_LOG ',j)):
                        df_CL_filtered.rename(columns={i:j}, inplace=True)
                        #print(i)
            self.CL_DF=df_CL_filtered

            
            
        
    def merge_stack(self):
        if self.cluster in range(1,5):
            self.modeling_start_date_str, self.modeling_end_date_str = self.modeling_start_end_date
            self.model_start = datetime.strptime(self.modeling_start_date_str, '%Y-%m-%d').date()
            self.model_end = datetime.strptime(self.modeling_end_date_str, '%Y-%m-%d').date()
            self.cluster_start_date=self.model_end+timedelta(1)
            days= self.model_end-self.model_start+timedelta(1)
            self.cluster_end_date=self.model_end+days
            datelist = pd.date_range(self.model_end+timedelta(1), periods=days.days).tolist()
            new_dates = [i.strftime("%Y-%m-%d") for i in datelist]
            #slicing dataframes basis modelling time period
            self.AVG_DF = self.AVG_DF[(self.AVG_DF['index'] >= pd.to_datetime(self.model_start)) & (self.AVG_DF['index'] <= pd.to_datetime(self.model_end))]
            
            self.CL_DF = self.CL_DF[(self.CL_DF['index'] >= pd.to_datetime(self.model_start)) & (self.CL_DF['index'] <= pd.to_datetime(self.model_end))]
            self.CL_DF['index']=new_dates
            merged_stack=self.AVG_DF.append(self.CL_DF)
            merged_stack=merged_stack.replace(np.nan, 0)
            merged_stack['index'] = pd.to_datetime(merged_stack['index']) 
            merged_stack.set_index("index", inplace = True, drop= False)
        return merged_stack
    
    
    #fixes spends, rates for the combined data stack(averge brand+ cluster)    
    def spend_rate_fix(self):
        #fixing spends
        for i in self.df.columns:
            for j in self.df.index:
                if (re.match('RATE',i)):
                    if(re.match('ON',i[5:])or re.match('OFF',i[5:]) or re.match('IN',i[5:])):
                        if (self.df.loc[j,"M"+i[4:]+'_SPEND']==0):
                            if(self.df.loc[j,"M"+i[4:]+'_IMP']!=0):
                                self.df.loc[j,"M"+i[4:]+'_SPEND']=self.df.loc[j,"M"+i[4:]+'_SPEND_CALC']
                    else:
                        if(i[-3:]=='CLK'):
                            x="M"+i[4:]
                            if (self.df.loc[j,x[:-3]+'SPEND']==0):
                                if(self.df.loc[j,"M"+i[4:]]!=0):
                                    self.df.loc[j,x[:-3]+'SPEND']=self.df.loc[j,x[:-3]+'SPEND_CALC']
                                
        #fixing rates
        for i in self.df.columns:
            if (re.match('RATE',i)):
                if (re.match('ON',i[5:]) or re.match('OFF',i[5:]) or re.match('IN',i[5:])):
                    self.df[i]=self.df["M"+i[4:]+'_SPEND']/self.df["M"+i[4:]+'_IMP']
                else:
                    if(i[-3:]=='CLK'):
                        x="M"+i[4:]
                        self.df[i]=self.df[x[:-3]+'SPEND']/self.df["M"+i[4:]]
        self.df=self.df.fillna(0)
    
    #reads dependent variables and separates them into WMC, WMT and base
    def get_model_result_df(self):
    
        try:    
            model_results_df = pd.read_excel(self.final_model_path)[['Variable Actual', 'Coefficient']]
        except:
            model_results_df = pd.read_excel("\\\\?\\"+os.path.abspath(self.final_model_path))[['Variable Actual', 'Coefficient']]
        WMC_vars = model_results_df[model_results_df['Variable Actual'].str.startswith('M_')].reset_index(drop= True)
        WMC_vars.set_index('Variable Actual', inplace = True, drop= True)
        self.WMT_vars = model_results_df[model_results_df['Variable Actual'].str.startswith('M_WMT')].reset_index(drop= True)
        self.base_vars= model_results_df[model_results_df['Variable Actual'].str.startswith(tuple(['D','I','O']))].reset_index(drop= True)
        for i in self.WMT_vars['Variable Actual']:
            WMC_vars.drop(index=i,axis=0,inplace=True)
        WMC_vars.reset_index(drop=False, inplace=True)
        WMC_vars1=pd.DataFrame()
        df1, df_cl=self.get_df_train_test()
        for i in WMC_vars['Variable Actual']:
            a=re.search(r'\d',i)
            if df_cl[(i[0:a.start()-1])].sum()!=0:
                entry = WMC_vars.loc[WMC_vars['Variable Actual'] == i]
                WMC_vars1=WMC_vars1.append( [entry] )
        return WMC_vars1    
        
        
    def get_ratio(self):
        media=[]
        model_results_df = self.get_model_result_df()
        self.df['M_TOTAL_MEDIA_SPEND']=0
        
        for i in model_results_df['Variable Actual']:
            a=re.search(r'\d',i)
            media.append(i[0:a.start()])
            
        for i in media:
            self.df['M_TOTAL_MEDIA_SPEND']=self.df['M_TOTAL_MEDIA_SPEND']+self.df[i[:-4]+'SPEND']
        
        base=[]
        df_train, df_test= self.get_df_train_test()
        df_train.to_excel('AVG_brand.xlsx')
        for i in df_test.columns:
            if(re.match(self.target_var,i)):
                base.append(i)
        base.append('O_SALE')
        
        total_spends='M_TOTAL_MEDIA_SPEND'
        media.append(total_spends)
        media.append(self.target_var)

        df_trans=pd.DataFrame(df_test[total_spends])
        df_trans[total_spends]=df_test[total_spends]
        for i in media+base:
            if (i==total_spends):
                continue
            else:
                if(re.match(self.target_var,i) or i=='O_SALE' ):
                    df_trans[i+'_ratio']=df_test[i]/df_test[self.target_var]
                else:
                    df_trans[i[:-4]+'ratio']=df_test[i[:-4]+'SPEND']/df_test[total_spends]
#         df_test.index=df_train.index
        df_trans.index=df_train.index
        return total_spends, df_trans, media
        
    #minmax scaling the cluster spends to average brand spends
    def min_max_scaling(self):
        df_temp=pd.DataFrame()
        df_train, df_test= self.get_df_train_test()
        total_spends , df_trans,media=self.get_ratio()
        for i in df_test.columns:
            if (i!=total_spends and i!=self.target_var):
                continue
            else:
                slope = (df_train[i].max() - df_train[i].min()) / (df_test[i].max() - df_test[i].min())
                scaled_var=df_train[i].min()+slope*(df_test[i]-df_test[i].min()) 
                df_temp[i]=scaled_var
        df_temp.to_excel('old_scaled.xlsx')
        #app 1.2 
        CL_og_sp_sale_ratio=df_test[total_spends].mean()/df_test[self.target_var].mean()
        CL_scaled_sp_sale_ratio=df_temp[total_spends].mean()/df_temp[self.target_var].mean()
        df_temp[total_spends]=(df_temp[total_spends]*CL_og_sp_sale_ratio)/CL_scaled_sp_sale_ratio

        #app 1.2 end
        df_temp.index=df_train.index
        df_temp.to_excel('new_scaled.xlsx')
        df_test.index=df_train.index
        df_test['index'] = df_train['index']
        
        # slicing of  cluster dataframe in optimization time frame
        self.actual_df = df_test[((df_test['index'] >= pd.to_datetime(self.model_start)) & (df_test['index'] <= pd.to_datetime(self.model_end)))]
#         df_trans.index=df_train.index
        
        return df_temp, df_test
        
    # creating dataframe with scaled spends, rates and impressions  
    # if you call this function then no need to call sget_ratio and min_max_scaling separately
    def scaled_cluster_data(self):
        if self.count==0:
            self.df=self.merge_stack()
            self.count+=1
        self.spend_rate_fix()
        total_spends , df_trans,media=self.get_ratio()
        df_train, df_test_not_used= self.get_df_train_test()
        df_temp,df_test=self.min_max_scaling()
        
        
        for i in df_trans.columns:
            if (i==total_spends):
                continue
            else:
                if(re.match(self.target_var,i) or re.match('O_SALE',i)):
                    df_temp[i[:-6]]=df_trans[i]*df_temp[self.target_var]
                else:
                    df_temp[i[:-5]+'SPEND']=df_trans[i]*df_temp[total_spends]
            
        #adding rates to stack; rates have been kept the same as that of the cluster
        for i in df_test.columns:
            if (re.match('RATE',i)):
                df_temp[i]=df_test[i]
        media.remove(total_spends)
        media.remove(self.target_var)
        #adding impression to stack; rates have been kept the same as that of the cluster
        for i in media:
            if(i[-4:-1]=='CLK'):
                df_temp[i[:-1]]=df_temp[i[:-4]+'SPEND']/df_temp['RATE'+i[1:-1]]
            else:
                df_temp[i[:-1]]=df_temp[i[:-4]+'SPEND']/df_temp['RATE'+i[1:-5]]
        df_temp=df_temp.fillna(0)
        #display(df_temp)
        
        #adding WMT and flag variables
        flags=[]
        for i in df_train.columns:
            if (re.match('D_',i)):
                flags.append(i)

        WMT=[]
        for i in df_train.columns:
            if (re.match('M_WMT_',i)):
                WMT.append(i)
                
        flagcols = df_train[flags]
        WMTcols = df_train[WMT]
        df_temp = pd.concat([df_temp,flagcols,WMTcols],axis = 1)
        return df_temp
        
        
    def get_df_train_test(self):
        # creating df_test and df_train using cluster and model start and end dates
        df_train = self.df[(self.df['index'] >= pd.to_datetime(self.model_start)) & (self.df['index'] <= pd.to_datetime(self.model_end))]
        df_test = self.df[(self.df['index'] >= pd.to_datetime(self.cluster_start_date)) & (self.df['index'] <= pd.to_datetime(self.cluster_end_date))]
        
        return df_train, df_test