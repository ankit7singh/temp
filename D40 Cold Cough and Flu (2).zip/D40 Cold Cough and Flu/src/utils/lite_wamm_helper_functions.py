#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# author: Mayukh Maitra
"""
Created on Sun Feb  4 00:24:43 2024

@author: m0m0tc7
"""
import math
import numpy as np
import pandas_gbq

def get_scurve_bounds_v1(data, brand_list, media_variables, lb=0.05, ub=0.95):
    target_thresh = {}
    target_sat = {}
    for var in range(len(media_variables)):
        target_thresh[media_variables[var]]=[]
        target_sat[media_variables[var]]=[]
        for brand in brand_list:
            df = data[data["SBU"]==brand].copy()
            threshold_point = df[df[media_variables[var]] > 0][
                media_variables[var]
            ].quantile(lb)
            target_thresh[media_variables[var]].append(threshold_point)
            saturation_point = df[df[media_variables[var]] > 0][
                media_variables[var]
            ].quantile(ub)
            target_sat[media_variables[var]].append(saturation_point)          

    target_threshold = []
    for k, v in target_thresh.items():
        target_threshold.append(np.mean(v))
    target_saturation = []
    for k, v in target_sat.items():
        target_saturation.append(np.mean(v))

    threshold_bounds = []
    saturation_bounds = []
    for var in range(len(media_variables)):
        threshold_point = target_threshold[var]
        saturation_point = target_saturation[var]
        
        threshold_bounds.append(
            np.array(
                [
                    threshold_point - threshold_point * 0.1,
                    threshold_point + threshold_point * 0.1,
                ]
            )
        )
        saturation_bounds.append(
            np.array(
                [
                    saturation_point - saturation_point * 0.1,
                    saturation_point + saturation_point * 0.1,
                ]
            )
        )

        ### If bounds overlap then bring threshold range further down and push saturation range further up
        while threshold_bounds[var][1] >= saturation_bounds[var][0]:
            threshold_bounds[var][1] = 0.7 * threshold_bounds[var][0]
            threshold_bounds[var][0] = 0.7 * threshold_bounds[var][1]
            saturation_bounds[var][1] = 1.3 * saturation_bounds[var][1]
            saturation_bounds[var][0] = 1.1 * saturation_bounds[var][0]
    return (
        np.asarray(threshold_bounds),
        np.asarray(saturation_bounds),
        target_threshold,
        target_saturation,
    )

def get_scurve_bounds(data, media_variables, thres_sat_dict, thres_dict, lb=0.01, ub=0.99, custom_s_curve_bounds = None):
    threshold_bounds = []
    saturation_bounds = []
    target_threshold = []
    target_saturation = []

    default_thresh = lb
    default_sat = ub

    for var in range(len(media_variables)):  
        media_var = media_variables[var]
        if custom_s_curve_bounds and media_var in custom_s_curve_bounds:            
            lb = custom_s_curve_bounds[media_var][0]
            ub = custom_s_curve_bounds[media_var][1]
        else:
            lb = default_thresh
            ub = default_sat
        
        if media_var not in thres_sat_dict.keys():
            if ("CATTO" in media_var) or ("_HP" in media_var) or ("OPD" in media_var):
                thres_sat_dict[media_var] = [0.2,1.00] 
            else:
                thres_sat_dict[media_var] = [0.2,0.75]       
        if lb == -1:                         # Placeholder for category wamm threshold replication
            threshold_point = 0
        else:        
            threshold_point = data[data[media_variables[var]] > 0][
                media_variables[var]
            ].quantile(lb)
        target_threshold.append(threshold_point)
        saturation_point = data[data[media_variables[var]] > 0][
            media_variables[var]
        ].quantile(ub)
        target_saturation.append(saturation_point)


        threshold_bounds.append(
            np.array(
                [
                    threshold_point - threshold_point * thres_dict[media_variables[var]][0],
                    threshold_point + threshold_point * thres_dict[media_variables[var]][1],
                ]
            )
        )


        saturation_bounds.append(
                np.array(
                    [
                        saturation_point - saturation_point * thres_sat_dict[media_variables[var]][0],
                        saturation_point + saturation_point * thres_sat_dict[media_variables[var]][1],
                    ]
                )
            )

        ### If bounds overlap then bring threshold range further down and push saturation range further up
        while threshold_bounds[var][1] >= saturation_bounds[var][0]:
            threshold_bounds[var][1] = 0.7 * threshold_bounds[var][0]
            threshold_bounds[var][0] = 0.7 * threshold_bounds[var][1]
            saturation_bounds[var][1] = 1.3 * saturation_bounds[var][1]
            saturation_bounds[var][0] = 1.1 * saturation_bounds[var][0]

    return (
        np.asarray(threshold_bounds),
        np.asarray(saturation_bounds),
        target_threshold,
        target_saturation,
    )

def get_scurve_bounds_inf_sat(data, media_variables, thres_sat_dict, lb=0.01, ub=0.99, custom_s_curve_bounds = None):
    inflection_bounds = []
    saturation_bounds = []
    target_inflection = []
    target_saturation = []

    for var in range(len(media_variables)):  
        media_var = media_variables[var]
        if custom_s_curve_bounds and media_var in custom_s_curve_bounds:            
            lb = custom_s_curve_bounds[media_var][0]
            ub = custom_s_curve_bounds[media_var][1]
        
        if media_var not in thres_sat_dict.keys():
            if ("CATTO" in media_var) or ("_HP" in media_var) or ("OPD" in media_var):
                thres_sat_dict[media_var] = [0.2,1.00] 
            else:
                thres_sat_dict[media_var] = [0.2,0.75]       
        inflection_point = data[data[media_variables[var]] > 0][
                media_variables[var]
            ].mean()

        target_inflection.append(inflection_point)
        saturation_point = data[data[media_variables[var]] > 0][
            media_variables[var]
        ].quantile(ub)
        target_saturation.append(saturation_point)

        ## For CPD Keep inflection and scale : 
        if ("CTV" in media_var) or ("DIGITAL_USGM" in media_var) :

            inflection_bounds.append(
                np.array(
                    [
                        inflection_point - inflection_point * 0.10,
                        inflection_point + inflection_point * 0.60,
                    ]
                )
            )


            saturation_bounds.append(
                    np.array(
                        [
                            saturation_point - saturation_point * 0.5,
                            saturation_point + saturation_point * 0.1,
                        ]
                    )
                )
            
        elif ("CATTO" in media_var) or ("_HPLO" in media_var) :

            inflection_bounds.append(
                np.array(
                    [
                        inflection_point - inflection_point * 0.80,
                        inflection_point + inflection_point * 0.01,
                    ]
                )
            )


            saturation_bounds.append(
                    np.array(
                        [
                            saturation_point - saturation_point * 0.2,
                            saturation_point + saturation_point * 0.1,
                        ]
                    )
                )

        elif (("SP" in media_var) or ("SBA" in media_var) ) and media_var != 'M_SP_AB_1_CLK':

            inflection_bounds.append(
                np.array(
                    [
                        inflection_point - inflection_point * 0.10,
                        inflection_point + inflection_point * 0.20,
                    ]
                )
            )


            saturation_bounds.append(
                    np.array(
                        [
                            saturation_point - saturation_point * 0.05,
                            saturation_point + saturation_point * 0.1,
                        ]
                    )
                )

        elif media_var == 'M_SP_AB_1_CLK':

            inflection_bounds.append(
                np.array(
                    [
                        inflection_point - inflection_point * 0.10,
                        inflection_point + inflection_point * 0.10,
                    ]
                )
            )


            saturation_bounds.append(
                    np.array(
                        [
                            saturation_point - saturation_point * 0.01,
                            saturation_point + saturation_point * 0.2,
                        ]
                    )
                )

        else:

            inflection_bounds.append(
                np.array(
                    [
                        inflection_point - inflection_point * 0.01,
                        inflection_point + inflection_point * 0.40,
                    ]
                )
            )


            saturation_bounds.append(
                    np.array(
                        [
                            saturation_point - saturation_point * 0.1,
                            saturation_point + saturation_point * 0.5,
                        ]
                    )
                )

        ### If bounds overlap then bring threshold range further down and push saturation range further up
        # while threshold_bounds[var][1] >= saturation_bounds[var][0]:
        #     threshold_bounds[var][1] = 0.7 * threshold_bounds[var][0]
        #     threshold_bounds[var][0] = 0.7 * threshold_bounds[var][1]
        #     saturation_bounds[var][1] = 1.3 * saturation_bounds[var][1]
        #     saturation_bounds[var][0] = 1.1 * saturation_bounds[var][0]

    return (
        np.asarray(inflection_bounds),
        np.asarray(saturation_bounds),
        target_inflection,
        target_saturation
        )



def get_media_iroas_prior(data, brand_list,outcome="O_UNIT",media_variables=[],is_category=False,is_premium=False,debug_flag=False):
    if debug_flag:
        is_premium=False
    if (not is_premium) and (not is_category):
        default_prior = np.array([2.0, 1.1, 1.5])
        brand_filter = (
            "upper(brand) in ("
            + ",".join('"{}"'.format(value) for value in brand_list)
            + ")"
        )
        ContriSummary_query = (
            """
            select media_driver, sum(incremental_sales) as Sales, sum(spend) as Spend from gcp_wmg_dev_ms.wamm_media_driver_contribution_summary
            where """
            + str(brand_filter)
            + """ and incremental_sales > 0 and spend > 0
            group by media_driver
            """
        )
        ContriSummary_df_og = pandas_gbq.read_gbq(
            ContriSummary_query, project_id="wmt-wmg-adops-adhoc-dev"
        )
        on_dis = ContriSummary_df_og.loc[
            (ContriSummary_df_og["media_driver"].str.startswith("M_ON_"))
        ]
        off_dis = ContriSummary_df_og.loc[
            (ContriSummary_df_og["media_driver"].str.startswith("M_OFF_"))
        ]
        sponsored_brands = ContriSummary_df_og.loc[
            (ContriSummary_df_og["media_driver"].str.startswith("M_SBA_"))
        ]
        sponsored_search = ContriSummary_df_og.loc[
            (ContriSummary_df_og["media_driver"].str.startswith("M_SP_"))
        ]
        try:
            on_dis_iroas = on_dis["Sales"].sum() / on_dis["Spend"].sum()
        except:
            on_dis_iroas = default_prior[0]
        if math.isnan(on_dis_iroas):
            on_dis_iroas = default_prior[0]
        try:
            off_dis_iroas = off_dis["Sales"].sum() / on_dis["Spend"].sum()
        except:
            off_dis_iroas = default_prior[1]
        if math.isnan(off_dis_iroas):
            off_dis_iroas = default_prior[1]
        try:
            search_iroas = (
                sponsored_brands["Sales"].sum() + sponsored_search["Sales"].sum()
            ) / (sponsored_brands["Spend"].sum() + sponsored_search["Spend"].sum())
        except:
            search_iroas = default_prior[2]
        if math.isnan(search_iroas):
            search_iroas = default_prior[2]

        if debug_flag:
            return {"M_OFF_DIS_TOTAL_IMP":off_dis_iroas,"M_ON_DIS_TOTAL_IMP":on_dis_iroas,"M_SEARCH_CLK":search_iroas}
        return np.array([on_dis_iroas, off_dis_iroas, search_iroas]) # premium_changes : change this line to return np.array([off_dis_iroas,on_dis_iroas, search_iroas])
    if (is_premium) and (not is_category):
        # for WAMM premium
        if outcome=='O_UNIT':
            outcome_type = 'OMNI Volume Sales Unit Model'
        elif outcome=='O_NEW_CUSTOMER':
            outcome_type = 'OMNI New Customer Count Model'
        else:
            outcome_type = 'OMNI Volume Sales Unit Model'
        default_prior = np.array([2.0, 1.1, 1.5])
        
        brand_filter = "upper(brand) in (" + ','.join('"{}"'.format(value) for value in brand_list) + ")"
        media_driver_filter = "upper(media_driver) in (" + ','.join('"{}"'.format(value) for value in media_variables) + ")"
        ContriSummary_query = f'''
            select media_driver, if(sum(spend)<=0,0,sum(incremental_sales)/sum(spend)) as iRoAS from gcp_wmg_dev_ms.wamm_media_driver_contribution_summary
            where {brand_filter} and model like '{outcome_type}' 
            and media_driver not like ('%M_NAT%') and media_driver like ('%M_%')
            group by media_driver
            '''
        print(ContriSummary_query)
        # where {brand_filter} and model={outcome_type} and {media_driver_filter}
        ContriSummary_df_og = pandas_gbq.read_gbq(ContriSummary_query, project_id='wmt-wmg-adops-adhoc-dev')

    
        ContriSummary_df_og_media_variables = list(ContriSummary_df_og.media_driver.unique())
        iroas_priors = {}
        for var in media_variables:
            if var in ContriSummary_df_og_media_variables:
                iroas_prior = ContriSummary_df_og[ContriSummary_df_og.media_driver==var]
            else:
                if var.startswith("M_ON"):
                    iroas_prior = default_prior[0]
                if var.startswith("M_OFF"):
                    iroas_prior = default_prior[1]
                if var.startswith("M_SP") or var.startswith("M_SBA") or var.startswith("M_SEARCH"):
                    iroas_prior = default_prior[2]
            iroas_priors[var] = iroas_prior

        return iroas_priors
    else:
        # Category WAMM  : TODO Updating the inputs from prior Category WAMMs
        if outcome=='O_UNIT':
            outcome_type = 'OMNI Volume Sales Unit Model'
        elif outcome=='O_NEW_CUSTOMER':
            outcome_type = 'OMNI New Customer Count Model'
        else:
            outcome_type = 'OMNI Volume Sales Unit Model'
        default_prior = np.array([2.0, 1.1, 1.5, 1.5])

        ## TODO : Update the Category WAMM Tables here
                
        # brand_filter = "upper(brand) in (" + ','.join('"{}"'.format(value) for value in brand_list) + ")"
        # media_driver_filter = "upper(media_driver) in (" + ','.join('"{}"'.format(value) for value in media_variables) + ")"
        # ContriSummary_query = f'''
        #     select media_driver, if(sum(spend)<=0,0,sum(incremental_sales)/sum(spend)) as iRoAS from gcp_wmg_dev_ms.wamm_media_driver_contribution_summary
        #     where {brand_filter} and model like '{outcome_type}' 
        #     and media_driver not like ('%M_NAT%') and media_driver like ('%M_%')
        #     group by media_driver
        #     '''
        # print(ContriSummary_query)
        # # where {brand_filter} and model={outcome_type} and {media_driver_filter}
        # ContriSummary_df_og = pandas_gbq.read_gbq(ContriSummary_query, project_id='wmt-wmg-adops-adhoc-dev')

    
        # ContriSummary_df_og_media_variables = list(ContriSummary_df_og.media_driver.unique())
        iroas_priors = {}
        for var in media_variables:
            # if var in ContriSummary_df_og_media_variables:
            #     iroas_prior = ContriSummary_df_og[ContriSummary_df_og.media_driver==var]
            # else:
                print(var)
                if var.startswith("M_ON"):
                    iroas_prior = default_prior[0]
                if var.startswith("M_OFF"):
                    iroas_prior = default_prior[1]
                if var.startswith("M_SP") or var.startswith("M_SBA") or var.startswith("M_SEARCH") or var.startswith("M_INSTORE"):
                    iroas_prior = default_prior[2]
                if var.startswith("M_WMT"):
                    iroas_prior = default_prior[3]
                
                iroas_priors[var] = iroas_prior

        return iroas_priors


def get_media_coef_prior(data, media_iroas_prior, media_variables,is_premium=False,is_category=False):
    
    data["PRICE"] = data["O_SALE"] / data["O_UNIT"]      # Category WAMM : Stack has the price included
    data["PRICE"] = data["PRICE"].mean()
    U_m, Var_m = [], []
    U_m_pooled = {}
    Var_m_pooled = {}    
    for i,var in enumerate(media_variables):
        if "_IMP" in media_variables[i]:
            spend_var = media_variables[i].replace("_IMP", "_SPEND")
        else:
            spend_var = media_variables[i].replace("_CLK", "_SPEND")

        delta_by_media = (data["PRICE"] * data[media_variables[i]]).sum() / data[
            spend_var
        ].sum()
        print(delta_by_media)
        if (not is_premium) and (not is_category):
            U_m.append(media_iroas_prior[i] / delta_by_media)
            Var_m.append(((media_iroas_prior[i] / (delta_by_media * 3)) ** 2))
        if (is_premium) and (not is_category):
            U_m.append(media_iroas_prior[var] / delta_by_media)
            Var_m.append(((media_iroas_prior[var] / (delta_by_media * 3)) ** 2))
        else:
            U_m.append(media_iroas_prior[var] / delta_by_media)
            Var_m.append(((media_iroas_prior[var] / (delta_by_media * 3)) ** 2))

    return np.asarray(U_m), np.asarray(Var_m)
