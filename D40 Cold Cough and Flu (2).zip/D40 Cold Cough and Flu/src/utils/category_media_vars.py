category_media_variables = [
                "M_ON_DIS_AT_IMP",
                "M_ON_DIS_CT_IMP",
                "M_ON_DIS_HPLO_IMP",
                "M_ON_DIS_KW_IMP",
                "M_ON_DIS_ROS_IMP",
                "M_ON_DIS_SEA_IMP",
                "M_OFF_DIS_FB_IMP",
                "M_OFF_DIS_PIN_IMP",
                "M_OFF_DIS_TIK_IMP",
                "M_OFF_DIS_WN_WITHOUTCTV_IMP",
                "M_OFF_DIS_DSP_CTV_IMP",
                "M_SP_AB_CLK",
                "M_SP_KWB_CLK",
                "M_SBA_CLK",
                "M_SP_VIDEO_CLK",
                "M_SV_CLK",
                "M_ON_DIS_OPD_HP_IMP",
                "M_ON_DIS_HP_IMP",
                "M_ON_DIS_APP_HPLO_IMP",
                "M_ON_DIS_HPGTO_IMP",
                "M_ON_DIS_CATTO_IMP",
                "M_OFF_DIS_INSTA_IMP"
]
category_cpd_variables = [
    "M_ON_DIS_HPLO_IMP",
    "M_ON_DIS_APP_HPLO_IMP",
    "M_ON_DIS_CATTO_IMP",
    "M_ON_DIS_HPGTO_IMP",
]

category_channel_variables = ["M_SEARCH_CLK","M_ON_DIS_TOTAL_IMP", "M_OFF_DIS_TOTAL_IMP"]


category_wmt_variables = ["M_WMT_AFFILIATES_SEM_USGM_L1_CLK",
                "M_WMT_U_M_DIGITAL_USGM_National_IMP",
                "M_WMT_U_M_SMEDIA_USGM_National_IMP",
                "M_WMT_U_M_TV_RADIO_USGM_National_IMP"]

default_tactic_combinations = {
    "M_ON_DIS_AT_IMP": ["M_ON_DIS_CT_IMP"],
    "M_ON_DIS_CT_IMP": ["M_ON_DIS_AT_IMP"],
    "M_ON_DIS_OPD_HP_IMP": ["M_ON_DIS_HP_IMP"],  # confirm this
    "M_ON_DIS_HP_IMP": ["M_ON_DIS_OPD_HP_IMP", "M_ON_DIS_ROS_IMP"],
    "M_ON_DIS_ROS_IMP": ["M_ON_DIS_HP_IMP"],
    "M_ON_DIS_HPLO_IMP": [
        "M_ON_DIS_APP_HPLO_IMP",
        "M_ON_DIS_HPTO_IMP",
        "M_ON_DIS_HPGTO_IMP",
    ],
    "M_ON_DIS_APP_HPLO_IMP": [
        "M_ON_DIS_HPLO_IMP",
        "M_ON_DIS_HPTO_IMP",
        "M_ON_DIS_HPGTO_IMP",
    ],
    "M_ON_DIS_HPGTO_IMP": [
        "M_ON_DIS_HPLO_IMP",
        "M_ON_DIS_HPTO_IMP",
        "M_ON_DIS_APP_HPLO_IMP",
    ],
    "M_ON_DIS_HPTO_IMP": [
        "M_ON_DIS_HPLO_IMP",
        "M_ON_DIS_HPGTO_IMP",
        "M_ON_DIS_APP_HPLO_IMP",
    ],
    "M_OFF_DIS_WN_WITHOUTCTV_IMP": ["M_OFF_DIS_DSP_CTV_IMP"],
    "M_OFF_DIS_DSP_CTV_IMP": ["M_OFF_DIS_WN_WITHOUTCTV_IMP"],
    "M_OFF_DIS_FB_IMP": [
        "M_OFF_DIS_PIN_IMP",
        "M_OFF_DIS_TIK_IMP",
        "M_OFF_DIS_INSTA_IMP",
    ],
    "M_OFF_DIS_PIN_IMP": [
        "M_OFF_DIS_FB_IMP",
        "M_OFF_DIS_TIK_IMP",
        "M_OFF_DIS_INSTA_IMP",
    ],
    "M_OFF_DIS_TIK_IMP": [
        "M_OFF_DIS_FB_IMP",
        "M_OFF_DIS_PIN_IMP",
        "M_OFF_DIS_INSTA_IMP",
    ],
    "M_OFF_DIS_INSTA_IMP": [
        "M_OFF_DIS_FB_IMP",
        "M_OFF_DIS_PIN_IMP",
        "M_OFF_DIS_TIK_IMP",
    ],
    "M_SP_AB_CLK": ["M_SP_KWB_CLK"],
    "M_SP_KWB_CLK": ["M_SP_AB_CLK"],
    "M_SBA_CLK": ["M_SP_VIDEO_CLK", "M_SV_CLK"],
    "M_SP_VIDEO_CLK": ["M_SBA_CLK"],
    "M_SV_CLK": ["M_SBA_CLK"],
}