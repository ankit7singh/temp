#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# author: Mayukh Maitra
"""
Created on Sun Feb  4 00:24:43 2024

@author: m0m0tc7
"""
import math
import re

# Computation of Spearman correlation clusters
import matplotlib.pyplot as plt
import numpy as np
# Dataframe and array manipulation
import pandas as pd
import plotly.graph_objects as go
# Linear regression
import statsmodels.api as sm
from custom_seasonality_analysis import VariableSeasonality
from numpy.linalg import inv, pinv
from sklearn.metrics import mean_absolute_percentage_error as mape
from sklearn.metrics import r2_score
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import grangercausalitytests

plt.rcParams["figure.dpi"] = 300
plt.rcParams["figure.figsize"] = (20, 20)


import warnings

warnings.filterwarnings("ignore")

spec = [["L3_CATEGORY_NAME"], ["L3_CATEGORY_NAME", "BRAND"]]

forecasting_method = ["HoltWinters", "AutoARIMA"]

essential_vars = ["D_HOL_CHRISTMAS", "D_HOL_THANKSGIVING"]

weekend_vars = []

non_media_fit = {}

def find_outcome_residuals(df, outcome_variable, essential_vars):
    """
    Calculates the residual of outcome_variable regressed against essential_vars
    """
    if len(essential_vars) > 0:
        Y = df[outcome_variable]
        X = df[essential_vars]
        X = sm.add_constant(X)
        model = sm.OLS(Y, X, missing="drop")
        model_result = model.fit()
        outcome_residuals = model_result.resid
    else:
        outcome_residuals = df[outcome_variable]
    return outcome_residuals

def find_essential_inv_var(df, outcome_variable, outcome_residuals):
    """
    Finds the highest Pearson correlated inventory/distribution variable (OOS variables are internally negated to
    be assed through the same condition) to the outcome data.
    """
    # outcome_residuals = find_outcome_residuals(df, outcome_variable, essential_vars)
    inventory_vars = [
        c
        for c in df.columns
        if "INV_" in c or "TDP" in c or "ACV" in c or "DISTRIBUTION" in c
    ]
    inv_corrs = df[inventory_vars].join(outcome_residuals.rename("resids")).copy()
    oos_cols = [c for c in inv_corrs.columns if "OOS" in c]
    if len(oos_cols) > 0:
        inv_corrs[oos_cols] = -inv_corrs[oos_cols]
    inv_corrs = inv_corrs.corr().iloc[-1]
    inv_corrs = inv_corrs[inv_corrs < 1.0]
    inv_corr = inv_corrs[np.argmax(inv_corrs)]
    if inv_corr > 0:
        inv_var = [inv_corrs.index[np.argmax(inv_corrs)]]
        if "OOS" in inv_var:
            inv_corr = -inv_corr
        print("Inventory variable for " + outcome_variable + ":", inv_var, inv_corr)
    else:
        inv_var = []
        print(
            "No positively Pearson correlated inventory variable found for "
            + outcome_variable
            + "."
        )
    return inv_var

def find_essential_price_var(df, outcome_variable, outcome_residuals):
    """
    Finds the lowest (i.e., most negative) Pearson correlated price variable to the outcome data
    """
    # outcome_residuals = find_outcome_residuals(df, outcome_variable, essential_vars)
    price_vars = [c for c in df.columns if c.startswith("PRICE") and "O_" not in c and "PRICE"!=c]

    price_corrs = (
        df[price_vars].join(outcome_residuals.rename("resids")).corr().iloc[-1]
    )
    price_corr = price_corrs[np.argmin(price_corrs)]
    if price_corr < 0:
        price_var = [price_corrs.index[np.argmin(price_corrs)]]
        print("Price variable for " + outcome_variable + ":", price_var, price_corr)
    else:
        price_var = []
        print(
            "No negatively Pearson correlated price variable found for "
            + outcome_variable
            + "."
        )
    return price_var
def find_essential_rtl_econ_var(df, outcome_variable, outcome_residuals,retail_kind):
    """
    Finds the highest Pearson correlated rtl_price cut variable to the outcome data.
    """
    if retail_kind == "retail_price_cut":
        prefix = "RTL_PRICE"
    elif retail_kind == "retail_feature":
        prefix = "RTL_FEATURE"
    elif retail_kind == "retail_mod_reset":
        prefix = "RTL_MOD"
    else:
        prefix = "ECO_" # only considers positive correlation

    rtl_vars = [c for c in df.columns if c.startswith(prefix) ]
    rtl_corrs = df[rtl_vars].join(outcome_residuals.rename("resids")).copy()
    rtl_corrs = rtl_corrs.corr().iloc[-1]
    rtl_corrs = rtl_corrs[rtl_corrs < 1.0]
    rtl_corr = rtl_corrs[np.argmax(rtl_corrs)]
    if rtl_corr > 0:
        rtl_var = [rtl_corrs.index[np.argmax(rtl_corrs)]]
        print(f"{retail_kind} variable for " + outcome_variable + ":", rtl_var, rtl_corr)
    else:
        rtl_var = []
        print(
            f"No positively Pearson correlated {retail_kind} variable found for "
            + outcome_variable
            + "."
        )
    return rtl_var
def add_non_dummy_non_media_cols(data, outcome, initial_features, non_dummy_list):
    final_list = initial_features.copy()
    outcome_residuals = find_outcome_residuals(data.copy(), outcome, essential_vars)
    for non_dummy in non_dummy_list:
        if "price"==non_dummy:
            price_var = find_essential_price_var(data.copy(), outcome, outcome_residuals)
            final_list.extend(price_var)
        if "inventory"==non_dummy:
            inv_var = find_essential_inv_var(data.copy(), outcome, outcome_residuals)
            final_list.extend(inv_var)
        if non_dummy in ["retail_price_cut","retail_feature","retail_mod_reset","moodys"]:
            rtl_var = find_essential_rtl_econ_var(data.copy(), outcome, outcome_residuals,non_dummy)
            final_list.extend(rtl_var)
    print(f"Additional non-dummy non-media variables added : {list(set(final_list)-set(initial_features))}")
        
    return list(set(final_list))

def feature_selection(
    data,
    brands_tst,
    outcome_vars,
    essential_non_media,
    exclude_non_media,
    non_dummy_list,
    EDA_check=False,
):
    if not EDA_check:
        print("********* Feature Selection Granger **********", "\n")
    res_lst = []
    outcome = outcome_vars[0]
    for month in range(1, 13):
        column_name = f"Month_{month}"
        data[column_name] = (data["Date"].dt.month == month).astype(int)

    df_processed = data.copy()
    essential_media_dict = {}
    for br in brands_tst:
        # Define maximum lag for Granger test
        maxlag = 4
        dummies = [
            col
            for col in df_processed.columns
            if col.startswith("D_")
            or col.startswith("Month_")
            or col in essential_non_media
        ]
        ref_df = df_processed[df_processed.BRAND == br]
        X = ref_df[dummies]
        if "D_January" in X.columns:
            X.drop(columns=["D_January"], inplace=True)


        res_dict = {}
        for col in X.columns:
            if (
                ref_df[col].nunique() <= 1
            ):  # Skip this column if it has 1 unique value (constant)
                continue
            try:
                test_result = grangercausalitytests(
                    ref_df[[outcome, col]], maxlag=maxlag, verbose=False
                )
                p_values = [
                    round(test_result[i + 1][0]["ssr_ftest"][1], 4)
                    for i in range(maxlag)
                ]
                if (min(p_values) < 0.001 or col in essential_non_media) and (
                    col not in exclude_non_media
                ):  # set significance level
                    res_dict[col] = min(p_values)
            except:
                print(f"grangercausalitytests failed for {col}")
        coef_df = pd.DataFrame(
            list(res_dict.items()), columns=["Feature", "P-Value"]
        )

        coef_df = coef_df.sort_values("P-Value")[
            : X.shape[1]
        ]  # Select top 3 months
        coef_df["Brand"] = [br] * coef_df.shape[0]

        res_lst.append(coef_df)

    report_df = pd.concat(res_lst)
    tp_lst = []
    if not EDA_check:
        print("brands", report_df.Brand.unique(), "\n")
    for br in report_df.Brand.unique():
        df_tp = df_processed[df_processed.BRAND == br]
        X_initial = df_tp[report_df[report_df.Brand == br]["Feature"].values.tolist()]
        y = df_tp[outcome]
        cols = list(X_initial.columns)
        pmax = 1
        while len(cols) > len(essential_non_media):
            p = []
            X_1 = X_initial[cols]
            X_1 = sm.add_constant(X_1)
            model = sm.OLS(y, X_1).fit()
            p = pd.Series(model.pvalues.values[1:], index=cols)
            vif = pd.DataFrame()
            vif["variables"] = X_1.columns[1:]
            vif["VIF"] = [
                variance_inflation_factor(X_1.values, i) for i in range(1, X_1.shape[1])
            ]
            max_vif = max(vif[~vif["variables"].isin(essential_non_media)]["VIF"])
            pmax = max(p)
            feature_with_p_max = p[~(p.index).isin(essential_non_media)].idxmax()
            feature_with_vif_max = vif[
                (~vif["variables"].isin(essential_non_media)) & (vif["VIF"] == max_vif)
            ]["variables"].values[0]

            if (pmax > 0.05 or max_vif > 3 or max_vif == float("inf")) and (
                (feature_with_p_max not in essential_non_media) or (feature_with_vif_max not in essential_non_media)
            ):
                if pmax > 0.05:
                    cols.remove(feature_with_p_max)
                    continue
                if not EDA_check:
                    print(f"check max_vif : {feature_with_vif_max},{max_vif}")
                    print(f"essential_non_media : {essential_non_media}")
                if max_vif > 3 or max_vif == float("inf"):
                    if not EDA_check:
                        print(f"removed max_vif : {feature_with_vif_max},{max_vif}")
                    cols.remove(feature_with_vif_max)
                    print(f"removed max_vif : {feature_with_vif_max},{max_vif}")
            else:
                break
        selected_features_BE = cols
        print(f"Initial shortlisted vars: {selected_features_BE}")
        # possible values for non_dummy_list = ["price","inventory","retail_price_cut","retail_feature","retail_mod_reset","moodys"]
        selected_features_BE = add_non_dummy_non_media_cols(df_tp.copy(), outcome, cols, non_dummy_list)
        print(f"Updated shortlisted vars: {selected_features_BE}")
        X_initial = df_tp[selected_features_BE]
        X = sm.add_constant(X_initial[selected_features_BE])
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(f"******* nonmedia r2: {model.rsquared}", "\n")

        coefficients = model.params[1:]
        positive_coefficients = coefficients
        weekday_dummies = [
                "D_DAY_FRIDAY",
                "D_DAY_MONDAY",
                "D_DAY_TUESDAY",
                "D_DAY_THURSDAY"
            ]
        while ((model.rsquared > 0.85) and (len(weekday_dummies)>0)):
            print(f"Possibility of overfitting. Dropping weekday dummies : {weekday_dummies[0]}")
            selected_features_BE[:] = [item for item in selected_features_BE if item!=weekday_dummies[0]]
            X_initial = df_tp[selected_features_BE]
            X = sm.add_constant(X_initial[selected_features_BE])
            model = sm.OLS(y, X).fit()
            
            print(f"******* nonmedia modified r2: {model.rsquared}", "\n")

            coefficients = model.params[1:]
            positive_coefficients = coefficients
            del weekday_dummies[0]



        vif = pd.DataFrame()
        vif["variables"] = X.columns[1:]
        vif["VIF"] = [
            variance_inflation_factor(X.values, i) for i in range(1, X.shape[1])
        ]

        results_df = pd.DataFrame(
            {
                "Feature": positive_coefficients.index,
                "Coefficient": positive_coefficients.values,
                "p-value": model.pvalues[positive_coefficients.index],
                "VIF": vif.set_index("variables").loc[
                    positive_coefficients.index, "VIF"
                ],
            }
        )
        results_df["Brand"] = [br] * results_df.shape[0]
        tp_lst.append(results_df)
        essential_media_dict[br] = list(set(positive_coefficients.index))

    final_df = pd.concat(tp_lst)
    if not EDA_check:
        display(final_df)

    return essential_media_dict, data

def residual_calculation_y_kj(data, var, exog, train_start,train_end,add_const=True,):
    """
    Returns residuals of var to a regression with exog on the training period
    """
    # fit model only on the training period
    df = data[(data.index >= train_start) & (data.index <= train_end)].copy()
    Y = df[var]
    X = df[exog]
    if add_const:
        X = sm.add_constant(X)
    model = sm.OLS(Y, X, missing="drop")
    model_result = model.fit()
    # Calculate residuals for the entire time period
    y_kj = data[var] - model_result.predict(data[exog])

    return y_kj

def residual_calculation(df, var, exog, add_const=True):
    """
    Returns residuals of var to a regression with exog
    """
    Y = df[var]
    X = df[exog]
    if add_const:
        X = sm.add_constant(X)
    model = sm.OLS(Y, X, missing="drop")
    model_result = model.fit()
    outcome_residuals = model_result.resid
    return outcome_residuals


def model_pred(df_testing, model_result, outcome_variable, essential_vars):
    Y_test = df_testing[outcome_variable]
    X_test = df_testing[essential_vars]
    X_test = sm.add_constant(X_test, has_constant="add")
    Y_pred = model_result.predict(X_test)

    perc_error = abs((model_result.predict(X_test) / Y_test) - 1)
    mape_v1 = perc_error.mean() * 100
    return X_test, Y_test, Y_pred


def update_layout(
    fig,
    title,
    legend_orientation="h",
    height=500,
    width=1000,
    title_x=0.46,
    title_y=0.8,
    legend_x=0.05,
    legend_y=-0.15,
    show_yaxis=True,
    tickformat=",.1f",
    tickangle=30,
    label_fontsize=14,
    legend_fontsize=14,
    title_fontsize=20,
):

    fig.update_layout(
        dict(
            xaxis=dict(
                showgrid=False,
                ticks="outside",
                mirror=False,
                showline=False,
                linecolor="#CED0D2",
                linewidth=1,
                tickangle=tickangle,
            ),
            yaxis=dict(
                showgrid=False,
                mirror=True,
                ticks="",
                showline=False,
                showticklabels=show_yaxis,
                linecolor="black",
                linewidth=1,
                tickformat=tickformat,
                rangemode="tozero",
            ),
            yaxis2=dict(
                overlaying="y",
                side="right",
                tickformat=tickformat,
                showticklabels=show_yaxis,
                tickmode="auto",
                rangemode="tozero",
            ),
            font=dict(size=label_fontsize),
        ),
        autosize=True,
        width=width,
        height=height,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        title={
            "text": title,
            "y": title_y,
            "x": title_x,
            "xanchor": "center",
            "yanchor": "top",
            "font": dict(size=title_fontsize),
        },
        legend_orientation=legend_orientation,
        legend=dict(x=legend_x, y=legend_y, font=dict(size=legend_fontsize)),
    )
    return fig


def plot_fig(df_testing, Y_test, Y_pred):
    data = []
    line1 = go.Scatter(
        x=df_testing.index,
        y=Y_test,
        line=dict(color="#0071CE"),
        name="Modeling Actual",
        yaxis="y1",
    )
    data.append(line1)

    line3 = go.Scatter(
        x=df_testing.index,
        y=Y_pred,
        line=dict(color="#FFC220"),
        name="Modeling Predicted",
        yaxis="y1",
    )
    data.append(line3)

    fig = go.Figure(data)
    fig = update_layout(
        fig,
        title="Actual vs Predicted Modeling Period",
        legend_y=-0.25,
        legend_x=0.25,
        show_yaxis=True,
    )
    fig.show()
def plot_fig_fit(df_testing, Y_test, Y_pred):
    data = []
    line1 = go.Scatter(
        x=df_testing['Date'],
        y=Y_test,
        line=dict(color="#0071CE"),
        name="Modeling Actual",
        yaxis="y1",
    )
    data.append(line1)

    line3 = go.Scatter(
        x=df_testing['Date'],
        y=Y_pred,
        line=dict(color="#FFC220"),
        name="Modeling Predicted",
        yaxis="y1",
    )
    data.append(line3)

    fig = go.Figure(data)
    fig = update_layout(
        fig,
        title="Actual vs Predicted Modeling Period",
        legend_y=-0.25,
        legend_x=0.25,
        show_yaxis=True,
    )
    fig.show()

def get_test_fit(
    df_testing,
    model_result,
    outcome_variable,
    essential_vars,
    nm_set=None,
    train_loop=True,
    EDA_check=False,
):

    X_test, Y_test, Y_pred = model_pred(
        df_testing, model_result, outcome_variable, essential_vars
    )
    r2 = r2_score(Y_test, Y_pred)
    mape_val = mape(Y_test, Y_pred) * 100
    if not EDA_check:
        print("r2:", r2)
        print("MAPE:", mape_val)

    if train_loop:
        non_media_fit.setdefault(nm_set, {}).update({"train": [r2, mape_val]})
    else:
        non_media_fit.setdefault(nm_set, {}).update({"test": [r2, mape_val]})
    if not EDA_check:
        plot_fig(df_testing, Y_test, Y_pred)


def generate_trend_seasonality_arima(
    data, essential_non_media, outcome="O_UNIT", EDA_check=False
):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["BRAND"].unique():
        if not EDA_check:
            print(f"**** BRAND: {brand} Set 6 sarimax ****")
        brand_level_df = brand_stack[brand_stack["BRAND"] == brand][
            [outcome] + essential_non_media
        ]
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        test_brand_df = brand_level_df.copy()
        seas_obj_cust = VariableSeasonality(
            test_brand_df.copy(), key_variable=outcome, exog=essential_non_media
        )
        seas_obj_cust.arma_arima_func(start_p=1, start_q=1, day_start=5, day_end=8)
        # additional_period_start_date is optional parameter. for this period, ETS terms would be created separately
        seas_obj_cust.creating_var_func()

        test_brand_df = seas_obj_cust.df.copy()
        seasonality_terms_units = []
        regex_seasonality_units = [
            "_" + i + "$" for i in seasonality_terms_units if "SARIMAX" not in i
        ] + ["_" + i + " \(" for i in seasonality_terms_units if "SARIMAX" in i]

        regex_seasonality_units = "|".join(regex_seasonality_units)

        seasonality_vars_units = [
            c
            for c in test_brand_df.columns
            if outcome in c and re.search(regex_seasonality_units, c) is not None
        ]
        test_brand_df["sarimax"] = test_brand_df[
            [var for var in seasonality_vars_units if var.startswith(outcome+"_SARIMAX ")]
        ]
        test_brand_df["sarimax_log"] = test_brand_df[
            [
                var
                for var in seasonality_vars_units
                if var.startswith(outcome+"_SARIMAX_LOG")
            ]
        ]

        test_brand_df.fillna(value=0, inplace=True)
        y = test_brand_df[outcome]

        ### Set 1
        X = test_brand_df[essential_non_media + ["sarimax"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(
                f"****** sarimax with variable {outcome}_SARIMAX: R_sq: {model.rsquared}",
                " ******\n",
            )
        ### Set 2
        X = test_brand_df[essential_non_media + ["sarimax_log"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(
                f"****** sarimax with variable {outcome}_SARIMAX_LOG: R_sq: {model.rsquared}",
                " ******\n",
            )
        ### Set 3
        X = test_brand_df[
            essential_non_media
            + [str(outcome) + "_TREND", str(outcome) + "_SEASONALITY"]
        ]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(
                f"****** sarimax with variable trend and seasonality: R_sq: {model.rsquared}",
                " ******\n",
            )
        ### Set 4
        X = test_brand_df[
            essential_non_media
            + [str(outcome) + "_TREND_LOG", str(outcome) + "_SEASONALITY_LOG"]
        ]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(
                f"****** sarimax with variable trend log and seasonality log: R_sq: {model.rsquared}",
                " ******\n",
            )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["SARIMAX"] = test_brand_df["sarimax"].copy()
        seasonality_dict[brand]["SARIMAX_LOG"] = test_brand_df["sarimax_log"].copy()
        seasonality_dict[brand][str(outcome) + "_TREND"] = test_brand_df[
            str(outcome) + "_TREND"
        ].copy()
        seasonality_dict[brand][str(outcome) + "_SEASONALITY"] = test_brand_df[
            str(outcome) + "_SEASONALITY"
        ].copy()
        seasonality_dict[brand][str(outcome) + "_TREND_LOG"] = test_brand_df[
            str(outcome) + "_TREND_LOG"
        ].copy()
        seasonality_dict[brand][str(outcome) + "_SEASONALITY_LOG"] = test_brand_df[
            str(outcome) + "_SEASONALITY_LOG"
        ].copy()

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["BRAND"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("BRAND", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop(f"{outcome}.1", axis=1, inplace=True)
    except:
        pass
    data.fillna(value=0, inplace=True)
    return data


def generate_trend_seasonality(
    data, essential_non_media, outcome="O_UNIT", EDA_check=False
):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["BRAND"].unique():
        if not EDA_check:
            print(f"**** BRAND: {brand} Set 0 moving average 7 ****")
        brand_level_df = brand_stack[brand_stack["BRAND"] == brand][
            [outcome] + essential_non_media
        ]
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        test_brand_df = brand_level_df.copy()
        trend_val = outcome_residuals.rolling(window=7, center=True).mean()
        test_brand_df["trend_val"] = trend_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        detrend = outcome_residuals - test_brand_df["trend_val"].astype(float)
        test_brand_df["detrend"] = detrend.copy()
        test_brand_df["month"] = test_brand_df.index.month
        seasonal_val = test_brand_df.groupby("month")["detrend"].transform("mean")
        test_brand_df["seasonal_val"] = seasonal_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(
                "\n****** trend and seasonality: MV 7; R_sq: ",
                model.rsquared,
                " ******\n",
            )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_1"] = trend_val.copy()
        seasonality_dict[brand]["MV_seasonality_1"] = seasonal_val.copy()

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["BRAND"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("BRAND", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop(f"{outcome}.1", axis=1, inplace=True)
    except:
        pass
    data.fillna(value=0, inplace=True)
    return data


def generate_trend_seasonality_hw(
    data, essential_non_media, outcome="O_UNIT", EDA_check=False
):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["BRAND"].unique():
        if not EDA_check:
            print(f"**** BRAND: {brand} Set 1 moving average 15 ****")
        brand_level_df = brand_stack[brand_stack["BRAND"] == brand][
            [outcome] + essential_non_media
        ]
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        test_brand_df = brand_level_df.copy()
        trend_val = outcome_residuals.rolling(window=15, center=True).mean()
        test_brand_df["trend_val"] = trend_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        detrend = outcome_residuals - test_brand_df["trend_val"].astype(float)
        test_brand_df["detrend"] = detrend.copy()
        test_brand_df["month"] = test_brand_df.index.month
        seasonal_val = test_brand_df.groupby("month")["detrend"].transform("mean")
        test_brand_df["seasonal_val"] = seasonal_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(
                "\n****** trend and seasonality: MV 15; R_sq: ",
                model.rsquared,
                " ******\n",
            )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_2"] = trend_val.copy()
        seasonality_dict[brand]["MV_seasonality_2"] = seasonal_val.copy()

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["BRAND"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("BRAND", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop(f"{outcome}.1", axis=1, inplace=True)
    except:
        pass
    data.fillna(value=0, inplace=True)
    return data


def generate_trend_seasonality_stl(
    data, essential_non_media, outcome="O_UNIT", EDA_check=False
):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["BRAND"].unique():
        if not EDA_check:
            print(f"**** BRAND: {brand} Set 2 moving average 30 ****")
        brand_level_df = brand_stack[brand_stack["BRAND"] == brand][
            [outcome] + essential_non_media
        ]
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        test_brand_df = brand_level_df.copy()
        trend_val = outcome_residuals.rolling(window=30, center=True).mean()
        test_brand_df["trend_val"] = trend_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        detrend = outcome_residuals - test_brand_df["trend_val"].astype(float)
        test_brand_df["detrend"] = detrend.copy()
        test_brand_df["month"] = test_brand_df.index.month
        seasonal_val = test_brand_df.groupby("month")["detrend"].transform("mean")
        test_brand_df["seasonal_val"] = seasonal_val.copy()
        test_brand_df.fillna(value=0, inplace=True)
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(
                "\n****** trend and seasonality: MV 30; R_sq: ",
                model.rsquared,
                " ******\n",
            )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_3"] = trend_val.copy()
        seasonality_dict[brand]["MV_seasonality_3"] = seasonal_val.copy()

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["BRAND"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("BRAND", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop(f"{outcome}.1", axis=1, inplace=True)
    except:
        pass
    data.fillna(value=0, inplace=True)
    return data


def generate_trend_seasonality_v1(
    data, essential_non_media, outcome="O_UNIT", EDA_check=False
):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)
    essential_non_media_wk = list(set(essential_non_media) - set(weekend_vars))
    seasonality_dict = {}
    for brand in brand_stack["BRAND"].unique():
        if not EDA_check:
            print(f"**** BRAND: {brand} Set 3 seasonal decompose period 52 ****")
        brand_level_df = brand_stack[brand_stack["BRAND"] == brand][
            [outcome] + essential_non_media_wk
        ]
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media_wk
        )
        result_additive = seasonal_decompose(
            x=outcome_residuals.copy(),
            extrapolate_trend="freq",
            model="additive",
            period=52,
        )

        test_brand_df = brand_level_df.copy()
        test_brand_df["trend_val"] = result_additive.trend.copy()
        test_brand_df["seasonal_val"] = result_additive.seasonal.copy()
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(
                "\n****** trend and seasonality: seasonal decompose period 52; R_sq: ",
                model.rsquared,
                " ******\n",
            )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_4"] = result_additive.trend
        seasonality_dict[brand]["MV_seasonality_4"] = result_additive.seasonal

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["BRAND"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("BRAND", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop(f"{outcome}.1", axis=1, inplace=True)
    except:
        pass
    return data


def generate_trend_seasonality_hw_v1(
    data, essential_non_media, outcome="O_UNIT", EDA_check=False
):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["BRAND"].unique():
        if not EDA_check:
            print(f"**** BRAND: {brand} Set 4 seasonal decompose period 12 ****")
        brand_level_df = brand_stack[brand_stack["BRAND"] == brand][
            [outcome] + essential_non_media
        ]
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        n = 7
        filter = np.ones(n) / n
        result_additive = seasonal_decompose(
            x=outcome_residuals.copy(),
            extrapolate_trend="freq",
            model="additive",
            period=12,
        )

        test_brand_df = brand_level_df.copy()
        test_brand_df["trend_val"] = result_additive.trend.copy()
        test_brand_df["seasonal_val"] = result_additive.seasonal.copy()
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(
                "\n****** trend and seasonality: seasonal decompose period 12; R_sq: ",
                model.rsquared,
                " ******\n",
            )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_5"] = result_additive.trend
        seasonality_dict[brand]["MV_seasonality_5"] = result_additive.seasonal

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["BRAND"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("BRAND", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop(f"{outcome}.1", axis=1, inplace=True)
    except:
        pass
    return data


def generate_trend_seasonality_stl_v1(
    data, essential_non_media, outcome="O_UNIT", EDA_check=False
):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["BRAND"].unique():
        if not EDA_check:
            print(f"**** BRAND: {brand} Set 5 seasonal decompose period 4 ****")
        brand_level_df = brand_stack[brand_stack["BRAND"] == brand][
            [outcome] + essential_non_media
        ]
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        outcome_residuals = residual_calculation(
            brand_level_df, outcome, essential_non_media
        )
        n = 7
        filter = np.ones(n) / n
        result_additive = seasonal_decompose(
            x=outcome_residuals.copy(),
            extrapolate_trend="freq",
            model="additive",
            period=4,
        )

        test_brand_df = brand_level_df.copy()
        test_brand_df["trend_val"] = result_additive.trend.copy()
        test_brand_df["seasonal_val"] = result_additive.seasonal.copy()
        y = test_brand_df[outcome]
        X = test_brand_df[essential_non_media + ["trend_val", "seasonal_val"]]
        X = sm.add_constant(X)
        model = sm.OLS(y, X).fit()
        if not EDA_check:
            print(
                "\n****** trend and seasonality: seasonal decompose period 4; R_sq: ",
                model.rsquared,
                " ******\n",
            )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["MV_trend_6"] = result_additive.trend
        seasonality_dict[brand]["MV_seasonality_6"] = result_additive.seasonal

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["BRAND"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("BRAND", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop(f"{outcome}.1", axis=1, inplace=True)
    except:
        pass
    return data


def OLS_func(
    data,
    indep_var,
    outcome,
    brand=None,
    train_start=None,
    train_end=None,
    valid_start=None,
):
    train_data = data[(data.index >= train_start) & (data.index <= train_end)].copy()
    test_data = data[(data.index >= valid_start)].copy()

    Y = train_data[train_data["BRAND"] == brand][outcome]
    X = train_data[train_data["BRAND"] == brand][indep_var]
    X = sm.add_constant(X)
    model = sm.OLS(Y, X, missing="drop")
    model_result = model.fit()
    return model_result, train_data, test_data


def vif_essential(df_X):
    """
    Finds VIF of the regressors of outcome_variable~essential_vars
    """

    # Calculate the VIF for each feature of df_X (a Pandas DataFrame).
    vif_data = [variance_inflation_factor(df_X.values, i) for i in range(df_X.shape[1])]
    return pd.Series(vif_data, index=df_X.columns)


# OLS_func(data, indep_var, outcome, brand=None, train_start=None, train_end=None, valid_start=None):


#### eliminating variables with high p-value and vif
def upd_shortlist_variables(
    data,
    essential_vars,
    shortlist_vars,
    brand,
    outcome_var,
    r_sq_adj,
    target_rsq,
    p_val_thresh=0.05,
    vif_thresh=1.1,
    train_start=None,
    train_end=None,
    valid_start=None,
    nm_set=None,
    EDA_check=False,
):
    forward = True
    # curr_rsq = target_rsq

    # while forward:
    #     flag = True
    inp_var = shortlist_vars.copy()
    model_result, train_data, test_data = OLS_func(
        data.copy(),
        inp_var,
        outcome_var,
        brand=brand,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_start,
    )

    curr_rsq = model_result.rsquared_adj

    vif_val = vif_essential(data[data["BRAND"] == brand][inp_var]).to_dict()

    for media, vif in vif_val.items():

        if (
            float(vif_val[media]) >= vif_thresh or math.isnan(vif_val[media])
        ) and curr_rsq > target_rsq:
            shortlist_vars.remove(media)
            inp_var_upd = essential_vars + shortlist_vars
            model_result, train_data, test_data = OLS_func(
                data.copy(),
                inp_var_upd.copy(),
                outcome_var,
                brand=brand,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
            )
            upd_rsq = model_result.rsquared
            if model_result.rsquared < target_rsq:
                shortlist_vars.append(media)
                upd_rsq = curr_rsq
                # forward = False
                # break
            curr_rsq = upd_rsq
        if math.isnan(vif_val[media]) or vif_val[media] == math.inf:
            try:
                shortlist_vars.remove(media)
            except:
                continue

        # flag = True
        # if flag:
        #     forward = False

    final_shortlist = shortlist_vars
    model_result, train_data, test_data = OLS_func(
        data.copy(),
        final_shortlist.copy(),
        outcome_var,
        brand=brand,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_start,
    )

    if not EDA_check:
        print("\n**********TRAIN FIT************")
    get_test_fit(
        train_data,
        model_result,
        outcome_var,
        final_shortlist.copy(),
        nm_set=nm_set,
        train_loop=True,
        EDA_check=EDA_check,
    )

    if not EDA_check:
        print("\n**********TEST FIT************")
    get_test_fit(
        test_data,
        model_result,
        outcome_var,
        final_shortlist.copy(),
        nm_set=nm_set,
        train_loop=False,
        EDA_check=EDA_check,
    )

    brand_r_sq_adj = model_result.rsquared
    return final_shortlist, brand_r_sq_adj


def find_minimum_features(
    data,
    essential_vars,
    shortlist_vars,
    brand,
    outcome_var,
    vif_thresh=1.1,
    train_start=None,
    train_end=None,
    valid_start=None,
    target_r2=0.75,
):
    best_r2 = 0
    selected_features = shortlist_vars.copy()
    potential_features = essential_vars.copy()
    inp_var = essential_vars + shortlist_vars

    # selected_features = list(set(selected_features) - set(essential_vars))
    model_result, train_data, test_data = OLS_func(
        data.copy(),
        selected_features + essential_vars,
        outcome_var,
        brand=brand,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_start,
    )
    return selected_features, best_r2


def get_non_media_coefs(
    brand_list,
    updated_stack,
    non_media_set,
    non_media_z_k,
    outcome="O_UNIT",
    train_start=None,
    train_end=None,
    valid_start=None,
):
    brand_non_media_coef = {}
    for brand in brand_list:
        brand_non_media_coef[brand] = []
        for i in non_media_set:
            model_result, train_data, test_data = OLS_func(
                updated_stack,
                non_media_z_k[brand][i],
                outcome=outcome,
                brand=brand,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
            )
            non_media_coefs = dict(model_result.params)
            brand_non_media_coef[brand].append(non_media_coefs)
    return brand_non_media_coef


def get_non_media_matrix(
    data,
    dummy_var_lst,
    essential_non_media,
    brand_list,
    outcome_vars,
    non_media_set,
    train_start,
    train_end,
    valid_start,
    valid_end,
    target_r2=0.8,
    EDA_check=False,
):

    essential_vars_og = sorted(list(set(dummy_var_lst[1:]) - set(essential_non_media)))
    seasonality_cols = ["MV_trend_1", "MV_seasonality_1"]
    seasonality_cols_hw = ["MV_trend_2", "MV_seasonality_2"]
    seasonality_cols_stl = ["MV_trend_3", "MV_seasonality_3"]
    seasonality_cols_v1 = ["MV_trend_4", "MV_seasonality_4"]
    seasonality_cols_hw_v1 = ["MV_trend_5", "MV_seasonality_5"]
    seasonality_cols_stl_v1 = ["MV_trend_6", "MV_seasonality_6"]
    seasonality_cols_sarimax = ["SARIMAX"]
    seasonality_cols_sarimax_log = ["SARIMAX_LOG"]
    seasonality_cols_out_trnd_seasn = [
        str(outcome_vars[0]) + "_TREND",
        str(outcome_vars[0]) + "_SEASONALITY",
    ]
    seasonality_cols_out_trnd_seasn_log = [
        str(outcome_vars[0]) + "_TREND_LOG",
        str(outcome_vars[0]) + "_SEASONALITY_LOG",
    ]

    # essential_vars_sd = essential_non_media + seasonality_cols
    essential_vars_sd = (
        list(set(essential_non_media) - set(weekend_vars)) + seasonality_cols
    )  ## Ignore weekends for weekly
    essential_vars_hw = essential_non_media + seasonality_cols_hw
    essential_vars_stl = essential_non_media + seasonality_cols_stl

    essential_vars_sd_v1 = (
        list(set(essential_non_media) - set(weekend_vars)) + seasonality_cols_v1
    )  ## Ignore weekends for weekly
    essential_vars_hw_v1 = essential_non_media + seasonality_cols_hw_v1
    essential_vars_stl_v1 = essential_non_media + seasonality_cols_stl_v1
    essential_vars_sarimax = essential_non_media + seasonality_cols_sarimax
    essential_vars_sarimax_log = essential_non_media + seasonality_cols_sarimax_log
    essential_vars_out_trnd_seasn = (
        essential_non_media + seasonality_cols_out_trnd_seasn
    )
    essential_vars_out_trnd_seasn_log = (
        essential_non_media + seasonality_cols_out_trnd_seasn_log
    )
    # updated_shortlist_hw, r_sq_adj_hw, updated_shortlist_ar, r_sq_adj_ar, updated_shortlist_sd, r_sq_adj_sd = {}, {}, {}, {}, {}, {}
    (
        updated_shortlist_hw,
        r_sq_adj_hw,
        updated_shortlist_stl,
        r_sq_adj_stl,
        updated_shortlist_sd,
        r_sq_adj_sd,
        updated_shortlist_hw_v1,
        r_sq_adj_hw_v1,
        updated_shortlist_stl_v1,
        r_sq_adj_stl_v1,
        updated_shortlist_sd_v1,
        r_sq_adj_sd_v1,
        updated_shortlist_sarimax,
        r_sq_adj_sarimax,
        updated_shortlist_sarimax_log,
        r_sq_adj_sarimax_log,
        updated_shortlist_out_trnd_seasn,
        r_sq_adj_out_trnd_seasn,
        updated_shortlist_out_trnd_seasn_log,
        r_sq_adj_out_trnd_seasn_log,
    ) = ({}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {})
    if not EDA_check:
        print(
            "*********** Performing seasonality analysis to get non media variables ***********"
        )
    for outcome in outcome_vars:
        seasonal_stack = generate_trend_seasonality(
            data.copy(), essential_non_media, outcome, EDA_check
        )
        seasonal_stack_hw = generate_trend_seasonality_hw(
            data.copy(), essential_non_media, outcome, EDA_check
        )
        seasonal_stack_stl = generate_trend_seasonality_stl(
            data.copy(), essential_non_media, outcome, EDA_check
        )

        seasonal_stack_v1 = generate_trend_seasonality_v1(
            data.copy(), essential_non_media, outcome, EDA_check
        )
        seasonal_stack_hw_v1 = generate_trend_seasonality_hw_v1(
            data.copy(), essential_non_media, outcome, EDA_check
        )
        seasonal_stack_stl_v1 = generate_trend_seasonality_stl_v1(
            data.copy(), essential_non_media, outcome, EDA_check
        )
        seasonal_stack_sarimax = generate_trend_seasonality_arima(
            data.copy(), essential_non_media, outcome, EDA_check
        )
    if not EDA_check:
        print(
            "*********** Performing backward elimination to only retain essential variables ***********\n"
        )
    outcome = outcome_vars[0]
    for brand in brand_list:
        updated_shortlist, r_sq_adj = essential_vars_sd.copy(),0
        updated_shortlist_sd[brand], r_sq_adj_sd[brand] = upd_shortlist_variables(
            seasonal_stack.copy(),
            essential_vars_sd.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            nm_set=0,
            EDA_check=EDA_check,
        )
        if not EDA_check:
            print(
                f"********* R_Sq_Adj Set 0 (trend+seasonality, using MV period: 7 or period 52) brand {brand} *********",
                r_sq_adj_sd[brand],
                "\n",
            )

        updated_shortlist, r_sq_adj = essential_vars_sd_v1.copy(),0
        updated_shortlist_sd_v1[brand], r_sq_adj_sd_v1[brand] = upd_shortlist_variables(
            seasonal_stack_v1.copy(),
            essential_vars_sd_v1.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            nm_set=1,
            EDA_check=EDA_check,
        )
        if not EDA_check:
            print(
                f"********* R_Sq_Adj Set 1 (trend+seasonality, using seasonal decompose period 52) brand {brand} *********",
                r_sq_adj_sd_v1[brand],
                "\n",
            )

        updated_shortlist, r_sq_adj = essential_vars_hw.copy(),0
        updated_shortlist_hw[brand], r_sq_adj_hw[brand] = upd_shortlist_variables(
            seasonal_stack_hw.copy(),
            essential_vars_hw.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            nm_set=2,
            EDA_check=EDA_check,
        )
        if not EDA_check:
            print(
                f"********* R_Sq_Adj Set 2 (trend+seasonality using MV period:15 or period 12) brand {brand} *********",
                r_sq_adj_hw[brand],
                "\n",
            )

        updated_shortlist, r_sq_adj = essential_vars_hw_v1.copy(),0
        updated_shortlist_hw_v1[brand], r_sq_adj_hw_v1[brand] = upd_shortlist_variables(
            seasonal_stack_hw_v1.copy(),
            essential_vars_hw_v1.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            nm_set=3,
            EDA_check=EDA_check,
        )
        if not EDA_check:
            print(
                f"********* R_Sq_Adj Set 3 (trend+seasonality using seasonal decompose period 12) brand {brand} *********",
                r_sq_adj_hw_v1[brand],
                "\n",
            )

        updated_shortlist, r_sq_adj = essential_vars_stl.copy(),0
        updated_shortlist_stl[brand], r_sq_adj_stl[brand] = upd_shortlist_variables(
            seasonal_stack_stl.copy(),
            essential_vars_stl.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            nm_set=4,
            EDA_check=EDA_check,
        )
        if not EDA_check:
            print(
                f"********* R_Sq_Adj Set 4 (trend+seasonality using MV period 30 or period 4) brand {brand} *********",
                r_sq_adj_stl[brand],
                "\n",
            )

        updated_shortlist, r_sq_adj = essential_vars_stl_v1.copy(),0
        updated_shortlist_stl_v1[brand], r_sq_adj_stl_v1[brand] = (
            upd_shortlist_variables(
                seasonal_stack_stl_v1.copy(),
                essential_vars_stl_v1.copy(),
                updated_shortlist.copy(),
                brand,
                outcome,
                r_sq_adj,
                target_r2,
                p_val_thresh=0.05,
                vif_thresh=3.5,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
                nm_set=5,
                EDA_check=EDA_check,
            )
        )
        if not EDA_check:
            print(
                f"********* R_Sq_Adj Set 5 (trend+seasonality using seasonal decompose period 4) brand {brand} *********",
                r_sq_adj_stl_v1[brand],
                "\n",
            )

        updated_shortlist, r_sq_adj = essential_vars_sarimax.copy(),0
        updated_shortlist_sarimax[brand], r_sq_adj_sarimax[brand] = (
            upd_shortlist_variables(
                seasonal_stack_sarimax.copy(),
                essential_vars_sarimax.copy(),
                updated_shortlist.copy(),
                brand,
                outcome,
                r_sq_adj,
                target_r2,
                p_val_thresh=0.05,
                vif_thresh=3.5,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
                nm_set=6,
                EDA_check=EDA_check,
            )
        )
        if not EDA_check:
            print(
                f"********* R_Sq_Adj Set 6 (sarimax) brand {brand} *********",
                r_sq_adj_sarimax[brand],
                "\n",
            )

        updated_shortlist, r_sq_adj = essential_vars_sarimax_log.copy(),0
        updated_shortlist_sarimax_log[brand], r_sq_adj_sarimax_log[brand] = (
            upd_shortlist_variables(
                seasonal_stack_sarimax.copy(),
                essential_vars_sarimax_log.copy(),
                updated_shortlist.copy(),
                brand,
                outcome,
                r_sq_adj,
                target_r2,
                p_val_thresh=0.05,
                vif_thresh=3.5,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
                nm_set=7,
                EDA_check=EDA_check,
            )
        )
        if not EDA_check:
            print(
                f"********* R_Sq_Adj Set 7 (sarimax log) brand {brand} *********",
                r_sq_adj_sarimax_log[brand],
                "\n",
            )

        updated_shortlist, r_sq_adj = essential_vars_out_trnd_seasn.copy(),0
        updated_shortlist_out_trnd_seasn[brand], r_sq_adj_out_trnd_seasn[brand] = (
            upd_shortlist_variables(
                seasonal_stack_sarimax.copy(),
                essential_vars_out_trnd_seasn.copy(),
                updated_shortlist.copy(),
                brand,
                outcome,
                r_sq_adj,
                target_r2,
                p_val_thresh=0.05,
                vif_thresh=3.5,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
                nm_set=8,
                EDA_check=EDA_check,
            )
        )
        if not EDA_check:
            print(
                f"********* R_Sq_Adj Set 8 (sarimax trend, seasonality) brand {brand} *********",
                r_sq_adj_out_trnd_seasn[brand],
                "\n",
            )

        updated_shortlist, r_sq_adj = essential_vars_out_trnd_seasn_log.copy(),0
        (
            updated_shortlist_out_trnd_seasn_log[brand],
            r_sq_adj_out_trnd_seasn_log[brand],
        ) = upd_shortlist_variables(
            seasonal_stack_sarimax.copy(),
            essential_vars_out_trnd_seasn_log.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=3.5,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            nm_set=9,
            EDA_check=EDA_check,
        )
        if not EDA_check:
            print(
                f"********* R_Sq_Adj Set 9 (sarimax trend log, seasonality log) brand {brand} *********",
                r_sq_adj_out_trnd_seasn_log[brand],
                "\n",
            )
        if EDA_check:
            return non_media_fit

    print("*********** Creating processed non media matrix ***********")
    combined_data = seasonal_stack.merge(
        seasonal_stack_hw[["BRAND", "MV_trend_2", "MV_seasonality_2"]],
        on=["Date", "BRAND"],
        how="left",
    )
    combined_data = combined_data.merge(
        seasonal_stack_stl[["BRAND", "MV_trend_3", "MV_seasonality_3"]],
        on=["Date", "BRAND"],
        how="left",
    )
    combined_data = combined_data.merge(
        seasonal_stack_v1[["BRAND", "MV_trend_4", "MV_seasonality_4"]],
        on=["Date", "BRAND"],
        how="left",
    )
    combined_data = combined_data.merge(
        seasonal_stack_hw_v1[["BRAND", "MV_trend_5", "MV_seasonality_5"]],
        on=["Date", "BRAND"],
        how="left",
    )
    combined_data = combined_data.merge(
        seasonal_stack_stl_v1[["BRAND", "MV_trend_6", "MV_seasonality_6"]],
        on=["Date", "BRAND"],
        how="left",
    )
    combined_data = combined_data.merge(
        seasonal_stack_sarimax[
            [
                "BRAND",
                "SARIMAX",
                "SARIMAX_LOG",
                str(outcome) + "_TREND",
                str(outcome) + "_SEASONALITY",
                str(outcome) + "_TREND_LOG",
                str(outcome) + "_SEASONALITY_LOG",
            ]
        ],
        on=["Date", "BRAND"],
        how="left",
    )

    """
    combined_data = seasonal_stack.merge(
        seasonal_stack_hw.merge(
            seasonal_stack_stl[["BRAND", "MV_trend_3", "MV_seasonality_3"]],
            on=["Date", "BRAND"],
            how="left",
        )[
            [
                "BRAND",
                "MV_trend_3",
                "MV_seasonality_3",
                "MV_trend_2",
                "MV_seasonality_2",
            ]
        ],
        on=["Date", "BRAND"],
        how="left",
    )
    """

    combined_data["INTERCEPT"] = 1

    non_media_z_k = {}
    for key, value in updated_shortlist_hw.items():
        # non_media_z_k[key] = [updated_shortlist_hw[key]+['INTERCEPT'], updated_shortlist_ar[key]+['INTERCEPT'], updated_shortlist_sd[key]+['INTERCEPT']]
        non_media_z_k[key] = [
            updated_shortlist_sd[key] + ["INTERCEPT"],
            updated_shortlist_hw[key] + ["INTERCEPT"],
            updated_shortlist_stl[key] + ["INTERCEPT"],
            updated_shortlist_sd_v1[key] + ["INTERCEPT"],
            updated_shortlist_hw_v1[key] + ["INTERCEPT"],
            updated_shortlist_stl_v1[key] + ["INTERCEPT"],
            updated_shortlist_sarimax[key] + ["INTERCEPT"],
            updated_shortlist_sarimax_log[key] + ["INTERCEPT"],
            updated_shortlist_out_trnd_seasn[key] + ["INTERCEPT"],
            updated_shortlist_out_trnd_seasn_log[key] + ["INTERCEPT"],
        ]

    num_non_media = len(non_media_z_k[brand_list[0]])

    pre_processed_matrix_U_kj, pre_processed_matrix_Y_kj = [], []
    for idx in range(len(brand_list)):
        matrix_U_kj, matrix_Y_kj = [], []
        for j in non_media_set:
            Z_k_j = combined_data[combined_data["BRAND"] == brand_list[idx]][
                non_media_z_k[brand_list[idx]][j]
            ].to_numpy()
            Z_k_j_transpose = Z_k_j.transpose()
            try:
                Z_k_j_inv = inv(Z_k_j_transpose.dot(Z_k_j))
            except:
                Z_k_j_inv = pinv(Z_k_j_transpose.dot(Z_k_j))

            P_k_j = np.dot(Z_k_j, np.dot(Z_k_j_inv, Z_k_j_transpose))
            # Z_k_j.dot(Z_k_j_inv.dot(Z_k_j_transpose))

            I = np.identity(P_k_j.shape[0])
            U_k_j = I - P_k_j

            Y_k = combined_data[
                combined_data["BRAND"] == brand_list[idx]
            ]  # .to_numpy()

            Y_k_j = np.asarray(
                residual_calculation_y_kj(
                    Y_k.copy(),
                    outcome,
                    non_media_z_k[brand_list[idx]][j],
                    train_start,
                    train_end,
                    add_const=False,
                )
            )
            matrix_U_kj.append(U_k_j)
            matrix_Y_kj.append(Y_k_j)
        pre_processed_matrix_U_kj.append(np.asarray(matrix_U_kj))
        pre_processed_matrix_Y_kj.append(np.asarray(matrix_Y_kj))

    #### fetch non media coefficients
    non_media_coef = get_non_media_coefs(
        brand_list,
        combined_data,
        non_media_set,
        non_media_z_k,
        outcome=outcome,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_end,
    )
    print("**************** selected non media ****************")
    for idx in range(len(brand_list)):
        print("brand: ", brand_list[idx])
        for j in non_media_set:
            print("\n set: ", j)
            print(non_media_z_k[brand_list[idx]][j])

    return (
        np.asarray(pre_processed_matrix_U_kj),
        np.asarray(pre_processed_matrix_Y_kj),
        combined_data,
        non_media_z_k,
        non_media_coef,
        non_media_fit,
    )
