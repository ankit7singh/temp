#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# author: Mayukh Maitra
"""
Created on Sun Feb  4 00:24:43 2024

@author: m0m0tc7
"""
import math

# Computation of Spearman correlation clusters
import matplotlib.pyplot as plt
import numpy as np
# Dataframe and array manipulation
import pandas as pd
import plotly.graph_objects as go
# Linear regression
import statsmodels.api as sm
from hierarchicalforecast.utils import aggregate
from numpy.linalg import inv, pinv
from sklearn.metrics import mean_absolute_percentage_error as mape
from sklearn.metrics import r2_score
from statsforecast import StatsForecast
from statsforecast.models import AutoARIMA, HoltWinters
from statsmodels.tsa.holtwinters import ExponentialSmoothing as es
from statsmodels.tsa.seasonal import STL, seasonal_decompose
from statsmodels.tsa.statespace.sarimax import SARIMAX as smx

plt.rcParams["figure.dpi"] = 300
plt.rcParams["figure.figsize"] = (20, 20)


import warnings

warnings.filterwarnings("ignore")

spec = [["L3_CATEGORY_NAME"], ["L3_CATEGORY_NAME", "BRAND"]]

forecasting_method = ["HoltWinters", "AutoARIMA"]

def residual_calculation(df,var,exog):
    """
    Returns residuals of var to a regression with exog
    """
    Y = df[var]
    X = df[exog]
    X = sm.add_constant(X)
    model = sm.OLS(Y, X, missing='drop')
    model_result = model.fit()
    outcome_residuals=model_result.resid
    return outcome_residuals


def model_pred(df_testing, model_result, outcome_variable, essential_vars):
    Y_test = df_testing[outcome_variable]
    X_test = df_testing[essential_vars]
    X_test = sm.add_constant(X_test, has_constant="add")
    Y_pred = model_result.predict(X_test)

    perc_error = abs((model_result.predict(X_test) / Y_test) - 1)
    mape_v1 = perc_error.mean() * 100
    return X_test, Y_test, Y_pred


def update_layout(
    fig,
    title,
    legend_orientation="h",
    height=500,
    width=1000,
    title_x=0.46,
    title_y=0.8,
    legend_x=0.05,
    legend_y=-0.15,
    show_yaxis=True,
    tickformat=",.1f",
    tickangle=30,
    label_fontsize=14,
    legend_fontsize=14,
    title_fontsize=20,
):

    fig.update_layout(
        dict(
            xaxis=dict(
                showgrid=False,
                ticks="outside",
                mirror=False,
                showline=False,
                linecolor="#CED0D2",
                linewidth=1,
                tickangle=tickangle,
            ),
            yaxis=dict(
                showgrid=False,
                mirror=True,
                ticks="",
                showline=False,
                showticklabels=show_yaxis,
                linecolor="black",
                linewidth=1,
                tickformat=tickformat,
                rangemode="tozero",
            ),
            yaxis2=dict(
                overlaying="y",
                side="right",
                tickformat=tickformat,
                showticklabels=show_yaxis,
                tickmode="auto",
                rangemode="tozero",
            ),
            font=dict(size=label_fontsize),
        ),
        autosize=True,
        width=width,
        height=height,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        title={
            "text": title,
            "y": title_y,
            "x": title_x,
            "xanchor": "center",
            "yanchor": "top",
            "font": dict(size=title_fontsize),
        },
        legend_orientation=legend_orientation,
        legend=dict(x=legend_x, y=legend_y, font=dict(size=legend_fontsize)),
    )
    return fig


def plot_fig(df_testing, Y_test, Y_pred):
    data = []
    line1 = go.Scatter(
        x=df_testing.index,
        y=Y_test,
        line=dict(color="#0071CE"),
        name="Modeling Actual",
        yaxis="y1",
    )
    data.append(line1)

    line3 = go.Scatter(
        x=df_testing.index,
        y=Y_pred,
        line=dict(color="#FFC220"),
        name="Modeling Predicted",
        yaxis="y1",
    )
    data.append(line3)

    fig = go.Figure(data)
    fig = update_layout(
        fig,
        title="Actual vs Predicted Modeling Period",
        legend_y=-0.25,
        legend_x=0.25,
        show_yaxis=True,
    )
    fig.show()


def get_test_fit(df_testing, model_result, outcome_variable, essential_vars):

    X_test, Y_test, Y_pred = model_pred(
        df_testing, model_result, outcome_variable, essential_vars
    )
    r2 = r2_score(Y_test, Y_pred)

    print("r2:", r2)
    print("MAPE:", mape(Y_test, Y_pred) * 100)

    plot_fig(df_testing, Y_test, Y_pred)


def generate_trend_seasonality(data, essential_non_media, outcome="O_UNIT"):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["SBU"].unique():
        brand_level_df = brand_stack[brand_stack["SBU"] == brand][[outcome]+ essential_non_media]
        outcome_residuals = residual_calculation(brand_level_df, outcome, essential_non_media)        

        result_additive = seasonal_decompose(
            x=outcome_residuals, extrapolate_trend="freq", model="additive"
        )

        seasonality_dict[brand] = {}
        seasonality_dict[brand]["Add_trend"] = result_additive.trend
        seasonality_dict[brand]["Add_seasonality"] = result_additive.seasonal

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("SBU", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    return data


def generate_trend_seasonality_hw(data, outcome="O_UNIT"):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["SBU"].unique():
        brand_level_df = brand_stack[brand_stack["SBU"] == brand][[outcome]]
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        result_additive = es(
            brand_level_df.copy(), seasonal_periods=7, seasonal="additive"
        ).fit()
        result_multiplicative = es(
            brand_level_df, seasonal_periods=7, seasonal="multiplicative"
        ).fit()
        seasonality_dict[brand] = {}
        seasonality_dict[brand]["Hw_Add_trend"] = result_additive.trend
        seasonality_dict[brand]["Hw_Add_seasonality"] = result_additive.season
        seasonality_dict[brand]["Hw_Mult_trend"] = result_multiplicative.trend
        seasonality_dict[brand]["Hw_Mult_seasonality"] = result_multiplicative.season

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("SBU", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    return data


def generate_trend_seasonality_stl(data, outcome="O_UNIT"):

    brand_stack = data.copy()
    brand_stack["Date"] = pd.to_datetime(brand_stack["Date"])
    brand_stack.set_index("Date", inplace=True)
    brand_stack.index = pd.to_datetime(brand_stack.index)

    seasonality_dict = {}
    for brand in brand_stack["SBU"].unique():
        brand_level_df = brand_stack[brand_stack["SBU"] == brand][[outcome]]
        brand_level_df.loc[brand_level_df[outcome] == 0, outcome] = 1e-9
        result_additive = STL(brand_level_df.copy(), seasonal=7).fit()
        seasonality_dict[brand] = {}
        seasonality_dict[brand]["STL_trend"] = result_additive.trend
        seasonality_dict[brand]["STL_seasonality"] = result_additive.seasonal

    frames = []
    for key, d in seasonality_dict.items():
        df = pd.DataFrame.from_dict(d)
        df["SBU"] = key
        frames.append(df)
    result_df = pd.concat(frames).reset_index().rename(columns={"index": "Date"})
    data = data.merge(result_df, on=("SBU", "Date"))
    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    try:
        data.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    return data


def hts_model(
    data,
    spec,
    outcome,
    train_start,
    train_end,
    valid_start,
    valid_end,
    forecasting_method="HoltWinters",
):

    hts_data = data.rename(columns={"Date": "ds", outcome: "y"})
    # split the data into different levels with the aggregate function.
    valid = hts_data[(pd.to_datetime(hts_data["ds"]) >= valid_start)]
    h = valid["ds"].nunique()  # forecast horizon 'h' = number of validation days
    category_name = list(data["L3_CATEGORY_NAME"].unique())[0]
    train_agg, S_train, tags = aggregate(hts_data, spec)

    # split the data into different levels with the aggregate function.
    valid_agg, S_valid, valid_tags = aggregate(valid, spec)
    if forecasting_method.lower() == "holtwinters":
        model = StatsForecast(
            models=[HoltWinters(season_length=7, error_type="A")], freq="D", n_jobs=-1
        )
    elif forecasting_method.lower() == "autoarima":
        model = StatsForecast(models=[AutoARIMA(season_length=7)], freq="D", n_jobs=-1)
    else:
        raise ValueError("Unsupported forecasting method")

    model.fit(train_agg)

    p = model.forecast(h=h, fitted=True)
    p_fitted = model.forecast_fitted_values()

    Aggregated_forecasted_col = list(
        p_fitted[p_fitted.index == category_name][forecasting_method]
    ) * len(list(data["SBU"].unique()))

    data["Agg_forecast"] = Aggregated_forecasted_col

    p_fitted_upd = p_fitted[p_fitted.index != category_name]
    brand_col = p_fitted_upd.index.astype(str)
    p_fitted_upd["SBU"] = brand_col
    p_fitted_upd["SBU"] = p_fitted_upd["SBU"].str[len(category_name) + 1 :]

    p_fitted_upd = p_fitted_upd.rename(columns={"y": "O_UNIT"})
    p_fitted_upd["index"] = pd.to_datetime(p_fitted_upd["ds"])  # Formatting the date
    p_fitted_upd.set_index("index", inplace=True, drop=False)
    p_fitted_upd.drop("index", axis=1, inplace=True)

    data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
    data.set_index("Date", inplace=True, drop=False)
    data.drop("Date", axis=1, inplace=True)
    data["ds"] = data.index

    merged = data.merge(p_fitted_upd[["ds", "SBU", forecasting_method]])

    merged["Date"] = pd.to_datetime(merged["ds"])  # Formatting the date
    merged.set_index("Date", inplace=True, drop=False)

    merged.drop("ds", axis=1, inplace=True)
    merged.drop("Date", axis=1, inplace=True)
    try:
        merged.drop("O_UNIT.1", axis=1, inplace=True)
    except:
        pass
    return merged, model, p_fitted


def OLS_func(
    data,
    indep_var,
    outcome,
    brand=None,
    train_start=None,
    train_end=None,
    valid_start=None,
):
    train_data = data[(data.index >= train_start) & (data.index <= train_end)].copy()
    test_data = data[(data.index >= valid_start)].copy()

    Y = train_data[train_data["SBU"] == brand][outcome]
    X = train_data[train_data["SBU"] == brand][indep_var]
    X = sm.add_constant(X)
    model = sm.OLS(Y, X, missing="drop")
    model_result = model.fit()
    return model_result, train_data, test_data


def vif_essential(df_X):
    """
    Finds VIF of the regressors of outcome_variable~essential_vars
    """
    from statsmodels.stats.outliers_influence import variance_inflation_factor

    # Calculate the VIF for each feature of df_X (a Pandas DataFrame).
    vif_data = [variance_inflation_factor(df_X.values, i) for i in range(df_X.shape[1])]
    return pd.Series(vif_data, index=df_X.columns)


# OLS_func(data, indep_var, outcome, brand=None, train_start=None, train_end=None, valid_start=None):


#### eliminating variables with high p-value and vif
def upd_shortlist_variables(
    data,
    essential_vars,
    shortlist_vars,
    brand,
    outcome_var,
    r_sq_adj,
    target_rsq,
    p_val_thresh=0.05,
    vif_thresh=1.1,
    train_start=None,
    train_end=None,
    valid_start=None,
):
    inp_var = shortlist_vars.copy()
    model_result, train_data, test_data = OLS_func(
        data.copy(),
        inp_var,
        outcome_var,
        brand=brand,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_start,
    )

    curr_rsq = model_result.rsquared_adj

    vif_val = vif_essential(data[data["SBU"] == brand][inp_var]).to_dict()

    for media, vif in vif_val.items():

        if (
            (float(vif_val[media]) >= vif_thresh or math.isnan(vif_val[media]))
            and (curr_rsq > target_rsq)
            and (media not in essential_vars)
        ):
            shortlist_vars.remove(media)
            inp_var_upd = essential_vars + shortlist_vars
            model_result, train_data, test_data = OLS_func(
                data.copy(),
                inp_var_upd.copy(),
                outcome_var,
                brand=brand,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
            )
            upd_rsq = model_result.rsquared_adj
            if model_result.rsquared_adj < target_rsq:
                shortlist_vars.append(media)
                upd_rsq = curr_rsq
            curr_rsq = upd_rsq
        if math.isnan(vif_val[media]) or vif_val[media] == math.inf:
            try:
                shortlist_vars.remove(media)
            except:
                continue

    final_shortlist = shortlist_vars

    model_result, train_data, test_data = OLS_func(
        data.copy(),
        final_shortlist.copy(),
        outcome_var,
        brand=brand,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_start,
    )

    brand_r_sq_adj = model_result.rsquared_adj
    return final_shortlist, brand_r_sq_adj


def find_minimum_features(
    data,
    essential_vars,
    shortlist_vars,
    brand,
    outcome_var,
    vif_thresh=1.2,
    train_start=None,
    train_end=None,
    valid_start=None,
    target_r2=0.75,
):
    best_r2 = 0
    selected_features = shortlist_vars.copy()
    potential_features = essential_vars.copy()
    inp_var = essential_vars + shortlist_vars
    '''
    while potential_features:
        # best_r2 < (target_r2 + 0.1 * target_r2) and
        best_feature = None
        for feature in potential_features:
            trial_features = selected_features + [feature]
            model_result, train_data, test_data = OLS_func(
                data.copy(),
                trial_features.copy(),
                outcome_var,
                brand=brand,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
            )
            if model_result.rsquared_adj > (best_r2 + 0.15 * best_r2):
                best_r2 = model_result.rsquared_adj
                best_feature = feature
        if best_feature is not None:
            selected_features.append(best_feature)
        potential_features.remove(feature)
    '''
    # selected_features = list(set(selected_features) - set(essential_vars))
    model_result, train_data, test_data = OLS_func(
        data.copy(),
        selected_features + essential_vars,
        outcome_var,
        brand=brand,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_start,
    )
    return selected_features, best_r2


def get_non_media_coefs(
    brand_list,
    updated_stack,
    non_media_z_k,
    outcome="O_UNIT",
    train_start=None,
    train_end=None,
    valid_start=None,
):
    brand_non_media_coef = {}
    for brand in brand_list:
        brand_non_media_coef[brand] = []
        for i in range(3):
            model_result, train_data, test_data = OLS_func(
                updated_stack,
                non_media_z_k[brand][i],
                outcome=outcome,
                brand=brand,
                train_start=train_start,
                train_end=train_end,
                valid_start=valid_start,
            )
            non_media_coefs = dict(model_result.params)
            brand_non_media_coef[brand].append(non_media_coefs)
    return brand_non_media_coef


def get_non_media_matrix(
    data,
    dummy_var_lst,
    essential_non_media,
    brand_list,
    outcome_vars,
    non_media_set,
    train_start,
    train_end,
    valid_start,
    valid_end,
    target_r2=0.8,
):
    essential_vars_og = sorted(list(set(dummy_var_lst[1:]) - set(essential_non_media)))

    seasonality_cols = [
        "Add_trend",
        "Add_seasonality",
        "Mult_trend",
        "Mult_seasonality",
    ]

    essential_vars_sd_1 = essential_non_media + ["Add_trend"]
    essential_vars_sd_2 = essential_non_media + ["Add_seasonality"]
    essential_vars_sd_3 = essential_non_media + ["Add_trend", "Add_seasonality"]

    (
        updated_shortlist_sd_1,
        r_sq_adj_sd_1,
        updated_shortlist_sd_2,
        r_sq_adj_sd_2,
        updated_shortlist_sd_3,
        r_sq_adj_sd_3,
    ) = ({}, {}, {}, {}, {}, {})
    print(
        "*********** Performing seasonality analysis to get non media variables ***********"
    )
    for outcome in outcome_vars:
        seasonal_stack = generate_trend_seasonality(data.copy(), essential_non_media, outcome)
        # seasonal_stack = generate_trend_seasonality_stl(data.copy(), outcome)

    print(
        "*********** Performing backward elimination to only retain essential variables ***********"
    )
    outcome = outcome_vars[0]
    for brand in brand_list:
        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack.copy(),
            essential_vars_og.copy(),
            essential_vars_sd_1.copy(),
            brand,
            outcome,
            vif_thresh=1.2,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_sd_1[brand], r_sq_adj_sd_1[brand] = upd_shortlist_variables(
            seasonal_stack.copy(),
            essential_vars_sd_1.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=1.2,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
        )
        print(
            f"********* R_Sq_Adj Set 1 brand {brand} *********",
            r_sq_adj_sd_1[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack.copy(),
            essential_vars_og.copy(),
            essential_vars_sd_2.copy(),
            brand,
            outcome,
            vif_thresh=1.2,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_sd_2[brand], r_sq_adj_sd_2[brand] = upd_shortlist_variables(
            seasonal_stack.copy(),
            essential_vars_sd_2.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=1.2,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
        )
        print(
            f"********* R_Sq_Adj Set 2 brand {brand} *********",
            r_sq_adj_sd_2[brand],
            "\n",
        )

        updated_shortlist, r_sq_adj = find_minimum_features(
            seasonal_stack.copy(),
            essential_vars_og.copy(),
            essential_vars_sd_3.copy(),
            brand,
            outcome,
            vif_thresh=1.2,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
            target_r2=target_r2,
        )
        updated_shortlist_sd_3[brand], r_sq_adj_sd_3[brand] = upd_shortlist_variables(
            seasonal_stack.copy(),
            essential_vars_sd_3.copy(),
            updated_shortlist.copy(),
            brand,
            outcome,
            r_sq_adj,
            target_r2,
            p_val_thresh=0.05,
            vif_thresh=1.2,
            train_start=train_start,
            train_end=train_end,
            valid_start=valid_start,
        )
        print(
            f"********* R_Sq_Adj Set 3 brand {brand} *********",
            r_sq_adj_sd_3[brand],
            "\n",
        )

    print("*********** Creating processed non media matrix ***********")
    combined_data = seasonal_stack.copy()

    combined_data["INTERCEPT"] = 1

    non_media_z_k = {}
    for key, value in updated_shortlist_sd_1.items():
        non_media_z_k[key] = [
            updated_shortlist_sd_1[key] + ["INTERCEPT"],
            updated_shortlist_sd_2[key] + ["INTERCEPT"],
            updated_shortlist_sd_3[key] + ["INTERCEPT"],
        ]

    # num_non_media = len(non_media_z_k[brand_list[0]])
    # num_non_media = 1

    pre_processed_matrix_U_kj, pre_processed_matrix_Y_kj = [], []
    for idx in range(len(brand_list)):
        matrix_U_kj, matrix_Y_kj = [], []
        for j in non_media_set:            
            Z_k_j = combined_data[combined_data["SBU"] == brand_list[idx]][
                non_media_z_k[brand_list[idx]][j]
            ].to_numpy()
            Z_k_j_transpose = Z_k_j.transpose()
            try:
                Z_k_j_inv = inv(Z_k_j_transpose.dot(Z_k_j))
            except:
                Z_k_j_inv = pinv(Z_k_j_transpose.dot(Z_k_j))

            P_k_j = np.dot(Z_k_j, np.dot(Z_k_j_inv, Z_k_j_transpose))

            I = np.identity(P_k_j.shape[0])
            U_k_j = I - P_k_j

            Y_k = combined_data[combined_data["SBU"] == brand_list[idx]][
                "O_UNIT"
            ].to_numpy()
            Y_k_j = U_k_j.dot(Y_k)  # (U_k_j)
            matrix_U_kj.append(U_k_j)
            matrix_Y_kj.append(Y_k_j)
        pre_processed_matrix_U_kj.append(np.asarray(matrix_U_kj))
        pre_processed_matrix_Y_kj.append(np.asarray(matrix_Y_kj))

    #### fetch non media coefficients
    non_media_coef = get_non_media_coefs(
        brand_list,
        combined_data,
        non_media_z_k,
        outcome=outcome,
        train_start=train_start,
        train_end=train_end,
        valid_start=valid_end,
    )
    print("**************** selected non media ****************")
    for idx in range(len(brand_list)): 
        print("SBU: ", brand_list[idx])
        for j in non_media_set:
            print("set: ", j)
            print(non_media_z_k[brand_list[idx]][j])        

    return (
        np.asarray(pre_processed_matrix_U_kj),
        np.asarray(pre_processed_matrix_Y_kj),
        combined_data,
        non_media_z_k,
        non_media_coef,
    )
