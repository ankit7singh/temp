import pandas as pd
import json
import os
from lite_wamm_modeling import create_folder_with_version
# from lite_non_media_utils_v1_1 import *
from lite_non_media_utils_v3_Nat_Fit import *
from lite_wamm_helper_functions import *
from IPython.display import display
from category_media_vars import (default_tactic_combinations,
                                category_cpd_variables, category_media_variables, category_channel_variables, category_wmt_variables)
class CategoryPreprocess:

    def __init__(self,config_file_path='../src/config_dir/category_config_pooled_1.json'):
        file_data = open(config_file_path)
        self.config = json.load(file_data) 
        self.fix_iterations = self.config["fix_iterations"]
        self.use_ridge = self.config["use_ridge"]
        self.media_stack_path = self.config["media_stack_path"]
        self.non_media_stack_path = self.config["non_media_stack_path"]
        self.outcome = self.config["outcome_var"]
        self.media_vars = self.config["modeling_parameters"][self.outcome]["media_vars"]
        self.media_vars_national = self.config["modeling_parameters"][self.outcome]["national_media_vars"]       #National Media Base Update
        self.lag_hf_media_national = self.config["modeling_parameters"][self.outcome]["national_media_vars_lg_hf"]       #National Media Base Update
        self.national_media_transform = self.config["modeling_parameters"][self.outcome]["national_media_transform"]       #National Media Base Update
        self.national_media_vars = self.config["modeling_parameters"][self.outcome]["national_media_vars"]       #National Media Base Update
        self.outlier_dummies = self.config["modeling_parameters"][self.outcome]["outlier_dummies"]       #National Media Base Update
        # self.dummy_vars = self.config[self.outcome]["dummy_vars"] #TODO : future scope
        self.media_to_split = self.config["modeling_parameters"][self.outcome]["media_to_split"]
        self.essential_non_media = self.config["modeling_parameters"][self.outcome]["essential_non_media_vars"]
        self.exclude_non_media = self.config["modeling_parameters"][self.outcome]["exclude_non_media"]
        self.excluded_SBU = self.config["modeling_parameters"][self.outcome]["excluded_SBU"]
        self.non_media_set = self.config["modeling_parameters"][self.outcome]["non_media_set"]
        self.lb = self.config["modeling_parameters"][self.outcome]["s_curve_bounds"]["lb"]
        self.ub = self.config["modeling_parameters"][self.outcome]["s_curve_bounds"]["ub"]
        self.target_r2 = self.config["modeling_parameters"][self.outcome]["target_r2"]
        self.train_start = self.config["modeling_parameters"][self.outcome]["train_start"]
        self.train_end = self.config["modeling_parameters"][self.outcome]["train_end"]
        self.valid_start = self.config["modeling_parameters"][self.outcome]["valid_start"]
        self.valid_end = self.config["modeling_parameters"][self.outcome]["valid_end"]
        self.output_path = self.config["output_path"]  
        self.use_pooled_bounds = self. config["modeling_parameters"][self.outcome]["use_pooled_bounds"]
        self.custom_s_curve_bounds = self.config["modeling_parameters"][self.outcome]["custom_s_curve_bounds"]
        self.split_dictionary = {}


    def update_essential_non_media(self, data, essential_non_media):
        xmas_thanks_exclusion = (data['D_HOL_CHRISTMAS'] == 0) & (data['D_HOL_THANKSGIVING_DAY'] == 0)
        data_temp = data.loc[xmas_thanks_exclusion]

        sales_mean = data_temp[self.outcome].mean()
        sales_std = data_temp[self.outcome].std()
        upper_bnd = sales_mean + 3*sales_std
        lower_bnd = sales_mean - 3*sales_std
        essential_media_dates = data[essential_non_media].any(axis=1)

        # Approach 1: single columns for high and low sales, lower dimensionality but may provide lesser control on fit
        # data["D_HIGH_SALES_DAYS"] = ((~essential_media_dates) & (data[self.outcome] > upper_bnd)).astype(int)
        # data["D_LOW_SALES_DAYS"] = ((~essential_media_dates) & (data[self.outcome] < lower_bnd)).astype(int)
        # if len(data["D_HIGH_SALES_DAYS"].unique()) > 1:
        #     essential_non_media.append("D_HIGH_SALES_DAYS")
        # if len(data["D_LOW_SALES_DAYS"].unique()) > 1:
        #     essential_non_media.append("D_LOW_SALES_DAYS")

        # Approach 2: separate columns based on month and year, might lead to more dimensionality but provide better control on fit
        data_temp = data.copy()
        data_temp["Month_Year"] = data_temp.Date.dt.to_period('M')
        for period in data_temp["Month_Year"].unique():
            data_temp[f"D_HIGH_SALES_{period}"] = ((~essential_media_dates) & (data_temp["Month_Year"] == period) & (data_temp[self.outcome] > upper_bnd)).astype(int)
            if len(data_temp[f"D_HIGH_SALES_{period}"].unique()) > 1:        
                essential_non_media.append(f"D_HIGH_SALES_{period}")
                data[f"D_HIGH_SALES_{period}"] = data_temp[f"D_HIGH_SALES_{period}"].copy()
                
            data_temp[f"D_LOW_SALES_{period}"] = ((~essential_media_dates) & (data_temp["Month_Year"] == period) & (data_temp[self.outcome] < lower_bnd)).astype(int)
            if len(data_temp[f"D_LOW_SALES_{period}"].unique()) > 1:        
                essential_non_media.append(f"D_LOW_SALES_{period}")
                data[f"D_LOW_SALES_{period}"] = data_temp[f"D_LOW_SALES_{period}"].copy()
                
        return essential_non_media, data.copy()

    def load_data(self, thres_sat_dict, passed_sbu=None):
        # CAT WAMM : Change read_excel
        data = pd.read_excel(
            self.media_stack_path
        )
        # filter data based on brand_list
        self.sbu_list = sorted(list(data[~data["SBU"].isin(self.excluded_SBU)]["SBU"].unique()))
        if passed_sbu:
            self.brand_list = [passed_sbu]
            print(f"Manually passed sbu name:{passed_sbu}", "\n")
        
        data = data[data["SBU"].isin(self.sbu_list)].reset_index(drop=True)
        self.non_media_stack = pd.read_csv(
            self.non_media_stack_path, low_memory=False
        )
        self.non_media_stack = self.non_media_stack.copy().fillna(0)
        data["Date"] = pd.to_datetime(data["index"])
        # data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
        self.non_media_stack["Date"] = pd.to_datetime(self.non_media_stack["Date"])  # Formatting the date

        # joining non media to the modeling stack
        self.data = data.merge(self.non_media_stack, how="left", on="Date", sort=False).sort_values(
            by=["SBU", "Date"], ascending=True
        )


        # determine media variables - splitting on the years by default 
        self.media_variables = sorted(list(set(self.media_vars) & set(list(self.data.columns))))
        self.media_variables_all = sorted(list(set(self.media_vars) & set(list(self.data.columns)))) #Later updated with splitted variables
        self.media_variables_national = sorted(list(set(self.media_vars_national) & set(list(self.data.columns)))) #Later updated with splitted variables

        self.thres_sat_upd = thres_sat_dict 

        # determine dummy variables
        self.dummy_var_lst = list(self.non_media_stack.columns)
        # outcome_vars
        self.outcome_vars = [self.outcome]
        print(list(self.data.columns))

    def media_split(self):
        interval = 365
        nrows = len(self.data.index)
        splits = int(nrows/interval) + (nrows % interval > 0)
        # assigning the buckets to the rows 

        sequence = list(np.repeat(np.arange(1, splits+1), interval))
        # sequence.reverse()
        self.data['media_split_bucket'] = sequence[(len(sequence)-nrows):]
        
        if self.media_to_split:
            for media in self.media_to_split:
                col_name_list = []
                for bucket in self.data['media_split_bucket'].unique():
                    if "CLK" in str(media):

                        clk_col_name = str(media).replace('_CLK', '') + '_' + str(bucket) + '_CLK'
                        col_name_list.append(clk_col_name)
                        spend_col_name = str(clk_col_name).replace("CLK","SPEND")
                        self.data[clk_col_name] = 0
                        self.data[spend_col_name] = 0
                        self.data.loc[self.data['media_split_bucket']==bucket, clk_col_name] = self.data[self.data['media_split_bucket']==bucket][media]
                        self.data.loc[self.data['media_split_bucket']==bucket, spend_col_name] = self.data[self.data['media_split_bucket']==bucket][(media).replace("CLK","SPEND")]

                    else:

                        imp_col_name = str(media).replace('_IMP', '') + '_' + str(bucket) + '_IMP'
                        col_name_list.append(imp_col_name)
                        spend_col_name = str(imp_col_name).replace("IMP","SPEND")
                        self.data[imp_col_name] = 0
                        self.data[spend_col_name] = 0
                        self.data.loc[self.data['media_split_bucket']==bucket, imp_col_name] = self.data[self.data['media_split_bucket']==bucket][media]
                        self.data.loc[self.data['media_split_bucket']==bucket, spend_col_name] = self.data[self.data['media_split_bucket']==bucket][(media).replace("IMP","SPEND")]

                self.split_dictionary[media] = col_name_list
        ## Update Media with splitted variables

        if self.split_dictionary:
            self.media_variables_all = [x for x in self.media_variables_all if x not in self.split_dictionary.keys()]
            self.media_variables_all = self.media_variables_all + [media for row in self.split_dictionary.values() for media in row]
        self.media_variables_all.sort()
        self.media_variables.sort()


    def preprocess_data(self, priorCommon):
        # TODO in-progress
        outcome = self.outcome
        media_variables = self.media_variables
        media_vars_national = self.media_variables_national #National Media Base Update
        national_media_transform  = self.national_media_transform #Flag for National Media in Base
        lag_hf_media_national  = self.lag_hf_media_national #Flag for National Media in Base
        media_variables_all = self.media_variables_all
        media_to_split = self.media_to_split
        dummy_var_lst = self.dummy_var_lst #TODO : future scope
        essential_non_media = self.essential_non_media
        non_media_set = self.non_media_set
        use_pooled_bounds = self.use_pooled_bounds
        lb = self.lb
        ub = self.ub
        target_r2 = self.target_r2
        train_start = self.train_start
        train_end = self.train_end
        valid_start = self.valid_start
        valid_end = self.valid_end
        output_path = self.output_path
        outcome_vars = self.outcome_vars
        sbu_list = self.sbu_list
        thres_sat_dict = self.thres_sat_upd

        print("Running WAMM Category Preprocessing & Prior Estimation")
        print(f"Outcome Type : {outcome}")
        print(f"Candidate SBUs : {sbu_list}")
        print(f"Media Variables : {media_variables}")
        print(f"Media Variables to be Split : {media_to_split}")
        print(f"All Media Variables : {media_variables_all}")
        print(f"Dummy variables : {dummy_var_lst}")
        print(f"essential_non_media_vars : {essential_non_media}")
        print(f"non_media_set : {non_media_set}")
        print(f"Training Start Date: {train_start}")
        print(f"Training End Date: {train_end}")
        print(f"Validation Start Date: {valid_start}")
        print(f"Validation End Date: {valid_end}")
        final_folder_path = create_folder_with_version(f"{output_path}/{outcome}")
        self.final_folder_path = final_folder_path
        data = self.data.copy()
        exclude_non_media = self.exclude_non_media
        national_params = {}


        if self.outlier_dummies:
            data = data[data["SBU"].isin(self.sbu_list)].reset_index(drop=True)
            essential_non_media, data = self.update_essential_non_media(
                    data, essential_non_media
                )
            print(f"updated essential_non_media_vars with dummies for outliers : {essential_non_media}", "\n")

        if national_media_transform:
            data, national_params = national_media_transform(data, sbu_list, outcome_vars, media_vars_national, self.custom_s_curve_bounds ,lag_hf_media_national)        #National Media Base Update
            print(f"National Media Transformed : {media_vars_national}")
            # media_vars_national = [x + '_transformed' for x in media_vars_national]
            # essential_non_media_with_nat = essential_non_media + media_vars_national
            essential_media_dict = feature_selection(data, sbu_list, outcome_vars, essential_non_media, exclude_non_media)      #National Media Added to Essential Non Media
        else:
            essential_media_dict = feature_selection(data, sbu_list, outcome_vars, essential_non_media, exclude_non_media)
        non_media_stack = self.non_media_stack.copy()
        data_pooled = data.copy()

        ## If WMT is included in media_vars_all : WMC + WMT Model fit
        national_media_vars_lg_hf_list = []
        if self.lag_hf_media_national and national_params:
            for national_media, params in national_params.items(): 
                nat_media_idx =  self.media_variables_all.index(national_media)
                lg = params[0]
                hf = params[1]
                inf = params[2]
                sc = params[3]
                national_media_vars_lg_hf_list.append([nat_media_idx,lg,hf,inf,sc])
            national_media_vars_lg_hf_list = sorted(national_media_vars_lg_hf_list,key=lambda x : x[0])
            self.national_media_lg_hf_list = national_media_vars_lg_hf_list
        else:
            self.national_media_lg_hf_list = []
        self.wmc_media_vars = [x for x in self.media_variables_all if x not in self.national_media_vars]


        (
            self.pre_processed_matrix_U_kj,
            self.pre_processed_matrix_Y_kj,
            self.updated_stack,
            self.non_media_z_k,
            self.non_media_coef,
        ) = get_non_media_matrix(
            data.copy(),
            dummy_var_lst,
            essential_media_dict[sbu_list[0]],
            sbu_list,
            outcome_vars,
            non_media_set,
            train_start,
            train_end,
            valid_start,
            valid_end,
            target_r2=target_r2
        )
        print("self.non_media_coef",self.non_media_coef)
#       Add price column : Not needed for Category WAMM
        self.updated_stack["PRICE"] = self.updated_stack["O_SALE"] / self.updated_stack["O_UNIT"]
        self.updated_stack["PRICE"].mean()
        updated_stack = self.updated_stack.copy()

# Replicate Category Thre / Saturations

        
        # target_threshold = [12258204.01,1699.67,186675.91,148672.50,244177.68,
        # 891069.17,1622769.38,0.00,380627.63,152609.56,677417.78,29345.68,
        # 141019.19,0.00,84763.65,47754.94,93074.66,1887.07,6994.61,
        # 12955.88,10581.98,2665.58,9367.22,4646.29,295.17,0.00,0.00,0.00,0.00,0.00]

        # target_saturation = [60459808,91741,904535,1229994,1480106.493,3048103.81,8070850.834,123370.768,1272561.87
        # ,2029440.337,2285036.359,116770.102,720242.262,770419.391,470658.513
        # ,538188.645,622760.034,8619.238,45027.301,62611.26,90763.789,23923.613,48446.518
        # ,78743.153,784.391,334951,176920,63801980,56638024,82069631]

        # threshold_bounds, saturation_bounds = (
        #     get_scurve_bounds_replicate_values(data_pooled.copy(), media_variables_all, thres_sat_dict, target_threshold, target_saturation, lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
        # )

# Standard Process : Uncomment 

        if priorCommon is True:
            if use_pooled_bounds:
                threshold_bounds, saturation_bounds, target_threshold, target_saturation = (
                    get_scurve_bounds(data_pooled.copy(), media_variables, thres_sat_dict, lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
                )
                #Separate bounds to create separate priors_info_df for National 
                if self.media_variables_national:
                    threshold_bounds_nat, saturation_bounds_nat, target_threshold_nat, target_saturation_nat = (
                    get_scurve_bounds(data_pooled.copy(), media_vars_national, thres_sat_dict, lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
                )

            else:
                # Use the below commented section if you would like to use average threshold and saturation bounds
                threshold_bounds, saturation_bounds, target_threshold, target_saturation = (
                    get_scurve_bounds_v1(data.copy(), sbu_list, media_variables, lb=lb, ub=ub)
                )
                if self.media_variables_national:
                    threshold_bounds_nat, saturation_bounds_nat, target_threshold_nat, target_saturation_nat = (
                    get_scurve_bounds_v1(data.copy(), sbu_list, media_vars_national, lb=lb, ub=ub)
                )
        else:
            if use_pooled_bounds:
                threshold_bounds, saturation_bounds, target_threshold, target_saturation = (
                    get_scurve_bounds(data_pooled.copy(), media_variables_all, thres_sat_dict, lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
                )
                if self.media_variables_national:
                    threshold_bounds_nat, saturation_bounds_nat, target_threshold_nat, target_saturation_nat = (
                    get_scurve_bounds(data_pooled.copy(), media_vars_national, thres_sat_dict, lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
                )

            else:
                # Use the below commented section if you would like to use average threshold and saturation bounds
                threshold_bounds, saturation_bounds, target_threshold, target_saturation = (
                    get_scurve_bounds_v1(data.copy(), sbu_list, media_variables_all, lb=lb, ub=ub)
                )
                if self.media_variables_national:
                    threshold_bounds_nat, saturation_bounds_nat, target_threshold_nat, target_saturation_nat = (
                        get_scurve_bounds(data.copy(), media_vars_national, thres_sat_dict, lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
                    )


#        Spread Th, St across all splitted media variables


#        alpha_o ## The Values are placeholder static values for now : #TODO : Category knowledge base integration 
        media_iroas_prior = get_media_iroas_prior(data.copy(), sbu_list, outcome, media_variables_all, is_category=True,is_premium=False,debug_flag=False)
        if self.media_variables_national:
            media_iroas_prior_nat = get_media_iroas_prior(data.copy(), sbu_list, outcome, media_vars_national, is_category=True,is_premium=False,debug_flag=False)


#         # U_m, Sigma_m
        coef_mean_prior, coef_var_prior = get_media_coef_prior(
            updated_stack.copy(), media_iroas_prior, media_variables_all, is_premium=True
        )
        if self.media_variables_national:
            coef_mean_prior_nat, coef_var_prior_nat = get_media_coef_prior(
                updated_stack.copy(), media_iroas_prior_nat, media_vars_national, is_premium=True
            )

        print(f"media_iroas_prior : {media_iroas_prior}")
        print(f"coef_mean_prior : {coef_mean_prior}")
        print(f"coef_var_prior : {coef_var_prior}")


        priors_info_dict_1 = {}
        priors_info_dict_2 = {}
        priors_info_dict = {}
        priors_info_dict_nat = {}

        ## OnAirDays per tactic
        def get_on_air_days(data,media_vars):
            on_air_df = {}
            df_onair_list = []
            for var in media_vars:
                df_var = data[[var]].copy()
                df_var.columns = ['Raw Variable']
                on_air_df = df_var[df_var['Raw Variable'] > 0]
                df_onair_list.append(len(on_air_df))
            return df_onair_list
        
        if priorCommon is True:
            for m, var in enumerate(media_variables):
                priors_info_dict_1[var] = list(threshold_bounds[m])+list(saturation_bounds[m])+[target_threshold[m]]+[target_saturation[m]]
            for m, var in enumerate(media_variables_all):
                priors_info_dict_2[var] = [media_iroas_prior[var]] + [coef_mean_prior[m]] + [coef_var_prior[m]] 

            priors_info_df_1 = pd.DataFrame.from_dict(priors_info_dict_1, orient='index').reset_index()
            priors_info_df_1.columns = ['media_variable','threshold_lb','threshold_ub','saturation_lb','saturation_ub','target_threshold','target_saturation']

            priors_info_df_2 = pd.DataFrame.from_dict(priors_info_dict_2, orient='index').reset_index()
            priors_info_df_2.columns = ['media_variable','iroas_prior','coef_mean_prior','coef_var_prior']

            split_inverse = { v: k for k, l in self.split_dictionary.items() for v in l }
            
            priors_info_df_2['splitted_variable'] = priors_info_df_2['media_variable'].map(split_inverse)
            priors_info_df_2['splitted_variable'] = np.where(priors_info_df_2.splitted_variable.isna(), priors_info_df_2.media_variable, priors_info_df_2.splitted_variable)

            priors_info_df = pd.merge(priors_info_df_2,priors_info_df_1,left_on='splitted_variable',right_on='media_variable',how='left')
            priors_info_df.drop(['media_variable_y'],axis=1,inplace=True)
            priors_info_df.rename(columns={"media_variable_x":"media_variable"},inplace=True)
            priors_info_df['on_air_days'] = get_on_air_days(data,media_variables_all)

            print(split_inverse)
            self.split_inverse = split_inverse
            self.priors_info_df = priors_info_df.copy()
            display(self.priors_info_df)
        else:
            for m, var in enumerate(media_variables_all):
                print(var)
                priors_info_dict[var] = list(threshold_bounds[m])+list(saturation_bounds[m])+[target_threshold[m]]+[target_saturation[m]]+[media_iroas_prior[var]]+[coef_mean_prior[m]]+[coef_var_prior[m]]
            self.split_inverse = {}
            priors_info_df = pd.DataFrame.from_dict(priors_info_dict, orient='index').reset_index()
            priors_info_df.columns = ['media_variable','threshold_lb','threshold_ub','saturation_lb','saturation_ub','target_threshold','target_saturation','iroas_prior','coef_mean_prior','coef_var_prior']
            self.priors_info_df = priors_info_df.copy()
            self.priors_info_df['on_air_days'] = get_on_air_days(data,media_variables_all)

            display(self.priors_info_df)

        if self.media_variables_national: 
            for m, var in enumerate(media_vars_national):
                print(var)
                priors_info_dict_nat[var] = list(threshold_bounds_nat[m])+list(saturation_bounds_nat[m])+[target_threshold_nat[m]]+[target_saturation_nat[m]]+[media_iroas_prior_nat[var]]+[coef_mean_prior_nat[m]]+[coef_var_prior_nat[m]]
            priors_info_df_nat = pd.DataFrame.from_dict(priors_info_dict_nat, orient='index').reset_index()
            priors_info_df_nat.columns = ['media_variable','threshold_lb','threshold_ub','saturation_lb','saturation_ub','target_threshold','target_saturation','iroas_prior','coef_mean_prior','coef_var_prior']
            self.priors_info_df_nat = priors_info_df_nat.copy()
            self.priors_info_df_nat['on_air_days'] = get_on_air_days(data,media_vars_national)

            display(self.priors_info_df_nat)




    def generate_panel_data(self):

        # load variables
        pre_processed_matrix_U_kj = self.pre_processed_matrix_U_kj
        pre_processed_matrix_Y_kj = self.pre_processed_matrix_Y_kj
        sbu_list = self.sbu_list
        updated_stack = self.updated_stack.copy()
        priors_info_df = self.priors_info_df.copy()
        priors_info_df_nat = self.priors_info_df_nat.copy()
        non_media_set = self.non_media_set
        final_folder_path = self.final_folder_path
        train_start = self.train_start
        train_end = self.train_end
        valid_start = self.valid_start
        valid_end = self.valid_end
        outcome = self.outcome
        media_variables_nat = self.media_variables_national
        media_variables = self.media_variables
        media_variables_all = self.media_variables_all
        split_dictionary = self.split_dictionary
        lag_hf_media_national = self.national_media_lg_hf_list
        wmc_media_vars = self.wmc_media_vars

        for k,sbu in enumerate(sbu_list):
    
            updated_stack_sbu = updated_stack[updated_stack["SBU"]==sbu]
            sbu_k_output_path = f"{final_folder_path}/{sbu}"
            try:
                os.mkdir(sbu_k_output_path)
                print(f"{sbu_k_output_path} created")
            except:
                print(f"{sbu_k_output_path} path already exists")
            modeling_stack_k_j_path = f"{sbu_k_output_path}/modeling_stack.csv"
            priors_info_df_path = f"{sbu_k_output_path}/priors_info.csv"
            priors_info_df_nat_path = f"{sbu_k_output_path}/priors_info_nat.csv"
            updated_stack_sbu.to_csv(modeling_stack_k_j_path)
            # media related updates
            priors_info_df.to_csv(priors_info_df_path,index=False)
            priors_info_df_nat.to_csv(priors_info_df_nat_path,index=False)
            print(f"Writing to {sbu_k_output_path}")
            for j in range(len(non_media_set)):
                sbu_k_j_output_path = f"{sbu_k_output_path}/z_{j}"
                try:
                    os.mkdir(sbu_k_j_output_path)
                    print(f"{sbu_k_j_output_path} created")
                except:
                    print(f"{sbu_k_j_output_path} path already exists")

                U_kj = pre_processed_matrix_U_kj[k][j]
                Y_kj = pre_processed_matrix_Y_kj[k][j]
                np.savetxt(f"{sbu_k_j_output_path}/U_kj.txt",U_kj)
                np.savetxt(f"{sbu_k_j_output_path}/Y_kj.txt",Y_kj)
                
                # generate config for k,j
                config_jk = {}
                config_jk['sbu_name']=sbu
                config_jk['modeling_stack_path'] = modeling_stack_k_j_path
                config_jk['priors_info_path'] = priors_info_df_path
                config_jk['priors_info_nat_path'] = priors_info_df_nat_path
                config_jk['U_kj_path']=f"{sbu_k_j_output_path}/U_kj.txt"
                config_jk['Y_kj_path']=f"{sbu_k_j_output_path}/Y_kj.txt"
                config_jk['non_media_set_idx']=j
                config_jk['outcome']=outcome
                config_jk['train_start']=train_start
                config_jk['train_end']=train_end
                config_jk['valid_start']=valid_start
                config_jk['valid_end']=valid_end
                config_jk['media_vars'] = media_variables + media_variables_nat
                config_jk["media_variables_all"] = media_variables_all + media_variables_nat
                config_jk["split_dictionary"] = split_dictionary
                config_jk["lag_hf_media_national"] = lag_hf_media_national
                config_jk["wmc_media_vars"] = wmc_media_vars
                config_jk["national_media_vars"] = media_variables_nat
                config_jk["non_media_z_k"] = self.non_media_z_k[sbu][j]
                config_jk["non_media_coef"] = self.non_media_coef[sbu][j]
                config_jk["split_inverse"] = self.split_inverse
                config_jk["use_ridge"] = self.use_ridge
                config_jk["fix_iterations"] = self.fix_iterations

                with open(f'{sbu_k_j_output_path}/panel_config.json', 'w') as fp:
                    json_dumps_str = json.dumps(config_jk, indent=4)
                    print(json_dumps_str, file=fp)
        print(f"Premium preprocessing results saved to : {final_folder_path}")
        print("Final set of sbus: ",self.sbu_list)
        return f"{self.sbu_list} :: {final_folder_path.split('_v')[1]} "

class PremiumPanel:
    def __init__(self) -> None:
        # Placeholder class for panel level processing
        pass



