import pandas as pd
import json
import os
from lite_wamm_modeling import create_folder_with_version
# from lite_non_media_utils_v1_1 import *
from lite_non_media_utils_v3_Nat_Fit import *
from lite_wamm_helper_functions import *
from IPython.display import display
import datetime
date_format = "%Y-%m-%d"

from category_media_vars import (default_tactic_combinations,
                                category_cpd_variables, category_media_variables, category_channel_variables, category_wmt_variables)

# MSedits START MS-00 : dummy-selection extensions (see MSEDITS_CHANGELOG.md)
from ms_dummy_selection import (
    build_ms_context,
    fill_thanksgiving_dummies,
    count_passing_bases,
    report_base_pass_rate,
    report_final_verdict,
    report_rescue_summary,
    relax_config_mape_limit,                                                                # MSedits MS-16 +
    resolve_panel_mape_limit,                                                               # MSedits MS-15 +
    run_base_rescue,
    write_rescue_log,
)
# MSedits END MS-00

class CategoryPreprocess:

    def __init__(self,config_file_path='../src/config_dir/category_config_pooled_1.json'):
        file_data = open(config_file_path)
        self.config = json.load(file_data)
        # MSedits START MS-16 : remember where this config came from, so the
        # MS-15 relaxation can be mirrored back into the same file notebooks
        # 03/05/06.0 re-open. Resolved now, against the cwd at construction, so
        # a later cell changing directories cannot invalidate it.
        self.config_file_path = os.path.abspath(config_file_path)
        # MSedits END MS-16
        self.media_stack_path = self.config["media_stack_path"]
        self.non_media_stack_path = self.config["non_media_stack_path"]
        self.outcome = self.config["outcome_var"]
        self.media_vars = self.config["modeling_parameters"][self.outcome]["media_vars"]
        self.media_vars_national = self.config["modeling_parameters"][self.outcome]["national_media_vars"]       #National Media Base Update
        self.lag_hf_media_national = self.config["modeling_parameters"][self.outcome]["national_media_vars_lg_hf"]       #National Media Base Update
        self.national_media_transform = self.config["modeling_parameters"][self.outcome]["national_media_transform"]       #National Media Base Update
        self.national_media_vars = self.config["modeling_parameters"][self.outcome]["national_media_vars"]       #National Media Base Update
        self.outlier_dummies = self.config["modeling_parameters"][self.outcome]["outlier_dummies"]       #National Media Base Update
        # self.dummy_vars = self.config[self.outcome]["dummy_vars"] #TODO : future scope
        self.media_to_split = self.config["modeling_parameters"][self.outcome]["media_to_split"]
        self.essential_non_media = self.config["modeling_parameters"][self.outcome]["category_essential_vars"]
        self.exclude_non_media = self.config["modeling_parameters"][self.outcome]["exclude_non_media"]
        self.excluded_SBU = self.config["modeling_parameters"][self.outcome]["excluded_SBU"]
        self.non_media_set = self.config["modeling_parameters"][self.outcome]["non_media_set"]
        self.lb = self.config["modeling_parameters"][self.outcome]["s_curve_bounds"]["lb"]
        self.ub = self.config["modeling_parameters"][self.outcome]["s_curve_bounds"]["ub"]
        self.thres_sat_upd = self.config["modeling_parameters"][self.outcome]["sat_bound_dict"]
        self.thres_upd = self.config["modeling_parameters"][self.outcome]["thres_bound_dict"]
        self.target_r2 = self.config["modeling_parameters"][self.outcome]["target_r2"]
        self.train_start = self.config["modeling_parameters"][self.outcome]["train_start"]
        self.train_end = self.config["modeling_parameters"][self.outcome]["train_end"]
        self.valid_start = self.config["modeling_parameters"][self.outcome]["valid_start"]
        self.valid_end = self.config["modeling_parameters"][self.outcome]["valid_end"]
        self.wmc_portfolio_dict = self.config["modeling_parameters"][self.outcome]["WMC_PORTFOLIO_DICT"]
        self.category_tactics_to_combine = self.config["modeling_parameters"][self.outcome]["category_tactics_to_combine"]

        # MSedits START MS-03 : dummy-selection settings
        # MS-13: NOT read from category_config.json any more. Configs are
        # imported differently per category and only two ever carried an
        # "ms_dummy_selection" block, so the feature stayed silently off
        # everywhere else. The settings now live in ms_dummy_selection.DEFAULTS;
        # an empty dict here means "use them unchanged". Any block still present
        # in a JSON config is deliberately ignored.
        self.ms_config = {}
        # Resolved from this module's own location so the calendar is found
        # regardless of the notebook's working directory.
        self.ms_config_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "..", "config_dir"
        )
        self.ms_ctx = None
        # MSedits END MS-03

        self.use_ridge = self.config["runner_settings"]["use_ridge"]
        self.fix_iterations = self.config["runner_settings"]["fix_iterations"]
        self.lambda_denominator = self.config["runner_settings"]["lambda_denominator"]
        self.use_sign_penalty = self.config["runner_settings"]["use_sign_penalty"]
        self.use_iroas_penalty = self.config["runner_settings"]["use_iroas_penalty"]
        self.iroas_penalty_multiplier = self.config["runner_settings"]["iroas_penalty_multiplier"]
        self.apply_scaling = self.config["runner_settings"]["apply_scaling"]
        self.iroas_dev_in_loss = self.config["runner_settings"]["iroas_dev_in_loss"]
        self.handle_added_value = self.config["runner_settings"]["handle_added_value"]
        self.tactic_level_lambda_multiplier_bounds = self.config["runner_settings"]["tactic_level_lambda_multiplier_bounds"]

        self.dynamic_lambda = self.config["runner_settings"]["dynamic_lambda"]
        self.use_thresh_sat = self.config["runner_settings"]["use_thresh_sat"]
        self.ridge_penalty_weight = self.config["runner_settings"]["ridge_penalty_weight"]
        self.iroas_deviation_weight = self.config["runner_settings"]["iroas_deviation_weight"]
        self.variable_sign_penalty_weight = self.config["runner_settings"]["variable_sign_penalty_weight"]

        self.ridge_penalty_weight_wmt = self.config["runner_settings"]["ridge_penalty_weight_wmt"]
        self.iroas_deviation_weight_wmt = self.config["runner_settings"]["iroas_deviation_weight_wmt"]
        self.variable_sign_penalty_weight_wmt = self.config["runner_settings"]["variable_sign_penalty_weight_wmt"]

        self.custom_priors_manual = self.config["runner_settings"]["custom_priors_manual"]
        self.iroas_constraints = self.config["runner_settings"]["iroas_constraints"]
        self.custom_priors_manual_wmt = self.config["runner_settings"]["custom_priors_manual_wmt"]
        self.iroas_constraints_wmt = self.config["runner_settings"]["iroas_constraints_wmt"]


        self.rsq_limit = self.config["runner_settings"]["rsq_limit"]
        self.mape_limit = self.config["runner_settings"]["mape_limit"]
        self.overall_iroas_limit = self.config["runner_settings"]["overall_iroas_limit"]
        self.overall_iroas_prior = self.config["runner_settings"]["overall_iroas_prior"]
        self.onsite_iroas_prior = self.config["runner_settings"]["onsite_iroas_prior"]    
        self.search_iroas_prior = self.config["runner_settings"]["search_iroas_prior"]
        self.offsite_iroas_prior = self.config["runner_settings"]["offsite_iroas_prior"]

        self.max_iterations = self.config["runner_settings"]["max_iterations"]

        self.output_path = self.config["output_path"]
        self.use_pooled_bounds = self. config["modeling_parameters"][self.outcome]["use_pooled_bounds"]
        self.custom_s_curve_bounds = self.config["modeling_parameters"][self.outcome]["custom_s_curve_bounds"]
        self.split_dictionary = {}


    def update_essential_non_media(self, data, essential_non_media):
        xmas_thanks_exclusion = (data['D_HOL_CHRISTMAS'] == 0) & (data['D_HOL_THANKSGIVINGDAY'] == 0)
        data_temp = data.loc[xmas_thanks_exclusion]

        sales_mean = data_temp[self.outcome].mean()
        sales_std = data_temp[self.outcome].std()
        upper_bnd = sales_mean + 3*sales_std
        lower_bnd = sales_mean - 3*sales_std
        essential_media_dates = data[essential_non_media].any(axis=1)

        # Approach 1: single columns for high and low sales, lower dimensionality but may provide lesser control on fit
        # data["D_HIGH_SALES_DAYS"] = ((~essential_media_dates) & (data[self.outcome] > upper_bnd)).astype(int)
        # data["D_LOW_SALES_DAYS"] = ((~essential_media_dates) & (data[self.outcome] < lower_bnd)).astype(int)
        # if len(data["D_HIGH_SALES_DAYS"].unique()) > 1:
        #     essential_non_media.append("D_HIGH_SALES_DAYS")
        # if len(data["D_LOW_SALES_DAYS"].unique()) > 1:
        #     essential_non_media.append("D_LOW_SALES_DAYS")

        # Approach 2: separate columns based on month and year, might lead to more dimensionality but provide better control on fit
        # data_temp = data.copy()
        # data_temp["Month_Year"] = data_temp.Date.dt.to_period('M')
        # for period in data_temp["Month_Year"].unique():
        #     data_temp[f"D_HIGH_SALES_{period}"] = ((~essential_media_dates) & (data_temp["Month_Year"] == period) & (data_temp[self.outcome] > upper_bnd)).astype(int)
        #     if len(data_temp[f"D_HIGH_SALES_{period}"].unique()) > 1:
        #         essential_non_media.append(f"D_HIGH_SALES_{period}")
        #         data[f"D_HIGH_SALES_{period}"] = data_temp[f"D_HIGH_SALES_{period}"].copy()
        #
        #     data_temp[f"D_LOW_SALES_{period}"] = ((~essential_media_dates) & (data_temp["Month_Year"] == period) & (data_temp[self.outcome] < lower_bnd)).astype(int)
        #     if len(data_temp[f"D_LOW_SALES_{period}"].unique()) > 1:
        #         essential_non_media.append(f"D_LOW_SALES_{period}")
        #         data[f"D_LOW_SALES_{period}"] = data_temp[f"D_LOW_SALES_{period}"].copy()

        # Approach 3: one dedicated dummy per exact outlier DATE (finer than month-level grouping).
        # Month-level dummies force every outlier day within the same month to share a single
        # coefficient, even when their deviations differ in size -- that under-fits the sharper
        # spikes/dips and leaves residual error on the table. A per-date dummy lets each exact
        # outlier day absorb its own deviation exactly, which is what actually reduces MAPE.
        data_temp = data.copy()
        high_outlier_dates = sorted(
            data_temp.loc[(~essential_media_dates) & (data_temp[self.outcome] > upper_bnd), "Date"].unique()
        )
        low_outlier_dates = sorted(
            data_temp.loc[(~essential_media_dates) & (data_temp[self.outcome] < lower_bnd), "Date"].unique()
        )
        for d in high_outlier_dates:
            colname = f"D_HIGH_SALES_{pd.Timestamp(d).strftime('%Y-%m-%d')}"
            data[colname] = (data["Date"] == d).astype(int)
            essential_non_media.append(colname)

        for d in low_outlier_dates:
            colname = f"D_LOW_SALES_{pd.Timestamp(d).strftime('%Y-%m-%d')}"
            data[colname] = (data["Date"] == d).astype(int)
            essential_non_media.append(colname)

        return essential_non_media, data.copy()

    def load_data(self, thres_sat_dict=None, thres_dict=None, passed_sbu=None):
        # CAT WAMM : Change read_excel
        data = pd.read_csv(
            self.media_stack_path
        )

        # NEW !! 5.21 +
        data.loc[data["O_UNIT"] < 1, "O_UNIT"] = 1
        data.loc[data["O_SALE"] < 1, "O_SALE"] = 1

        # filter data based on brand_list
        self.sbu_list = sorted(list(data[~data["SBU"].isin(self.excluded_SBU)]["SBU"].unique()))
        if passed_sbu:
            self.brand_list = [passed_sbu]
            print(f"Manually passed sbu name:{passed_sbu}", "\n")
        
        data = data[data["SBU"].isin(self.sbu_list)].reset_index(drop=True)
        
        for combined_var, var_lst in self.category_tactics_to_combine.items():
            spend_var_lst = [var[:-4] + "_SPEND" for var in var_lst]
            data[combined_var] = data[var_lst].sum(axis=1)
            data[combined_var[:-4] + "_SPEND"] = data[spend_var_lst].sum(axis=1)

        self.non_media_stack = pd.read_csv(
            self.non_media_stack_path, low_memory=False
        )
        self.non_media_stack = self.non_media_stack.copy().fillna(0)

        try:

            if 'index' in data.columns:
                data["Date"] = pd.to_datetime(data["index"])
                #self.data.set_index('index', inplace=True)
            else:
                raise KeyError('Column "index" not found')
            


        except KeyError:

            if 'INDEX' in data.columns:
                data["Date"] = pd.to_datetime(data["INDEX"])
                #self.data.set_index('INDEX', inplace=True)
            else:
                raise KeyError('Neither "index" nor "INDEX" column found in the dataframe.')
        
        data.sort_values(by='Date', inplace=True)

        # data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
        #combine_social_media_metrics
        # Define the columns for impressions (IMP) and spend
        impression_columns = [
            "M_WMT_U_M_SMEDIA_PIN_USGM_National_IMP",
            "M_WMT_U_M_SMEDIA_FB_USGM_National_IMP",
            "M_WMT_U_M_SMEDIA_TW_USGM_National_IMP",
            "M_WMT_U_M_SMEDIA_SNAP_USGM_National_IMP",
            "M_WMT_U_M_SMEDIA_TIKTOK_USGM_National_IMP"
        ]
        spend_columns = [
            "M_WMT_U_M_SMEDIA_PIN_USGM_National_SPEND",
            "M_WMT_U_M_SMEDIA_FB_USGM_National_SPEND",
            "M_WMT_U_M_SMEDIA_TW_USGM_National_SPEND",
            "M_WMT_U_M_SMEDIA_SNAP_USGM_National_SPEND",
            "M_WMT_U_M_SMEDIA_TIKTOK_USGM_National_SPEND"
        ]

        # Combine the impressions and spend columns by summing them across the specified columns
        # data["M_WMT_U_M_SMEDIA_USGM_National_IMP"] = data[impression_columns].sum(axis=1, skipna=True)
        # data["M_WMT_U_M_SMEDIA_USGM_National_SPEND"] = data[spend_columns].sum(axis=1, skipna=True)
        
        self.non_media_stack["Date"] = pd.to_datetime(self.non_media_stack["Date"])  # Formatting the date

        # joining non media to the modeling stack
        # self.data = data.merge(self.non_media_stack, how="left", on="Date", sort=False).sort_values(
        #     by=["SBU", "Date"], ascending=True
        # )
        self.data = data

        self.data = self.data[(self.data['Date'] >= self.train_start) & (self.data['Date'] <= self.valid_end)]
        self.data.reset_index(inplace=True, drop=True)

        # determine media variables - splitting on the years by default 
        self.media_variables = sorted(list(set(self.media_vars) & set(list(self.data.columns))))
        self.media_variables_all = sorted(list(set(self.media_vars) & set(list(self.data.columns)))) #Later updated with splitted variables
        self.media_variables_national = sorted(list(set(self.media_vars_national) & set(list(self.data.columns)))) #Later updated with splitted variables

        # self.thres_sat_upd = thres_sat_dict 
        # self.thres_upd = thres_dict 

        # determine dummy variables
        self.dummy_var_lst = [col for col in self.data.columns if col.startswith("D_")]

        # MSedits START MS-02 : Thanksgiving safety net
        # D_HOL_THANKSGIVINGDAY_<year> ships present-but-empty in the stack, which
        # leaves the Christmas/Thanksgiving exclusion in update_essential_non_media
        # reading an all-zero column -- so it excludes nothing and the outlier
        # detector invents D_LOW_SALES_<YYYY-MM> for what is really a holiday.
        # MS-01 fixes the stack on disk; this repeats the fill in memory so a
        # regenerated stack cannot silently regress. Idempotent, so the two
        # cannot double-apply. Placed AFTER the dummy_var_lst snapshot above so
        # the candidate pool is unchanged.
        self.data, ms_tg_fill_log = fill_thanksgiving_dummies(self.data)
        for _ms_rec in ms_tg_fill_log:
            if _ms_rec["action"] == "filled":
                print(f"[MSedits MS-02] filled {_ms_rec['column']} on {_ms_rec['date']}")
            elif _ms_rec["action"] != "already_populated":
                print(f"[MSedits MS-02] {_ms_rec['column']}: {_ms_rec['action']} - {_ms_rec['detail']}")
        self.ms_thanksgiving_fill_log = ms_tg_fill_log
        # MSedits END MS-02

        # outcome_vars
        self.outcome_vars = [self.outcome]
        print(list(self.data.columns))

    def media_split(self):
        interval = 365
        nrows = len(self.data.index)
        splits = int(nrows/interval) + (nrows % interval > 0)
        # assigning the buckets to the rows 

        sequence = list(np.repeat(np.arange(1, splits+1), interval))
        # sequence.reverse()
        self.data['media_split_bucket'] = sequence[(len(sequence)-nrows):]
        
        if self.media_to_split:
            for media in self.media_to_split:
                col_name_list = []
                for bucket in self.data['media_split_bucket'].unique():
                    if "CLK" in str(media):

                        clk_col_name = str(media).replace('_CLK', '') + '_' + str(bucket) + '_CLK'
                        col_name_list.append(clk_col_name)
                        spend_col_name = str(clk_col_name).replace("CLK","SPEND")
                        self.data[clk_col_name] = 0
                        self.data[spend_col_name] = 0
                        self.data.loc[self.data['media_split_bucket']==bucket, clk_col_name] = self.data[self.data['media_split_bucket']==bucket][media]
                        self.data.loc[self.data['media_split_bucket']==bucket, spend_col_name] = self.data[self.data['media_split_bucket']==bucket][(media).replace("CLK","SPEND")]

                    else:

                        imp_col_name = str(media).replace('_IMP', '') + '_' + str(bucket) + '_IMP'
                        col_name_list.append(imp_col_name)
                        spend_col_name = str(imp_col_name).replace("IMP","SPEND")
                        self.data[imp_col_name] = 0
                        self.data[spend_col_name] = 0
                        self.data.loc[self.data['media_split_bucket']==bucket, imp_col_name] = self.data[self.data['media_split_bucket']==bucket][media]
                        self.data.loc[self.data['media_split_bucket']==bucket, spend_col_name] = self.data[self.data['media_split_bucket']==bucket][(media).replace("IMP","SPEND")]

                self.split_dictionary[media] = col_name_list
        ## Update Media with splitted variables

        if self.split_dictionary:
            self.media_variables_all = [x for x in self.media_variables_all if x not in self.split_dictionary.keys()]
            self.media_variables_all = self.media_variables_all + [media for row in self.split_dictionary.values() for media in row]
        self.media_variables_all.sort()
        self.media_variables.sort()


    def _ms_register(self, names, essential_non_media, essential_media_dict):
        """Fold rescue dummy names into ALL THREE lists (MS-08, reused by MS-14).

        essential_non_media_with_outliers is frozen before feature_selection runs
        and is the shield against VIF elimination, so a name that misses it
        silently loses protection. The rebuild loop registers on every pass, so
        this had to stop being inline.
        """
        for _ms_name in names or []:
            if _ms_name not in essential_non_media:
                essential_non_media.append(_ms_name)
            if _ms_name not in self.essential_non_media_with_outliers:
                self.essential_non_media_with_outliers.append(_ms_name)
            for _ms_sbu in essential_media_dict:
                if _ms_name not in essential_media_dict[_ms_sbu]:
                    essential_media_dict[_ms_sbu].append(_ms_name)

    def preprocess_data(self, priorCommon):
        # TODO in-progress
        outcome = self.outcome
        media_variables = self.media_variables
        media_vars_national = self.media_variables_national #National Media Base Update
        national_media_transform  = self.national_media_transform #Flag for National Media in Base
        lag_hf_media_national  = self.lag_hf_media_national #Flag for National Media in Base
        media_variables_all = self.media_variables_all
        media_to_split = self.media_to_split
        dummy_var_lst = self.dummy_var_lst #TODO : future scope
        essential_non_media = self.essential_non_media
        non_media_set = self.non_media_set
        use_pooled_bounds = self.use_pooled_bounds
        lb = self.lb
        ub = self.ub
        target_r2 = self.target_r2
        train_start = self.train_start
        train_end = self.train_end
        valid_start = self.valid_start
        valid_end = self.valid_end
        output_path = self.output_path
        outcome_vars = self.outcome_vars
        sbu_list = self.sbu_list
        thres_sat_dict = self.thres_sat_upd
        thres_dict = self.thres_upd

        print("Running WAMM Category Preprocessing & Prior Estimation")
        print(f"Outcome Type : {outcome}")
        print(f"Candidate SBUs : {sbu_list}")
        print(f"Media Variables : {media_variables}")
        print(f"Media Variables to be Split : {media_to_split}")
        print(f"All Media Variables : {media_variables_all}")
        print(f"Dummy variables : {dummy_var_lst}")
        print(f"essential_non_media_vars : {essential_non_media}")
        print(f"non_media_set : {non_media_set}")
        print(f"Training Start Date: {train_start}")
        print(f"Training End Date: {train_end}")
        print(f"Validation Start Date: {valid_start}")
        print(f"Validation End Date: {valid_end}")
        final_folder_path = create_folder_with_version(f"{output_path}/{outcome}")
        self.final_folder_path = final_folder_path
        data = self.data.copy()
        exclude_non_media = self.exclude_non_media
        national_params = {}


        if self.outlier_dummies:
            data = data[data["SBU"].isin(self.sbu_list)].reset_index(drop=True)
            essential_non_media, data = self.update_essential_non_media(
                    data, essential_non_media
                )
            print(f"updated essential_non_media_vars with dummies for outliers : {essential_non_media}", "\n")
        
        self.essential_non_media_with_outliers = essential_non_media.copy()

        # MSedits START MS-07 : build the rescue-loop context
        # feature_selection has no date parameters, but the rescue loop must
        # restrict itself to training rows (never place a dummy on a validation
        # day), so train_end is threaded in here rather than by changing that
        # signature. Returns None when the config block is absent or disabled,
        # which makes every call-site below a no-op.
        self.ms_ctx = build_ms_context(
            self.ms_config,
            data,
            train_end,
            config_dir=self.ms_config_dir,
            sbu=sbu_list[0] if sbu_list else None,
        )
        # MSedits END MS-07

        if national_media_transform:
            data, national_params = national_media_transform(data, sbu_list, outcome_vars, media_vars_national, self.custom_s_curve_bounds ,lag_hf_media_national)        #National Media Base Update
            print(f"National Media Transformed : {media_vars_national}")
            # media_vars_national = [x + '_transformed' for x in media_vars_national]
            # essential_non_media_with_nat = essential_non_media + media_vars_national
            # essential_media_dict = feature_selection(data, sbu_list, outcome_vars, essential_non_media, exclude_non_media)      #National Media Added to Essential Non Media    # MSedits MS-06 -
            essential_media_dict = feature_selection(data, sbu_list, outcome_vars, essential_non_media, exclude_non_media, ms_ctx=self.ms_ctx)      #National Media Added to Essential Non Media    # MSedits MS-06 +
        else:
            # essential_media_dict = feature_selection(data, sbu_list, outcome_vars, essential_non_media, exclude_non_media)                                                       # MSedits MS-06 -
            essential_media_dict = feature_selection(data, sbu_list, outcome_vars, essential_non_media, exclude_non_media, ms_ctx=self.ms_ctx)                                     # MSedits MS-06 +

        # MSedits START MS-08 : register rescue dummies in ALL THREE lists
        # essential_non_media_with_outliers is frozen at line 356 -- BEFORE
        # feature_selection runs -- and it is the shield against VIF elimination
        # at lite_non_media_utils_v3_Nat_Fit.py:1138/:1158. Names appended inside
        # feature_selection are therefore NOT in it. Miss this and a rescue dummy
        # silently loses its protection, or the code crashes later looking for a
        # name it only half-knows. essential_media_dict[sbu] needs no work: it is
        # derived from the refitted model's params at :231, so it already has them.
        if self.ms_ctx is not None:
            ms_new_dummies = self.ms_ctx["registry"].get("new_dummies", [])
            self._ms_register(ms_new_dummies, essential_non_media, essential_media_dict)
            if ms_new_dummies:
                print(f"[MSedits MS-08] registered rescue dummies : {ms_new_dummies}")
                self.essential_non_media = essential_non_media
            self.ms_new_dummies = ms_new_dummies
            report_rescue_summary(self.ms_ctx)                                                  # MSedits MS-11 +
            write_rescue_log(
                self.ms_ctx["registry"].get("log_records", []),
                self.ms_ctx["config"].get("log_dir") or output_path,                    # MSedits MS-13 ~
                sbu=sbu_list[0] if sbu_list else None,
            )
        else:
            self.ms_new_dummies = []
        # MSedits END MS-08

        non_media_stack = self.non_media_stack.copy()
        data_pooled = data.copy()

        ## If WMT is included in media_vars_all : WMC + WMT Model fit
        national_media_vars_lg_hf_list = []
        if self.lag_hf_media_national and national_params:
            for national_media, params in national_params.items(): 
                nat_media_idx =  self.media_variables_all.index(national_media)
                lg = params[0]
                hf = params[1]
                inf = params[2]
                sc = params[3]
                national_media_vars_lg_hf_list.append([nat_media_idx,lg,hf,inf,sc])
            national_media_vars_lg_hf_list = sorted(national_media_vars_lg_hf_list,key=lambda x : x[0])
            self.national_media_lg_hf_list = national_media_vars_lg_hf_list
        else:
            self.national_media_lg_hf_list = []
        self.wmc_media_vars = [x for x in self.media_variables_all if x not in self.national_media_vars]


        # MSedits START MS-14 : base-gated rescue loop.
        # The release criterion is about the 10 z_k bases, which only exist once
        # get_non_media_matrix has run -- so the rescue decision has to live here,
        # not inside feature_selection. Each extra pass is a FULL rebuild
        # (SARIMAX-dominated, minutes), so all three exits are checked BEFORE
        # spending one. A category that already passes costs exactly 1x.
        # feature_selection is deliberately NOT re-run: new dummy names reach the
        # bases through essential_media_dict and the D_* columns are already in
        # `data`, so rebuilding the matrix is sufficient.
        _ms_cfg = self.ms_ctx["config"] if self.ms_ctx is not None else {}
        _ms_max_passes = int(_ms_cfg.get("max_base_rebuilds", 1)) if self.ms_ctx else 1
        _ms_need = int(_ms_cfg.get("min_passing_bases", 3)) if self.ms_ctx else 0

        for _ms_pass in range(1, max(_ms_max_passes, 1) + 1):
            (
                self.pre_processed_matrix_U_kj,
                self.pre_processed_matrix_Y_kj,
                self.updated_stack,
                self.non_media_z_k,
                self.non_media_coef,
            ) = get_non_media_matrix(
                data.copy(),
                dummy_var_lst,
                essential_media_dict[sbu_list[0]],
                sbu_list,
                outcome_vars,
                non_media_set,
                train_start,
                train_end,
                valid_start,
                valid_end,
                target_r2=target_r2,
                essential_non_media_with_outliers = self.essential_non_media_with_outliers,
                ms_ctx=self.ms_ctx,                                                                 # MSedits MS-12 +
            )
            if self.ms_ctx is None:
                break

            _ms_sbu = sbu_list[0] if sbu_list else None
            _ms_n = count_passing_bases(
                self.ms_ctx["registry"].get("fit_metrics", []),
                rsq_limit=target_r2,
                mape_limit=_ms_cfg.get("mape_limit", 15.0),
            )
            print(
                f"[MSedits] {_ms_sbu} | pass {_ms_pass} | BASE GATE: {_ms_n} base(s) pass "
                f"(need {_ms_need})"
            )
            if _ms_n >= _ms_need:
                break                                   # the common case: 1x cost
            if _ms_pass >= _ms_max_passes:
                print(
                    f"[MSedits] {_ms_sbu} | pass {_ms_pass} | rebuild budget exhausted "
                    f"({_ms_max_passes}); stopping with {_ms_n} of {_ms_need}"
                )
                break
            data, _ms_added, _ms_log = run_base_rescue(
                data, self.ms_ctx, sbu=_ms_sbu, pass_no=_ms_pass
            )
            if not _ms_added:
                print(
                    f"[MSedits] {_ms_sbu} | pass {_ms_pass} | no new dummies; "
                    "another rebuild would change nothing -- stopping"
                )
                break
            self._ms_register(_ms_added, essential_non_media, essential_media_dict)
            self.ms_new_dummies = list(self.ms_ctx["registry"].get("new_dummies", []))
            print(
                f"[MSedits] {_ms_sbu} | pass {_ms_pass} | REBUILDING 10 bases "
                "(full SARIMAX pass -- slow)"
            )
        # MSedits END MS-14
        print("self.non_media_coef",self.non_media_coef)

        # MSedits START MS-09 : integrity check + release guardrail
        # Reporting only -- it does not re-loop the 10-base build, which would
        # cost 10x the OLS-chain time for the same dummy set.
        if self.ms_ctx is not None:
            _ms_missing = {}
            for _ms_sbu, _ms_bases in self.non_media_z_k.items():
                for _ms_j, _ms_vars in enumerate(_ms_bases):
                    _ms_absent = [
                        v for v in _ms_vars
                        if v != "INTERCEPT" and v not in self.updated_stack.columns
                    ]
                    if _ms_absent:
                        _ms_missing[f"{_ms_sbu}/z_{_ms_j}"] = _ms_absent
            if _ms_missing:
                print(f"[MSedits MS-09] WARNING names in non_media_z_k with no column: {_ms_missing}")
            else:
                print("[MSedits MS-09] OK every non_media_z_k name resolves to a column")

            _ms_unprotected = [
                n for n in self.ms_new_dummies
                if n not in self.essential_non_media_with_outliers
            ]
            if _ms_unprotected:
                print(f"[MSedits MS-09] WARNING rescue dummies missing VIF protection: {_ms_unprotected}")
            elif self.ms_new_dummies:
                print(f"[MSedits MS-09] OK all {len(self.ms_new_dummies)} rescue dummies are VIF-protected")

            self.ms_base_usage = {
                f"{s}/z_{j}": len([v for v in vs if v != "INTERCEPT"])
                for s, bs in self.non_media_z_k.items()
                for j, vs in enumerate(bs)
            }
            print(f"[MSedits MS-09] non-media variable count per base: {self.ms_base_usage}")

            # MSedits MS-12 : closing verdict -- what the rescue did, and whether
            # >= 5 of the 10 bases now pass. Runs here because fit_metrics only
            # exists once get_non_media_matrix has built the bases above.
            report_final_verdict(self.ms_ctx)
        # MSedits END MS-09

#       Add price column : Not needed for Category WAMM
        self.updated_stack["PRICE"] = self.updated_stack["O_SALE"] / self.updated_stack["O_UNIT"]
        self.updated_stack["PRICE"].mean()
        updated_stack = self.updated_stack.copy()

# Replicate Category Thre / Saturations

        
        # target_threshold = [12258204.01,1699.67,186675.91,148672.50,244177.68,
        # 891069.17,1622769.38,0.00,380627.63,152609.56,677417.78,29345.68,
        # 141019.19,0.00,84763.65,47754.94,93074.66,1887.07,6994.61,
        # 12955.88,10581.98,2665.58,9367.22,4646.29,295.17,0.00,0.00,0.00,0.00,0.00]

        # target_saturation = [60459808,91741,904535,1229994,1480106.493,3048103.81,8070850.834,123370.768,1272561.87
        # ,2029440.337,2285036.359,116770.102,720242.262,770419.391,470658.513
        # ,538188.645,622760.034,8619.238,45027.301,62611.26,90763.789,23923.613,48446.518
        # ,78743.153,784.391,334951,176920,63801980,56638024,82069631]

        # threshold_bounds, saturation_bounds = (
        #     get_scurve_bounds_replicate_values(data_pooled.copy(), media_variables_all, thres_sat_dict, target_threshold, target_saturation, lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
        # )

# Standard Process : Uncomment 

        if priorCommon is True:
            if use_pooled_bounds:
                threshold_bounds, saturation_bounds, target_threshold, target_saturation = (
                    get_scurve_bounds(data_pooled.copy(), media_variables, thres_sat_dict, thres_dict,lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
                )
                #Separate bounds to create separate priors_info_df for National 
                if self.media_variables_national:
                    threshold_bounds_nat, saturation_bounds_nat, target_threshold_nat, target_saturation_nat = (
                    get_scurve_bounds(data_pooled.copy(), media_vars_national, thres_sat_dict, thres_dict,lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
                )

            else:
                # Use the below commented section if you would like to use average threshold and saturation bounds
                threshold_bounds, saturation_bounds, target_threshold, target_saturation = (
                    get_scurve_bounds_v1(data.copy(), sbu_list, media_variables, lb=lb, ub=ub)
                )
                if self.media_variables_national:
                    threshold_bounds_nat, saturation_bounds_nat, target_threshold_nat, target_saturation_nat = (
                    get_scurve_bounds_v1(data.copy(), sbu_list, media_vars_national, lb=lb, ub=ub)
                )
        else:
            if use_pooled_bounds:
                threshold_bounds, saturation_bounds, target_threshold, target_saturation = (
                    get_scurve_bounds(data_pooled.copy(), media_variables_all, thres_sat_dict, thres_dict,lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
                )
                if self.media_variables_national:
                    threshold_bounds_nat, saturation_bounds_nat, target_threshold_nat, target_saturation_nat = (
                    get_scurve_bounds(data_pooled.copy(), media_vars_national, thres_sat_dict, thres_dict,lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
                )

            else:
                # Use the below commented section if you would like to use average threshold and saturation bounds
                threshold_bounds, saturation_bounds, target_threshold, target_saturation = (
                    get_scurve_bounds_v1(data.copy(), sbu_list, media_variables_all, lb=lb, ub=ub)
                )
                if self.media_variables_national:
                    threshold_bounds_nat, saturation_bounds_nat, target_threshold_nat, target_saturation_nat = (
                        get_scurve_bounds(data.copy(), media_vars_national, thres_sat_dict, thres_dict,lb=lb, ub=ub, custom_s_curve_bounds = self.custom_s_curve_bounds)
                    )


#        Spread Th, St across all splitted media variables


#        alpha_o ## The Values are placeholder static values for now : #TODO : Category knowledge base integration 
        media_iroas_prior = get_media_iroas_prior(data.copy(), sbu_list, outcome, media_variables_all, is_category=True,is_premium=False,debug_flag=False)
        if self.media_variables_national:
            media_iroas_prior_nat = get_media_iroas_prior(data.copy(), sbu_list, outcome, media_vars_national, is_category=True,is_premium=False,debug_flag=False)


#         # U_m, Sigma_m
        coef_mean_prior, coef_var_prior = get_media_coef_prior(
            updated_stack.copy(), media_iroas_prior, media_variables_all, is_premium=True
        )
        if self.media_variables_national:
            coef_mean_prior_nat, coef_var_prior_nat = get_media_coef_prior(
                updated_stack.copy(), media_iroas_prior_nat, media_vars_national, is_premium=True
            )

        print(f"media_iroas_prior : {media_iroas_prior}")
        print(f"coef_mean_prior : {coef_mean_prior}")
        print(f"coef_var_prior : {coef_var_prior}")


        priors_info_dict_1 = {}
        priors_info_dict_2 = {}
        priors_info_dict = {}
        priors_info_dict_nat = {}

        ## OnAirDays per tactic
        def get_on_air_days(data,media_vars):
            on_air_df = {}
            df_onair_list = []
            for var in media_vars:
                df_var = data[[var]].copy()
                df_var.columns = ['Raw Variable']
                on_air_df = df_var[df_var['Raw Variable'] > 0]
                df_onair_list.append(len(on_air_df))
            return df_onair_list
        
        if priorCommon is True:
            for m, var in enumerate(media_variables):
                priors_info_dict_1[var] = list(threshold_bounds[m])+list(saturation_bounds[m])+[target_threshold[m]]+[target_saturation[m]]
            for m, var in enumerate(media_variables_all):
                priors_info_dict_2[var] = [media_iroas_prior[var]] + [coef_mean_prior[m]] + [coef_var_prior[m]] 

            priors_info_df_1 = pd.DataFrame.from_dict(priors_info_dict_1, orient='index').reset_index()
            priors_info_df_1.columns = ['media_variable','threshold_lb','threshold_ub','saturation_lb','saturation_ub','target_threshold','target_saturation']

            priors_info_df_2 = pd.DataFrame.from_dict(priors_info_dict_2, orient='index').reset_index()
            priors_info_df_2.columns = ['media_variable','iroas_prior','coef_mean_prior','coef_var_prior']

            split_inverse = { v: k for k, l in self.split_dictionary.items() for v in l }
            
            priors_info_df_2['splitted_variable'] = priors_info_df_2['media_variable'].map(split_inverse)
            priors_info_df_2['splitted_variable'] = np.where(priors_info_df_2.splitted_variable.isna(), priors_info_df_2.media_variable, priors_info_df_2.splitted_variable)

            priors_info_df = pd.merge(priors_info_df_2,priors_info_df_1,left_on='splitted_variable',right_on='media_variable',how='left')
            priors_info_df.drop(['media_variable_y'],axis=1,inplace=True)
            priors_info_df.rename(columns={"media_variable_x":"media_variable"},inplace=True)
            priors_info_df['on_air_days'] = get_on_air_days(data,media_variables_all)

            print(split_inverse)
            self.split_inverse = split_inverse
            self.priors_info_df = priors_info_df.copy()
            display(self.priors_info_df)
        else:
            for m, var in enumerate(media_variables_all):
                print(var)
                priors_info_dict[var] = list(threshold_bounds[m])+list(saturation_bounds[m])+[target_threshold[m]]+[target_saturation[m]]+[media_iroas_prior[var]]+[coef_mean_prior[m]]+[coef_var_prior[m]]
            self.split_inverse = {}
            priors_info_df = pd.DataFrame.from_dict(priors_info_dict, orient='index').reset_index()
            priors_info_df.columns = ['media_variable','threshold_lb','threshold_ub','saturation_lb','saturation_ub','target_threshold','target_saturation','iroas_prior','coef_mean_prior','coef_var_prior']
            self.priors_info_df = priors_info_df.copy()
            self.priors_info_df['on_air_days'] = get_on_air_days(data,media_variables_all)

            display(self.priors_info_df)

        if self.media_variables_national: 
            for m, var in enumerate(media_vars_national):
                print(var)
                priors_info_dict_nat[var] = list(threshold_bounds_nat[m])+list(saturation_bounds_nat[m])+[target_threshold_nat[m]]+[target_saturation_nat[m]]+[media_iroas_prior_nat[var]]+[coef_mean_prior_nat[m]]+[coef_var_prior_nat[m]]
            priors_info_df_nat = pd.DataFrame.from_dict(priors_info_dict_nat, orient='index').reset_index()
            priors_info_df_nat.columns = ['media_variable','threshold_lb','threshold_ub','saturation_lb','saturation_ub','target_threshold','target_saturation','iroas_prior','coef_mean_prior','coef_var_prior']
            self.priors_info_df_nat = priors_info_df_nat.copy()
            self.priors_info_df_nat['on_air_days'] = get_on_air_days(data,media_vars_national)

            display(self.priors_info_df_nat)
        else:
            self.priors_info_df_nat = pd.DataFrame()



    def generate_panel_data(self):

        # load variables
        pre_processed_matrix_U_kj = self.pre_processed_matrix_U_kj
        pre_processed_matrix_Y_kj = self.pre_processed_matrix_Y_kj
        sbu_list = self.sbu_list
        updated_stack = self.updated_stack.copy()
        priors_info_df = self.priors_info_df.copy()
        priors_info_df_nat = self.priors_info_df_nat.copy()
        non_media_set = self.non_media_set
        final_folder_path = self.final_folder_path
        train_start = self.train_start
        train_end = self.train_end
        valid_start = self.valid_start
        valid_end = self.valid_end
        outcome = self.outcome
        media_variables_nat = self.media_variables_national
        media_variables = self.media_variables
        media_variables_all = self.media_variables_all
        split_dictionary = self.split_dictionary
        lag_hf_media_national = self.national_media_lg_hf_list
        wmc_media_vars = self.wmc_media_vars

        # MSedits START MS-15 : relax the forwarded MAPE bar if the gate was not
        # met. The rule lives in ms_dummy_selection; this is the one place the
        # value is consumed (config_jk["mape_limit"] below). A passing run, or a
        # run with the rescue disabled, leaves self.mape_limit untouched.
        _ms_strict_limit = self.mape_limit                                                  # MSedits MS-16 +
        self.mape_limit = resolve_panel_mape_limit(
            getattr(self, "ms_ctx", None), self.mape_limit
        )
        # MSedits END MS-15

        # MSedits START MS-16 : mirror that same relaxation into the
        # category_config.json this run was configured from. panel_config.json is
        # not what notebooks 03/05/06.0 read -- they re-open category_config.json
        # and filter Train_Mape on runner_settings["mape_limit"], so leaving it at
        # 15 while the panels are solved at 20 can strand a category with zero
        # surviving solutions. The gate is NOT re-evaluated here: the helper gets
        # the before/after pair MS-15 just produced, so the file cannot disagree
        # with the verdict printed above. Equal pair -> no write, which covers a
        # passing gate, a disabled rescue, an absent ms_ctx and an empty base set.
        relax_config_mape_limit(
            getattr(self, "config_file_path", None),
            _ms_strict_limit,
            self.mape_limit,
            outcome=self.outcome,
        )
        # MSedits END MS-16

        for k,sbu in enumerate(sbu_list):
    
            updated_stack_sbu = updated_stack[updated_stack["SBU"]==sbu]
            sbu_k_output_path = f"{final_folder_path}/{sbu}"
            try:
                os.mkdir(sbu_k_output_path)
                print(f"{sbu_k_output_path} created")
            except:
                print(f"{sbu_k_output_path} path already exists")
            modeling_stack_k_j_path = f"{sbu_k_output_path}/modeling_stack.csv"
            priors_info_df_path = f"{sbu_k_output_path}/priors_info.csv"
            priors_info_df_nat_path = f"{sbu_k_output_path}/priors_info_nat.csv"
            updated_stack_sbu.to_csv(modeling_stack_k_j_path)
            # media related updates
            priors_info_df.to_csv(priors_info_df_path,index=False)
            priors_info_df_nat.to_csv(priors_info_df_nat_path,index=False)
            print(f"Writing to {sbu_k_output_path}")
            for j in range(len(non_media_set)):
                sbu_k_j_output_path = f"{sbu_k_output_path}/z_{j}"
                try:
                    os.mkdir(sbu_k_j_output_path)
                    print(f"{sbu_k_j_output_path} created")
                except:
                    print(f"{sbu_k_j_output_path} path already exists")

                U_kj = pre_processed_matrix_U_kj[k][j]
                Y_kj = pre_processed_matrix_Y_kj[k][j]
                np.savetxt(f"{sbu_k_j_output_path}/U_kj.txt",U_kj)
                np.savetxt(f"{sbu_k_j_output_path}/Y_kj.txt",Y_kj)
                
                # generate config for k,j
                config_jk = {}
                config_jk['sbu_name']=sbu
                config_jk['modeling_stack_path'] = modeling_stack_k_j_path
                config_jk['priors_info_path'] = priors_info_df_path
                config_jk['priors_info_nat_path'] = priors_info_df_nat_path
                config_jk['U_kj_path']=f"{sbu_k_j_output_path}/U_kj.txt"
                config_jk['Y_kj_path']=f"{sbu_k_j_output_path}/Y_kj.txt"
                config_jk['non_media_set_idx']=j
                config_jk['outcome']=outcome
                config_jk['train_start']=train_start
                config_jk['train_end']=train_end
                config_jk['valid_start']=valid_start
                config_jk['valid_end']=valid_end
                config_jk['media_vars'] = media_variables + media_variables_nat
                config_jk["media_variables_all"] = media_variables_all + media_variables_nat
                config_jk["split_dictionary"] = split_dictionary
                config_jk["lag_hf_media_national"] = lag_hf_media_national
                config_jk["wmc_media_vars"] = wmc_media_vars
                config_jk["national_media_vars"] = media_variables_nat
                config_jk["non_media_z_k"] = self.non_media_z_k[sbu][j]
                config_jk["non_media_coef"] = self.non_media_coef[sbu][j]
                config_jk["split_inverse"] = self.split_inverse
                config_jk["wmc_portfolio_dict"] = self.wmc_portfolio_dict

                config_jk["fix_iterations"] = self.fix_iterations
                config_jk["use_ridge"] = self.use_ridge
                config_jk["lambda_denominator"] = self.lambda_denominator
                config_jk["use_sign_penalty"] = self.use_sign_penalty
                config_jk["use_iroas_penalty"] = self.use_iroas_penalty
                config_jk["iroas_penalty_multiplier"] = self.iroas_penalty_multiplier
                config_jk["apply_scaling"] = self.apply_scaling
                config_jk["iroas_dev_in_loss"] = self.iroas_dev_in_loss
                config_jk["dynamic_lambda"] = self.dynamic_lambda
                config_jk["use_thresh_sat"] = self.use_thresh_sat
                config_jk["handle_added_value"] = self.handle_added_value
                config_jk["tactic_level_lambda_multiplier_bounds"] = self.tactic_level_lambda_multiplier_bounds
                config_jk["ridge_penalty_weight"] = self.ridge_penalty_weight
                config_jk["iroas_deviation_weight"] = self.iroas_deviation_weight
                config_jk["variable_sign_penalty_weight"] = self.variable_sign_penalty_weight


                config_jk["ridge_penalty_weight_wmt"] = self.ridge_penalty_weight_wmt
                config_jk["iroas_deviation_weight_wmt"] = self.iroas_deviation_weight_wmt
                config_jk["variable_sign_penalty_weight_wmt"] = self.variable_sign_penalty_weight_wmt

                config_jk["custom_priors_manual"] = self.custom_priors_manual
                config_jk["iroas_constraints"] = self.iroas_constraints
                config_jk["custom_priors_manual_wmt"] = self.custom_priors_manual_wmt
                config_jk["iroas_constraints_wmt"] = self.iroas_constraints_wmt
                config_jk["rsq_limit"] = self.rsq_limit
                config_jk["mape_limit"] = self.mape_limit
                config_jk["max_iterations"] = self.max_iterations


                with open(f'{sbu_k_j_output_path}/panel_config.json', 'w') as fp:
                    json_dumps_str = json.dumps(config_jk, indent=4)
                    print(json_dumps_str, file=fp)
        print(f"Premium preprocessing results saved to : {final_folder_path}")
        print("Final set of sbus: ",self.sbu_list)
        return f"{self.sbu_list} :: {final_folder_path.split('_v')[1]} "


class CategoryEDA:
    def __init__(
        self,
        media_stack_path,
        non_media_stack_path,
        prior_info_path,
        sbu,
        media_vars,
        wmt_vars,
        outcome_var
    ):
        
        self.media_stack_path = media_stack_path
        self.non_media_stack_path = non_media_stack_path
        self.prior_info_path = prior_info_path
        self.sbu = sbu
        self.outcome_var = outcome_var
        self.config_eda = {}
        self.airflow_config = {}
        self.brand_exclude_non_media = {}

        
        self.exclude_non_media = [
                "D_HOL_THANKSGIVING_DAY",  # based on knowledge base stacks
                "D_HOL_CHRISTMAS_DAY",  # based on knowledge base stacks
                "D_HOL_THANKSGIVING",
                "D_HOL_CHRISTMAS",
                "D_DAY_MONDAY",
                "D_DAY_TUESDAY",
                "D_DAY_WEDNESDAY",
                "D_DAY_THURSDAY",
                "D_DAY_FRIDAY"
            ]
        
        self.non_media_set = [0,1,2,3,4,5,6,7,8,9]
        self.use_pooled_bounds = True
        
        self.data = pd.read_csv(self.media_stack_path, low_memory=False)

        try:

            if 'index' in self.data.columns:
                self.data["Date"] = pd.to_datetime(self.data["index"])
                #self.data.set_index('index', inplace=True)
            else:
                raise KeyError('Column "index" not found')
            


        except KeyError:

            if 'INDEX' in self.data.columns:
                self.data["Date"] = pd.to_datetime(self.data["INDEX"])
                #self.data.set_index('INDEX', inplace=True)
            else:
                raise KeyError('Neither "index" nor "INDEX" column found in the dataframe.')
            
        self.data["SBU"] = self.sbu[0]
        self.data.sort_values(by='Date', inplace=True)
        
        
        self.target_r2 = 0.75
        self.target_mape = 15
        self.overall_iroas_limit = 1.5
        self.overall_iroas_prior = 1.5
        self.onsite_iroas_prior = 1.5
        self.offsite_iroas_prior = 1.5
        self.search_iroas_prior = 2.0


        self.output_path = "../data/category_processed_input"
        self.output_path_eda = "../data/EDA_output"
        
        
        self.default_tactic_combinations = {}#default_tactic_combinations

        self.common_media_vars =  category_media_variables

        self.channel_variables_wmc = category_channel_variables
        self.media_variables_wmt = wmt_vars

        self.national_media_vars_lg_hf = {}
        for i in self.media_variables_wmt:
            self.national_media_vars_lg_hf[i] = [0,0]

        
        self.media = sorted(list(set(self.common_media_vars + media_vars)))
        #self.media = sorted(list(set(media_vars)))
        
    def get_brand_tactics(self, brand):

        # print(f"*********{brand}*********")
        self.brand_tactics = []
        df_brand = self.data[self.data["SBU"] == brand].copy()
        for i in df_brand.columns:

            if i in self.media:
                self.brand_tactics.append(i)

        return self.brand_tactics


    def extract_media_columns(self, df):

        media_variables_all = [i for i in df.columns if (i.startswith("M_") & (i.endswith("_CLK") or (i.endswith("_IMP"))))]
        media_variables_non_wmc = [i for i in media_variables_all if ((i.startswith("M_WMT")) or (i.startswith("M_S") & i.endswith("_IMP")))]
        media_variables_wmc = list(set(media_variables_all) - set(media_variables_non_wmc) - set(['M_SEARCH_CLK', 'M_TOTAL_DISPLAY_IMP', 'M_ON_DIS_TOTAL_IMP', 'M_OFF_DIS_TOTAL_IMP', 'M_OFF_DIS_SMEDIA_IMP', 'M_SP_CLK', 'M_ON_DIS_OTHERS_IMP', 'M_OFF_DIS_WN_IMP']))

        channel_variables_wmc = ['M_SEARCH_CLK','M_ON_DIS_TOTAL_IMP', 'M_OFF_DIS_TOTAL_IMP']

        media_variables_wmt = ["M_WMT_AFFILIATES_SEM_USGM_L1_CLK",

                "M_WMT_U_M_DIGITAL_USGM_National_IMP",
                "M_WMT_U_M_SMEDIA_USGM_National_IMP",
                "M_WMT_U_M_TV_RADIO_USGM_National_IMP"]

        return channel_variables_wmc, media_variables_wmc, media_variables_wmt

    def get_yoy_time_periods(self, train_start_date, train_end_date):
        # Convert date to datetime if it's not already
        train_start_date = pd.to_datetime(train_start_date)
        train_end_date = pd.to_datetime(train_end_date)

        # Calculate the total number of months between the start and end dates
        total_months = (train_end_date.year - train_start_date.year) * 12 + (
            train_end_date.month - train_start_date.month
        )

        if total_months >= 24:
            # Period 2: Latest 12 months

            period_2_start = (
                train_end_date - pd.DateOffset(months=12) + pd.DateOffset(days=1)
            )
            # Period 1: Previous 12 months
            period_1_end = period_2_start - pd.DateOffset(days=1)
            period_1_start = (
                period_1_end - pd.DateOffset(months=12) + pd.DateOffset(days=1)
            )
        else:
            # Less than 24 months, split the dataset in half
            total_days = (train_end_date - train_start_date).days
            half_days = total_days // 2
            mid_date = train_start_date + pd.Timedelta(days=half_days)
            # Period 2: From mid_date to train_end_date
            period_2_start = mid_date
            # Period 1: From start_date to mid_date - 1 day
            period_1_start = train_start_date
            period_1_end = period_2_start - pd.DateOffset(days=1)

        YoY_comparison = {           
                            "1": {
                                "start_date": train_start_date.strftime("%Y-%m-%d"),
                                "end_date": train_end_date.strftime("%Y-%m-%d"),
                                "Period": "Modeling period"
                            },
                            "2": {
                                "start_date": period_2_start.strftime("%Y-%m-%d"),
                                "end_date": train_end_date.strftime("%Y-%m-%d"),
                                "Period": "Latest 12 months"
                            },
                            "3": {
                                "start_date": period_1_start.strftime("%Y-%m-%d"),
                                "end_date": period_1_end.strftime("%Y-%m-%d"),
                                "Period": "Previous 12 months"
                            }
                        }
        
        return YoY_comparison

    def train_valid_date(self, brand, output):

        brand_essential_vars = []
        df_brand = self.data[self.data["SBU"] == brand].copy()
        try:
            df_brand["Date"] = pd.to_datetime(df_brand["Date"], format="mixed")
        except:
            print("Mixed format not working. Dropping format=mixed")
            df_brand["Date"] = pd.to_datetime(df_brand["Date"])
        max_date = df_brand["Date"].max()
        min_date = max_date - pd.DateOffset(months=32)
        train_start = df_brand["Date"].min()#max_date - pd.DateOffset(months=32) + pd.DateOffset(days=1)
                
        diff = (max_date - min_date).days

        # if diff > 729:
        valid_end = df_brand["Date"].max()
        valid_start = valid_end - pd.DateOffset(months=3)
        train_end = df_brand["Date"].max()

        YoY_comparison = self.get_yoy_time_periods(train_start, train_end)

        start_year = train_start.year
        end_year = train_end.year

        for i in range(start_year, end_year + 1):

            if train_end >= pd.to_datetime(f"{i}-11-28"):
                brand_essential_vars.append(f"D_HOL_THANKSGIVING_{i}")
            if train_end >= pd.to_datetime(f"{i}-12-25"):
                brand_essential_vars.append(f"D_HOL_CHRISTMAS_{i}")

        brand_essential_vars = brand_essential_vars + [
            "D_DAY_SUNDAY",
            "D_DAY_SATURDAY",
        ]

        brand_period = {
            "train_start": train_start.strftime("%Y-%m-%d"),
            "train_end": train_end.strftime("%Y-%m-%d"),
            "valid_start": valid_start.strftime("%Y-%m-%d"),
            "valid_end": valid_end.strftime("%Y-%m-%d"),
        }

        if (
            pd.to_datetime(brand_period["train_end"])
            - pd.to_datetime(brand_period["train_start"])
        ).days < 729:
            print(
                "\nWARNING!!! Less than 2 years worth of training data, add more data if possible",
                file=output,
            )

        elif (
            pd.to_datetime(brand_period["valid_end"])
            - pd.to_datetime(brand_period["train_start"])
        ).days <= 729:
            print(
                "\nWARNING!!! Not enough data for validation, add more data if possible",
                file=output,
            )

        return brand_period, brand_essential_vars, YoY_comparison

    def check_spend(self, data, media_vars, output, verbose=False):

        tactics_to_drop = []
        df_brand = data
        # all_tactics = [m for m in media_vars if ("M_NAT" not in m and "M_WMT" not in m)]
        all_tactics = media_vars
        print(f"\n\tSPEND ANALYSIS:\n", file=output)
        for m in all_tactics:
            spend_var = m[:-4] + "_SPEND"
            tactic_spend = df_brand[spend_var].sum()
            if tactic_spend == 0.0:
                print(f"\t{m} spend is zero and will be dropped", file=output)
                tactics_to_drop.append(m)

        return tactics_to_drop

    def check_on_air_days(self, data, media_vars, cpd_tactics, output, verbose=False):

        tactics_to_combine = []
        tactics_to_drop = []
        df_brand = data
        all_tactics = [m for m in media_vars if ("M_NAT" not in m and "M_WMT" not in m)]
        non_zero_data = df_brand.replace(0, np.nan)
        print(f"\n\tON-AIR DAYS ANALYSIS:\n", file=output)
        for m in all_tactics:
            spend_var = m[:-4] + "_SPEND"
            non_zero_values_media = df_brand[m][
                np.logical_and(df_brand[m] != 0, np.isnan(df_brand[m]) == False)
            ]
            non_zero_values_spend = df_brand[spend_var][
                np.logical_and(df_brand[m] != 0, np.isnan(df_brand[m]) == False)
            ]
            on_air_media = int(non_zero_values_media.shape[0])
            on_air_spend = int(non_zero_values_spend.shape[0])

            if (on_air_media > on_air_spend) and (on_air_media != on_air_spend):
                print(
                    f"\t{m} had {on_air_media-on_air_spend} days as added value and needs to be taken care of in modeling",
                    file=output,
                )
            if on_air_media == 0:
                print(
                    f"\t***ALERT*** {m} was on-air for 0 days but we have non-zero spend!",
                    file=output,
                )
                tactics_to_drop.append(m)
            elif on_air_media <= 9:# and m not in cpd_tactics:
                print(
                    f"\t{m} was on-air only for {on_air_media} days and hence will be dropped",
                    file=output,
                )
                tactics_to_drop.append(m)

        return tactics_to_combine, tactics_to_drop

    def check_corr(self, data, media_vars, output):

        tactics_to_combine = []
        df_brand = data
        all_tactics = [m for m in media_vars if "M_NAT" not in m]
        corr_mat = df_brand[all_tactics].corr().abs()
        upper_corr_mat = corr_mat.where(
            np.triu(np.ones(corr_mat.shape), k=1).astype(bool)
        )

        print(f"\n\tCORRELATION ANALYSIS:\n", file=output)
        unique_corr_pairs = upper_corr_mat.unstack().dropna()
        sorted_mat = unique_corr_pairs.sort_values()
        for index, value in sorted_mat.items():
            if value > 0.8:
                print(
                    f"\tCorrelation between {index[0]} & {index[1]} is more than 80% and hence could be combined",
                    file=output,
                )
                tactics_to_combine.append(index[0])
                tactics_to_combine.append(index[1])

        return list(set(tactics_to_combine))
    
    def find_outliers(self, brand, output):

        df = self.data[self.data["SBU"] == brand].copy()
        df = df.drop(['11/24/22', '11/23/23','12/25/22','12/25/23'], inplace=True)
        #df.index = pd.to_datetime(category_stack_3.index)
        # fig, ax = plt.subplots(figsize=(15,6))
        # ax.plot(df.index, df['O_UNIT'], '-r')
        # ax.legend(loc='upper right')
        # plt.show()
        upper_limit=df['O_UNIT'].mean()+3*df['O_UNIT'].std()
        lower_limit=df['O_UNIT'].mean()-3*df['O_UNIT'].std()
        if len(df[(df['O_UNIT']>=upper_limit)].index)>0:
            print(f'Consider adding dummies for {df[(df["O_UNIT"]>=upper_limit)].index}', file=output)
        if len(df[(df['O_UNIT']<=lower_limit)].index)>0:
            print(f'Consider adding dummies for {df[(df["O_UNIT"]<=lower_limit)].index}', file=output)

    def check_tactic_comb(self, var_list):
        if (
            all(map(lambda x: x.endswith("_IMP"), var_list))
            or all(map(lambda x: x.endswith("_CLK"), var_list))
        ) and (
            all(map(lambda x: x.startswith("M_ON"), var_list))
            or all(map(lambda x: x.startswith("M_OFF"), var_list))
            or all(map(lambda x: x.startswith("M_S"), var_list))
            or all(map(lambda x: x.startswith("M_NAT"), var_list))
            or all(map(lambda x: x.startswith("M_WMT"), var_list))
        ):
            return True
        else:
            return False

    def combine_tactics(self, output, brand):

        brand_tactics_to_combine = {}

        media_vars = self.brand_tactics
        print(f"\t\t\t\t*******{brand}*******", file=output)

        brand_period, brand_essential_vars, YoY_comparison = self.train_valid_date(
            brand, output
        )

        df_brand = self.data[self.data["SBU"] == brand].copy()

        onsite_tactics = [m for m in media_vars if m.startswith("M_ON")]
        onsite_tactics = [m for m in onsite_tactics if m not in category_cpd_variables]
        offsite_tactics = [m for m in media_vars if m.startswith("M_OFF")]
        search_tactics = [m for m in media_vars if m.endswith("_CLK")]
        cpd_tactics = [m for m in media_vars if m in category_cpd_variables]

        print(f"\nFINDINGS:", file=output)

        tactics_to_drop_spend = self.check_spend(df_brand, media_vars, output)
        media_vars = [m for m in media_vars if m not in tactics_to_drop_spend]

        tactics_to_combine_on_air, tactics_to_drop_on_air = self.check_on_air_days(
            df_brand, media_vars, cpd_tactics, output
        )
        media_vars = [m for m in media_vars if m not in tactics_to_drop_on_air]
        initial_brand_tactics = sorted(media_vars)
        print(f"\n\tInitial set of media variables: {media_vars}\n", file=output)
        tactics_to_combine_corr = self.check_corr(df_brand, media_vars, output)
        print(f"\nACTIONS:\n", file=output)

        potential_tactics_to_combine = sorted(
            list(set(tactics_to_combine_on_air + tactics_to_combine_corr))
        )
        tactic_combinations = {}

        final_media_vars = media_vars.copy()

        for tactic_to_combine in potential_tactics_to_combine:
            if (tactic_to_combine in self.default_tactic_combinations.keys()) and (
                tactic_to_combine not in tactic_combinations.values()
            ):
                for tactic_pair in self.default_tactic_combinations[tactic_to_combine]:
                    if (tactic_pair in final_media_vars) and (
                        tactic_to_combine in final_media_vars
                    ):
                        tactic_combinations[tactic_to_combine] = tactic_pair

                        var_lst = sorted([tactic_to_combine, tactic_pair])
                        i = var_lst[0]
                        j = var_lst[1]

                        if not "CLK" in i:
                            if j == "M_ON_DIS_OPD_HP_IMP":
                                final_tactic_name = (
                                    i[:-8]
                                    + "_"
                                    + j.split("_")[-4:][0]
                                    + "_"
                                    + j.split("_")[-4:][1]
                                    + "_"
                                    + j.split("_")[-4:][2]
                                    + "_"
                                    + j.split("_")[-4:][3]
                                )
                            else:
                                final_tactic_name = (
                                    i[:-4]
                                    + "_"
                                    + j.split("_")[-2:][0]
                                    + "_"
                                    + j.split("_")[-2:][1]
                                    # + "_"
                                    # + j.split("_")[-3:][2]
                                )
                        else:

                            if j == "M_SP_VIDEO_CLK":

                                final_tactic_name = (
                                    i[:-4]
                                    + "_"
                                    + j.split("_")[-3:][0]
                                    + "_"
                                    + j.split("_")[-3:][1]
                                    + "_"
                                    + j.split("_")[-3:][2]
                                )
                            else:
                                final_tactic_name = (
                                    i[:-4]
                                    + "_"
                                    + j.split("_")[-2:][0]
                                    + "_"
                                    + j.split("_")[-2:][1]
                                )                                             
                        brand_tactics_to_combine[final_tactic_name] = [i, j]

                        final_media_vars.remove(i)
                        final_media_vars.remove(j)
                        final_media_vars.append(final_tactic_name)
                        print(
                            f"\t{i} was combined with {j} to form {final_tactic_name}",
                            file=output,
                        )

        # for priority_combinations in permissible_tactic_combinations["priority_1"]:
        #     if set(priority_combinations) <= set(final_media_vars):
        #         i = priority_combinations[0]
        #         j = priority_combinations[1]

        #         final_tactic_name = (
        #             i[:-4] + "_" + j.split("_")[-2:][0] + "_" + j.split("_")[-2:][1]
        #         )
        #         brand_tactics_to_combine[final_tactic_name] = [i, j]

        #         final_media_vars.remove(i)
        #         final_media_vars.remove(j)
        #         final_media_vars.append(final_tactic_name)
        #         print(
        #             f"\t{i} was combined with {j} to form {final_tactic_name} as a benchmark recommendation",
        #             file=output,
        #         )

        # Always combine M_ON_DIS_APP_HPLO_IMP and M_ON_DIS_HPLO_IMP if both are present
        if "M_ON_DIS_APP_HPLO_IMP" in final_media_vars and "M_ON_DIS_HPLO_IMP" in final_media_vars:
            i = "M_ON_DIS_APP_HPLO_IMP"
            j = "M_ON_DIS_HPLO_IMP"
            final_tactic_name = "M_ON_DIS_APP_HPLO_HPLO_IMP"
            
            brand_tactics_to_combine[final_tactic_name] = [i, j]
            final_media_vars.remove(i)
            final_media_vars.remove(j)
            final_media_vars.append(final_tactic_name)
            print(
                f"\t{i} was combined with {j} to form {final_tactic_name}",
                file=output,
            )

        print(
            f"\n\tTactics that could not be combined :{list(set(potential_tactics_to_combine).intersection(set(final_media_vars)))}\n",
            file=output,
        )

        print(f"\n\tFinal set of media variables: {final_media_vars}\n", file=output)
        updated_brand_tactics = sorted(final_media_vars)

        #self.find_outliers(brand, output)

        return (
            brand_tactics_to_combine,
            updated_brand_tactics,
            initial_brand_tactics,
            # sorted(common_media_vars),
            brand_period,
            brand_essential_vars,
            YoY_comparison,
        )

    def generate_media_summary(self, brand_tactics, brand, channel_plots = True):

        final_df = pd.DataFrame()
        result = pd.DataFrame()
        df_brand = self.data.copy()

        for col in brand_tactics:
            if col not in df_brand.columns:
                print(col)
                var_lst = self.brand_tactics_to_combine[brand][col]
                spend_var_lst = [var[:-4] + "_SPEND" for var in var_lst]

                df_brand[col] = df_brand[var_lst].sum(axis=1)
                df_brand[col[:-4] + "_SPEND"] = df_brand[spend_var_lst].sum(axis=1)

            non_zero_values = df_brand[col][
                np.logical_and(df_brand[col] != 0, np.isnan(df_brand[col]) == False)
            ]
            if non_zero_values.shape[0] != 0:
                min_val = int(non_zero_values.min())
                q1 = int(non_zero_values.quantile(0.25))
                median = int(non_zero_values.median())
                q3 = int(non_zero_values.quantile(0.75))
                max_val = int(non_zero_values.max())
                mean = int(non_zero_values.mean())
                std = round(non_zero_values.std(), 2)
                on_air = int(non_zero_values.shape[0])
                if "IMP" in col:
                    tp = col.replace("IMP", "SPEND")
                elif "CLK" in col:
                    tp = col.replace("CLK", "SPEND")
                total_spend = int(df_brand[tp].sum())
                total_imp_clk = int(df_brand[col].sum())
                try:
                    result = result._append(
                        pd.DataFrame(
                            {
                                "SBU": [brand],
                                "Media_tactic": [col],
                                "Total_spend": [total_spend],
                                "On_Air_Days": [on_air],
                                "Total_IMP/CLK": [total_imp_clk],
                                "Min_IMP/CLK": [min_val],
                                "Q1_IMP/CLK": [q1],
                                "Mean_IMP/CLK": [mean],
                                "Median_IMP/CLK": [median],
                                "Q3_IMP/CLK": [q3],
                                "Max_IMP/CLK": [max_val],
                                "Std_IMP/CLK": [std],
                            }
                        ),
                        ignore_index=True,
                    )
                except:
                    result = result.append(
                        pd.DataFrame(
                            {
                                "SBU": [brand],
                                "Media_tactic": [col],
                                "Total_spend": [total_spend],
                                "On_Air_Days": [on_air],
                                "Total_IMP/CLK": [total_imp_clk],
                                "Min_IMP/CLK": [min_val],
                                "Q1_IMP/CLK": [q1],
                                "Mean_IMP/CLK": [mean],
                                "Median_IMP/CLK": [median],
                                "Q3_IMP/CLK": [q3],
                                "Max_IMP/CLK": [max_val],
                                "Std_IMP/CLK": [std],
                            }
                        ),
                        ignore_index=True,
                    )                    

        result.dropna(how="all", inplace=True)
        result = result.sort_values("Total_spend", ascending=False)
        result.reset_index(inplace=True, drop=True)
        display(result)
        try:
            final_df._append(result, ignore_index=True)
        except:
            final_df.append(result, ignore_index=True)

        # add summary for outcome variables
        #display(df_brand[[self.outcome_var, "O_SALE"]].describe().astype(int).T)
        self.generate_media_plots(brand, result, channel_plots=channel_plots)

        return result

    def generate_media_plots(self, brand, final_summary_df, channel_plots = True):

        df_brand = self.data.copy()
        try:
            df_brand["Date"] = pd.to_datetime(df_brand["Date"], format="mixed")
        except:
            print("Mixed format not working. Dropping format=mixed")
            df_brand["Date"] = pd.to_datetime(df_brand["Date"])

        for tactic in final_summary_df.Media_tactic.values:

            if tactic not in df_brand.columns:

                var_lst = self.brand_tactics_to_combine[brand][tactic]
                spend_var_lst = [var[:-4] + "_SPEND" for var in var_lst]

                df_brand[tactic] = df_brand[var_lst].sum(axis=1)
                df_brand[tactic[:-4] + "_SPEND"] = df_brand[spend_var_lst].sum(axis=1)

            # plt.figure(figsize=(10,6))
            spend_var = tactic[:-4] + "_SPEND"
            # print(spend_var)
            df_tactic = df_brand[["Date", "SBU", tactic, spend_var]]
            fig, ax1 = plt.subplots(figsize=(15, 6))
            ax_twin = ax1.twinx()
            df_tactic.reset_index(inplace=True, drop=True)
            ax_twin.plot(
                df_tactic["Date"],
                df_tactic[spend_var],
                label="Spend",
                linestyle="--",
                color="b",
                alpha=0.5,
            )
            ax1.plot(
                df_tactic["Date"],
                df_tactic[tactic],
                label="IMP/CLK",
                linestyle="-",
                color="r",
            )

            ax1.legend(loc="upper left")
            ax_twin.legend(loc="upper right")

            # sns.lineplot(data=df_tactic, x="Date", y=m, hue="BRAND")
            # sns.lineplot(data=df_tactic, x="Date", y=spend_var, hue="BRAND", color='r')

            plt.title(f"{brand} : {tactic} pacing")
            plt.show()

        # show outcomes
        if channel_plots:
            for outcome_type in [self.outcome_var, "O_SALE"]:

                df_outcome = df_brand[["Date", "SBU", outcome_type]]
                fig, ax1 = plt.subplots(figsize=(15, 6))
                ax_twin = ax1.twinx()
                df_outcome.reset_index(inplace=True, drop=True)
                ax1.plot(
                    df_outcome["Date"],
                    df_outcome[outcome_type],
                    label=outcome_type,
                    linestyle="-",
                    color="b",
                )

                ax1.legend()

                plt.title(f"{brand} : {outcome_type} pacing")
                plt.show()

    def get_scurve_bounds_eda(self, brand):

        custom_s_curve_bounds = {}
        brand_tactics = self.updated_brand_tactics[brand]
        for tactic in brand_tactics:
            if brand not in self.custom_scurve or (
                tactic not in self.custom_scurve[brand]
            ):
                lb = 0.05
                ub = 0.95
                custom_s_curve_bounds[tactic] = [lb, ub]
            else:
                custom_s_curve_bounds[tactic] = self.custom_scurve[brand][tactic]

        return custom_s_curve_bounds

    def get_thresh_sat_dict(self, brand):

        thresh_sat_dict = {}
        df_brand = self.data[self.data["BRAND"] == brand].copy()

        brand_tactics = self.updated_brand_tactics[brand]
        for tactic in brand_tactics:
            if tactic not in df_brand.columns:
                var_lst = self.brand_tactics_to_combine[brand][tactic]
                df_brand[tactic] = df_brand[var_lst].sum(axis=1)

            if self.custom_sat_bounds:
                sat_inflate_fact = 1.0
                non_zero_values = df_brand[tactic][
                    np.logical_and(
                        df_brand[tactic] != 0, np.isnan(df_brand[tactic]) == False
                    )
                ]
                thre = int(non_zero_values.quantile(0.05))
                sat = int(non_zero_values.quantile(0.95) * sat_inflate_fact)
                avg_media = int(non_zero_values.mean())
                max_inc = (2 * 2 * avg_media - 0.9 * thre) / sat

                if (max_inc - 1) > 0:
                    thresh_sat_dict[tactic] = [0.1, round(max_inc - 1, 2)]
                else:
                    thresh_sat_dict[tactic] = [0.5, 0.1]
            else:

                thresh_sat_dict[tactic] = [0.75, 0.75]

        return thresh_sat_dict


    def get_iroas_priors(self, excel_file_path):
        """
        Get iRoAS priors for each tactic based on historical data.
        
        Parameters:
        -----------
        excel_file_path : str
            Path to Excel file with sheets:
            - 'Category_Mapping': columns L0, L1, L2, L3, L4, Category
            - 'Prior_Info': columns L0, L1, L2, L3, L4, variable_name, iRoAs, Model delivery date
            
        Returns:
        --------
        tuple : A tuple containing two dictionaries:
            - tactic_iroas_priors: Dictionary mapping media tactic names to their median iRoAS values
            - channel_iroas_priors: Dictionary mapping channel names to their median iRoAS values
        """
        
        # Load category mapping schema from Excel sheet
        category_mapping = pd.read_excel(excel_file_path, sheet_name='Category_Mapping')
        
        # Load iRoAS historical data from Excel sheet
        iroas_data = pd.read_excel(excel_file_path, sheet_name='Prior_Info')
        
        # Find the mapping information for this SBU
        sbu_mapping = category_mapping[category_mapping['Category'] == self.sbu[0]]
        
        if sbu_mapping.empty:
            print(f"Warning: No mapping found for SBU '{self.sbu[0]}' in category mapping file")
            return {},{}
        
        # Get the hierarchy information
        sbu_info = sbu_mapping.iloc[0]
        hierarchy = {
            'SBU': sbu_info.get('SBU'),
            'L1': sbu_info.get('L1'),
            'L2': sbu_info.get('L2'),
            'L3': sbu_info.get('L3'),
            'L4': sbu_info.get('L4')
        }
        
        print(f"\nCategory Hierarchy for {self.sbu[0]}:")
        print(f"  SBU: {hierarchy['SBU']}")
        print(f"  L1: {hierarchy['L1']}")
        print(f"  L2: {hierarchy['L2']}")
        print(f"  L3: {hierarchy['L3']}")
        print(f"  L4: {hierarchy['L4']}")
        
        # Dictionary to store iRoAS priors
        tactic_iroas_priors = {}
        channel_iroas_priors = {}
        
        # For each tactic, find the median iRoAS
        for tactic in self.updated_brand_tactics:
            median_iroas = None
            
            # Try filtering from L4 down to SBU
            for level in ['L4', 'L3', 'L2', 'L1', 'SBU']:
                if pd.isna(hierarchy[level]) or hierarchy[level] == '':
                    continue
                
                # Build hierarchical filter from SBU down to current level
                all_levels = ['SBU', 'L1', 'L2', 'L3', 'L4']
                current_level_idx = all_levels.index(level)
                
                # Start with tactic filter
                filter_condition = (iroas_data['variable_name'] == tactic)
                
                # Check all levels from SBU down to current level - exact match only
                for check_level in all_levels[:current_level_idx + 1]:
                    if not (pd.isna(hierarchy[check_level]) or hierarchy[check_level] == ''):
                        # Exact match required - no wildcards
                        level_matches = (iroas_data[check_level] == hierarchy[check_level])
                        filter_condition = filter_condition & level_matches
                
                filtered_data = iroas_data[filter_condition]
                
                if not filtered_data.empty and 'iRoAS' in filtered_data.columns:
                    # Calculate median iRoAS and round to 2 decimal places
                    median_iroas = round(filtered_data['iRoAS'].median(), 2)
                    break
            
            # Store the result with proper rounding
            if median_iroas is not None:
                tactic_iroas_priors[tactic] = round(median_iroas, 2)
            else:
                # Default value if no data found at any level, rounded to 2 decimal places
                tactic_iroas_priors[tactic] = round(1.5, 2)
        
        # Extract channel-level priors
        channel_tactics = ["Offsite Display", "Onsite Display", "Overall", "Sponsored Products"]
        
        for channel in channel_tactics:
            median_iroas = None
            
            # Try filtering from L4 down to SBU
            for level in ['L4', 'L3', 'L2', 'L1', 'SBU']:
                if pd.isna(hierarchy[level]) or hierarchy[level] == '':
                    continue
                
                # Build hierarchical filter from SBU down to current level
                all_levels = ['SBU', 'L1', 'L2', 'L3', 'L4']
                current_level_idx = all_levels.index(level)
                
                # Start with channel filter
                filter_condition = (iroas_data['variable_name'] == channel)
                
                # Check all levels from SBU down to current level - exact match only
                for check_level in all_levels[:current_level_idx + 1]:
                    if not (pd.isna(hierarchy[check_level]) or hierarchy[check_level] == ''):
                        # Exact match required - no wildcards
                        level_matches = (iroas_data[check_level] == hierarchy[check_level])
                        filter_condition = filter_condition & level_matches
                
                filtered_data = iroas_data[filter_condition]
                
                if not filtered_data.empty and 'iRoAS' in filtered_data.columns:
                    # Calculate median iRoAS and round to 2 decimal places
                    median_iroas = round(filtered_data['iRoAS'].median(), 2)
                    break
            
            # Store the result with proper rounding
            if median_iroas is not None:
                channel_iroas_priors[channel] = round(median_iroas, 2)
            else:
                # Default value if no data found at any level, rounded to 2 decimal places
                channel_iroas_priors[channel] = round(1.5, 2)
        
        return tactic_iroas_priors, channel_iroas_priors

    def generate_common_config_params(self, sbu, config_eda={}):
        # config_eda["modeler_email"] = self.modeler_email
        # config_eda["modeler"] = self.modeler
        # config_eda["test_version"] = self.test_version
        # config_eda["config_version"] = self.test_version_local
        # config_eda["repo_branch"] = self.repo_branch
        config_eda["media_stack_path"] = self.media_stack_path
        config_eda["non_media_stack_path"] = self.non_media_stack_path
        #config_eda["brand_list"] = self.brand_list

        # if self.airflow_run:
        #     # we need this nomenclature for airflow
        #     config_eda["media_stack_path"] = (
        #         "../data/processed_input_data/modeling_stack.csv"
        #     )
        #     config_eda["non_media_stack_path"] = (
        #         "../data/processed_input_data/nonmedia_stack.csv"
        #     )
        config_eda["output_path"] = self.output_path
        config_eda["outcome_var"] = self.outcome_var
        # config_eda["use_ridge"] = True
        # config_eda["fix_iterations"] = True

        config_eda["runner_settings"] = {}

        # config_eda["runner_settings"]["use_ridge"] = self.use_ridge
        # config_eda["runner_settings"]["use_sign_penalty"] = self.use_sign_penalty
        # config_eda["runner_settings"]["handle_added_value"] = self.handle_added_value
        # config_eda["runner_settings"]["use_iroas_penalty"] = self.use_iroas_penalty
        # config_eda["runner_settings"]["fix_iterations"] = self.fix_iterations
        # config_eda["runner_settings"]["iroas_dev_in_loss"] = self.iroas_dev_in_loss

        # config_eda["runner_settings"][
        #     "iroas_penalty_multiplier"
        # ] = self.iroas_penalty_multiplier
        # config_eda["runner_settings"]["max_iterations"] = self.max_iterations
        # config_eda["runner_settings"]["lambda_k"] = self.lambda_k
        # config_eda["runner_settings"]["custom_priors_manual"] = {}
        # config_eda["runner_settings"]["iroas_constraints"] = {}
        # config_eda["runner_settings"]["rsq_limit"] = self.target_r2
        # config_eda["runner_settings"]["mape_limit"] = self.target_mape

        # config_eda["runner_settings"]["valid_r2_limit"] = self.target_valid_r2
        # config_eda["runner_settings"]["valid_mape_limit"] = self.target_valid_mape
        # config_eda["runner_settings"]["overall_iroas_limit"] = self.overall_iroas_limit
        # config_eda["runner_settings"]["use_lambda_cv"] = self.use_lambda_cv
        # config_eda["runner_settings"]["use_scaling"] = self.use_scaling
        # config_eda["runner_settings"]["use_pooled_priors"] = self.use_pooled_priors
        config_eda["modeling_parameters"] = {}

        config_eda["modeling_parameters"][self.outcome_var] = {}
        config_eda["modeling_parameters"][self.outcome_var][
            "media_vars"
        ] = self.updated_brand_tactics

        config_eda["modeling_parameters"][self.outcome_var][
            "category_tactics_to_combine"
        ] = self.brand_tactics_to_combine

        config_eda["modeling_parameters"][self.outcome_var][
            "national_media_vars"
        ] = self.media_variables_wmt

        config_eda["modeling_parameters"][self.outcome_var][
            "national_media_vars_lg_hf"
        ] = self.national_media_vars_lg_hf

        config_eda["modeling_parameters"][self.outcome_var][
            "national_media_base"
        ] = False

        config_eda["modeling_parameters"][self.outcome_var][
            "national_media_transform"
        ] = False        

        config_eda["modeling_parameters"][self.outcome_var][
            "outlier_dummies"
        ] = True        

        config_eda["modeling_parameters"][self.outcome_var][
            "media_to_split"
        ] = []  

        config_eda["modeling_parameters"][self.outcome_var]["category_essential_vars"] = self.brand_essential_vars

        config_eda["modeling_parameters"][self.outcome_var][
            "exclude_non_media"
        ] = self.exclude_non_media

        config_eda["modeling_parameters"][self.outcome_var]["excluded_SBU"] = []

        config_eda["modeling_parameters"][self.outcome_var]["non_media_set"]= self.non_media_set
        config_eda["modeling_parameters"][self.outcome_var][
            "use_pooled_bounds"
        ] = self.use_pooled_bounds
        # config_eda["modeling_parameters"][self.outcome_var][
        #     "use_pooled_priors"
        # ] = self.use_pooled_priors
        # config_eda["modeling_parameters"][self.outcome_var][
        #     "tactic_level_clusters"
        # ] = self.tactic_level_clusters
        config_eda["modeling_parameters"][self.outcome_var]["s_curve_bounds"] = {
            "lb": 0.05,
            "ub": 0.95,
        }

        config_eda["modeling_parameters"][self.outcome_var]["sat_bound_dict"] = {tactic: [0.4, 1.2] for tactic in self.updated_brand_tactics}

        config_eda["modeling_parameters"][self.outcome_var]["thres_bound_dict"] = {tactic: [0.3, 0.3] for tactic in self.updated_brand_tactics}

        config_eda["modeling_parameters"][self.outcome_var]["custom_s_curve_bounds"] = {}

        # config_eda["modeling_parameters"][self.outcome_var]["priors_manual"] = {}
        config_eda["modeling_parameters"][self.outcome_var][
            "target_r2"
        ] = self.target_r2
        config_eda["modeling_parameters"][self.outcome_var][
            "mape_limit"
        ] = self.target_mape
        config_eda["modeling_parameters"][self.outcome_var]["overall_iroas_limit"] = self.overall_iroas_limit
        config_eda["modeling_parameters"][self.outcome_var]["overall_iroas_prior"] = self.channel_iroas_priors.get("Overall", 1.5)
        config_eda["modeling_parameters"][self.outcome_var]["WMC_PORTFOLIO_DICT"] =  self.YoY_comparison

        config_eda["runner_settings"]["custom_priors_manual"] = self.tactic_iroas_priors
        config_eda["runner_settings"]["iroas_constraints"] = {tactic: [0.5, 5] for tactic in self.updated_brand_tactics}
        config_eda["runner_settings"]["custom_priors_manual_wmt"] = {}
        config_eda["runner_settings"]["iroas_constraints_wmt"] = {}

        config_eda["runner_settings"]["rsq_limit"] = self.target_r2
        config_eda["runner_settings"]["mape_limit"] = self.target_mape
        config_eda["runner_settings"]["overall_iroas_limit"] = self.overall_iroas_limit
        config_eda["runner_settings"]["overall_iroas_prior"] = self.channel_iroas_priors.get("Overall", 1.5)
        config_eda["runner_settings"]["onsite_iroas_prior"] = self.channel_iroas_priors.get("Onsite Display", 1.5)
        config_eda["runner_settings"]["search_iroas_prior"] = self.channel_iroas_priors.get("Sponsored Products", 1.5)
        config_eda["runner_settings"]["offsite_iroas_prior"] = self.channel_iroas_priors.get("Offsite Display", 1.5)

        config_eda["runner_settings"]["max_iterations"] = 500
        config_eda["runner_settings"]["fix_iterations"] = True
        config_eda["runner_settings"]["use_ridge"] = True
        config_eda["runner_settings"]["lambda_denominator"] = 1
        config_eda["runner_settings"]["use_sign_penalty"] = False
        config_eda["runner_settings"]["use_iroas_penalty"] = True
        config_eda["runner_settings"]["iroas_penalty_multiplier"] = 1
        config_eda["runner_settings"]["apply_scaling"] = True
        config_eda["runner_settings"]["iroas_dev_in_loss"] = False
        config_eda["runner_settings"]["dynamic_lambda"] = True
        config_eda["runner_settings"]["use_thresh_sat"] = True
        config_eda["runner_settings"]["handle_added_value"] = False
        config_eda["runner_settings"]["tactic_level_lambda_multiplier_bounds"] = {tactic: [0, 1] for tactic in self.updated_brand_tactics}
        config_eda["runner_settings"]["ridge_penalty_weight"] = 100
        config_eda["runner_settings"]["iroas_deviation_weight"] = 0.001
        config_eda["runner_settings"]["variable_sign_penalty_weight"] = 10

        config_eda["runner_settings"]["ridge_penalty_weight_wmt"] = 100
        config_eda["runner_settings"]["iroas_deviation_weight_wmt"] = 0.001
        config_eda["runner_settings"]["variable_sign_penalty_weight_wmt"] = 100


        # config_eda["modeling_parameters"][self.outcome_var][
        #     "target_valid_r2"
        # ] = self.target_valid_r2
        # config_eda["modeling_parameters"][self.outcome_var][
        #     "target_valid_mape"
        # ] = self.target_valid_mape
        # config_eda["runner_settings"]["YoY_comparison"] = {}
        # config_eda["modeling_parameters"][self.outcome_var]["brand_tactics"] = {}
        # config_eda["modeling_parameters"][self.outcome_var][
        #     "brand_tactics_to_combine"
        # ] = {}
        # config_eda["modeling_parameters"][self.outcome_var]["brand_essential_vars"] = {}
        # config_eda["modeling_parameters"][self.outcome_var][
        #     "brand_exclude_non_media"
        # ] = {}
        # config_eda["modeling_parameters"][self.outcome_var]["non_media_set"] = {}
        # config_eda["modeling_parameters"][self.outcome_var][
        #     "custom_s_curve_bounds"
        # ] = {}
        # config_eda["modeling_parameters"][self.outcome_var]["thresh_sat_dict"] = {}
        config_eda["modeling_parameters"][self.outcome_var]["train_start"] = self.brand_period["train_start"]
        config_eda["modeling_parameters"][self.outcome_var]["train_end"] = self.brand_period["train_end"]
        config_eda["modeling_parameters"][self.outcome_var]["valid_start"] = self.brand_period["valid_start"]
        config_eda["modeling_parameters"][self.outcome_var]["valid_end"] = self.brand_period["valid_end"]

        config_eda["modeling_parameters"]["O_NEW_CUSTOMER"] = {}
        path = self.eda_out_path[sbu]
        print(f"Writing config to {path}/category_config.json")
        with open(f"{path}/category_config.json", "w") as fp:
            json_dumps_str = json.dumps(config_eda, indent=4)
            print(json_dumps_str, file=fp)

        return config_eda


    def update_config_by_brand(self, brand, config_eda, brand_specific_config=True):
        df_brand = self.data[self.data["BRAND"] == brand].copy()
        # load variables
        custom_s_curve_bounds = self.get_scurve_bounds_eda(brand)
        thresh_sat_dict = self.get_thresh_sat_dict(brand)

        config_eda["runner_settings"]["YoY_comparison"][brand] = self.YoY_comparison[
            brand
        ]
        config_eda["modeling_parameters"][self.outcome_var]["category_tactics"][brand] = (
            self.updated_brand_tactics[brand]
        )
        config_eda["modeling_parameters"][self.outcome_var]["category_tactics_to_combine"][
            brand
        ] = self.brand_tactics_to_combine[brand]
        config_eda["modeling_parameters"][self.outcome_var]["category_essential_vars"][
            brand
        ] = self.brand_essential_vars[brand]
        config_eda["modeling_parameters"][self.outcome_var]["category_exclude_non_media"][
            brand
        ] = self.brand_exclude_non_media[brand]
        config_eda["modeling_parameters"][self.outcome_var]["non_media_set"][
            brand
        ] = self.non_media_set
        config_eda["modeling_parameters"][self.outcome_var]["custom_s_curve_bounds"][
            brand
        ] = custom_s_curve_bounds
        config_eda["modeling_parameters"][self.outcome_var]["thresh_sat_dict"][
            brand
        ] = thresh_sat_dict
        config_eda["modeling_parameters"][self.outcome_var]["train_start"][brand] = (
            self.brand_period[brand]["train_start"]
        )
        config_eda["modeling_parameters"][self.outcome_var]["train_end"][brand] = (
            self.brand_period[brand]["train_end"]
        )
        config_eda["modeling_parameters"][self.outcome_var]["valid_start"][brand] = (
            self.brand_period[brand]["valid_start"]
        )
        config_eda["modeling_parameters"][self.outcome_var]["valid_end"][brand] = (
            self.brand_period[brand]["valid_end"]
        )
        config_eda["modeling_parameters"][self.outcome_var]["use_ridge"][brand] = True

        config_eda["modeling_parameters"][self.outcome_var]["lambda_denominator"][brand] = 1

        config_eda["modeling_parameters"][self.outcome_var]["use_sign_penalty"][brand] = False

        config_eda["modeling_parameters"][self.outcome_var]["use_iroas_penalty"][brand] = True

        config_eda["modeling_parameters"][self.outcome_var]["iroas_penalty_multiplier"][brand] = 1

        config_eda["modeling_parameters"][self.outcome_var]["apply_scaling"][brand] = True

        config_eda["modeling_parameters"][self.outcome_var]["iroas_dev_in_loss"][brand] = False



        return config_eda

    def generate_brand_specific_config(self, brand, config_eda):
        config_eda["brand_name"] = f"{brand.lower()}"
        config_eda["dag_name"] = f"{re.sub(r'[^a-zA-Z0-9]', '', brand).lower()}"
        if "brand_list" in config_eda:
            del config_eda["brand_list"]
        config_eda["cloud_path"] = f"model/model_{self.modeler}/model_{brand}"
        self.config_eda[brand] = config_eda
        path = self.eda_out_path[brand]
        print(f"Writing config to {path}/premium_config.json")
        with open(f"{path}/premium_config.json", "w") as fp:
            json_dumps_str = json.dumps(config_eda, indent=4)
            print(json_dumps_str, file=fp)
        print(f"Writing priors to {path}/priors_info_df.json")
        self.pooled_priors[self.pooled_priors["BRAND"] == brand].to_csv(
            f"{path}/priors_info_df.csv", index=False
        )

    def run_EDA(self):
        self.eda_out_path = {}
        for sbu in self.sbu:
            self.eda_out_path[sbu] = create_folder_with_version(
                f"{self.output_path_eda}/{sbu}/{self.outcome_var}"
            )

            self.brand_tactics = self.get_brand_tactics(sbu)
            file1 = self.eda_out_path[sbu] + f"/{sbu}_EDA_notes.txt"
            with open(file1, mode="w", encoding="UTF-8") as output:

                (
                    self.brand_tactics_to_combine,
                    self.updated_brand_tactics,
                    self.initial_brand_tactics,
                    self.brand_period,
                    self.brand_essential_vars,
                    self.YoY_comparison,
                ) = self.combine_tactics(output, sbu)


                self.final_summary_df = self.generate_media_summary(
                    self.channel_variables_wmc, sbu, channel_plots = True
                )
                self.final_summary_df = self.generate_media_summary(
                    self.initial_brand_tactics, sbu, channel_plots = False
                )
            
            print('*****Generating Config*****')
            self.tactic_iroas_priors, self.channel_iroas_priors = self.get_iroas_priors(self.prior_info_path)
            self.eda_config = self.generate_common_config_params(sbu)

            print(
                f"Please proceed after reviewing {file1} file for recommendations based on EDA"
            )

        # common_media_vars = self.media.copy()
        # for combined_var, var_lst in self.initial_brand_tactics.items():
        #     common_media_vars = list(
        #         (set(common_media_vars).intersection(set(var_lst)))
        #     )
        # self.common_media_vars = common_media_vars.copy()


def process_solutions(args):
    (
        df_by_brand,
        brand_name,
        num_media_vars,
        num_non_media_vars,
        media_variables,
        data,
        iroas_lb,
        iroas_ub,
        initial_solution,
        seed,
        base_num,
        wmc_idx,
        i,
        sol,
    ) = args
    (
        hf_arr,
        thr_arr,
        sat_arr,
        lag_arr,
        lambda_k_arr,
        lambda_k,
        scl,
        infl,
        beta_j,
        beta_unscaled,
        Tactic_iRoAS,
        Overall_iRoAS,
        iroas_dev_from_prior,
        train_mape,
        valid_mape,
        train_wape,  # WAPE_INTEGRATION
        valid_wape,  # WAPE_INTEGRATION
        r_sq_train,
        r_sq_valid,
        media_contrib_1,
        media_spend_1,
        media_contrib_2,
        media_spend_2,
        media_iroas_1,
        media_iroas_2,
        overall_contrib_1,
        overall_contrib_2,
        overall_iroas_1,
        overall_iroas_2,
        monotonic_inc_contrib_tactic_bool,
        monotonic_inc_contrib_overall_bool,
        total_loss,
    ) = sol

    non_media_df = pd.DataFrame()

    for non_media_idx in range(num_non_media_vars):
        (
            solution_number_col,
            driver_col,
            seed_col,
            coeff,
            coeff_unscaled,
            overall_iroas_col,
            inf_pt_y,
            sum_iroas_dev,
            sum_inf_dev,
        ) = ([], [], [], [], [], [], [], [], [])
        initial_solution_col, obj_value_col = ([], [])
        train_rsq, train_mp, valid_rsq, valid_mp = [], [], [], []
        train_wp, valid_wp = [], []  # WAPE_INTEGRATION
        (
            iroas_res,
            DE_sol,
            transf_res,
            thres_sat_res,
            iroas_in_bound_res,
            on_air_days_res,
            days_beyon_sat_res,
            days_below_thresh_res,
        ) = ([], [], [], [], [], [], [], [])
        (
            transformations,
            coefficient,
            thres_sat,
            inflection_point_y,
            iroas_in_bound,
            on_air_days_perc,
            days_beyond_saturation,
            days_below_threshold,
            dev_from_inf,
            saturation_acceptable,
            threshold_acceptable,
            dev_from_iroas_prior,
            coefficient_unscaled,
        ) = ({}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {})
        (
            hf_res,
            inf_res,
            sc_res,
            lg_res,
            lambda_k_res,
            thresh_res,
            sat_res,
            dev_inf_res,
            sat_acceptable_res,
            thresh_acceptable_res,
            roas_dev_res,
            inf_dev_arr,
        ) = ([], [], [], [], [], [], [], [], [], [], [], [])

        for idx in range(num_media_vars):
            media_var = media_variables[idx]

            on_air_df = data[data[media_var] > 0]
            on_air_days_perc[media_variables[idx]] = len(on_air_df) / len(data)

            days_beyond_saturation[media_variables[idx]] = len(
                on_air_df[data[media_var] > sat_arr[idx]]
            ) / len(data[data[media_var] > 0])

            if (media_var.startswith("M_SP") or media_var.startswith("M_SBA")):

                saturation_acceptable[media_variables[idx]] = (
                    True
                    if (
                        ( 
                            on_air_days_perc[media_variables[idx]] >= 0.20
                            and days_beyond_saturation[media_variables[idx]] <= 0.05        #New Guardrails
                        )
                        or on_air_days_perc[media_variables[idx]] < 0.20
                    )
                    else False
                )
            else:
                saturation_acceptable[media_variables[idx]] = (
                    True
                    if (
                        (
                            on_air_days_perc[media_variables[idx]] >= 0.20
                            and days_beyond_saturation[media_variables[idx]] <= 0.20        #New Guardrails
                        )
                        or on_air_days_perc[media_variables[idx]] < 0.20
                    )
                    else False
                )

            days_below_threshold[media_variables[idx]] = len(
                on_air_df[data[media_var] < thr_arr[idx]]
            ) / len(data[data[media_var] > 0])

            threshold_acceptable[media_variables[idx]] = (
                True
                if (
                    (
                        on_air_days_perc[media_variables[idx]] >= 0.20
                        and days_below_threshold[media_variables[idx]] <= 0.10      #New Guardrails
                    )
                    or on_air_days_perc[media_variables[idx]] < 0.20
                )
                else False
            )

            dev_from_iroas_prior[media_variables[idx]] = iroas_dev_from_prior[idx]

            if (Tactic_iRoAS[idx] >= iroas_lb[idx]) and (
                Tactic_iRoAS[idx] <= iroas_ub[idx]
            ):
                iroas_in_bound[media_variables[idx]] = True
            else:
                iroas_in_bound[media_variables[idx]] = False

            transformations[media_variables[idx]] = [
                hf_arr[idx],
                infl[idx],
                scl[idx],
                lag_arr[idx],
                lambda_k_arr[idx]

            ]
            thres_sat[media_variables[idx]] = [
                thr_arr[idx],
                sat_arr[idx],
            ]
            coefficient[media_variables[idx]] = beta_j[idx]
            coefficient_unscaled[media_variables[idx]] = beta_unscaled[idx]
            inflection_point_y[media_variables[idx]] = (
                infl[idx] * df_by_brand[media_variables[idx]].mean()
            )
            dev_from_inf[media_variables[idx]] = (
                inflection_point_y[media_variables[idx]]
                - data[media_variables[idx]].mean()
            ) ** 2
            if on_air_days_perc[media_variables[idx]] >= 0.20:
                inf_dev_arr.append(dev_from_inf[media_variables[idx]])

        inf_dev_arr = np.asarray(inf_dev_arr)

        try:
            monotonic_inc_contrib_tactic_bool = (
                monotonic_inc_contrib_tactic_bool.astype(np.bool)
            )
            monotonic_inc_contrib_overall_bool = (
                monotonic_inc_contrib_overall_bool.astype(np.bool)
            )
        except:
            monotonic_inc_contrib_tactic_bool = (
                monotonic_inc_contrib_tactic_bool.astype(bool)
            )
            monotonic_inc_contrib_overall_bool = (
                monotonic_inc_contrib_overall_bool.astype(bool)
            )
        if (beta_j > 0).sum() == num_media_vars:
            driver_col += media_variables
            solution_number_col += [i] * len(media_variables)
            initial_solution_col += list(initial_solution)
            on_air_days_res += list(on_air_days_perc.values())
            iroas_res += list(Tactic_iRoAS)
            iroas_in_bound_res += list(iroas_in_bound.values())
            transf_res += list(transformations.values())
            hf_res += list(hf_arr)
            inf_res += list(infl)
            sc_res += list(scl)
            lg_res += list(lag_arr)
            lambda_k_res += list(lambda_k)
            thres_sat_res += list(thres_sat.values())
            thresh_res += list(thr_arr)
            sat_res += list(sat_arr)
            days_beyon_sat_res += list(days_beyond_saturation.values())
            days_below_thresh_res += list(days_below_threshold.values())
            sat_acceptable_res += list(saturation_acceptable.values())
            thresh_acceptable_res += list(threshold_acceptable.values())

            overall_iroas_col += list(Overall_iRoAS)
            train_rsq += list(r_sq_train)  # [r_sq_train] * len(media_variables)
            train_mp += list(train_mape)  # [train_mape] * len(media_variables)
            valid_rsq += list(r_sq_valid)  # [r_sq_valid] * len(media_variables)
            valid_mp += list(valid_mape)  # [valid_mape] * len(media_variables)
            train_wp += list(train_wape)  # WAPE_INTEGRATION
            valid_wp += list(valid_wape)  # WAPE_INTEGRATION
            obj_value_col += list(total_loss)  # [obj_fn_loss] * len(media_variables)
            seed_col += [seed] * len(media_variables)
            coeff += list(coefficient.values())
            coeff_unscaled += list(coefficient_unscaled.values())
            inf_pt_y += list(inflection_point_y.values())
            dev_inf_res += list(dev_from_inf.values())
            sum_inf_dev += [inf_dev_arr.sum()] * len(media_variables)
            # inf_dev_acceptable_res += list(inf_deviation_acceptable.values())
            roas_dev_res += list(dev_from_iroas_prior.values())
            DE_sol += list(sol)
            sum_iroas_dev += [sum(iroas_dev_from_prior)]*len(media_variables)
            result_data = {
                "Seed": seed_col,
                "sbu_name": brand_name,
                "Solution_number": solution_number_col,
                "Non_media_set": [base_num] * len(solution_number_col),
                "Media_tactic": driver_col,
                "Coefficient": coeff,
                "Coefficient_unscaled": coeff_unscaled,
                "Tactic_iRoAS": iroas_res,
                "Overall_iroas": overall_iroas_col,
                "Tactic_iRoAS_dev_from_prior": roas_dev_res,
                "Sum_deviation_from_prior": sum_iroas_dev,
                "Tactic_iRoAS_in_bound": iroas_in_bound_res,
                "Year_1_spend": media_spend_1,
                "Year_1_contrib": media_contrib_1,
                "Year_1_iroas": media_iroas_1,
                "Year_2_spend": media_spend_2,
                "Year_2_contrib": media_contrib_2,
                "Year_2_iroas": media_iroas_2,
                "YoY_Monotonic_tactic": monotonic_inc_contrib_tactic_bool,
                "Year_1_overall_spend": [np.asarray(media_spend_1)[wmc_idx].sum()]
                * len(media_variables),
                "Year_1_overall_contrib": overall_contrib_1,
                "Year_1_overall_iroas": overall_iroas_1,
                "Year_2_overall_spend": [np.asarray(media_spend_2)[wmc_idx].sum()]
                * len(media_variables),
                "Year_2_overall_contrib": overall_contrib_2,
                "Year_2_overall_iroas": overall_iroas_2,
                "YoY_Monotonic_overall": monotonic_inc_contrib_overall_bool,
                "Train_R_Square": train_rsq,
                "Train_Mape": train_mp,
                "Train_Wape": train_wp,  # WAPE_INTEGRATION
                "Validation_R_Square": valid_rsq,
                "Validation_Mape": valid_mp,
                "Validation_Wape": valid_wp,  # WAPE_INTEGRATION
                "Media_transformation (hf, inf, sc, lg)": transf_res,
                "Halflife": hf_res,
                "Inflection": inf_res,
                "Scale": sc_res,
                "Lag": lg_res,
                "Lambda_k": lambda_k_res,
                "Threshold_Saturation": thres_sat_res,
                "Threshold": thresh_res,
                "Saturation": sat_res,
                "Inflection_Point": inf_pt_y,
                "Perc_on_air_days": on_air_days_res,
                "Perc_days_beyond_saturation": days_beyon_sat_res,
                "Perc_days_below_threshold": days_below_thresh_res,
                "Deviation_from_inflection": dev_inf_res,
                "Sum_dev_from_inflection": sum_inf_dev,
                "Acceptable_saturation": sat_acceptable_res,
                "Acceptable_threshold": thresh_acceptable_res,
                # "Acceptable_inflection_dev": inf_dev_acceptable_res,
                "DE_objective_value": obj_value_col,
            }
            results = pd.DataFrame.from_dict(result_data)
            non_media_df = pd.concat([non_media_df, results], ignore_index=True)

    return non_media_df


def update_priors(prior_info, data, priors_manual,iroas_constraints, train_end):
    
    data["Date"] = pd.to_datetime(data["Date"])
    train_end = pd.to_datetime(train_end)
    data["PRICE"] = data["O_SALE"] / data["O_UNIT"]
    # data["PRICE"] = data["PRICE"].mean()
    if "M_ON_DIS_KW_IMP" in prior_info.media_variable.unique():
        prior_info.loc[prior_info["media_variable"]=="M_ON_DIS_KW_IMP",'iroas_lb'] = 1.0
        prior_info.loc[prior_info["media_variable"]=="M_ON_DIS_KW_IMP",'iroas_ub'] = 60.0

    for var in prior_info.media_variable.unique():
        if bool(priors_manual):
            if var in priors_manual.keys():
                print(f"***************Updating iroas prior for {var}*****************")
                if "_IMP" in var:
                    spend_var = var.replace("_IMP", "_SPEND")
                else:
                    spend_var = var.replace("_CLK", "_SPEND")

                delta_by_media = (data["PRICE"] * data[var]).sum() / data[spend_var].sum()
                delta_by_media = data[data["Date"] <= train_end]["PRICE"].mean()* (data[var]).sum() / data[spend_var].sum()
                U_m = priors_manual[var] / delta_by_media
                Var_m = (priors_manual[var] / (delta_by_media * 3)) ** 2
                prior_info.loc[prior_info["media_variable"]==var,'iroas_prior'] = priors_manual[var]
                prior_info.loc[prior_info["media_variable"]==var,'coef_mean_prior'] = U_m
                prior_info.loc[prior_info["media_variable"]==var,'coef_var_prior'] = Var_m
        if bool(iroas_constraints):
            if var in iroas_constraints.keys():
                print(f"***************Updating iroas constraints for {var}*****************")
                iroas_lb = iroas_constraints[var][0]
                iroas_ub = iroas_constraints[var][1]
                # iroas_prior = prior_info.loc[prior_info["media_variable"]==var,'iroas_prior'].values[0]
                # if iroas_lb >= iroas_prior:
                #     print(f"Lowering the iroas lower bound for {var} to include the iroas prior in range")
                #     iroas_lb = iroas_prior*0.8
                # if iroas_ub <= iroas_prior:
                #     print(f"Increasing the iroas upper bound for {var} to include the iroas prior in range")
                #     iroas_ub = iroas_prior*1.2
                prior_info.loc[prior_info["media_variable"]==var,'iroas_lb'] = iroas_lb
                prior_info.loc[prior_info["media_variable"]==var,'iroas_ub'] = iroas_ub
    return prior_info


# placeholder method
# filters out media variables where spend=0 in the training period
# overwrites any priors specified and also modifies the coefficient priors accordingly
# updates iroas constraints
def filter_media(data, train_start, train_end, media_variables_og, priors_df_og,priors_manual,iroas_constraints):
    media_vars_upd = []
    training_spend = []
    st_dt = datetime.datetime.strptime(train_start, date_format)
    train_end_dt = datetime.datetime.strptime(train_end, date_format)
    train_end_index = (train_end_dt - st_dt).days + 1
    train_data = data[:train_end_index]
    training_price = train_data["PRICE"].mean()
    
    # set default iroas constraints
    priors_df_og["iroas_lb"] = 0.5
    priors_df_og["iroas_ub"] = 5.0
    if "M_ON_DIS_KW_IMP" in priors_df_og.media_variable.unique():
        priors_df_og.loc[priors_df_og["media_variable"]=="M_ON_DIS_KW_IMP",'iroas_lb'] = 1.0
        priors_df_og.loc[priors_df_og["media_variable"]=="M_ON_DIS_KW_IMP",'iroas_ub'] = 60.0


    for var in media_variables_og:
        if "_IMP" in var:
            spend_var = var.replace("_IMP", "_SPEND")
        else:
            spend_var = var.replace("_CLK", "_SPEND")
        
        training_spend_var = train_data[spend_var].sum()
        

        if training_spend_var > 0:
            media_vars_upd.append(var)
            training_spend.append(training_spend_var)
        else:
            print(f"Dropping {var} as SPEND=0 in the training period")
    priors_df_upd = priors_df_og[priors_df_og['media_variable'].isin(media_vars_upd)]
    
    
    if bool(priors_manual) or bool(iroas_constraints):
        priors_df_upd = update_priors(priors_df_upd.copy(), data.copy(), priors_manual,iroas_constraints, train_end)
    
    # overwrite iroas constraints if conflicting with the iroas_prior
    priors_df_upd["iroas_lb"] = np.minimum(priors_df_upd["iroas_lb"],priors_df_upd["iroas_prior"])
    priors_df_upd["iroas_ub"] = np.maximum(priors_df_upd["iroas_ub"],priors_df_upd["iroas_prior"])
    priors_df_upd["iroas_lb_opt"] = priors_df_upd["iroas_lb"]
    priors_df_upd["iroas_ub_opt"] = priors_df_upd["iroas_ub"]
    
    priors_df_upd["train_spend"] = training_spend
    priors_df_upd["train_price"] = training_price
    
    return media_vars_upd,priors_df_upd

class PremiumPanel:
    def __init__(self) -> None:
        # Placeholder class for panel level processing
        pass



