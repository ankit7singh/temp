import ast
import os
import sys
import warnings
from time import time
from datetime import datetime
import io
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.stats as stats
import seaborn as sns
from fitter import Fitter
from numba_helper_functions import *
from scipy.stats import gaussian_kde, norm
from dateutil.relativedelta import relativedelta
import re


date_format = "%Y-%m-%d"
timestamp = datetime.now().strftime("%Y%m%d%H")

warnings.filterwarnings("ignore")
# from IPython.display import display

# module_path = os.path.abspath(os.path.join("../src/utils"))
# if module_path not in sys.path:
#     sys.path.append(module_path)

# if os.path.abspath("../src/config_dir") not in sys.path:
#     sys.path.append(os.path.abspath("../src/config_dir"))

# if module_path not in sys.path:
#     sys.path.append(module_path)

_script_dir = os.path.dirname(os.path.abspath(__file__))
_pipeline_root = os.path.normpath(os.path.join(_script_dir, ".."))
_utils_dir = os.path.join(_pipeline_root, "utilities")

# Add both to sys.path
for _p in [_utils_dir, _script_dir]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

print(f"✓ Utils paths loaded")

import importlib

import custom_mmm_modelling_ga

importlib.reload(custom_mmm_modelling_ga)
from custom_mmm_modelling_ga import MMM_Modelling
from custom_modelling_plots_mod import ModellingPlots
# from lite_non_media_utils_nat_fit import *
from lite_non_media_utils_v3_Nat_Fit import *
# from lite_wamm_modeling import create_folder_with_version
# from gcs_utils import upload_dataframe_to_gcs, load_file_from_gcs, upload_eda_files_to_gcs

# Load data dictionary from local input data
bucket_name = "category-wamm-model-outputs-stage"
data_dict_path = "../data/input_data/WMG WAMM Project Data Dictionary_v19.xlsx"

pd.set_option("display.max_columns", None)  # or 1000
pd.set_option("display.max_rows", None)  # or 1000
pd.set_option("display.max_colwidth", 1)  # or 199

try:
    print(f"Loading data dictionary from {data_dict_path}")

    data_dict = pd.read_excel(data_dict_path)

    print(f"✓ Loaded data dictionary: {len(data_dict)} rows")

    # Normalize columns
    data_dict.columns = data_dict.columns.str.strip()
    print(f"📊 Original columns: {list(data_dict.columns)}")

    # Rename columns if needed
    if 'Variable' in data_dict.columns and 'Variable Name' not in data_dict.columns:
        data_dict = data_dict.rename(columns={'Variable': 'Variable Name'})
    if 'Description' in data_dict.columns and 'Variable Description' not in data_dict.columns:
        data_dict = data_dict.rename(columns={'Description': 'Variable Description'})

    print(f"✓ Final columns: {list(data_dict.columns)}")

except Exception as e:
    print(f"❌ Error loading data dictionary: {e}")
    import traceback

    traceback.print_exc()
    data_dict = pd.DataFrame(columns=['Variable Name', 'Variable Description'])

modeling_parameters_shared_media_dictionary = {
    "IMP": "Impression",
    "SPEND": "Spend",
    "VIEW_IMP": "Viewable Impression",
    "CLK": "Click",
}

media_hier_files = []

for key in modeling_parameters_shared_media_dictionary.keys():
    try:
        local_path = f"../data/input_data/media_hierarchy_{key}.csv"
        print(f"Loading {local_path}")

        df = pd.read_csv(local_path)
        media_hier_files.append(df)
        print(f"✓ Loaded media_hierarchy_{key}.csv: {len(df)} rows")

    except Exception as e:
        print(f"Warning: Could not load media_hierarchy_{key}.csv: {e}")

if media_hier_files:
    media_hier = pd.concat(media_hier_files, axis=0)
    print(f"✓ Combined media hierarchy: {len(media_hier)} total rows")
else:
    print("Warning: No media hierarchy files loaded, using empty DataFrame")
    media_hier = pd.DataFrame()

other_variables = []  ## Ignore non media for S curves

def upload_df_to_gcs(df, gcs_full_path, bucket_name=bucket_name, index=True):
    """
    Save a DataFrame as CSV locally instead of uploading to GCS.
    Accepts either a gs://bucket/path style path or a plain local path;
    the gs://bucket/ prefix (if present) is stripped and the rest is
    treated as a local (relative) path.
    """
    local_path = gcs_full_path.replace(f"gs://{bucket_name}/", "")
    local_path = os.path.abspath(local_path) #added by Abhishek on 7.20.2026
    os.makedirs(os.path.dirname(local_path), exist_ok=True)
    df.to_csv(local_path, index=index)
    print(f"✅ Saved locally to: {local_path}")


def filter_solutions_lite(
        priors_df,
        shortlisted_sol_output_path,
        updated_stack,
        sol_data,
        media_variables,
        r_sq_limit,
        mape_limit,
        overall_iroas_limit,
        tactic_level_monotonic_yoy=False,
        use_combined_monotonic_yoy=False,
        use_ridge=False,
        brand_nm=None,
        zs=0,
        # WMC_Fit=False,                                
        WMC_Fit=True,                               # NEW 3.30
        tactic_level_iroas_filter=True,
        new_solution_selection=True,
        date_difference=None,
        prior_iroas_values=[],
        iroas_deviation_dict={},
        iroas_deviation_dict_yoy={},
        final_folder_path=None,
        panel_version=None,
        post_adjustment_tool=False

):
    # on_air_days = dict(zip(priors_df["media_variable"], priors_df["on_air_days"]))

    def scurve_filter(group):
        flag = True
        for media_variable in group["Media_tactic"].unique():
            Acceptable_threshold = group[group["Media_tactic"] == media_variable][
                "Acceptable_threshold"
            ]
            Acceptable_saturation = group[group["Media_tactic"] == media_variable][
                "Acceptable_saturation"
            ]

            if not (
                    (Acceptable_threshold == True).all()
                    and (Acceptable_saturation == True).all()
            ):
                flag = False
                break

        return group if flag else pd.DataFrame(columns=group.columns)

    def sub_filter_1(group):
        flag = True
        iroas_lb, iroas_ub = (
            priors_df["iroas_lb"].to_numpy(),
            priors_df["iroas_ub"].to_numpy(),
        )
        for idx, media_variable in enumerate(group["Media_tactic"].unique()):
            tactic_iroas = group[group["Media_tactic"] == media_variable][
                "Tactic_iRoAS"
            ]
            if not (
                    media_variable.startswith("M_WMT") or media_variable.startswith("M_NAT")
            ):
                # if media_variable.startswith("M_SP") or media_variable.startswith(
                #     "M_SBA"
                # ):
                #     if not (
                #         (tactic_iroas >= iroas_lb[idx]).all()
                #         and (tactic_iroas <= iroas_ub[idx]).all()
                #     ):
                #         flag = False
                #         break
                # elif media_variable.startswith("M_ON_DIS_KW_"):
                #     if not (
                #         (tactic_iroas >= iroas_lb[idx]).all()
                #         and (tactic_iroas <= iroas_ub[idx]).all()
                #     ):
                #         flag = False
                #         break
                # else:
                if not (
                        (tactic_iroas >= iroas_lb[idx]).all()
                        # and (tactic_iroas <= iroas_ub[idx]).all()
                ):
                    flag = False
                    break
        return group if flag else pd.DataFrame(columns=group.columns)

    if post_adjustment_tool:
        sol_data = sol_data.drop(['YoY_overall_iroas_perc',
                                  'YoY_flag_overall_iroas',
                                  'CM_flag_overall_iroas',
                                  'Search_iRoAS',
                                  'Onsite_iRoAS',
                                  'Offsite_iRoAS',
                                  'Instore_iRoAS',
                                  'CM_flag_search_iroas',
                                  'CM_flag_onsite_iroas',
                                  'CM_flag_offsite_iroas'
                                  ], axis=1, errors='ignore')

    ### Flag Analysis ###
    sol_data_og = sol_data

    print(f"Solutions from csv: {sol_data['Solution_number'].nunique()}")
    # WAPE_INTEGRATION: fall back to Train_Wape<=25 only when mape_limit has
    # already been relaxed to 20 and no solution clears Train_Mape<=20.
    mape_ok = sol_data["Train_Mape"] <= mape_limit
    if mape_limit == 20 and not mape_ok.any():
        mape_ok = sol_data["Train_Wape"] <= 25

    sol_data = sol_data[
        (sol_data["Train_R_Square"] >= r_sq_limit)
        & mape_ok
        & (sol_data["Overall_iroas"] >= overall_iroas_limit)
        ].copy()
    print(
        f"Solutions after r_sq, mape, overall_iroas filters: {sol_data['Solution_number'].nunique()}"
    )

    if new_solution_selection:

        #### Overall iroas : YoY filters
        sol_data_og['YoY_overall_iroas_perc'] = (sol_data_og['Year_1_overall_iroas'] - sol_data_og[
            'Year_2_overall_iroas']) / sol_data_og['Year_1_overall_iroas']
        sol_data_og['YoY_flag_overall_iroas'] = sol_data_og['YoY_overall_iroas_perc'].abs() < \
                                                iroas_deviation_dict_yoy[0][0]

        threshold_days = sorted(iroas_deviation_dict.keys())
        #### Overall iroas : CM filters
        if date_difference < threshold_days[0]:
            if not sol_data.empty:
                sol_data = sol_data[sol_data.groupby("Solution_number")['Overall_iroas'].transform(lambda x: (
                        abs(x - prior_iroas_values[0]) / prior_iroas_values[0] <=
                        iroas_deviation_dict[threshold_days[0]][0]).all())
                ].copy()
            sol_data_og['CM_flag_overall_iroas'] = sol_data_og.groupby("Solution_number")['Overall_iroas'].transform(
                lambda x: (abs(x - prior_iroas_values[0]) / prior_iroas_values[0] <=
                                     iroas_deviation_dict[threshold_days[0]][0]).any())

        elif (date_difference > threshold_days[0]) and (date_difference < threshold_days[1]):
            if not sol_data.empty:
                sol_data = sol_data[sol_data.groupby("Solution_number")['Overall_iroas'].transform(lambda x: (
                        abs(x - prior_iroas_values[0]) / prior_iroas_values[0] <=
                        iroas_deviation_dict[threshold_days[1]][0]).all())
                ].copy()
            sol_data_og['CM_flag_overall_iroas'] = sol_data_og.groupby("Solution_number")['Overall_iroas'].transform(
                lambda x: (abs(x - prior_iroas_values[0]) / prior_iroas_values[0] <=
                                     iroas_deviation_dict[threshold_days[1]][0]).any())

        elif (date_difference > threshold_days[1]) and (date_difference < threshold_days[2]):
            if not sol_data.empty:
                sol_data = sol_data[sol_data.groupby("Solution_number")['Overall_iroas'].transform(lambda x: (
                        abs(x - prior_iroas_values[0]) / prior_iroas_values[0] <=
                        iroas_deviation_dict[threshold_days[2]][0]).all())
                ].copy()
            sol_data_og['CM_flag_overall_iroas'] = sol_data_og.groupby("Solution_number")['Overall_iroas'].transform(
                lambda x: (abs(x - prior_iroas_values[0]) / prior_iroas_values[0] <=
                                     iroas_deviation_dict[threshold_days[2]][0]).any())

        else:
            print('Day difference between new model and prior model more than 720 days or did not pass above filter')

        print(
            f"Solutions after overall_iroas Deviation Filter: {sol_data['Solution_number'].nunique()}"
        )
        
        if sol_data['Solution_number'].nunique() != 0:

            #### Channel iroas : CM filters
            sol_data['unique_key'] = (sol_data['Solution_number'].astype(str)) + '_' + (
                sol_data['Non_media_set'].astype(str))
            sol_data_channel_iroas = sol_data.groupby(['Solution_number', 'Non_media_set'], sort=False)[
                ['unique_key', 'Media_tactic', 'Coefficient', 'Tactic_iRoAS',
                 'Media_transformation (hf, inf, sc, lg)']].apply(
                lambda grouped_df: get_iroas_metrics_channel(grouped_df, data=updated_stack, ))
            sol_data_channel_iroas = sol_data_channel_iroas.reset_index()
            if 'Solution_number' in sol_data_channel_iroas.columns:
                sol_data_channel_iroas = sol_data_channel_iroas.drop('Solution_number', axis=1)
            sol_data_channel_iroas = sol_data_channel_iroas[
                ['unique_key', 'Media_tactic', 'Search_iRoAS', 'Onsite_iRoAS', 'Offsite_iRoAS',
                 'Instore_iRoAS']]
            sol_data = sol_data.merge(sol_data_channel_iroas, on=['unique_key', 'Media_tactic'], how='left')
            # sol_data.to_csv("sol_data.csv")                                                                                  # NEW 4.24 -

            print(f"NEW: Solutions after Filter 1: {sol_data['Solution_number'].nunique()}")                                   # NEW 4.23 +
            print(f'NEW: prior_iroas_values: {prior_iroas_values}')                                                            # NEW 4.23 +

            if date_difference < threshold_days[0]:
                try:
                    sol_data = sol_data[sol_data.groupby("Solution_number")['Search_iRoAS'].transform(lambda x: (
                            (~np.isfinite(pd.to_numeric(x, errors='coerce'))) | (           # NEW
                            abs(x - prior_iroas_values[3]) / prior_iroas_values[3] <=
                            iroas_deviation_dict[threshold_days[0]][1])).all())
                    ].copy()
                    sol_data = sol_data[sol_data.groupby("Solution_number")['Onsite_iRoAS'].transform(lambda x: (
                            (~np.isfinite(pd.to_numeric(x, errors='coerce'))) | (           # NEW
                            abs(x - prior_iroas_values[1]) / prior_iroas_values[1] <=
                            iroas_deviation_dict[threshold_days[0]][1])).all())
                    ].copy()
                    
                    sol_data = sol_data[sol_data.groupby("Solution_number")['Offsite_iRoAS'].transform(lambda x: (
                            (~np.isfinite(pd.to_numeric(x, errors='coerce'))) | (           # NEW
                            abs(x - prior_iroas_values[2]) / prior_iroas_values[2] <=
                            iroas_deviation_dict[threshold_days[0]][1])).all())
                    ].copy()
                except:
                    print("Channel iRoAS Bounds : Returns No Selected Solutions")

            elif (date_difference > threshold_days[0]) and (date_difference < threshold_days[1]):

                try:
                    sol_data = sol_data[sol_data.groupby("Solution_number")['Search_iRoAS'].transform(lambda x: (
                            (~np.isfinite(pd.to_numeric(x, errors='coerce'))) | (           # NEW
                            abs(x - prior_iroas_values[3]) / prior_iroas_values[3] <=
                            iroas_deviation_dict[threshold_days[1]][1])).all())
                    ].copy()
                    sol_data = sol_data[sol_data.groupby("Solution_number")['Onsite_iRoAS'].transform(lambda x: (
                            (~np.isfinite(pd.to_numeric(x, errors='coerce'))) | (           # NEW
                            abs(x - prior_iroas_values[1]) / prior_iroas_values[1] <=
                            iroas_deviation_dict[threshold_days[1]][1])).all())
                    ].copy()
                    sol_data = sol_data[sol_data.groupby("Solution_number")['Offsite_iRoAS'].transform(lambda x: (
                            (~np.isfinite(pd.to_numeric(x, errors='coerce'))) | (           # NEW
                            abs(x - prior_iroas_values[2]) / prior_iroas_values[2] <=
                            # iroas_deviation_dict[threshold_days[2]][1]).all())                                              # NEW 4.23 -
                            iroas_deviation_dict[threshold_days[1]][1])).all())                                              # NEW 4.23 +
                    ].copy()

                    print(f"NEW: Solutions after Filter 2: {sol_data['Solution_number'].nunique()}")                          # NEW 4.23 +

                except:
                    print("Channel iRoAS Bounds : Returns No Selected Solutions")

            elif (date_difference > threshold_days[1]) and (date_difference < threshold_days[2]):

                try:

                    sol_data = sol_data[sol_data.groupby("Solution_number")['Search_iRoAS'].transform(lambda x: (
                            (~np.isfinite(pd.to_numeric(x, errors='coerce'))) | (           # NEW
                            abs(x - prior_iroas_values[3]) / prior_iroas_values[3] <=
                            iroas_deviation_dict[threshold_days[2]][1])).all())
                    ].copy()
                    sol_data = sol_data[sol_data.groupby("Solution_number")['Onsite_iRoAS'].transform(lambda x: (
                            (~np.isfinite(pd.to_numeric(x, errors='coerce'))) | (           # NEW
                            abs(x - prior_iroas_values[1]) / prior_iroas_values[1] <=
                            iroas_deviation_dict[threshold_days[2]][1])).all())
                    ].copy()
                    sol_data = sol_data[sol_data.groupby("Solution_number")['Offsite_iRoAS'].transform(lambda x: (
                            (~np.isfinite(pd.to_numeric(x, errors='coerce'))) | (           # NEW
                            abs(x - prior_iroas_values[2]) / prior_iroas_values[2] <=
                            iroas_deviation_dict[threshold_days[2]][1])).all())
                    ].copy()


                except:
                    print("Channel iRoAS Bounds : Returns No Selected Solutions")

            else:
                print(' Day difference between new model and prior model more than 720 days ')

        print(f"NEW: Solutions BEFORE Tactic iRoAS filters: {sol_data['Solution_number'].nunique()}")                         # NEW 4.23 +

        if len(sol_data) == 0:
            print('Channel iRoAS Bounds : Returns No Selected Solutions')
        sol_data_og['unique_key'] = (sol_data_og['Solution_number'].astype(str)) + '_' + (
            sol_data_og['Non_media_set'].astype(str))
        sol_data_channel_iroas_og = sol_data_og.groupby(['Solution_number', 'Non_media_set'], sort=False)[
            ['unique_key', 'Media_tactic', 'Coefficient', 'Tactic_iRoAS',
             'Media_transformation (hf, inf, sc, lg)']].apply(
            lambda grouped_df: get_iroas_metrics_channel(grouped_df, data=updated_stack, ))
        sol_data_channel_iroas_og = sol_data_channel_iroas_og.reset_index()
        if 'Solution_number' in sol_data_channel_iroas_og.columns:
            sol_data_channel_iroas_og = sol_data_channel_iroas_og.drop('Solution_number', axis=1)
        sol_data_channel_iroas_og = sol_data_channel_iroas_og[
            ['unique_key', 'Media_tactic', 'Search_iRoAS', 'Onsite_iRoAS', 'Offsite_iRoAS',
             'Instore_iRoAS']]
        sol_data_og = sol_data_og.merge(sol_data_channel_iroas_og, on=['unique_key', 'Media_tactic'], how='left')

        # sol_data_channel_iroas.to_csv("sol_data_channel_iroas.csv")
        print("Channel iRoAS calculated")


        if date_difference < threshold_days[0]:

            sol_data_og['CM_flag_search_iroas'] = sol_data_og.groupby("Solution_number")['Search_iRoAS'].transform(
                lambda x: (abs(x - prior_iroas_values[3]) / prior_iroas_values[3] <=
                                     iroas_deviation_dict[threshold_days[0]][1]).all())
            sol_data_og['CM_flag_onsite_iroas'] = sol_data_og.groupby("Solution_number")['Onsite_iRoAS'].transform(
                lambda x: (abs(x - prior_iroas_values[1]) / prior_iroas_values[1] <=
                                     iroas_deviation_dict[threshold_days[0]][1]).all())
            sol_data_og['CM_flag_offsite_iroas'] = sol_data_og.groupby("Solution_number")['Offsite_iRoAS'].transform(
                lambda x: (abs(x - prior_iroas_values[2]) / prior_iroas_values[2] <=
                                     iroas_deviation_dict[threshold_days[0]][1]).all())

        elif (date_difference > threshold_days[0]) and (date_difference < threshold_days[1]):

            sol_data_og['CM_flag_search_iroas'] = sol_data_og.groupby("Solution_number")['Search_iRoAS'].transform(
                lambda x: (abs(x - prior_iroas_values[3]) / prior_iroas_values[3] <=
                                     iroas_deviation_dict[threshold_days[1]][1]).all())
            sol_data_og['CM_flag_onsite_iroas'] = sol_data_og.groupby("Solution_number")['Onsite_iRoAS'].transform(
                lambda x: (abs(x - prior_iroas_values[1]) / prior_iroas_values[1] <=
                                     iroas_deviation_dict[threshold_days[1]][1]).all())
            sol_data_og['CM_flag_offsite_iroas'] = sol_data_og.groupby("Solution_number")['Offsite_iRoAS'].transform(
                lambda x: (abs(x - prior_iroas_values[2]) / prior_iroas_values[2] <=
                                     iroas_deviation_dict[threshold_days[1]][1]).all())

        elif (date_difference > threshold_days[1]) and (date_difference < threshold_days[2]):

            sol_data_og['CM_flag_search_iroas'] = sol_data_og.groupby("Solution_number")['Search_iRoAS'].transform(
                lambda x: (abs(x - prior_iroas_values[3]) / prior_iroas_values[3] <=
                                     iroas_deviation_dict[threshold_days[2]][1]).all())
            sol_data_og['CM_flag_onsite_iroas'] = sol_data_og.groupby("Solution_number")['Onsite_iRoAS'].transform(
                lambda x: (abs(x - prior_iroas_values[1]) / prior_iroas_values[1] <=
                                     iroas_deviation_dict[threshold_days[2]][1]).all())
            sol_data_og['CM_flag_offsite_iroas'] = sol_data_og.groupby("Solution_number")['Offsite_iRoAS'].transform(
                lambda x: (abs(x - prior_iroas_values[2]) / prior_iroas_values[2] <=
                                     iroas_deviation_dict[threshold_days[2]][1]).all())

        else:
            print(' Day difference between new model and prior model more than 720 days ')
            sol_data_og['CM_flag_search_iroas'] = True
            sol_data_og['CM_flag_onsite_iroas'] = True
            sol_data_og['CM_flag_offsite_iroas'] = True

        # NEW 5.26 Handle 0 spend 
        sol_data_og.loc[~np.isfinite(sol_data_og['Onsite_iRoAS']),'CM_flag_onsite_iroas'] = True
        sol_data_og.loc[~np.isfinite(sol_data_og['Offsite_iRoAS']),'CM_flag_offsite_iroas'] = True
        sol_data_og.loc[~np.isfinite(sol_data_og['Search_iRoAS']),'CM_flag_search_iroas'] = True



        if len(sol_data) != 0:

            if WMC_Fit and tactic_level_iroas_filter:
                sol_data = sol_data[
                    sol_data.groupby("Solution_number")['Tactic_iRoAS'].transform(lambda x: (x > 0.5).all())
                ].copy()

                # else:
                #     sol_data = (
                #         sol_data.groupby("Solution_number")
                #         .apply(sub_filter_1)
                #         .reset_index(drop=True)
                #     )

                print(
                    f"Solutions after Tactic iRoAS filters: {sol_data['Solution_number'].nunique()}"
                )

            if use_combined_monotonic_yoy:
                sol_data = sol_data[
                    (sol_data["YoY_Monotonic_tactic"] == True)
                    & (sol_data["YoY_Monotonic_overall"] == True)
                    ].copy()
            elif tactic_level_monotonic_yoy:
                sol_data = sol_data[sol_data["YoY_Monotonic_tactic"] == True].copy()
            else:
                sol_data = sol_data[
                    sol_data["YoY_Monotonic_overall"] > 0.0
                    ].copy()  # use column name YoY_Monotonic_overall

            print(
                f"Solutions after tactic level iroas and yoy filter: {sol_data['Solution_number'].nunique()}"
            )
            # if WMC_Fit:
            #     sol_data = (
            #         sol_data.groupby("Solution_number").filter(lambda group: ( (group["Acceptable_threshold"].sum() >= len(group["Acceptable_threshold"]) -2) &
            #                                                 (group["Acceptable_saturation"].sum() >= len(group["Acceptable_saturation"]) -2)
            #                                                 )
            #         )
            #     )
            # print(f"Solutions after scurve filter: {sol_data['Solution_number'].nunique()}")

            merged_df = pd.merge(sol_data, sol_data_og[
                ['unique_key', 'Media_tactic', 'CM_flag_search_iroas', 'CM_flag_onsite_iroas', 'CM_flag_offsite_iroas',
                 'CM_flag_overall_iroas', 'YoY_flag_overall_iroas']], on=['unique_key', 'Media_tactic'], how='left')
            filtered_data = merged_df.copy()

        else:
            filtered_data = pd.DataFrame(columns=sol_data_og.columns)

        sbu_normalized = brand_nm.title().replace(" ", "_")

        # Save solution selection results into the latest panel_output_v{panel_version} folder
        result_folder = f"{final_folder_path}_v{panel_version}"
        result_file_path = f"{result_folder}/results_{brand_nm}_solution_selection.csv"

        print(f"Saving solution selection to: {result_file_path}")
        upload_df_to_gcs(sol_data_og, result_file_path, bucket_name, index=False)
        print("✓ Finished saving sol_data_og locally")

        print(
            f"Solutions after base level filters: {filtered_data['Solution_number'].nunique()}"
        )

        filtered_data = filtered_data.groupby('Solution_number').filter(
            lambda x: x['CM_flag_search_iroas'].all() and
                      x['CM_flag_onsite_iroas'].all() and
                      x['CM_flag_offsite_iroas'].all() and
                      x['CM_flag_overall_iroas'].all() and
                      x['YoY_flag_overall_iroas'].all())

        print(
            f"Solutions after Change Management Filters: {filtered_data['Solution_number'].nunique()}"
        )
        if filtered_data['Solution_number'].nunique() == 0:
            print("Run Adjustment Tool")

        get_5_point_summary(shortlisted_sol_output_path, filtered_data.copy(), brand_nm, zs)


    else:

        if WMC_Fit and tactic_level_iroas_filter:
            sol_data = sol_data[sol_data.groupby("Solution_number")['Tactic_iRoAS'].transform(lambda x: (x > 0.5).all())
            ].copy()

            # else:
            #     sol_data = (
            #         sol_data.groupby("Solution_number")
            #         .apply(sub_filter_1)
            #         .reset_index(drop=True)
            #     )

            print(
                f"Solutions after Tactic iRoAS filters: {sol_data['Solution_number'].nunique()}"
            )

        if use_combined_monotonic_yoy:
            sol_data = sol_data[
                (sol_data["YoY_Monotonic_tactic"] == True)
                & (sol_data["YoY_Monotonic_overall"] == True)
                ].copy()
        elif tactic_level_monotonic_yoy:
            sol_data = sol_data[sol_data["YoY_Monotonic_tactic"] == True].copy()
        else:
            sol_data = sol_data[
                sol_data["YoY_Monotonic_overall"] > 0.0
                ].copy()  # use column name YoY_Monotonic_overall

        print(
            f"Solutions after tactic level iroas and yoy filter: {sol_data['Solution_number'].nunique()}"
        )
        if WMC_Fit:
            sol_data = (
                sol_data.groupby("Solution_number").filter(
                    lambda group: ((group["Acceptable_threshold"].sum() >= len(group["Acceptable_threshold"]) - 2) &
                                   (group["Acceptable_saturation"].sum() >= len(group["Acceptable_saturation"]) - 2)
                                   )
                )
            )
        print(f"Solutions after scurve filter: {sol_data['Solution_number'].nunique()}")

        filtered_data = sol_data.copy()
        print(
            f"Solutions after base level filters: {filtered_data['Solution_number'].nunique()}"
        )

        get_5_point_summary(shortlisted_sol_output_path, filtered_data.copy(), brand_nm, zs)

    return filtered_data


def get_point_estimate(shortlisted_sols, iRoAS_within_bound, media_variables):
    solution_metrics = shortlisted_sols.groupby('Base_sol_num').agg({
        'Sum_deviation_from_prior': 'mean',  # Total iROAS deviation
        'Tactic_iRoAS_in_bound': 'sum',  # Count of tactics in bounds
        'Acceptable_saturation': 'sum',  # Count of acceptable saturation
        'Acceptable_threshold': 'sum'  # Count of acceptable threshold
    })
    solution_metrics = solution_metrics.apply(pd.to_numeric, errors='coerce')

    # 2. Find solutions with lowest iROAS deviation
    if len(solution_metrics) > 1:
        min_deviation = solution_metrics['Sum_deviation_from_prior'].nsmallest(round(len(solution_metrics) * 0.1)).max()
        best_bounds_solutions = solution_metrics[
            solution_metrics['Sum_deviation_from_prior'] <= min_deviation
            ]
    else:
        best_bounds_solutions = solution_metrics
    best_bounds_solutions = best_bounds_solutions.sort_values('Sum_deviation_from_prior', ascending=True)

    max_in_bounds = max(best_bounds_solutions['Tactic_iRoAS_in_bound'])

    if iRoAS_within_bound:
        # 3. Among those, find solutions with maximum tactics in bounds
        # max_in_bounds = len(media_variables) -
        best_bounds_solutions = best_bounds_solutions[
            best_bounds_solutions['Tactic_iRoAS_in_bound'] == max_in_bounds
            ]

    # 4. Finally, among remaining solutions, find the one with best threshold and saturation
    # best_bounds_solutions['acceptance_score'] = (
    #     best_bounds_solutions['Acceptable_saturation'] +
    #     best_bounds_solutions['Acceptable_threshold']
    # )

    # best_solution = best_bounds_solutions.loc[
    #     best_bounds_solutions['acceptance_score'].idxmax()
    # ]

    return best_bounds_solutions['Sum_deviation_from_prior'].idxmin()


def get_point_estimate_by_base(shortlisted_sols, final_selection=False):
    if not final_selection:
        tactic_stat = shortlisted_sols.groupby("Media_tactic")["Tactic_iRoAS"].median()
    else:
        tactic_stat = shortlisted_sols.groupby("Media_tactic")["Tactic_iRoAS"].quantile(0.75)

    # Step 2: Map the stat to each row (vectorized, no apply)
    shortlisted_sols = shortlisted_sols.copy()  # Avoid modifying original
    shortlisted_sols["tactic_stat"] = shortlisted_sols["Media_tactic"].map(tactic_stat)
    shortlisted_sols["deviation"] = np.abs(shortlisted_sols["Tactic_iRoAS"] - shortlisted_sols["tactic_stat"])

    # Step 3: Sum deviations per Base_sol_num
    solution_deviation = shortlisted_sols.groupby("Base_sol_num")["deviation"].sum()
    # Step 4: Find the solution_number with the minimum sum of deviations
    best_solution_number = solution_deviation.idxmin()

    return best_solution_number


def get_upd_media(media_variables, solution_arr):
    ### update media_vars with lag, halflife, inflection, scale
    i = 0
    j = 5
    media_var_upd = []
    coef = {}
    for var in media_variables:
        decision_vars = solution_arr[i:j]

        upd_var = (
                var
                + "_"
                + str(int(decision_vars[4]))
                + "_"
                + str(decision_vars[1])
                + "_"
                + str(decision_vars[2])
                + "_"
                + str(decision_vars[3])
                + "_0"
        )
        media_var_upd.append(upd_var)
        coef[upd_var] = decision_vars[0]
        i += 5
        j += 5

    media_variables = media_var_upd
    return media_variables, coef


def get_5_point_summary(
        shortlisted_sol_output_path,
        brand_df,
        brand_nm,
        base_num=0,
        base_list=None,
        best_sol_num=None,
):
    print(f"SBU: {brand_nm}")
    fig_title = "default_plot.png"
    media_tactics = brand_df["Media_tactic"].unique()
    bases = base_list if (base_list and len(base_list) > 0) else [base_num]
    selected_bases = []
    season = {
        "0": "MV 7",
        "1": "MV 15",
        "2": "MV 30",
        "3": "Period 52",
        "4": "Monthly",
        "5": "Quarterly",
        "6": "Sarimax",
        "7": "Sarimax Log",
        "8": "Trend_Seasonality",
        "9": "Trend_Seasonality_Log",
        "10": "Final shortlisted",
    }
    for media in media_tactics:
        fig, axs = plt.subplots(1, len(bases), figsize=(30, 5))
        if len(bases) == 1:
            axs = [axs]
        for i, ax in enumerate(axs):

            if bases[i] == 10:
                filtered_df = brand_df[(brand_df["Media_tactic"] == media)]

            else:
                filtered_df = brand_df[
                    (brand_df["Non_media_set"] == bases[i])
                    & (brand_df["Media_tactic"] == media)
                    ]
            if len(filtered_df) > 0:
                selected_bases.append(bases[i])
                try:
                    n_bins = min(30, max(1, len(filtered_df) // 2))
                    sns.histplot(data=filtered_df, x="Tactic_iRoAS", kde=False, ax=ax, bins=n_bins)  # , bins=30
                except:
                    sns.histplot(data=filtered_df, x="Tactic_iRoAS", kde=False, ax=ax, bins=1) 
                
                if best_sol_num:
                    ax.axvline(
                        filtered_df[filtered_df["Base_sol_num"] == best_sol_num][
                            "Tactic_iRoAS"
                        ].mean(),
                        color="r",
                        linestyle="--",
                    )
                else:
                    ax.axvline(
                        filtered_df["Tactic_iRoAS"].mean(), color="r", linestyle="--"
                    )
                if bases[i] == 10:
                    ax.set_title(f"{media} / {season[str(bases[i])]}")
                    fig_title = f"{media} - {season[str(bases[i])]}.png"

                else:
                    ax.set_title(f"{media} / Base: {season[str(bases[i])]}")
                    fig_title = f"{media} - Base: {season[str(bases[i])]}.png"

                # Compute 5-point summary
                min_val = filtered_df["Tactic_iRoAS"].min()
                max_val = filtered_df["Tactic_iRoAS"].max()
                median_val = filtered_df["Tactic_iRoAS"].median()
                mean_val = filtered_df["Tactic_iRoAS"].mean()
                std_val = filtered_df["Tactic_iRoAS"].std()
                quartile1_val = filtered_df["Tactic_iRoAS"].quantile(0.25)
                quartile3_val = filtered_df["Tactic_iRoAS"].quantile(0.75)

                # Fit KDE and compute peak
                if filtered_df["Tactic_iRoAS"].dropna().shape[0] < 2:
                    peak_val = mean_val
                else:
                    try:
                        kde = gaussian_kde(filtered_df["Tactic_iRoAS"].dropna())
                        x_vals = np.linspace(min_val, max_val, 1000)
                        peak_val = x_vals[np.argmax(kde(x_vals))]
                    except:
                        peak_val = mean_val

                # Print 5-point summary and peak on the plot
                summary_text = f"Min: {round(min_val, 2)}\nQ1: {round(quartile1_val, 2)}\nMedian: {round(median_val, 2)}\nMean: {round(mean_val, 2)}\nStd: {round(std_val, 2)} \nQ3: {round(quartile3_val, 2)}\nMax: {round(max_val, 2)}\nPeak: {round(peak_val, 2)}"
                ax.text(
                    0.95,
                    0.95,
                    summary_text,
                    transform=axs[i].transAxes,
                    verticalalignment="top",
                    horizontalalignment="right",
                )
                # ax.savefig(f"{shortlisted_sol_output_path}/{fig_title}")

        plt.tight_layout()

        sbu_normalized = brand_nm.title().replace(" ", "_")

        base_path = shortlisted_sol_output_path.replace(f'gs://{bucket_name}/', '')
        if '/shortlisted_solutions' in base_path:
            base_path = base_path.split('/shortlisted_solutions')[0]

        plots_dir = f"{base_path}/plots"
        os.makedirs(plots_dir, exist_ok=True)
        local_plot_path = f"{plots_dir}/{fig_title}"
        plt.savefig(local_plot_path, format='png', bbox_inches='tight', dpi=300)
        print(f"✅ Saved plot locally to: {local_plot_path}")
        # plt.show()

    # Plot histogram of Overall iRoAS for different bases in one row
    fig, axs = plt.subplots(1, len(bases), figsize=(30, 5))
    max_overall_iroas = -float("inf")
    selected_base = 0
    if len(bases) == 1:
        axs = [axs]
    for i, ax in enumerate(axs):
        if bases[i] == 10:
            df = (
                brand_df.groupby(["Solution_number", "Base_sol_num"])["Overall_iroas"]
                .mean()
                .reset_index()
            )
        else:
            df = (
                brand_df[brand_df["Non_media_set"] == bases[i]]
                .groupby(["Solution_number"])["Overall_iroas"]
                .mean()
                .reset_index()
            )
        
        n_bins = min(30, max(1, len(df) // 2))
        try:
            sns.histplot(data=df, x="Overall_iroas", kde=False, ax=ax, bins=n_bins)  # , bins=30
        except:
            sns.histplot(data=df, x="Overall_iroas", kde=False, ax=ax, bins=1)

        if best_sol_num:
            ax.axvline(
                df[df["Base_sol_num"] == best_sol_num]["Overall_iroas"].mean(),
                color="r",
                linestyle="--",
            )
            ax.set_title(f"Overall_iroas: {season[str(bases[i])]}")
            fig_title = f"Overall_iroas- {season[str(bases[i])]}.png"
        else:
            ax.axvline(df["Overall_iroas"].mean(), color="r", linestyle="--")
            ax.set_title(f"Overall_iroas / Base: {season[str(bases[i])]}")
            fig_title = f"Overall_iroas - Base: {season[str(bases[i])]}.png"

        # Compute 5-point summary for Overall_iroas
        min_val = df["Overall_iroas"].min()
        max_val = df["Overall_iroas"].max()
        median_val = df["Overall_iroas"].median()
        mean_val = df["Overall_iroas"].mean()
        std_val = df["Overall_iroas"].std()
        quartile1_val = df["Overall_iroas"].quantile(0.25)
        quartile3_val = df["Overall_iroas"].quantile(0.75)
        if mean_val > max_overall_iroas:
            max_overall_iroas = max(mean_val, max_overall_iroas)
            selected_base = i
        # Fit KDE and compute peak for Overall_iroas
        # print(df['Overall_iroas'].shape)
        if df["Overall_iroas"].dropna().shape[0] < 4:
            peak_val = mean_val
        else:
            try:
                kde = gaussian_kde(df["Overall_iroas"].dropna())
                x_vals = np.linspace(min_val, max_val, 1000)
                peak_val = x_vals[np.argmax(kde(x_vals))]
            except:
                peak_val = mean_val

        # Print 5-point summary and peak on the plot for Overall_iroas
        summary_text = f"Min: {round(min_val, 2)}\nQ1: {round(quartile1_val, 2)}\nMedian: {round(median_val, 2)}\nMean: {round(mean_val, 2)}\nStd: {round(std_val, 2)} \nQ3: {round(quartile3_val, 2)}\nMax: {round(max_val, 2)}\nPeak: {round(peak_val, 2)}"
        ax.text(
            0.95,
            0.95,
            summary_text,
            transform=ax.transAxes,
            verticalalignment="top",
            horizontalalignment="right",
        )

    plt.tight_layout()

    sbu_normalized = brand_nm.title().replace(" ", "_")

    base_path = shortlisted_sol_output_path.replace(f'gs://{bucket_name}/', '')
    if '/shortlisted_solutions' in base_path:
        base_path = base_path.split('/shortlisted_solutions')[0]

    plots_dir = f"{base_path}/plots"
    os.makedirs(plots_dir, exist_ok=True)
    local_plot_path = f"{plots_dir}/{fig_title}"
    plt.savefig(local_plot_path, format='png', bbox_inches='tight', dpi=300)
    print(f"✅ Saved plot locally to: {local_plot_path}")
    # plt.show()


def calculate_quantiles(df, brand, col_names, train_start, train_end):
    df["Date"] = pd.to_datetime(df["Date"])
    df.set_index("Date", inplace=True)

    avg_dic = {col_names[0]: [], col_names[1]: [], col_names[2]: [], "SBU": []}
    avg_dic["sbu_name"].append(brand)

    tp = df[df["sbu_name"] == brand]

    for col_name in col_names:
        tp_nzero = tp[tp[col_name] > 0]
        avg_dic[col_name].append(int(tp_nzero[col_name].mean()))

    avg_df = pd.DataFrame(avg_dic)

    df = df.loc[train_start:train_end]
    stats = []
    for col_name in col_names:
        df_nonzero = df[df[col_name] != 0]
        perc_5 = int(df_nonzero[col_name].quantile(0.05))
        perc_95 = int(df_nonzero[col_name].quantile(0.95))
        mean = int(df_nonzero[col_name].mean())
        median = int(df_nonzero[col_name].quantile(0.5))
        Q1 = int(df_nonzero[col_name].quantile(0.25))
        Q3 = int(df_nonzero[col_name].quantile(0.75))
        stats.append([col_name, perc_5, perc_95, Q1, Q3, mean, median])

    stats_df = pd.DataFrame(
        stats,
        columns=[
            "Column",
            "5th_Quantile",
            "95th_Quantile",
            "Q1",
            "Q3",
            "Mean",
            "Median",
        ],
    )
    return stats_df


def shortlist_solutions(target_df, dictionary, brand, dev_threshold=0.3):
    max_dev_strategy = False

    tact_median = {
        tc: target_df.loc[target_df.Media_tactic == tc, "Tactic_iRoAS"].median()
        for tc in target_df.Media_tactic.unique()
    }
    tact_mean = {
        tc: target_df.loc[target_df.Media_tactic == tc, "Tactic_iRoAS"].mean()
        for tc in target_df.Media_tactic.unique()
    }
    tact_q1 = {
        tc: target_df.loc[target_df.Media_tactic == tc, "Tactic_iRoAS"].quantile(0.25)
        for tc in target_df.Media_tactic.unique()
    }
    tact_q3 = {
        tc: target_df.loc[target_df.Media_tactic == tc, "Tactic_iRoAS"].quantile(0.75)
        for tc in target_df.Media_tactic.unique()
    }

    target_df[["Threshold", "Saturation"]] = pd.DataFrame(
        target_df.Threshold_Saturation.apply(
            lambda s: list(ast.literal_eval(s))
        ).tolist(),
        index=target_df.index,
    )

    target_df["iRoAS_Median"] = target_df["Media_tactic"].map(tact_median)
    target_df["iRoAS_Mean"] = target_df["Media_tactic"].map(tact_mean)
    target_df["Q1_iRoAS"] = target_df["Media_tactic"].map(tact_q1)
    target_df["Q3_iRoAS"] = target_df["Media_tactic"].map(tact_q3)
    target_df["Sat_Target"] = target_df["Media_tactic"].map(dictionary)
    target_df["tac_dev"] = (
            abs(target_df["Tactic_iRoAS"] - target_df["iRoAS_Median"])
            / target_df["iRoAS_Median"]
    )
    target_df["Inflection"] = (target_df["Saturation"] + target_df["Threshold"]) / 2
    target_df["Sat_Dev"] = target_df.apply(
        lambda row: (min((row["Saturation"] - row["Sat_Target"]), 0)) ** 2
                    / row["Sat_Target"] ** 2,
        axis=1,
    )

    scores = target_df.groupby("Solution_number")["Sat_Dev"].sum().reset_index()
    scores.columns = ["Solution_number", "score_sat"]
    target_df = pd.merge(target_df, scores, on="Solution_number")

    scores = target_df.groupby("Solution_number")["tac_dev"].sum().reset_index()
    scores.columns = ["Solution_number", "score_iroas"]
    target_df = pd.merge(target_df, scores, on="Solution_number")
    target_df = target_df.sort_values("score_sat", ascending=True)
    t_summary = (
        target_df.groupby("Media_tactic")[["Saturation", "Inflection"]]
        .describe()
        .astype(int)
    )

    if max_dev_strategy:
        sol_select = [
            target_df.loc[target_df.Solution_number == i]
            for i in target_df.Solution_number.unique()
            if target_df.loc[target_df.Solution_number == i, "tac_dev"]
            .le(dev_threshold)
            .all()
        ]
    else:
        sol_select = []

        unique_solution_numbers = target_df["Solution_number"].unique()

        for solution_number in unique_solution_numbers:
            tp = target_df[target_df["Solution_number"] == solution_number]
            condition = (tp["Q1_iRoAS"] <= tp["Tactic_iRoAS"]) & (
                    tp["Tactic_iRoAS"] <= tp["Q3_iRoAS"]
            )
            valid_row_count = condition.sum()
            if valid_row_count == 3:
                sol_select.append(tp)

    media_names = {
        "M_ON_DIS_TOTAL_IMP": "Onsite",
        "M_OFF_DIS_TOTAL_IMP": "Offsite",
        "M_SEARCH_CLK": "Search",
        "M_ON_DIS_TOTAL_UPD_IMP": "Onsite",
        "M_OFF_DIS_TOTAL_UPD_IMP": "Offsite",
        "M_SEARCH_UPD_CLK": "Search",
    }
    if len(sol_select) < 1:
        print(
            f"1. No Solutions for sbu {brand} with deviation threshold {dev_threshold}"
        )
        return [], None
    else:
        fin_df = pd.concat(sol_select)
        sol_select = [
            fin_df.loc[fin_df.Solution_number == i]
            for i in fin_df.Solution_number.unique()
            if fin_df.loc[fin_df.Solution_number == i, "tac_dev"]
            .le(dev_threshold)
            .all()
        ]
        if len(sol_select) < 1:
            print(
                f"2. No Solutions for sbu {brand} with deviation threshold {dev_threshold}"
            )
            return [], None
        else:
            fin_df = pd.concat(sol_select)
        fin_df["Media"] = fin_df["Media_tactic"].map(media_names)
        fin_df = fin_df[
            [
                "Solution_number",
                "Media",
                "Tactic_iRoAS",
                "Overall_iroas",
                "Saturation",
                "Inflection",
                "Sat_Target",
            ]
        ]
        fin_df.sort_values("Saturation", ascending=False)
        for col in fin_df.select_dtypes(include=[np.float64]):
            fin_df[col] = fin_df[col].round(2)
        print("********************** Tactics summary **********************")
        print(f"{t_summary : t_summary}")

    selected_solutions = [
        sol_select[i].Solution_number.unique()[0] for i in range(len(sol_select))
    ]
    return selected_solutions, fin_df.sort_values(
        by=["Overall_iroas", "Solution_number", "Media"], ascending=[False, True, True]
    )


def plot_pacing_charts(data, shortlisted_df, priors_info_df):
    print(data.head())
    print(shortlisted_df)

    data = data.set_index(pd.to_datetime(data["Date"]))
    for m in priors_info_df["media_variable"].unique():
        target_threshold = priors_info_df.loc[
            priors_info_df["media_variable"] == m, "target_threshold"
        ].values[0]
        target_saturation = priors_info_df.loc[
            priors_info_df["media_variable"] == m, "target_saturation"
        ].values[0]
        threshold = shortlisted_df.loc[
            shortlisted_df["Media_tactic"] == m, "Threshold"
        ].values[0]
        saturation = shortlisted_df.loc[
            shortlisted_df["Media_tactic"] == m, "Saturation"
        ].values[0]
        inflection = shortlisted_df.loc[
            shortlisted_df["Media_tactic"] == m, "Inflection_Point"
        ].values[0]
        plt.figure(figsize=(15, 5))
        df_tactic = data[["SBU", m]].copy()
        df_tactic.reset_index(inplace=True)
        sns.lineplot(data=df_tactic, x="Date", y=m, hue="SBU")
        plt.axhline(
            target_threshold,
            color="r",
            linestyle=":",
            label="target_threshold",
            alpha=0.5,
        )
        plt.axhline(
            target_saturation,
            color="blue",
            linestyle=":",
            label="target_saturation",
            alpha=0.5,
        )
        plt.axhline(threshold, color="r", linestyle="--", label="actual_threshold")
        plt.axhline(inflection, color="yellow", linestyle="--", label="actual_inflection")
        plt.axhline(saturation, color="blue", linestyle="--", label="actual_saturation")
        plt.title(f"Imp/Clk for {m}")
        plt.legend()
        # plt.show()


def get_scurves(
        priors,
        shortlisted_df,
        point_estimate_sol,
        media_variables,
        data,
        train_start,
        train_end,
        test_start,
        test_end,
        folder_path,
):
    print(f"Get_scurves")
    selected_df = shortlisted_df[
        shortlisted_df["Base_sol_num"] == point_estimate_sol
        ].copy()
    print(shortlisted_df.columns)
    plot_pacing_charts(data.copy(), selected_df.copy(), priors.copy())
    solution_arr = []
    for media in media_variables:
        solution_arr.append(
            selected_df[selected_df["Media_tactic"] == media]["Coefficient"].values[0]
        )
        solution_arr.append(
            selected_df[selected_df["Media_tactic"] == media]["Halflife"].values[0]
        )
        solution_arr.append(
            selected_df[selected_df["Media_tactic"] == media]["Inflection"].values[0]
        )
        solution_arr.append(
            selected_df[selected_df["Media_tactic"] == media]["Scale"].values[0]
        )
        solution_arr.append(
            selected_df[selected_df["Media_tactic"] == media]["Lag"].values[0]
        )
        # solution_arr += ast.literal_eval(
        #     selected_df[selected_df["Media_tactic"] == media][
        #         "Media_transformation (hf, inf, sc, lg)"
        #     ].values[0]
        # )

    media_var_upd, coef = get_upd_media(media_variables, solution_arr)

    df = data.copy()
    if 'INDEX' in df.columns:
        df = df.drop('INDEX', axis=1)
    if 'index' in df.columns:
        df = df.drop('index', axis=1)
    df = df.reset_index(drop=True)

    df["Date"] = pd.to_datetime(df["Date"])
    df = df.rename(columns={"Date": "index"})

    # print(train_start)
    # print(train_end)
    model_obj = MMM_Modelling(
        df,
        "O_UNIT",
        media_var_upd,
        other_variables,
        output_path=folder_path,
        data_dict=data_dict,
        media_hier=media_hier,
        comment="Media Mix Model",
        solution=solution_arr,
        start=train_start,
        end=train_end,
    )
    model_obj.coefs_dict = coef
    # Creating train test split
    model_obj.create_train_test_split(train_start, train_end, test_start, test_end)
    # create all the media transformations

    model_obj.create_missing_media_transformations(
        media_var_upd, trans_start_date=train_start, trans_end_date=train_end
    )
    for c in media_var_upd:
        model_obj.df[c] = model_obj.df[c] + 1.0e-15

    for c in media_var_upd:
        s = model_obj.df[
            (model_obj.df["index"] >= train_start)
            & (model_obj.df["index"] <= train_end)
            ][c].sum()
        if s <= 0.0:
            print(c, s)

    model_obj.create_model_results(X_vars=media_var_upd, model_type="Manual Model 1")
    model_obj.set_plot_point_position(
        inf_pt_pos="middle right",
        sat_pt_pos="top right",
        thres_pt_pos="middle right",
        avg_pt_pos="bottom right",
    )
    for media in media_var_upd:
        print(f"Media: {media} | Start Date: {train_start} | End Date: {train_end}")
        model_obj.plot_response_curve(
            media,
            model_label="Manual Model 1",
            start_date=train_start,
            end_date=train_end,
            threshold_calculator="logistic",
            saturation_calculator="logistic",
            spend=False,
            show_xy_labels=True,
            show_xyaxis_title=False,
            use_freezed_values=True,
            use_freezed_values_tp=True,
        )
    ####
    # Latest 12 months S curves
    start_date_12 = train_end - relativedelta(months=12) + relativedelta(days=1)
    for media in media_var_upd:
        print("latest 12 months S curve:")
        print(f"Media: {media} | Start Date: {start_date_12} | End Date: {train_end}")
        model_obj.plot_response_curve(
            media,
            model_label="Manual Model 1",
            start_date=start_date_12,
            end_date=train_end,
            threshold_calculator="logistic",
            saturation_calculator="logistic",
            spend=False,
            show_xy_labels=True,
            show_xyaxis_title=False,
            use_freezed_values=True,
            use_freezed_values_tp=True,
        )
    #####


def get_transformed_actual(data, media_variables):
    df_data_by_brand = data[media_variables].copy()
    df_data_by_brand = df_data_by_brand.to_numpy().astype("float64")
    return df_data_by_brand


def get_transformed_spend_actual(data, media_variables):
    df_media_spend_by_brand = []
    spend_variables = []
    for media in media_variables:
        spend_variables.append(media[:-4] + "_SPEND")
    df_media_spend_by_brand = data[spend_variables].copy()
    df_media_spend_by_brand = df_media_spend_by_brand.to_numpy().astype("float64")
    df_media_spend_by_brand = np.asarray(df_media_spend_by_brand)
    transformed_spend_var_actual = (df_media_spend_by_brand > 0).astype(int)
    return transformed_spend_var_actual


def create_solution_list(df):
    result = []
    for solution in df["Base_sol_num"].unique():
        solution_df = df[df["Base_sol_num"] == solution]
        solution_list = (
            solution_df[["Coefficient", "Halflife", "Inflection", "Scale", "Lag"]]
            .values.flatten()
            .tolist()
        )
        result.append(solution_list)
    return result


def get_transformed_sales(
        solution,
        media_variables,
        df_by_brand,
        transformed_var_actual,
        transformed_spend_var_actual,
        price,
        handle_added_value=False,
        use_scaling=False,
):
    # halflife, threshold, saturation, lag
    i = 0
    j = 5
    df_filtered = df_by_brand.copy()
    num_media_vars = len(media_variables)
    transformed_daily_sales = np.zeros((num_media_vars, len(transformed_var_actual)))

    for media_var_idx in range(num_media_vars):
        coef = solution[i]
        decision_vars = solution[i + 1: j]

        halflife = decision_vars[0]
        inflection = decision_vars[1]
        scale = decision_vars[2]
        lag = int(decision_vars[3])

        # Running actual transformations
        transformed_var = transformed_var_actual[:, media_var_idx]
        transformed_spend = transformed_spend_var_actual[:, media_var_idx]
        if handle_added_value:
            transformed_var = (
                    transformed_var * transformed_spend
            )  ### ignore spend = 0 for added value
        if lag != 0:
            transformed_var = lag_transformation(transformed_var, lag)
        if halflife != 0:
            transformed_var = halflife_transformation(transformed_var, halflife)

        var_mean = transformed_var.mean()

        if (scale != 0) and (inflection != 0):
            transformed_var_scaled = transformed_var / var_mean
            saturation_term = scale * (inflection - transformed_var_scaled)
            scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (
                    1 + np.exp(scale * inflection)
            )
            scurve_var_mean = scurve_var.mean()
            transformed_var = scurve_var * var_mean / scurve_var_mean

        # calculate scaling factor here
        if use_scaling:
            scaling_factor = max(transformed_var) - min(transformed_var)
            transformed_var = (transformed_var - min(transformed_var)) / scaling_factor
        else:
            scaling_factor = 1

        transformed_daily_sales[media_var_idx] = np.asarray(
            transformed_var * price * coef
        )  # daily sales
        i += 5
        j += 5

    return transformed_daily_sales


def get_final_solution_with_ridge(
        updated_stack_brand,
        shortlisted_sols,
        ridge_shortlisted_sols,
        media_variables,
        train_start,
        train_end,
        valid_start,
        valid_end,
        results_folder,
        handle_added_value,
        use_scaling,
):
    time_val = int(time())
    shortlisted_sol_path = (
            results_folder + f"/Ridge_with_iRoAS_Priors_Shortlisted_Sols_{time_val}.csv"
    )
    ridge_shortlisted_sols.to_csv(shortlisted_sol_path, index=True)

    min_roas_sol_data = shortlisted_sols[
        ["Base_sol_num", "Sum_deviation_from_prior", "Sum_dev_from_inflection"]
    ].drop_duplicates()
    min_roas_sol_data_backup = min_roas_sol_data.copy()
    try:
        min_roas_sol_data = min_roas_sol_data.nsmallest(10, "Sum_deviation_from_prior")[
            ["Base_sol_num", "Sum_deviation_from_prior", "Sum_dev_from_inflection"]
        ]
    except:
        print("Failing for nsmallest")
        min_roas_sol_data = min_roas_sol_data_backup.sort_values(
            ["Sum_deviation_from_prior"]
        ).head(10)
    point_estimate_sol = min_roas_sol_data.sort_values(["Sum_dev_from_inflection"])[
        "Base_sol_num"
    ].iloc[0]

    print("\n**************** SELECTED SOLUTION ******************\n")

    # display(shortlisted_sols[shortlisted_sols["Base_sol_num"] == point_estimate_sol])
    print(shortlisted_sols[shortlisted_sols["Base_sol_num"] == point_estimate_sol])
    print("\n\n")
    ridge_shortlisted_sols.reset_index(drop=True, inplace=True)
    get_5_point_summary(
        ridge_shortlisted_sols.copy(),
        list(ridge_shortlisted_sols.sbu_name.unique())[0],
        base_num=10,
        best_sol_num=point_estimate_sol,
    )
    print("\n\n")
    # Step 1: Group the data by media tactic
    grouped = ridge_shortlisted_sols.groupby("Media_tactic")["Tactic_iRoAS"]
    grouped2 = ridge_shortlisted_sols.groupby("Base_sol_num")["Overall_iroas"].mean()

    # Step 2: Calculate summary metrics
    summary_df = pd.DataFrame(
        {
            "Min": grouped.min(),
            "Q1": grouped.quantile(0.25),
            "Median": grouped.median(),
            "Mean": grouped.mean(),
            "Q3": grouped.quantile(0.75),
            "Max": grouped.max(),
        }
    )
    summary_df_overall = pd.Series(
        {
            "Min": grouped2.min(),
            "Q1": grouped2.quantile(0.25),
            "Median": grouped2.median(),
            "Mean": grouped2.mean(),
            "Q3": grouped2.quantile(0.75),
            "Max": grouped2.max(),
        },
        name="Overall_iroas",
    )
    summary_df = pd.concat([summary_df, summary_df_overall.to_frame().T])

    # Step 3: Add selected tactic iroas values from the best solution
    selected_values = ridge_shortlisted_sols[
        ridge_shortlisted_sols["Base_sol_num"] == point_estimate_sol
        ].set_index("Media_tactic")["Tactic_iRoAS"]
    selected_overall = pd.Series(
        ridge_shortlisted_sols[
            ridge_shortlisted_sols["Base_sol_num"] == point_estimate_sol
            ]["Overall_iroas"].mean(),
        name="Overall_iroas",
    )
    selected_values = pd.concat([selected_values, selected_overall])
    selected_values.index = selected_values.index[:-1].tolist() + ["Overall_iroas"]
    summary_df["selected_value"] = selected_values

    # Transpose the dataframe to have tactics as columns and metrics as rows
    summary_df = summary_df.T
    shortlisted_sol_summary_path = (
            results_folder + f"/Ridge_with_iRoAS_Priors_Sols_Summary_{time_val}.csv"
    )
    # summary_df.to_csv(shortlisted_sol_summary_path)
    upload_dataframe_to_gcs(summary_df, shortlisted_sol_summary_path)

    get_final_solution_ridge_smooth(
        shortlisted_sols[shortlisted_sols["Base_sol_num"] == point_estimate_sol].copy(),
        updated_stack_brand.copy(),
        media_variables.copy(),
        handle_added_value,
        results_folder,
        list(shortlisted_sols.sbu_name.unique())[0],
        use_scaling,
        train_end,
    )
    try:
        get_scurves(
            priors_info,
            no_ridge_shortlisted_sols.copy(),
            best_solution_number,
            media_variables,
            updated_stack_brand.copy(),
            train_start,
            train_end,
            valid_start,
            valid_end,
            folder_path=results_folder,
        )
    except Exception as e:
        print(f"⚠️  get_scurves skipped (non-critical): {e}")


def get_final_solution(
        shortlisted_sol_output_path,
        priors_info,
        no_ridge_shortlisted_sols,
        media_variables,
        updated_stack_brand,
        train_start,
        train_end,
        valid_start,
        valid_end,
        results_folder,
        non_media_coefs,
        handle_added_value,
        WMC_PORTFOLIO_DICT,
        use_scaling,
        brand_nm=None,
        percentile_filter=True,
        Median_filter=True,
        iRoAS_within_bound=True,
        post_adjustment_tool=False
):
    train_start = datetime.strptime(train_start, date_format)
    train_end = datetime.strptime(train_end, date_format)
    train_end_index = (train_end - train_start).days + 1
    training_price = updated_stack_brand[:train_end_index]["PRICE"].mean()

    # no_ridge_shortlisted_sols = no_ridge_shortlisted_sols.loc[
    #                             :, ~no_ridge_shortlisted_sols.columns.str.startswith('Unnamed')
    #                             ]
    # no_ridge_shortlisted_sols = no_ridge_shortlisted_sols.reset_index(drop=True)

    time_val = int(time())
    shortlisted_sol_path = (
            results_folder + f"/Ridge_Default_iRoAS_Shortlisted_Sols_{time_val}.csv"
    )
    upload_df_to_gcs(no_ridge_shortlisted_sols, shortlisted_sol_path, bucket_name)
    print(f"✅ Shortlisted solutions uploaded: {shortlisted_sol_path}")

    def sub_filter(group):
        flag = True
        for media_variable in group["Media_tactic"].unique():
            tactic_iroas = group[group["Media_tactic"] == media_variable][
                "Tactic_iRoAS"
            ]
            if not (
                    (tactic_iroas >= tactic_iroas_q1[media_variable]).all()
                    and (tactic_iroas <= tactic_iroas_q3[media_variable]).all()
            ):
                flag = False
                break
        return group if flag else pd.DataFrame(columns=group.columns)

    tactic_iroas_q1 = no_ridge_shortlisted_sols.groupby("Media_tactic")[
        "Tactic_iRoAS"
    ].quantile(0.02)
    tactic_iroas_q3 = no_ridge_shortlisted_sols.groupby("Media_tactic")[
        "Tactic_iRoAS"
    ].quantile(0.98)

    if percentile_filter:
        no_ridge_shortlisted_sols = (
            no_ridge_shortlisted_sols.groupby("Solution_number")
            .apply(sub_filter)
            .reset_index(drop=True)
        )

    print(
        f"Solutions after percentile filter: {no_ridge_shortlisted_sols['Solution_number'].nunique()}"
    )
    # no_ridge_shortlisted_sols.to_csv(shortlisted_sol_path, index=False)

    ######## iRoAS closest to Median filter #########

    if no_ridge_shortlisted_sols['Solution_number'].nunique() != 0:
        if Median_filter:
            best_solution_number = get_point_estimate_by_base(
                no_ridge_shortlisted_sols, final_selection=False
            )

            print("\n**************** SELECTED SOLUTION ******************\n")
            print("\n\n")
            print(
                no_ridge_shortlisted_sols[
                    no_ridge_shortlisted_sols["Base_sol_num"] == best_solution_number
                    ]
            )
            print("\n\n")
            no_ridge_shortlisted_sols.reset_index(drop=True, inplace=True)
            get_5_point_summary(
                shortlisted_sol_output_path,
                no_ridge_shortlisted_sols.copy(),
                list(no_ridge_shortlisted_sols.sbu_name.unique())[0],
                base_num=10,
                best_sol_num=best_solution_number,
            )
            print("\n\n")
            # Step 1: Group the data by media tactic
            grouped = no_ridge_shortlisted_sols.groupby("Media_tactic")["Tactic_iRoAS"]
            grouped2 = no_ridge_shortlisted_sols.groupby("Base_sol_num")["Overall_iroas"].mean()

            # Step 2: Calculate summary metrics
            summary_df = pd.DataFrame(
                {
                    "Min": grouped.min(),
                    "Q1": grouped.quantile(0.25),
                    "Median": grouped.median(),
                    "Mean": grouped.mean(),
                    "Q3": grouped.quantile(0.75),
                    "Max": grouped.max(),
                }
            )
            summary_df_overall = pd.Series(
                {
                    "Min": grouped2.min(),
                    "Q1": grouped2.quantile(0.25),
                    "Median": grouped2.median(),
                    "Mean": grouped2.mean(),
                    "Q3": grouped2.quantile(0.75),
                    "Max": grouped2.max(),
                },
                name="Overall_iroas",
            )
            summary_df = pd.concat([summary_df, summary_df_overall.to_frame().T])

            # Step 3: Add selected tactic iroas values from the best solution
            selected_values = no_ridge_shortlisted_sols[
                no_ridge_shortlisted_sols["Base_sol_num"] == best_solution_number
                ].set_index("Media_tactic")["Tactic_iRoAS"]
            selected_overall = pd.Series(
                no_ridge_shortlisted_sols[
                    no_ridge_shortlisted_sols["Base_sol_num"] == best_solution_number
                    ]["Overall_iroas"].mean(),
                name="Overall_iroas",
            )
            selected_values = pd.concat([selected_values, selected_overall])
            selected_values.index = selected_values.index[:-1].tolist() + ["Overall_iroas"]
            summary_df["selected_value"] = selected_values

            # Transpose the dataframe to have tactics as columns and metrics as rows
            summary_df = summary_df.T
            # shortlisted_sol_summary_path = (
            #         results_folder + f"/Ridge_Default_iRoAS_Sols_Summary_{time_val}.csv"
            # )
            shortlisted_sol_summary_path = f"{results_folder.rstrip('/')}/Ridge_Default_iRoAS_Sols_Summary_{time_val}.csv"

            # summary_df.to_csv(shortlisted_sol_summary_path)
            upload_df_to_gcs(summary_df, shortlisted_sol_summary_path, bucket_name)  # m0p01io

            best_solution = no_ridge_shortlisted_sols[
                no_ridge_shortlisted_sols["Base_sol_num"] == best_solution_number
                ].copy()

            df_transformed_from_solution = get_transformed_df(best_solution, updated_stack_brand)
            df_transformed_from_solution["Date"] = pd.to_datetime(df_transformed_from_solution["Date"])

            # plot_model_fit(media_variables,
            #                 non_media_coefs,
            #                 updated_stack_brand,
            #                 best_solution,
            #                 df_transformed_from_solution)

            for key, value in WMC_PORTFOLIO_DICT.items():
                start_date = value["start_date"]
                end_date = value["end_date"]
                period = value["Period"]

                get_iroas_metrics(best_solution,
                                  df_transformed_from_solution,
                                  media_variables,
                                  updated_stack_brand,
                                  start_date,
                                  end_date,
                                  period,
                                  training_price)

            try:
                get_scurves(
                    priors_info,
                    no_ridge_shortlisted_sols.copy(),
                    best_solution_number,
                    media_variables,
                    updated_stack_brand.copy(),
                    train_start,
                    train_end,
                    valid_start,
                    valid_end,
                    folder_path=results_folder,
                )
            except Exception as e:
                print(f"⚠️  get_scurves skipped (non-critical): {e}")

            print("Most Recent 1 Year S curves")

            try:
                most_recent_s_curve_table(media_variables, updated_stack_brand.copy(), best_solution, train_start,
                                          train_end)
            except Exception as e:
                print(f"⚠️  most_recent_s_curve_table skipped (non-critical): {e}")

            return best_solution_number


        else:

            best_solution_number = get_point_estimate(
                no_ridge_shortlisted_sols.copy(), iRoAS_within_bound, media_variables
            )

            print("\n**************** SELECTED SOLUTION ******************\n")
            print("\n\n")
            print(
                no_ridge_shortlisted_sols[
                    no_ridge_shortlisted_sols["Base_sol_num"] == best_solution_number
                    ]
            )
            print("\n\n")
            no_ridge_shortlisted_sols.reset_index(drop=True, inplace=True)
            get_5_point_summary(
                shortlisted_sol_output_path,
                no_ridge_shortlisted_sols.copy(),
                list(no_ridge_shortlisted_sols.sbu_name.unique())[0],
                base_num=10,
                best_sol_num=best_solution_number,
            )
            print("\n\n")
            # Step 1: Group the data by media tactic
            grouped = no_ridge_shortlisted_sols.groupby("Media_tactic")["Tactic_iRoAS"]
            grouped2 = no_ridge_shortlisted_sols.groupby("Base_sol_num")["Overall_iroas"].mean()

            # Step 2: Calculate summary metrics
            summary_df = pd.DataFrame(
                {
                    "Min": grouped.min(),
                    "Q1": grouped.quantile(0.25),
                    "Median": grouped.median(),
                    "Mean": grouped.mean(),
                    "Q3": grouped.quantile(0.75),
                    "Max": grouped.max(),
                }
            )
            summary_df_overall = pd.Series(
                {
                    "Min": grouped2.min(),
                    "Q1": grouped2.quantile(0.25),
                    "Median": grouped2.median(),
                    "Mean": grouped2.mean(),
                    "Q3": grouped2.quantile(0.75),
                    "Max": grouped2.max(),
                },
                name="Overall_iroas",
            )
            summary_df = pd.concat([summary_df, summary_df_overall.to_frame().T])

            # Step 3: Add selected tactic iroas values from the best solution
            selected_values = no_ridge_shortlisted_sols[
                no_ridge_shortlisted_sols["Base_sol_num"] == best_solution_number
                ].set_index("Media_tactic")["Tactic_iRoAS"]
            selected_overall = pd.Series(
                no_ridge_shortlisted_sols[
                    no_ridge_shortlisted_sols["Base_sol_num"] == best_solution_number
                    ]["Overall_iroas"].mean(),
                name="Overall_iroas",
            )
            selected_values = pd.concat([selected_values, selected_overall])
            selected_values.index = selected_values.index[:-1].tolist() + ["Overall_iroas"]
            summary_df["selected_value"] = selected_values

            # Transpose the dataframe to have tactics as columns and metrics as rows
            summary_df = summary_df.T
            # shortlisted_sol_summary_path = (
            #         results_folder + f"/Ridge_Default_iRoAS_Sols_Summary_{time_val}.csv"
            # )
            shortlisted_sol_summary_path = f"{results_folder.rstrip('/')}/Ridge_Default_iRoAS_Sols_Summary_{time_val}.csv"
            # summary_df.to_csv(shortlisted_sol_summary_path)
            upload_df_to_gcs(summary_df, shortlisted_sol_summary_path, bucket_name)  # m0p01io

            best_solution = no_ridge_shortlisted_sols[
                no_ridge_shortlisted_sols["Base_sol_num"] == best_solution_number
                ].copy()

            df_transformed_from_solution = get_transformed_df(best_solution, updated_stack_brand)
            df_transformed_from_solution["Date"] = pd.to_datetime(df_transformed_from_solution["Date"])

            # plot_model_fit(media_variables,
            #                 non_media_coefs,
            #                 updated_stack_brand,
            #                 best_solution,
            #                 df_transformed_from_solution)

            for key, value in WMC_PORTFOLIO_DICT.items():
                start_date = value["start_date"]
                end_date = value["end_date"]
                period = value["Period"]

                get_iroas_metrics(best_solution,
                                  df_transformed_from_solution,
                                  media_variables,
                                  updated_stack_brand,
                                  start_date,
                                  end_date,
                                  period,
                                  training_price)
            try:
                get_scurves(
                    priors_info,
                    no_ridge_shortlisted_sols.copy(),
                    best_solution_number,
                    media_variables,
                    updated_stack_brand.copy(),
                    train_start,
                    train_end,
                    valid_start,
                    valid_end,
                    folder_path=results_folder,
                )
            except Exception as e:
                print(f"⚠️  get_scurves skipped (non-critical): {e}")

            print("Most Recent 1 Year S curves")

            try:
                most_recent_s_curve_table(media_variables, updated_stack_brand.copy(), best_solution, train_start,
                                          train_end)
            except Exception as e:
                print(f"⚠️  most_recent_s_curve_table skipped (non-critical): {e}")

    else:
        print(" No Solutions for Final Shortlisting Criteria")


# def get_transformed_df(solutions, data):
#     solutions['media_transformation_string'] = solutions['Media_transformation (hf, inf, sc, lg)'].str.replace('[', '_')
#     solutions['media_transformation_string'] = solutions['media_transformation_string'].str.replace(',', '_')
#     solutions['media_transformation_string'] = solutions['media_transformation_string'].str.replace(']', '')
#     solutions['media_transformation_string'] = solutions['media_transformation_string'].str.replace(' ', '')
#     solutions['lambda_'] = solutions["media_transformation_string"].apply(lambda x: (float(x.split('_')[-1])))
#     solutions["media_transformation_string"] = solutions["media_transformation_string"].apply(
#         lambda x: '_'.join([str(item) for item in x.split('_')[:-1]]))
#
#     solutions['variable_transformations'] = solutions["Media_tactic"].astype(str) + solutions[
#         "media_transformation_string"]
#
#     # variable_transformations
#     df_transformed_new = create_missing_media_transformations_new(data, solutions['variable_transformations'],
#                                                                   trans_start_date=None, trans_end_date=None)
#     return df_transformed_new

def get_transformed_df(solutions, data):
    # Convert Media_transformation column to string FIRST
    solutions['media_transformation_string'] = solutions['Media_transformation (hf, inf, sc, lg)'].astype(str)
    # NumPy >=2.0 changed scalar repr: str([np.float64(3.0)]) -> '[np.float64(3.0)]'
    # instead of the old '[3.0]'.  Strip the wrapper so downstream float() calls work.
    import re as _re_np2
    solutions['media_transformation_string'] = solutions['media_transformation_string'].str.replace(
        r'np\.float64\(([^)]+)\)', r'\1', regex=True)
    solutions['media_transformation_string'] = solutions['media_transformation_string'].str.replace('[', '_')
    solutions['media_transformation_string'] = solutions['media_transformation_string'].str.replace(',', '_')
    solutions['media_transformation_string'] = solutions['media_transformation_string'].str.replace(']', '')
    solutions['media_transformation_string'] = solutions['media_transformation_string'].str.replace(' ', '')

    import re
    def _parse_last_float(x):
        last = x.split('_')[-1]
        m = re.search(r'[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?', last)
        return float(m.group()) if m else float(last)
    solutions['lambda_'] = solutions["media_transformation_string"].apply(_parse_last_float)
    #solutions['lambda_'] = solutions["media_transformation_string"].apply(lambda x: (float(x.split('_')[-1])))
    solutions["media_transformation_string"] = solutions["media_transformation_string"].apply(
        lambda x: '_'.join([str(item) for item in x.split('_')[:-1]]))

    solutions['variable_transformations'] = solutions["Media_tactic"].astype(str) + solutions[
        "media_transformation_string"]

    # variable_transformations
    df_transformed_new = create_missing_media_transformations_new(data, solutions['variable_transformations'],
                                                                  trans_start_date=None, trans_end_date=None)
    return df_transformed_new


def final_report_formatting(input_df, media_variables, train_end):
    new_order = [
        "Date",
        "advertiser_name",
        "sbu",
        "super_dept_nm",
        "dept_nm",
        "categ_nm",
        "sbu_name",
        "sales_channel",
        "sales_dma",
        "sales_product",
        "sales_gmv",
        "sales_unit",
        "unit_price",
        "media_product",
        "media_tactic",
        "media_variable",
        "media_type",
        "media_dma",
        "media_wmc_flag",
        "media_spend",
        "media_event_count",
        "model_kpi",
        "incremental_sales",
        "incremental_unit",
        "reporting_kpi",
        "version",
    ]
    value_var_list = []
    for media in media_variables:
        value_var_list.append(media)
        value_var_list.append(media[:-3] + "SPEND")
        value_var_list.append(media[:-3] + "SALES")
    value_var_list.append("Base_Sales")
    # Melt the DataFrame
    melted_df = pd.melt(
        input_df,
        id_vars=[
            "Date",
            "advertiser_name",
            "sbu",
            "super_dept_nm",
            "dept_nm",
            "sbu_name",
            "sales_gmv",
            "sales_unit",
            "unit_price",
            "version",
            "model_kpi",
            "reporting_kpi",
        ],
        value_vars=value_var_list,
        var_name="Variable",
        value_name="Value",
    )
    # Map Variable to Media and Type
    melted_df["media_product"] = melted_df["Variable"].apply(
        lambda x: (
            "Search"
            if "SEARCH" in x
            else (
                "Onsite"
                if "ON_DIS" in x
                else (
                    "Offsite"
                    if "OFF_DIS" in x
                    else (
                        "Base"
                        if "Base_" in x
                        else "Instore" if "INSTORE" in x else "N/A"
                    )
                )
            )
        )
    )
    melted_df["media_variable"] = melted_df["Variable"].apply(
        lambda x: (
            "M_SEARCH_CLK"
            if "SEARCH" in x
            else (
                "M_ON_DIS_TOTAL_IMP"
                if "ON_DIS" in x
                else (
                    "M_OFF_DIS_TOTAL_IMP"
                    if "OFF_DIS" in x
                    else (
                        "Base"
                        if "Base_" in x
                        else "M_INSTORE_TOTAL_CNT" if "INSTORE" in x else "N/A"
                    )
                )
            )
        )
    )
    melted_df["media_type"] = melted_df["media_product"]

    melted_df["Type"] = melted_df["Variable"].apply(
        lambda x: (
            "media_spend"
            if "_SPEND" in x
            else (
                "media_event_count"
                if "_CLK" in x or "_IMP" in x or "_CNT" in x
                else ("incremental_sales" if "_Sales" in x or "_SALES" in x else None)
            )
        )
    )

    # Pivot the DataFrame to have separate columns for Spend, Val, and Sales
    final_df = melted_df.pivot_table(
        index=[
            "Date",
            "advertiser_name",
            "sbu",
            "super_dept_nm",
            "dept_nm",
            "sbu_name",
            "sales_gmv",
            "sales_unit",
            "unit_price",
            "media_product",
            "media_variable",
            "media_type",
            "version",
            "model_kpi",
            "reporting_kpi",
        ],
        columns="Type",
        values="Value",
        aggfunc="first",
    ).reset_index()
    final_df["categ_nm"] = [np.nan] * len(final_df)
    final_df["sales_channel"] = ["Omni"] * len(final_df)
    final_df["sales_dma"] = [np.nan] * len(final_df)
    final_df["sales_product"] = [np.nan] * len(final_df)
    final_df["media_tactic"] = [np.nan] * len(final_df)
    final_df["media_dma"] = [np.nan] * len(final_df)
    final_df["media_wmc_flag"] = final_df["media_product"].apply(
        lambda x: 0 if x == "Base" else 1
    )
    final_df["incremental_unit"] = (
            final_df["incremental_sales"]
            / input_df[input_df["Date"] <= train_end]["unit_price"].mean()
    )

    final_df["media_event_count"].fillna(0, inplace=True)
    final_df["media_spend"].fillna(0, inplace=True)
    final_df = final_df[new_order]
    return final_df


def get_final_solution_ridge_smooth(
        sol_data,
        updated_stack_brand,
        media_variables,
        handle_added_value,
        folder_path,
        brand_nm,
        use_scaling=False,
        train_end=None,
):
    ### Saving solution for export
    solutions = create_solution_list(sol_data.copy())
    df_by_brand = updated_stack_brand.copy()
    transformed_var_actual = get_transformed_actual(df_by_brand.copy(), media_variables)
    transformed_spend_var_actual = get_transformed_spend_actual(
        df_by_brand.copy(), media_variables
    )

    transformed_sales_total = []
    for i, solution in enumerate(solutions):
        transformed_sales_total.append(
            get_transformed_sales(
                solution,
                media_variables,
                df_by_brand,
                transformed_var_actual,
                transformed_spend_var_actual,
                df_by_brand[df_by_brand["Date"] <= train_end][
                    "PRICE"
                ].mean(),  # to_numpy().astype("float64"),
                handle_added_value=handle_added_value,
                use_scaling=use_scaling,
            )
        )
    transformed_sales_total = np.asarray(transformed_sales_total)
    transformed_sales_average = transformed_sales_total.mean(axis=0)
    transformed_sales_df = pd.DataFrame(
        transformed_sales_average.T,
        columns=[
            media_variables[0][:-4] + "_SALES",
            media_variables[1][:-4] + "_SALES",
            media_variables[2][:-4] + "_SALES",
        ],
    )
    df_by_brand = pd.concat([df_by_brand, transformed_sales_df], axis=1)
    df_by_brand["Base_Sales"] = df_by_brand["O_SALE"] - df_by_brand[
        [
            media_variables[0][:-4] + "_SALES",
            media_variables[1][:-4] + "_SALES",
            media_variables[2][:-4] + "_SALES",
        ]
    ].sum(axis=1)
    df_by_brand["incremental_sales"] = df_by_brand[
        [
            media_variables[0][:-4] + "_SALES",
            media_variables[1][:-4] + "_SALES",
            media_variables[2][:-4] + "_SALES",
        ]
    ].sum(axis=1)
    df_by_brand["incremental_unit"] = (
            df_by_brand["incremental_sales"]
            / df_by_brand[df_by_brand["Date"] <= train_end]["PRICE"].mean()
    )
    df_by_brand["Base_Sales_percentage"] = round(
        (df_by_brand["Base_Sales"] / df_by_brand["O_SALE"]) * 100, 2
    )
    df_by_brand["Incremental_Sales_percentage"] = round(
        100 - df_by_brand["Base_Sales_percentage"], 2
    )
    df_by_brand["sales_channel"] = ["OMNI"] * len(df_by_brand)
    df_by_brand["sales_dma"] = ["N/A"] * len(df_by_brand)
    df_by_brand["sales_product"] = ["N/A"] * len(df_by_brand)
    df_by_brand["media_tactic"] = ["N/A"] * len(df_by_brand)
    df_by_brand["media_dma"] = ["N/A"] * len(df_by_brand)
    df_by_brand["model_kpi"] = ["Unit Sales"] * len(df_by_brand)
    df_by_brand["reporting_kpi"] = ["iRoAS"] * len(df_by_brand)
    df_by_brand["version"] = [int(time())] * len(df_by_brand)

    df_by_brand = df_by_brand.rename(
        columns={
            "advertiser": "advertiser_name",
            "L0_CATEGORY_NAME": "sbu",
            "L1_CATEGORY_NAME": "super_dept_nm",
            "L2_CATEGORY_NAME": "dept_nm",
            "SBU": "sbu_name",
            "O_SALE": "sales_gmv",
            "O_UNIT": "sales_unit",
            "PRICE": "unit_price",
            "TOTAL_SPEND": "media_spend",
        }
    )
    final_df = final_report_formatting(df_by_brand.copy(), media_variables, train_end)

    # file_save_name = folder_path + "/" + str(brand_nm) + "_wamm_lite_contribution.csv"
    # final_df.to_csv(file_save_name, index=False)
    file_save_name = f"{folder_path.rstrip('/')}/{brand_nm}_wamm_lite_contribution.csv"
    upload_df_to_gcs(final_df, file_save_name, bucket_name)

    iroas_details = {}
    for media in media_variables:
        sales = media[:-4] + "_SALES"
        spend = media[:-4] + "_SPEND"
        iroas_details[media] = df_by_brand[sales].sum() / df_by_brand[spend].sum()

    iroas_details["overall_iroas"] = (
                                             df_by_brand.sales_gmv.sum() - df_by_brand.Base_Sales.sum()
                                     ) / df_by_brand.media_spend.sum()
    df = pd.DataFrame(iroas_details.items(), columns=["Media_tactic/Overall", "iRoAS"])
    df.to_csv(
        folder_path + "/" + str(brand_nm) + "_summary.csv",
        index=True,
    )
    print("File saved at:", file_save_name)


def create_missing_media_transformations_new(df, media_vars, trans_start_date=None, trans_end_date=None):
    '''
    Creates the mising media transformation

    Params
        media_vars : List of all media variables
    '''
    # Creates the missing media transformations
    ## added:09.29.2022, jangho, for sliders
    media_variables = media_vars
    sat = {}
    thr = {}
    if trans_start_date is None:
        trans_start_date = '2021-05-01'

    if trans_end_date is None:
        trans_end_date = '2023-12-31'

    for var in media_vars:

        lag = int(float(var.split("_")[-1]))

        halflife = float(var.split("_")[-4])
        sscurve_inflection = float(var.split("_")[-3])
        sscurve_scale = float(var.split("_")[-2])

        orig_media_var = var.split("_")[:-4]
        orig_media_var = '_'.join([str(elem) for elem in orig_media_var])

        # Saving the numbers on the required period defined by trans_start_date and trans_end_date
        df_filtered = df
        transformed_var = df_filtered[orig_media_var]

        # Saving the means on the filtered dataset

        if lag != 0:
            transformed_var = lag_transformation(transformed_var, int(lag))

        if halflife != 0:
            transformed_var = halflife_transformation(transformed_var, halflife)

        var_mean = transformed_var.mean()

        if (sscurve_scale != 0) and (sscurve_inflection != 0):
            transformed_var_scaled = transformed_var / var_mean
            saturation_term = sscurve_scale * (sscurve_inflection - transformed_var_scaled)
            scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (1 + np.exp(sscurve_scale * sscurve_inflection))
            scurve_var_mean = scurve_var.mean()
            transformed_var = scurve_var * var_mean / scurve_var_mean

        scaling_factor = max(transformed_var) - min(transformed_var)
        transformed_var = (
                                  transformed_var - min(transformed_var)
                          ) / scaling_factor

        df[orig_media_var + '_transformed'] = transformed_var

    return df


def recursive_filter(x, ar_coeff):
    n = len(x)
    y = np.zeros(n)
    y[0] = x[0]
    for i in range(1, n):
        y[i] = ar_coeff * y[i - 1] + x[i]
    return y


def lag_transformation(var, lag):
    lag_variable = np.append(np.zeros(int(lag)), var[:-lag])
    return lag_variable


def halflife_transformation(var, halflife):
    retention = np.exp(math.log(0.5) / halflife)
    transformed_var = var * (1 - retention)
    transformed_var[np.isnan(transformed_var)] = 0
    transformed_var = recursive_filter(transformed_var, retention)
    return transformed_var


def gompertz_logistic_saturation_pts(df, Media_var, inflection, scale):
    Point = pd.DataFrame({'Media': [Media_var]})
    # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
    Point['Saturation Point using Logistic'] = (4.59511985013 / (scale) + inflection) * df.mean()
    saturation = Point[['Saturation Point using Logistic']].min(axis=1)
    return saturation.values[0]


def gompertz_logistic_threshold_pts(df, Media_var, inflection, scale):
    Point = pd.DataFrame({'Media': [Media_var]})
    # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
    if scale * inflection < 4.59511985013:
        Point['Threshold Point using Logistic'] = 0
    else:
        Point['Threshold Point using Logistic'] = (-4.59511985013 / (scale) + inflection) * df.mean()
    threshold = Point[['Threshold Point using Logistic']].max(axis=1)
    return threshold.values[0]


def get_iroas_metrics(
        best_solution,
        df_transformed_from_solution,
        media_variables,
        data,
        train_start,
        train_end,
        period,
        training_price):
    print(f'*****{period}*****')
    price = training_price

    train_start_index = df_transformed_from_solution[df_transformed_from_solution['Date'] == train_start].index[0]
    train_end_index = df_transformed_from_solution[df_transformed_from_solution['Date'] == train_end].index[0]

    media_var_list = []
    contri_list = []
    incremental_sales_list = []
    spend_list = []
    media_list = []
    iroas_list = []

    for media_tactic in media_variables:

        if not 'WMT' in media_tactic:

            transformed_var = media_tactic + '_transformed'
            coef = best_solution.loc[best_solution['Media_tactic'] == media_tactic, 'Coefficient'].values[0]
            contri = df_transformed_from_solution[transformed_var] * coef

            contri = contri[train_start_index:train_end_index + 1].sum()
            incremental_sales = contri * price
            contri_list.append(contri)
            incremental_sales_list.append(incremental_sales)

            if "_IMP" in media_tactic:
                spend_var = media_tactic.replace("_IMP", "_SPEND")
            else:
                spend_var = media_tactic.replace("_CLK", "_SPEND")
            spend = df_transformed_from_solution.loc[train_start_index:train_end_index + 1, spend_var].sum()
            media = df_transformed_from_solution.loc[train_start_index:train_end_index + 1, media_tactic].sum()

            iroas = incremental_sales / spend
            spend_list.append(spend)
            media_list.append(media)
            iroas_list.append(iroas)
            media_var_list.append(media_tactic)

    contribution_share = list(np.asarray(contri_list) * 100) / sum(contri_list)
    spend_share = list(np.asarray(spend_list) * 100) / sum(spend_list)
    media_share = list(np.asarray(media_list) * 100) / sum(media_list)

    iroas_summary = {'Display Level': media_var_list,
                     'Contribution Share (%)': contribution_share,
                     'Total Contribution': contri_list,
                     'Total Sales ($)': incremental_sales_list,
                     'Total Spend ($)': spend_list,
                     'Spend Share (%)': spend_share,
                     'Raw Media': media_list,
                     'Raw Media Share (%)': media_share,
                     'Value iRoAS ($)': iroas_list}

    iroas_summary = pd.DataFrame.from_dict(iroas_summary)

    total_incremental = pd.DataFrame({"Display Level": ["Total incremental"],
                                      'Contribution Share (%)': sum(contri_list) * 100 / sum(data['O_UNIT']),
                                      'Total Contribution': sum(contri_list),
                                      'Total Sales ($)': sum(contri_list) * price,
                                      'Total Spend ($)': sum(spend_list),
                                      'Spend Share (%)': sum(spend_share),
                                      'Raw Media': sum(media_list),
                                      'Raw Media Share (%)': sum(media_share),
                                      'Value iRoAS ($)': sum(contri_list) * price / sum(spend_list)})
    iroas_summary = pd.concat([iroas_summary, total_incremental], ignore_index=True)
    print(iroas_summary)


def get_iroas_metrics_channel(
        solution,
        data
):
    df_transformed_from_solution = get_transformed_df(solution, data)
    df_transformed_from_solution["Date"] = pd.to_datetime(df_transformed_from_solution["Date"])

    price = data["PRICE"].mean()

    search_tactics = []
    offsite_cpm_tactics = []
    instore_tactics = []
    onsite_tactics = []
    WMT_tactics = []

    contribution_list = []

    search_spend = 0
    offsite_spend = 0
    instore_spend = 0
    onsite_spend = 0
    wmt_spend = 0

    for media_tactic in solution['Media_tactic']:
        transformed_var = media_tactic + '_transformed'

        if "_IMP" in media_tactic:
            spend_var = media_tactic.replace("_IMP", "_SPEND")
        else:
            spend_var = media_tactic.replace("_CLK", "_SPEND")
        spend = df_transformed_from_solution[spend_var].sum()

        if ('SP' in media_tactic and 'CLK' in media_tactic) or 'SBA' in media_tactic or 'SV' in media_tactic:
            search_tactics.append(media_tactic)
            search_spend = search_spend + spend
            coef = solution.loc[solution['Media_tactic'] == media_tactic, 'Coefficient'].values[0]
            contri = df_transformed_from_solution[transformed_var].sum() * coef
            contribution_list.append(contri)

        if 'M_OFF' in media_tactic:
            offsite_cpm_tactics.append(media_tactic)
            offsite_spend = offsite_spend + spend
            coef = solution.loc[solution['Media_tactic'] == media_tactic, 'Coefficient'].values[0]
            contri = df_transformed_from_solution[transformed_var].sum() * coef
            contribution_list.append(contri)

        if 'STORE' in media_tactic:
            instore_tactics.append(media_tactic)
            instore_spend = instore_spend + spend
            coef = solution.loc[solution['Media_tactic'] == media_tactic, 'Coefficient'].values[0]
            contri = df_transformed_from_solution[transformed_var].sum() * coef
            contribution_list.append(contri)

        if 'M_ON' in media_tactic:
            onsite_tactics.append(media_tactic)
            onsite_spend = onsite_spend + spend
            coef = solution.loc[solution['Media_tactic'] == media_tactic, 'Coefficient'].values[0]
            contri = df_transformed_from_solution[transformed_var].sum() * coef
            contribution_list.append(contri)

        if 'M_WMT' in media_tactic:
            WMT_tactics.append(media_tactic)
            wmt_spend = wmt_spend + spend
            coef = solution.loc[solution['Media_tactic'] == media_tactic, 'Coefficient'].values[0]
            contri = df_transformed_from_solution[transformed_var].sum() * coef
            contribution_list.append(contri)

    solution['Contribution'] = contribution_list

    tota_term = solution.loc[solution['Media_tactic'].isin(search_tactics), 'Contribution'].sum()
    solution['Search_iRoAS'] = (tota_term * price / search_spend)

    tota_term = solution.loc[solution['Media_tactic'].isin(offsite_cpm_tactics), 'Contribution'].sum()
    solution['Offsite_iRoAS'] = (tota_term * price / offsite_spend)

    tota_term = solution.loc[solution['Media_tactic'].isin(instore_tactics), 'Contribution'].sum()
    solution['Instore_iRoAS'] = (tota_term * price / instore_spend)

    tota_term = solution.loc[solution['Media_tactic'].isin(onsite_tactics), 'Contribution'].sum()
    solution['Onsite_iRoAS'] = (tota_term * price / onsite_spend)

    return solution[['Media_tactic', 'unique_key', 'Search_iRoAS', 'Onsite_iRoAS', 'Offsite_iRoAS', 'Instore_iRoAS']]


def plot_model_fit(media_vars, non_media_coefs, data, solution, df_transformed_from_solution):
    data['Y_pred'] = 0
    for i, j in non_media_coefs.items():
        data['Y_pred'] += data[i] * j

    for media_tactic in media_vars:
        transformed_var = media_tactic + '_transformed'

        coef = solution.loc[solution['Media_tactic'] == media_tactic, 'Coefficient'].values[0]
        data['Y_pred'] += df_transformed_from_solution[transformed_var] * coef
    plot_fig(data, data['O_UNIT'], data['Y_pred'])


def most_recent_s_curve_table(media_vars, data, solution, train_start, train_end):
    train_end_index = data[data['Date'] == train_end].index[0]

    s_curve_table = solution[['Media_tactic', 'Threshold', 'Saturation', 'Inflection_Point']]
    media_1_year = []
    below_threshold = []
    below_inflection = []
    above_inflection = []
    above_saturation = []

    for media_var in media_vars:
        # print(f"Media: {media_var} | Start Date: {train_end_index-365} | End Date: {train_end_index+1}")
        media = data.loc[train_end_index - 365:train_end_index + 1, media_var].mean()
        media_1_year.append(media)

        threshold = s_curve_table[s_curve_table["Media_tactic"] == media_var]["Threshold"].values[0]
        saturation = s_curve_table[s_curve_table["Media_tactic"] == media_var]["Saturation"].values[0]
        inflection = s_curve_table[s_curve_table["Media_tactic"] == media_var]["Inflection_Point"].values[0]

        on_air_df = data[data[media_var] > 0]

        below_threshold.append(100 * len(on_air_df[data[media_var] < threshold]) / len(data[data[media_var] > 0]))

        below_inflection.append(100 * len(
            on_air_df[(data[media_var] >= threshold) & (data[media_var] < inflection)]
        ) / len(data[data[media_var] > 0]))

        above_inflection.append(100 * len(
            on_air_df[(data[media_var] >= inflection) & (data[media_var] < saturation)]
        ) / len(data[data[media_var] > 0]))

        above_saturation.append(100 * len(
            on_air_df[data[media_var] >= saturation]
        ) / len(data[data[media_var] > 0]))

    s_curve_table['Recent 1 Year Avg Media IMP/CLK'] = media_1_year
    s_curve_table['% Days below Threshold'] = below_threshold
    s_curve_table['% Days b/w Threshold & Inflection'] = below_inflection
    s_curve_table['% Days b/w Inflection & Saturation'] = above_inflection
    s_curve_table['% Days above Saturation'] = above_saturation
    print("s_curve_table creation is done")
