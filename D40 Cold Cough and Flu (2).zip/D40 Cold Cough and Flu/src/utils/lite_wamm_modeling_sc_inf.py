#!/usr/bin/env python
# coding: utf-8
# author: Mayukh Maitra

import ast
import math
import os
import pickle
import sys
from datetime import datetime
import itertools

import _differentialevolution_ols as differential_evolution
import numba
import numpy as np
import pandas as pd
from IPython.display import display
from numba import jit, literally, njit, numba, objmode
from numba.typed import List
from numba_helper_functions import *
from numpy.linalg import inv, pinv
from scipy.optimize import minimize
import multiprocessing as mp
from lite_non_media_utils_v3 import residual_calculation

module_path = os.path.abspath(os.path.join("../src/utils"))
if module_path not in sys.path:
    sys.path.append(module_path)

if os.path.abspath("../src/config_dir") not in sys.path:
    sys.path.append(os.path.abspath("../src/config_dir"))

if module_path not in sys.path:
    sys.path.append(module_path)

import warnings

warnings.filterwarnings("ignore")

date_format = "%Y-%m-%d"


def create_folder_with_version(directory_path):
    version = 1
    while os.path.exists(f"{directory_path}_v{version}"):
        version += 1
    new_directory_path = f"{directory_path}_v{version}"
    os.makedirs(new_directory_path)
    print(f"Create output folder : {new_directory_path}")
    return new_directory_path


class WAMM_Lite:
    def __init__(
        self,
        updated_stack,
        outcome,
        pre_processed_matrix_U_kj,
        pre_processed_matrix_Y_kj,
        coef_mean_prior,
        coef_var_prior,
        threshold_bounds,
        saturation_bounds,
        media_variables_og,  # Category WAMM Change
        media_variables_all, # Category WAMM Change 
        sbu_list,
        train_start,
        train_end,
        valid_start,
        valid_end,
        media_iroas_prior,
        folder_path,
        iroas_lb = None,# default to handle Lite
        iroas_ub = None,# default to handle lite
        use_iroas_penalty = False,
        iroas_penalty_multiplier = 1.0,
        is_premium=False,# premium changes
        lambda_denominator = 3, # value will be discarded if use_ridge==False
        use_sign_penalty = False, # if true, use_ridge is set to False
        apply_scaling = False,
        train_spend = [],# default to handle lite
        train_price = None, # default to handle lite
        iroas_dev_in_loss=False,
        YoY_comparison = None,
        common_s_curve = True,
        handle_added_value = False,
        fix_iterations=False,
        use_ridge=True,
        lambda_k=True,
        base_num = 0,
        non_media_variables = None,
        national_media_vars_lg_hf = None,
        wmc_media_var = []
) -> None:
        self.updated_stack = updated_stack
        self.outcome = outcome
        self.threshold_bounds = threshold_bounds
        self.saturation_bounds = saturation_bounds
        self.media_variables = media_variables_all  # category wamm change
        self.num_media_vars = len(media_variables_all) # category wamm change
        self.media_variables_og = media_variables_og # category wamm change
        self.num_media_vars_og = len(media_variables_og) # category wamm change
        self.sbu_list = sbu_list
        self.train_start = train_start
        self.train_end = train_end
        self.valid_start = valid_start
        self.valid_end = valid_end
        self.num_sbu = len(sbu_list)
        self.st_dt = datetime.strptime(train_start, date_format)
        self.train_end_dt = datetime.strptime(train_end, date_format)
        self.test_st_dt = datetime.strptime(valid_start, date_format)
        self.test_end_dt = datetime.strptime(valid_end, date_format)
        self.data = updated_stack.copy()
        self.train_end_index = (self.train_end_dt - self.st_dt).days + 1
        self.pre_processed_matrix_U_kj = pre_processed_matrix_U_kj
        self.pre_processed_matrix_Y_kj = pre_processed_matrix_Y_kj
        self.num_non_media_vars = self.pre_processed_matrix_U_kj.shape[1]
        self.coef_mean_prior = coef_mean_prior
        self.coef_var_prior = coef_var_prior
        self.media_iroas_prior = media_iroas_prior
        self.folder_path = folder_path
        self.solution_arr = []
        # self.brand_non_media_coef = brand_non_media_coef
        self.split_interval = 365 # category wamm change
        self.solution_beta_arr = []
        self.solution_contri_arr = []
        self.solution_iroas_arr = []
        self.solution_iroas_penalty_arr = []
        self.solution_scurve_penalty_arr = []
        self.lambda_k_arr = []
        self.prior_loss_arr = []
        self.scaled_prior = []
        self.scaling_factor = []
        self.iteration_logs = []
        self.fix_iterations = fix_iterations
        self.use_ridge = use_ridge
        self.is_premium = is_premium
        self.lambda_denominator = lambda_denominator # value will be discarded if use_ridge==False
        self.use_sign_penalty = use_sign_penalty
        self.iroas_lb = iroas_lb
        self.iroas_ub = iroas_ub
        self.train_spend = train_spend
        self.train_price = train_price
        self.use_iroas_penalty = use_iroas_penalty
        self.iroas_penalty_multiplier = iroas_penalty_multiplier
        self.apply_scaling = apply_scaling
        self.iroas_dev_in_loss = iroas_dev_in_loss
        self.YoY_comparison = YoY_comparison
        self.common_s_curve = common_s_curve
        self.handle_added_value = handle_added_value
        self.lambda_k_val = lambda_k
        self.base_num = base_num
        self.non_media_variables = non_media_variables
        self.national_media_vars_lg_hf = national_media_vars_lg_hf
        self.num_wmc_media_var = len(wmc_media_var)
        self.wmc_media_var = wmc_media_var
        self.on_air_df = {}
        self.df_onair_list = []
        for var in self.media_variables:
            df_var = self.data[[var]].copy()
            df_var.columns = ['Raw Variable']
            on_air_df = df_var[df_var['Raw Variable'] > 0]
            self.on_air_df[var] = on_air_df

        for i in range(len(self.media_variables)):
            self.df_onair_list.append(self.on_air_df[self.media_variables[i]])
        df_media_onair = pd.concat(self.df_onair_list, axis=1)
        df_media_onair = df_media_onair.to_numpy() 
        self.df_media_onair = df_media_onair.astype('float64')

    def create_ga_bounds(self):
        self.ga_bounds_media = {}
        for media_idx,var in enumerate(self.wmc_media_var):

            if "_IMP" in var:
                halflife_bounds_var = [0, 5]
                lag_bounds_var = [0, 6]
                inflection_bounds = [0, 5]
                scale_bounds = [0, 5]
                
            elif "_CLK" in var:
                halflife_bounds_var = [0, 5]
                lag_bounds_var = [0, 3]
                inflection_bounds = [0, 5]
                scale_bounds = [0, 5]                

            else:
                # TODO : error out if the media variable name is invalid
                print(f"Invalid media variable name : {var}")
            self.ga_bounds_media[var] = {
                "halflife_bounds": halflife_bounds_var,
                "inflection_bounds": inflection_bounds,
                "scale_bounds": scale_bounds,
                "lag_bounds": lag_bounds_var,
            }# Janhavi : premium changes

    def get_spend_variables(self):
        self.spend_variables = []
        for i in range(len(self.media_variables)):
            if "_IMP" in self.media_variables[i]:
                spend_var = self.media_variables[i].replace("_IMP", "_SPEND")
            else:
                spend_var = self.media_variables[i].replace("_CLK", "_SPEND")
            self.spend_variables.append(spend_var)

    def get_initial_solution(self):
        # halflife, threshold, saturation, lag
        self.init_sol_raw_list = []
        i = 0
        np.random.seed(42)
        for var in self.wmc_media_var:
            self.init_sol_raw_list.append(
                np.random.uniform(
                    self.ga_bounds_media[var]["halflife_bounds"][0],
                    self.ga_bounds_media[var]["halflife_bounds"][1],
                )
            )  # inflection
            self.init_sol_raw_list.append(
                np.random.uniform(
                    self.ga_bounds_media[var]["inflection_bounds"][0],
                    self.ga_bounds_media[var]["inflection_bounds"][1],
                )
            )  # scale
            self.init_sol_raw_list.append(
                np.random.uniform(
                    self.ga_bounds_media[var]["scale_bounds"][0],
                    self.ga_bounds_media[var]["scale_bounds"][1],
                )
            )  #  saturation
            self.init_sol_raw_list.append(
                np.random.randint(
                    self.ga_bounds_media[var]["lag_bounds"][0],
                    self.ga_bounds_media[var]["lag_bounds"][1],
                )
            )  # lag
            i += 1

        self.initial_solution = np.asarray(self.init_sol_raw_list).astype(np.float)

    def data_prep(self):

        self.create_ga_bounds()
        self.get_spend_variables()
        self.get_initial_solution()

        ## USE numba ######################################################################
        #### pandas to numpy media
        self.df_data_by_sbu = []
        self.outcome_by_sbu = []
        self.start_idx = 0
        self.end_idx = len(self.data) / len(self.sbu_list)
        for i in range(len(self.sbu_list)):
            temp_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.media_variables].copy()
            outcome_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.outcome].copy()
            temp_data = temp_data.to_numpy().astype("float64")
            outcome_data = outcome_data.to_numpy().astype("float64")
            self.df_data_by_sbu.append(temp_data)
            self.outcome_by_sbu.append(outcome_data)
            self.start_idx = self.end_idx * (i + 1)
        self.df_data_by_sbu = np.asarray(self.df_data_by_sbu)
        self.outcome_by_sbu = np.asarray(self.outcome_by_sbu)

        self.transformed_var_actual = self.df_data_by_sbu.copy()
        self.outcome_by_sbu_actual = self.outcome_by_sbu.copy()
        ######################################################################

        #### pandas to numpy media train data
        self.df_train_data = []
        for sbu_data in self.df_data_by_sbu:
            self.df_train_data.append(sbu_data[: self.train_end_index])
        self.df_train_data = np.asarray(self.df_train_data)
        ######################################################################

        #### pandas to numpy spend
        self.df_media_spend_by_sbu = []
        self.start_idx = 0
        self.end_idx = len(self.data) / len(self.sbu_list)
        for i in range(len(self.sbu_list)):
            temp_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.spend_variables].copy()
            temp_data = temp_data.to_numpy().astype("float64")
            self.df_media_spend_by_sbu.append(temp_data)
            self.start_idx = self.end_idx * (i + 1)
        self.df_media_spend_by_sbu = np.asarray(self.df_media_spend_by_sbu)
        self.transformed_spend_var_actual = (self.df_media_spend_by_sbu > 0).astype(int)
        ######################################################################

        #### pandas to numpy outcome
        self.df_outcome_by_sbu = []
        self.start_idx = 0
        self.end_idx = len(self.data) / len(self.sbu_list)
        for i in range(len(self.sbu_list)):
            temp_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.outcome].copy()
            temp_data = temp_data.to_numpy().astype("float64")
            self.df_outcome_by_sbu.append(temp_data)
            self.start_idx = self.end_idx * (i + 1)
        self.df_outcome_by_sbu = np.asarray(self.df_outcome_by_sbu)
        ######################################################################

        #### Category WAMM : Per SBU : Creating groups of spliited Media on index > for S - Curve consistency
        
        # self.split_media_index = []
        # for i in range(len(self.sbu_list)):
        #     for key, value in self.split_dictionary.items(): 
        #         media_all = np.array(self.media_variables)
        #         a = np.array(value)
        #         sorter = np.argsort(media_all)
        #         self.split_media_index.append(sorter[np.searchsorted(media_all, a, sorter=sorter)])
        # self.split_media_index = np.array(self.split_media_index)

    def get_bnds_dict(self):
        self.bnds_dict = {}
        for i in self.wmc_media_var:
            self.bnds_dict[i] = [
                tuple(self.ga_bounds_media[i]["halflife_bounds"]),
                tuple(self.ga_bounds_media[i]["inflection_bounds"]),
                tuple(self.ga_bounds_media[i]["scale_bounds"]),
                tuple(self.ga_bounds_media[i]["lag_bounds"]),
            ]
        self.bnds = []
        for k in self.bnds_dict:
            self.bnds += self.bnds_dict[k]

    def run_DE(
        self,
        seed,
        num_sbu,
        num_media_vars,
        num_media_vars_og,
        train_end_index,
        transformed_var_actual,
        transformed_spend_var_actual,
        pre_processed_matrix_U_kj,
        pre_processed_matrix_Y_kj,
        num_non_media_vars,
        coef_mean_prior,
        coef_var_prior,
        outcome_by_sbu,
        bnds,
        initial_solution,
        lambda_k_val,
        iroas_dev_in_loss,
        global_opt=True,
        solution_save=False,
        media_roas_prior=None,
        use_ridge = True,
        is_premium = False,
        lambda_denominator = 3,
        apply_scaling = True,
        use_sign_penalty = False,
        use_iroas_penalty = False,
        iroas_penalty_multiplier = 1.0,
        iroas_lb = None,
        iroas_ub = None,
        train_spend = None,
        train_price = None,
        common_s_curve = True,
        handle_added_value = False,
        media_variables=None,
        non_media_variables=None,
        data=None,
        national_media_vars_lg_hf = None,
        num_wmc_media_var = None,
        on_air_days = None
    ):
        self.obj_loss = 10e100        
        def save_intermediate_solution(sbu_idx, x, total_loss, debug_flag):
            with objmode():
                iterim_sol_arr = np.concatenate((x.copy(), np.array([total_loss])))
                # self.solution_arr.append(iterim_sol_arr.copy())
                with open(
                    os.path.join(
                        self.folder_path,
                        f"interim_sol_{self.sbu_list[sbu_idx]}_{debug_flag}.pkl",
                    ),
                    "ab",
                ) as f:
                    pickle.dump(iterim_sol_arr, f)

        def save_iteration_log(sbu_idx, log_details, SST, term_1, term_2, term_2_1, term_3, term_4, min_loss):

                iteration_log_arr = [list(self.solution_arr), 
                                     [sbu_idx,log_details,SST,term_1,term_2,term_2_1,term_3, term_4, min_loss],
                                     list(self.solution_beta_arr),
                                     list(self.solution_contri_arr),
                                     list(self.solution_iroas_arr),
                                     list(self.solution_iroas_penalty_arr),
                                     list(self.solution_scurve_penalty_arr),
                                     list(self.lambda_k_arr),
                                     list(self.prior_loss_arr),
                                     list(self.scaled_prior),
                                     list(self.scaling_factor),
                                     ]
                self.iteration_logs.append(iteration_log_arr.copy())

        @njit(cache = True)
        def get_scurve_params(transformed_var, on_air_df, scale, inflection):
            
            on_air_df = on_air_df[~np.isnan(on_air_df)]
            
            saturation_point = (4.59511985013/(scale) + inflection) * transformed_var.mean()

            # threshold point
            if scale*inflection < 4.59511985013:
                threshold_point = 0
            else:
                threshold_point = (-4.59511985013/(scale) + inflection) * transformed_var.mean()
                    
            # on_air_days = on_air_df.shape[0]
            below_threshold_days = np.nanmean(on_air_df <= threshold_point)
            beyond_saturation_days = np.nanmean(on_air_df > saturation_point)
            
            s_curve_params = np.zeros(2)
            s_curve_params[0] = below_threshold_days
            s_curve_params[1] = beyond_saturation_days
            
            return s_curve_params


        @njit(cache=True)
        def optimization_fn_numba(x, debug_flag=0, log_details=0):

            total_loss, log_solution_total, beta_delta = 0, 0, 0
            sbu_losses = np.zeros(num_sbu)
            with objmode():
                self.solution_arr = x.copy()
            for sbu_idx in range(num_sbu):
                transformed_media = np.zeros((num_media_vars, train_end_index))
                lambda_k = np.zeros(num_media_vars)
                scaled_prior = np.zeros(num_media_vars)
                scurve_penalty_thr_bnd = np.array([0.3] * num_media_vars)
                scurve_penalty_sat_bnd = np.array([0.3] * num_media_vars)
                s_curve_dic_thr = np.zeros(num_media_vars)
                s_curve_dic_sat = np.zeros(num_media_vars)
                i, j = 0, 4
                SST = np.sum(
                    (outcome_by_sbu[sbu_idx] - np.mean(outcome_by_sbu[sbu_idx]))
                    ** 2
                )
                ## SST -> sum(sq(outcome - mean(outcome)))
                ### Getting media transformations ###
                # sepehr_fc_list = np.zeros(num_media_vars)
                scaling_factor_list = np.zeros(num_media_vars)
                for media_var_idx in range(num_wmc_media_var):
                    
                    decision_vars = x[i:j]  # halflife, threshold, saturation, lag
                    halflife, inflection, scale, lag = (
                        decision_vars[0],
                        decision_vars[1],
                        decision_vars[2],
                        int(decision_vars[3]),
                    )

                    transformed_var = transformed_var_actual[sbu_idx][
                        :, media_var_idx
                    ]
                    transformed_spend = transformed_spend_var_actual[sbu_idx][
                        :, media_var_idx
                    ]
                    df_media_onair_var = on_air_days[:, media_var_idx]
                    
                    if handle_added_value:
                        transformed_var = (
                            transformed_var * transformed_spend
                        )  ### ignore spend = 0 for added value
                    scaling_factor_raw = max(transformed_var) - min(transformed_var)


                    if lag != 0:
                        transformed_var = lag_transformation(transformed_var, lag)
                    if halflife != 0:
                        transformed_var = halflife_transformation(
                            transformed_var, halflife
                        )

                    var_mean = transformed_var.mean()

                    # calculate scale and inflection
                    if (scale != 0) and (inflection != 0):
                        transformed_var_scaled = transformed_var / var_mean
                        saturation_term = scale * (inflection - transformed_var_scaled)
                        scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (
                            1 + np.exp(scale * inflection)
                        )
                        scurve_var_mean = scurve_var[:train_end_index].mean()
                        transformed_var = scurve_var * var_mean / scurve_var_mean

                    ### S curve Penalty : 02.12.2024
                    s_curve_params = get_scurve_params(transformed_var, df_media_onair_var, scale, inflection)
                    s_curve_dic_thr[media_var_idx] = s_curve_params[0]
                    s_curve_dic_sat[media_var_idx] = s_curve_params[1] 

                    sepehr_fc = transformed_var.std() / transformed_var.mean()
                    # calculate scaling factor here
                    scaling_factor = max(transformed_var) - min(transformed_var)
                    # transformed_var = (
                    #     transformed_var - min(transformed_var)
                    # ) / scaling_factor

                    transformed_var = transformed_var[:train_end_index]
                    transformed_media[media_var_idx] = np.asarray(
                        transformed_var
                    )  # X_mk
                    if use_ridge:
                        # scaled_prior[media_var_idx] = (
                        #     coef_mean_prior[media_var_idx] * scaling_factor
                        # )
                        lambda_k[media_var_idx] = 1 / (sepehr_fc * coef_mean_prior[media_var_idx])**2
                            # 1 / (sepehr_fc * scaled_prior[media_var_idx]) ** 2
                            # 100 / sepehr_fc
                            # 0.5
                            # 5 / sepehr_fc
                            # 1
                            # if lambda_k_val
                            # else variance_calculation(outcome_by_sbu[sbu_idx])
                            # / (lambda_denominator)
                        
                        # sepehr_fc_list[media_var_idx] = sepehr_fc
                        scaling_factor_list[media_var_idx] = scaling_factor
                    else:
                        lambda_k[media_var_idx] = 0.0
                        scaled_prior[media_var_idx] = 0.0
                    i += 4
                    j += 4
                
                # for media_var_idx in [13,14,15]:
                #     transformed_var = transformed_var_actual[sbu_idx][
                #         :, media_var_idx
                #     ]
                #     transformed_spend = transformed_spend_var_actual[sbu_idx][
                #         :, media_var_idx
                #     ]
                #     scaling_factor = max(transformed_var) - min(transformed_var)
                #     sepehr_fc = transformed_var.std() / transformed_var.mean()
                    
                #     transformed_var = (
                #         transformed_var - min(transformed_var)
                #     ) / scaling_factor

                #     transformed_var = transformed_var[:train_end_index]
                #     transformed_media[media_var_idx] = np.asarray(
                #         transformed_var
                #     )  # X_mk
                #     if use_ridge:
                #         scaled_prior[media_var_idx] = (
                #             coef_mean_prior[media_var_idx] * scaling_factor
                #         )
                #         lambda_k[media_var_idx] = 1 / (scaled_prior[media_var_idx]) ** 2
                #         scaling_factor_list[media_var_idx] = scaling_factor
                #     else:
                #         lambda_k[media_var_idx] = 0.0
                #         scaled_prior[media_var_idx] = 0.0

                ### Caclulating media Betas for each set of non media variables ###
                X_tilde = np.zeros(
                    (num_non_media_vars, num_media_vars, train_end_index)
                )
                Beta = np.zeros((num_non_media_vars, num_media_vars))
                pos_coeffs_j = []
                log_solution = 0
                for non_media_idx in range(num_non_media_vars):
                    # U_kj = pre_processed_matrix_U_kj[sbu_idx][non_media_idx][
                    #     :train_end_index, :train_end_index
                    # ]
                    Y_kj = pre_processed_matrix_Y_kj[sbu_idx][non_media_idx][
                        :train_end_index
                    ]
                    
                    var_y = Y_kj.std()
                    var_y = var_y **2

                    X_tilde_j = np.zeros((num_media_vars, train_end_index))

                    # for i in range(num_media_vars):
                    #     X_tilde_j[i] = (U_kj * transformed_media[i]).sum(axis=1)
                    # with objmode():
                    for i in range(num_media_vars):
                        # X_tilde_j[i] = (U_kj * transformed_media[i]).sum(axis=1)
                        # col_name = media_variables[i] + "_transformed"
                        # train_data[col_name] = transformed_media[i]
                        # X_tilde_j[i] = np.asarray(
                        #     residual_calculation(
                        #         data,
                        #         transformed_media[i],
                        #         "optimization_fn",
                        #         is_pandas=False,
                        #         add_const=False
                        #     )
                        # )
                        train_data = data[:train_end_index].copy()
                        data_upd = train_data.astype(np.float64).copy()
                        trans_med_tot = (
                                                    transformed_media[i].astype(np.float64).copy()
                                                    )
                        beta = (
                                    np.linalg.inv(data_upd.T @ data_upd)
                                    @ data_upd.T
                                    @ trans_med_tot.T
                                    )
                        fitted_values = data_upd @ beta
                        X_tilde_j[i] = trans_med_tot - fitted_values

                    X_tilde[non_media_idx] = np.asarray(X_tilde_j)

                    I = np.identity(num_media_vars)
                    for i in range(num_media_vars):
                        # X_var_i = np.var(X_tilde_j[i])
                        # print('-----')
                        # print(i)
                        # print(X_var_i)
                        # lambda_k[i] = lambda_k[i] * var_y
                        # lambda_k[i] = lambda_k[i]
                        if i in [13,14,15]:
                            lambda_k[i] = 100 * lambda_k[i]
                        else:
                            lambda_k[i] = var_y * lambda_k[i]
                        I[i][i] = lambda_k[i]

                    val_2 = np.dot(
                        X_tilde[non_media_idx], X_tilde[non_media_idx].transpose()
                    )

                    P_mkj = inv(I + val_2)

                    Q_mkj = np.dot(X_tilde[non_media_idx], Y_kj) + np.dot(
                        lambda_k, coef_mean_prior
                    )

                    Beta_j = np.dot(P_mkj, Q_mkj)
                    Beta[non_media_idx] = Beta_j
                    if log_details > 0:
                        with objmode():
                            self.solution_beta_arr = Beta_j.copy()
                    if (Beta_j > 0).sum() > 0:
                        pos_coeffs_j.append((Beta_j > 0).sum())
                    else:
                        pos_coeffs_j.append(0)

                    if (Beta_j > 0).sum() == num_media_vars:

                        log_solution = 1
                count_pos_coef = max(pos_coeffs_j)
                J_star = np.array(
                    [i for i, num in enumerate(pos_coeffs_j) if num == count_pos_coef]
                )
                
                # iroas_list = []

                ### Calculating objective function loss ###
                min_loss = np.inf
                for i in J_star:
                    term_1 = np.sum(
                        np.square(
                            pre_processed_matrix_Y_kj[sbu_idx][i][:train_end_index]
                            - np.dot(Beta[i], X_tilde[i])
                        )
                    )
                    term_2 = (lambda_k * np.square(Beta[i] - scaled_prior)).sum() 
                    # calculate iroas_penalty
                    term_3, term_2_1, term_4 = 0.0, 0.0, 0.0
                    prior_loss = np.square(Beta[i] - scaled_prior)
                    if use_iroas_penalty:

                        contribution = Beta[i] * transformed_media.sum(axis=1)
                        iroas = contribution * train_price / train_spend
                        # iroas_list.append(iroas)
                        term_2_1 = (
                            lambda_k * np.square(iroas - media_roas_prior)
                        ).sum()
                        
                        iroas_penalty = np.where(
                            (iroas >= iroas_lb) & (iroas <= iroas_ub), 0, 1
                        )

                        scurve_penalty = np.where(
                            np.logical_or(s_curve_dic_thr >= scurve_penalty_thr_bnd,
                                          s_curve_dic_sat >= scurve_penalty_sat_bnd
                            ), 0, 1
                        )
                        #WMT iRoAS penalty excluded
                        # replace_pen = [0] * 5
                        # iroas_penalty[-5:] = replace_pen
                        if log_details > 0:
                            with objmode():
                                self.solution_contri_arr = contribution.copy()
                                self.solution_iroas_arr = iroas.copy()
                                self.solution_iroas_penalty_arr = iroas_penalty.copy()
                                self.solution_scurve_penalty_arr = scurve_penalty.copy()
                                self.lambda_k_arr = lambda_k.copy()
                                self.prior_loss_arr = prior_loss.copy()
                                self.scaled_prior = scaled_prior.copy()
                                self.scaling_factor = scaling_factor_list.copy()
                        # sum up the penalty and scale to [0,1]
                        # term_3 = float(iroas_penalty[:-5].sum()) / (float(num_media_vars)-5.0)
                        term_3 = iroas_penalty.sum() / num_media_vars
                        term_4 = scurve_penalty.sum() / num_media_vars

                    loss = (
                        term_1 / SST
                        + term_2 / SST 
                        + (term_3 * iroas_penalty_multiplier)
                        + term_4
                    )
                    
                    # x_updated = x
                    # for nat_index in range(len(national_media_vars_lg_hf)):
                    #     national_info = national_media_vars_lg_hf[nat_index]
                    #     transformed_nat_var = transformed_media[int(national_info[0])]    
                    #     nat_lg = national_info[1]
                    #     nat_hf = national_info[2]
                    #     nat_inf = national_info[3]
                    #     nat_sc = national_info[4]
                    #     x_updated = np.append(x_updated,[nat_hf,nat_inf,nat_sc,nat_lg])
                    # with objmode():
                    #     self.solution_arr = x_updated.copy()

                    min_loss = min(min_loss, loss)
                    if log_details > 0:
                        with objmode():
                            save_iteration_log(
                                sbu_idx,
                                log_details,
                                SST,
                                term_1,
                                term_2,
                                term_2_1,
                                term_3,
                                term_4,
                                min_loss
                            )
    
                if (log_solution > 0) and (term_1 / SST <= 0.3):
                    with objmode():
                        save_intermediate_solution(sbu_idx, x, term_3, debug_flag)
                if is_premium and use_sign_penalty:
                    sbu_losses[sbu_idx] = min_loss * 1.0 - max(pos_coeffs_j)
                else:
                    sbu_losses[sbu_idx] = min_loss
                log_solution_total += log_solution

                # print('lambda_k : ')
                # print((lambda_k))

                # print('term_2 : ')
                # print((term_2))


                # print('X_tilde_j : ')
                # print((X_var_i))

                # print('term_2 : ')
                # print((np.square(Beta[i] - scaled_prior)))

                # print('variance y_tilde : ')
                # print((var_y))

                # print('Scaling Factor : ')
                # print((scaling_factor_list))

                # print('Coef Var : ')
                # print((sepehr_fc_list))

                # print('Scaled   : ')
                # print((scaled_prior))

                # print('Beta   : ')
                # print((Beta))

                # print('contribution   : ')
                # print((contribution))

                # print('transformed_media Sum  : ')
                # print((transformed_media.sum(axis=1)))

                # print('Train Price   : ')
                # print((train_price))

                # print('Train Spend   : ')
                # print((train_spend))

                # print('iRoAS   : ')
                # print((iroas_list))

            for i in range(num_sbu):
                total_loss += sbu_losses[i]

            return total_loss


        if solution_save:
            return optimization_fn_numba(initial_solution)

        if global_opt:
            solution = differential_evolution.differential_evolution(
                optimization_fn_numba,
                bnds,
                maxiter = 600,
                popsize = 15,
                seed=seed,
                workers=1,
                tol=0.01,
                disp=True,
                updating="deferred",
                mutation=(0.5, 1.5),
                strategy="best1bin",
                recombination=0.7,
                x0=initial_solution,
                polish=False,
                fix_iterations=self.fix_iterations
            )
        else:
            solution = minimize(
                optimization_fn_numba,
                initial_solution,
                bounds=bnds,
                method="SLSQP",
                options={"disp": True},
            )

        solution.saved_solutions.append(
            np.concatenate((solution.x, np.array([optimization_fn_numba(solution.x)])))
        )

        return solution

    def run_optimizer(self, seed, global_opt=True):
        self.solution = self.run_DE(
            seed,
            self.num_sbu,
            self.num_media_vars,
            self.num_media_vars_og,
            self.train_end_index,
            self.transformed_var_actual,
            self.transformed_spend_var_actual,
            self.pre_processed_matrix_U_kj,
            self.pre_processed_matrix_Y_kj,
            self.num_non_media_vars,
            self.coef_mean_prior,
            self.coef_var_prior,
            self.outcome_by_sbu_actual,
            self.bnds,
            self.initial_solution,
            self.lambda_k_val,
            self.iroas_dev_in_loss,
            global_opt,
            media_roas_prior=self.media_iroas_prior,
            use_ridge = self.use_ridge,
            is_premium = self.is_premium,
            lambda_denominator = self.lambda_denominator, 
            use_sign_penalty = self.use_sign_penalty,
            use_iroas_penalty = self.use_iroas_penalty,
            iroas_penalty_multiplier = self.iroas_penalty_multiplier,
            iroas_lb = self.iroas_lb,
            iroas_ub = self.iroas_ub, 
            train_spend = self.train_spend,
            train_price = self.train_price,
            common_s_curve= self.common_s_curve,
            handle_added_value = self.handle_added_value,
            media_variables=self.media_variables,
            non_media_variables=self.non_media_variables,
            data=np.asarray(self.data[self.non_media_variables]),
            national_media_vars_lg_hf = np.asarray(self.national_media_vars_lg_hf),
            num_wmc_media_var = self.num_wmc_media_var,
            on_air_days = self.df_media_onair
        )

    ################################ Solution Processing ################################

    def get_beta(
        self,
        pre_processed_matrix_U_kj,
        pre_processed_matrix_Y_kj,
        transformed_media,
        lambda_k,
        transformed_total,
        sbu_idx,
        coef_mean_prior,
    ):
        ### Caclulating media Betas for each set of non media variables ###
        X_tilde = np.zeros(
            (self.num_non_media_vars, self.num_media_vars, self.train_end_index)
        )
        X_tilde_all = np.zeros(
            (self.num_non_media_vars, self.num_media_vars, len(transformed_total[0]))
        )

        Beta = np.zeros((self.num_non_media_vars, self.num_media_vars))

        for non_media_idx in range(self.num_non_media_vars):
            U_kj = pre_processed_matrix_U_kj[sbu_idx][non_media_idx][
                : self.train_end_index, : self.train_end_index
            ]
            U_kj_all = pre_processed_matrix_U_kj[sbu_idx][non_media_idx][:, :]

            Y_kj = pre_processed_matrix_Y_kj[sbu_idx][non_media_idx][
                : self.train_end_index
            ]
            var_y = (Y_kj.std()) ** 2
            X_tilde_j = np.zeros((self.num_media_vars, self.train_end_index))
            X_tilde_j_all = np.zeros((self.num_media_vars, len(transformed_total[0])))

            # for i in range(self.num_media_vars):
            #     X_tilde_j[i] = (U_kj * transformed_media[i]).sum(axis=1)

            # for i in range(self.num_media_vars):
            #     X_tilde_j_all[i] = (U_kj_all * transformed_total[i]).sum(axis=1)

            ### Residual from OLS update
            train_data = np.asarray(self.data[self.non_media_variables])
            train_data = train_data[: self.train_end_index].copy()
            for i in range(self.num_media_vars):
                # # X_tilde_j[i] = (U_kj * transformed_media[i]).sum(axis=1)
                # col_name = self.media_variables[i] + "_transformed"
                # train_data[col_name] = transformed_media[i]
                # X_tilde_j[i] = np.asarray(
                #     residual_calculation(
                #         train_data.copy(),
                #         col_name,
                #         self.non_media_variables,
                #         add_const=False,
                #     )
                # )

                data_upd = train_data.astype(np.float64).copy()
                trans_med_tot = (
                                            transformed_media[i].astype(np.float64).copy()
                                            )
                beta = (
                            np.linalg.inv(data_upd.T @ data_upd)
                            @ data_upd.T
                            @ trans_med_tot.T
                            )
                fitted_values = data_upd @ beta
                X_tilde_j[i] = trans_med_tot - fitted_values


            all_data = np.asarray(self.data[self.non_media_variables]).copy()
            for i in range(self.num_media_vars):
                # X_tilde_j_all[i] = (U_kj_all * transformed_total[i]).sum(axis=1)
                # col_name = self.media_variables[i] + "_transformed"
                # all_data[col_name] = transformed_total[i]
                # X_tilde_j_all[i] = np.asarray(
                #     residual_calculation(
                #         all_data.copy(),
                #         col_name,
                #         self.non_media_variables,
                #         add_const=False,
                #     )
                # )

                data_upd = all_data.astype(np.float64).copy()
                trans_med_tot = (
                                            transformed_total[i].astype(np.float64).copy()
                                            )
                beta = (
                            np.linalg.inv(data_upd.T @ data_upd)
                            @ data_upd.T
                            @ trans_med_tot.T
                            )
                fitted_values = data_upd @ beta
                X_tilde_j_all[i] = trans_med_tot - fitted_values



            X_tilde[non_media_idx] = np.asarray(X_tilde_j)
            X_tilde_all[non_media_idx] = np.asarray(X_tilde_j_all)


            I = np.identity(self.num_media_vars)
            for i in range(self.num_media_vars):
                # X_var_i = np.var(X_tilde[i])
                # lambda_k[i] = lambda_k[i]
                if i in [13,14,15]:
                    lambda_k[i] = 100 * lambda_k[i]
                else:
                    lambda_k[i] = var_y * lambda_k[i]
                I[i][i] = lambda_k[i]

            val_2 = np.dot(X_tilde[non_media_idx], X_tilde[non_media_idx].transpose())

            P_mkj = inv(I + val_2)

            Q_mkj = np.dot(X_tilde[non_media_idx], Y_kj) + np.dot(
                lambda_k, coef_mean_prior
            )

            Beta_j = np.dot(P_mkj, Q_mkj)
            Beta[non_media_idx] = Beta_j

        return Beta, X_tilde, X_tilde_all

    def get_params(
        self,
        solution,
        sbu_idx,
        media_variables,
        df_by_sbu,
        transformed_var_actual,
        transformed_spend_var_actual,
    ):
        # halflife, threshold, saturation, lag
        i = 0
        j = 4
        hf, inf, sc, lg, thr, sat = {}, {}, {}, {}, {}, {}
        df_filtered = df_by_sbu.copy()
        transformed_media = np.zeros((self.num_media_vars, self.train_end_index))
        transformed_total = np.zeros(
            (self.num_media_vars, len(transformed_var_actual[0]))
        )

        scaled_prior = np.zeros(len(media_variables))

        lambda_k = np.zeros(self.num_media_vars)
        SST = np.sum(
            (
                self.outcome_by_sbu[sbu_idx]
                - np.mean(self.outcome_by_sbu[sbu_idx])
            )
            ** 2
        )
        for media_var_idx in range(self.num_media_vars):
            if media_var_idx in [13,14,15]:
                transformed_var = transformed_var_actual[sbu_idx][:, media_var_idx]
                transformed_spend = transformed_spend_var_actual[sbu_idx][
                    :, media_var_idx
                ]

                for nat_index in range(len(self.national_media_vars_lg_hf)):
                    national_info = self.national_media_vars_lg_hf[nat_index]
                    if media_var_idx == national_info[0]:
                        lag_national = national_info[1]
                        halflife_national = national_info[2]
                        inflection_national = national_info[3]
                        scale_national = national_info[4]
                thr[media_variables[media_var_idx]] =  np.quantile(a=transformed_var, q=0.05)
                sat[media_variables[media_var_idx]] =  np.quantile(a=transformed_var, q=0.95)                
                hf[media_variables[media_var_idx]], halflife = (halflife_national,halflife_national)
                inf[media_variables[media_var_idx]], inflection = (inflection_national,inflection_national)
                sc[media_variables[media_var_idx]], scale = (scale_national,scale_national)
                lg[media_variables[media_var_idx]], lag = (lag_national,lag_national)

                sepehr_fc = transformed_var.std() / transformed_var.mean()

                scaling_factor = max(transformed_var) - min(transformed_var)
                transformed_var = (transformed_var - min(transformed_var)) / scaling_factor


                transformed_total[media_var_idx] = np.asarray(transformed_var)
                transformed_var = transformed_var[: self.train_end_index]
                transformed_media[media_var_idx] = np.asarray(transformed_var)  # X_mk
                
                if self.use_ridge:

                    scaled_prior[media_var_idx] = (
                        self.coef_mean_prior[media_var_idx] * scaling_factor
                    )
                    lambda_k[media_var_idx] = 1 / (self.coef_mean_prior[media_var_idx] * sepehr_fc) ** 2

                else:
                    lambda_k[media_var_idx] = 0.0
                    scaled_prior[media_var_idx] = 0.0

                i += 4
                j += 4
                
            else:

                decision_vars = solution[i:j]

                hf[media_variables[media_var_idx]], halflife = (
                    decision_vars[0],
                    decision_vars[0],
                )

                inf[media_variables[media_var_idx]], inflection = (
                    decision_vars[1],
                    decision_vars[1],
                )
                sc[media_variables[media_var_idx]], scale = (
                    decision_vars[2],
                    decision_vars[2],
                )
                lg[media_variables[media_var_idx]], lag = int(decision_vars[3]), int(
                    decision_vars[3]
                )
                
                transformed_var = transformed_var_actual[sbu_idx][:, media_var_idx]
                transformed_spend = transformed_spend_var_actual[sbu_idx][
                    :, media_var_idx
                ]
                if self.handle_added_value:
                    transformed_var = (
                        transformed_var * transformed_spend
                    )  ### ignore spend = 0 for added value
                scaling_factor_raw = max(transformed_var) - min(transformed_var)

                if lag != 0:
                    transformed_var = lag_transformation(transformed_var, lag)
                if halflife != 0:
                    transformed_var = halflife_transformation(transformed_var, halflife)


                sat[media_variables[media_var_idx]] = self.gompertz_logistic_saturation_pts(transformed_var, 'Raw Variable',
                                                                        inflection, scale)                    
            
                # threshold point
                thr[media_variables[media_var_idx]] = self.gompertz_logistic_threshold_pts(transformed_var, 'Raw Variable', 
                                                            inflection, scale)

                var_mean = transformed_var.mean()


                if (scale != 0) and (inflection != 0):
                    transformed_var_scaled = transformed_var / var_mean
                    saturation_term = scale * (inflection - transformed_var_scaled)
                    scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (
                        1 + np.exp(scale * inflection)
                    )
                    scurve_var_mean = scurve_var[: self.train_end_index].mean()
                    transformed_var = scurve_var * var_mean / scurve_var_mean

                sepehr_fc = transformed_var.std() / transformed_var.mean()

                scaling_factor = max(transformed_var) - min(transformed_var)
                # transformed_var = (transformed_var - min(transformed_var)) / scaling_factor


                transformed_total[media_var_idx] = np.asarray(transformed_var)
                transformed_var = transformed_var[: self.train_end_index]
                transformed_media[media_var_idx] = np.asarray(transformed_var)  # X_mk
                if self.use_ridge:

                    scaled_prior[media_var_idx] = (
                        self.coef_mean_prior[media_var_idx] * scaling_factor
                    )
                    lambda_k[media_var_idx] = 1 / (self.coef_mean_prior[media_var_idx] * sepehr_fc) ** 2
                        # 1 / (sepehr_fc * scaled_prior[media_var_idx]) ** 2
                        # 100 / sepehr_fc
                        # 5 / sepehr_fc
                    #     7.5 / sepehr_fc
                    #     # 1
                    #     if self.lambda_k_val
                    #     else variance_calculation(self.outcome_by_sbu[sbu_idx])
                    #     / (self.lambda_denominator)
                    # )  # Lambda_mk

                else:
                    lambda_k[media_var_idx] = 0.0
                    scaled_prior[media_var_idx] = 0.0

                i += 4
                j += 4
                
        beta, X_tilde, X_tilde_all = self.get_beta(
            self.pre_processed_matrix_U_kj,
            self.pre_processed_matrix_Y_kj,
            transformed_media,
            lambda_k,
            transformed_total,
            sbu_idx,
            self.coef_mean_prior,
        )

        return (
            beta,
            transformed_media,
            transformed_total,
            hf,
            inf,
            sc,
            lg,
            thr,
            sat,
            X_tilde,
            X_tilde_all,
        )

    def run_diagnostics(self): # willl only work with single brand and single base

        if self.is_premium:
            solutions_list = []
            # sol_details : brand_idx,log_details,SST,term_1,term_2,term_3,min_loss
            transformation_arr, iteration_number, sst, term_1, term_2, term_2_1, term_3, term_4 ,min_loss = [], [], [], [], [], [], [], [], []
            for sol in self.iteration_logs:
                term_1_by_sst = sol[1][3]/sol[1][2]
                term_2_by_sst = sol[1][4]/sol[1][2]
                transformation_arr = np.reshape(sol[0],(self.num_media_vars,4)).tolist()
                iteration_log_result_dict = {
                            
                            "SBU_name": self.sbu_list[0],
                            "Iteration_number": sol[1][1],
                            "sst" : sol[1][2],
                            "term_1" : sol[1][3],
                            "term_1_by_sst" : term_1_by_sst,
                            "term_2" : sol[1][4],
                            "term_2_by_sst" : term_2_by_sst,
                            "term_2_1": sol[1][5],
                            "term_3": sol[1][6],
                            "term_4": sol[1][7],
                            "min_loss" : sol[1][8],
                            "media_variable" : self.media_variables,
                            "Tactic_iroas" : sol[4],
                            "Tactic_contri" : sol[3],
                            "Tactic_coef" : sol[2],
                            "Tactic_iroas_penalty" : sol[5],
                            "Tactic_scurve_penalty" : sol[6],
                            "Tactic_lambda_k" : sol[7],
                            "B - B0 Square" : sol[8],
                            "Scaled_prior" : sol[9],
                            "Scaling_factor" : sol[10],
                            "Transformation": transformation_arr

                        }
                iteration_log_results = pd.DataFrame.from_dict(iteration_log_result_dict)
                solutions_list.append(iteration_log_results)

            try:
                combined_iteration_log = pd.concat(solutions_list)
                combined_iteration_log.to_csv(
                    f"{self.folder_path}/iteration_log_details.csv", index=False
                )
            except:
                print("No intermediate log to save \n")
                
    def load_pickle_files(self, seed):
        self.seed = seed
        self.sbu_level_sol = {}
        for sbu in self.sbu_list:
            try:
                interim_sols = [
                    filename
                    for filename in os.listdir(self.folder_path)
                    if filename.startswith(f"interim_sol_{sbu}")
                ]
                solutions_res = []
                for file_name in interim_sols:
                    file = os.path.join(self.folder_path, file_name)
                    objects = []
                    with open(file, "rb") as f:
                        while True:
                            try:
                                obj = pickle.load(f)
                                objects.append(obj)
                            except EOFError:
                                break
                    solutions_res += objects

                combined_sol = [l.tolist() for l in (solutions_res)]
                combined_sol.sort()
                combined_sol = list(
                    combined_sol for combined_sol, _ in itertools.groupby(combined_sol)
                )
                combined_sol = [np.asarray(arr) for arr in combined_sol]
                print(f"length of single solution : {len(combined_sol[0])}")
            except:
                print("no interim solutions for sbu", sbu)
            self.sbu_level_sol[sbu] = combined_sol

        for sbu, sols in self.sbu_level_sol.items():
            print(
                sbu,
                "number of solutions loaded from pickle file",
                abs(len(self.sbu_level_sol[sbu])),
                "\n"
            )
        print("saving iteration logs \n")
        self.run_diagnostics()
        print("************* saving iteration logs - Done ************* \n")


    def process_solution(self, args):
        (df_by_sbu, sbu_idx, YoY_comparison, i, sol) = args
        df_yoy_sets = []
        for k, v in YoY_comparison.items():
            sub_dfs = []
            for st, end in eval(v):
                idx = (df_by_sbu["Date"] >= st) & (df_by_sbu["Date"] <= end)
                st_idx = df_by_sbu[idx].index.min()
                end_idx = df_by_sbu[idx].index.max()
                sub_dfs.append((st_idx, end_idx))
            df_yoy_sets.append(sub_dfs)

        non_media_df = pd.DataFrame()
        (
            beta,
            transformed_media,
            transformed_total,
            hf,
            inf,
            sc,
            lg,
            thr,
            sat,
            X_tilde,
            X_tilde_all,
        ) = self.get_params(
            sol[:-1],
            sbu_idx,
            self.media_variables,
            df_by_sbu,
            self.transformed_var_actual,
            self.transformed_spend_var_actual,
        )
        X_tilde_valid = X_tilde_all[:, :, self.train_end_index :]

        for non_media_idx in range(self.num_non_media_vars):
            Y_tilde_train = self.pre_processed_matrix_Y_kj[sbu_idx][non_media_idx][
                : self.train_end_index
            ]
            Y_tilde_valid = self.pre_processed_matrix_Y_kj[sbu_idx][non_media_idx][
                self.train_end_index :
            ]

            total_spend, total_cont, total_train_outcome, total_valid_outcome = (
                0,
                0,
                0,
                0,
            )
            (
                solution_number_col,
                driver_col,
                seed_col,
                coeff,
                overall_iroas_col,
                inf_pt_y,
                sum_iroas_dev,
                sum_inf_dev,
            ) = ([], [], [], [], [], [], [], [])
            initial_solution_col, obj_value_col = ([], [])
            train_rsq, train_mp, valid_rsq, valid_mp = [], [], [], []
            (
                iroas_res,
                DE_sol,
                transf_res,
                thres_sat_res,
                iroas_in_bound_res,
                on_air_days_res,
                days_beyon_sat_res,
                days_below_thresh_res,
            ) = ([], [], [], [], [], [], [], [])
            (
                iroas,
                media_iroas_arr,
                transformations,
                coefficient,
                thres_sat,
                inflection_point_y,
                iroas_in_bound,
                on_air_days_perc,
                days_beyond_saturation,
                days_below_threshold,
                dev_from_inf,
                saturation_acceptable,
                threshold_acceptable,
                inf_deviation_acceptable,
                dev_from_iroas_prior,
            ) = ({}, [], {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {})
            (
                hf_res,
                inf_res,
                sc_res,
                lg_res,
                thresh_res,
                sat_res,
                dev_inf_res,
                sat_acceptable_res,
                thresh_acceptable_res,
                inf_dev_acceptable_res,
                roas_dev_res,
                inf_dev_arr,
            ) = ([], [], [], [], [], [], [], [], [], [], [], [])

            price = df_by_sbu["PRICE"][: self.train_end_index].mean()

            for idx in range(self.num_media_vars):
                media_var = self.media_variables[idx]
                spend_var = self.media_variables[idx][:-4] + "_SPEND"
                coef = beta[non_media_idx][idx]
                on_air_df = self.data[self.data[media_var] > 0]

                on_air_days_perc[self.media_variables[idx]] = len(on_air_df) / len(
                    self.data
                )

                days_beyond_saturation[self.media_variables[idx]] = len(
                    on_air_df[self.data[media_var] > sat[media_var]]
                ) / len(on_air_df)

                saturation_acceptable[self.media_variables[idx]] = (
                    True
                    if (
                        (
                            on_air_days_perc[self.media_variables[idx]] >= 0.20
                            and days_beyond_saturation[self.media_variables[idx]]
                            <= 0.15
                        )
                        or on_air_days_perc[self.media_variables[idx]] < 0.20
                    )
                    else False
                )

                days_below_threshold[self.media_variables[idx]] = len(
                    on_air_df[self.data[media_var] < thr[media_var]]
                ) / len(self.data[self.data[media_var] > 0])

                threshold_acceptable[self.media_variables[idx]] = (
                    True
                    if (
                        (
                            on_air_days_perc[self.media_variables[idx]] >= 0.20
                            and days_below_threshold[self.media_variables[idx]] <= 0.15
                        )
                        or on_air_days_perc[self.media_variables[idx]] < 0.20
                    )
                    else False
                )

                term = coef * transformed_media[idx]
                total_train_outcome += term

                valid_term = coef * transformed_total[idx][self.train_end_index :]
                total_valid_outcome += valid_term
                if "WMT" not in self.media_variables[idx]:               # National Media included in Cat WAMM is Walmart level
                    total_cont += term.sum()
                iroas_val = (term.sum() * price) / df_by_sbu[spend_var][
                    : self.train_end_index
                ].sum()
                iroas[self.media_variables[idx]] = iroas_val
                dev_from_iroas_prior[self.media_variables[idx]] = (
                    iroas_val - self.media_iroas_prior[idx]
                ) ** 2

                if (iroas_val >= self.iroas_lb[idx]) and (
                    iroas_val <= self.iroas_ub[idx]
                ):
                    iroas_in_bound[self.media_variables[idx]] = True
                else:
                    iroas_in_bound[self.media_variables[idx]] = False

                media_iroas_arr.append(iroas_val)
                if "WMT" not in self.media_variables[idx]:                   # National Media included in Cat WAMM is Walmart level
                    total_spend += df_by_sbu[spend_var][: self.train_end_index].sum()

                transformations[self.media_variables[idx]] = [
                    hf[self.media_variables[idx]],
                    inf[self.media_variables[idx]],
                    sc[self.media_variables[idx]],
                    lg[self.media_variables[idx]],
                ]
                thres_sat[self.media_variables[idx]] = [
                    thr[self.media_variables[idx]],
                    sat[self.media_variables[idx]],
                ]
                coefficient[self.media_variables[idx]] = beta[non_media_idx][idx]
                inflection_point_y[self.media_variables[idx]] = (
                    inf[self.media_variables[idx]]
                    * df_by_sbu[self.media_variables[idx]].mean()
                )
                dev_from_inf[self.media_variables[idx]] = (
                    inflection_point_y[self.media_variables[idx]]
                    - self.data[self.media_variables[idx]].mean()
                ) ** 2
                if on_air_days_perc[self.media_variables[idx]] >= 0.20:
                    inf_dev_arr.append(dev_from_inf[self.media_variables[idx]])
                """
                inf_deviation_acceptable[self.media_variables[idx]] = (
                    True
                    if (
                        (
                            on_air_days_perc[self.media_variables[idx]] >= 0.20
                            and dev_from_inf[self.media_variables[idx]] <= 0.40
                        )
                        or on_air_days_perc[self.media_variables[idx]] < 0.20
                    )
                    else False
                )
                """

            overall_iroas = total_cont * price / total_spend
            inf_dev_arr = np.asarray(inf_dev_arr)

            ### Monotonic Incremental Contribution in Spend YoY
            monotonic_inc_contrib_overall, monotonic_inc_contrib_tactic = [], []
            for sub_dfs in df_yoy_sets:
                idx1, idx2, idx3, idx4 = (
                    sub_dfs[0][0],
                    sub_dfs[0][1],
                    sub_dfs[1][0],
                    sub_dfs[1][1],
                )
                df_1 = df_by_sbu[idx1 : idx2 + 1]
                df_2 = df_by_sbu[idx3 : idx4 + 1]
                price_1, price_2 = df_1["PRICE"].mean(), df_2["PRICE"].mean()
                total_cont_1, total_cont_2, total_spend_1, total_spend_2 = 0, 0, 0, 0
                media_contrib_1, media_spend_1, media_contrib_2, media_spend_2 = (
                    {},
                    {},
                    {},
                    {},
                )
                for idx in range(self.num_media_vars):
                    media_var = self.media_variables[idx]
                    spend_var = self.media_variables[idx][:-4] + "_SPEND"
                    coef = beta[non_media_idx][idx]

                    total_cont_1 += coef * transformed_total[idx][idx1 : idx2 + 1].sum()
                    total_cont_2 += coef * transformed_total[idx][idx3 : idx4 + 1].sum()

                    media_spend_1[media_var] = df_1[spend_var].sum()
                    total_spend_1 += df_1[spend_var].sum()
                    media_spend_2[media_var] = df_2[spend_var].sum()
                    total_spend_2 += df_2[spend_var].sum()

                    media_contrib_1[media_var] = (
                        coef * transformed_total[idx][idx1 : idx2 + 1].sum()
                    ) * price_1
                    media_contrib_2[media_var] = (
                        coef * transformed_total[idx][idx3 : idx4 + 1].sum()
                    ) * price_2

                    if "_IMP" in media_var:
                        if (
                            (media_spend_2[media_var] > media_spend_1[media_var])
                            and (
                                media_contrib_2[media_var] < media_contrib_1[media_var]
                            )
                        ) or (
                            (media_spend_2[media_var] < media_spend_1[media_var])
                            and (
                                media_contrib_2[media_var] > media_contrib_1[media_var]
                            )
                        ):
                            monotonic_inc_contrib_tactic.append(False)
                        else:
                            monotonic_inc_contrib_tactic.append(True)
                    else:
                        if (media_spend_2[media_var] > media_spend_1[media_var]) and (
                            media_contrib_2[media_var] < media_contrib_1[media_var]
                        ):
                            monotonic_inc_contrib_tactic.append(False)
                        else:
                            monotonic_inc_contrib_tactic.append(True)
                overall_contrib_1 = total_cont_1 * price_1
                overall_contrib_2 = total_cont_2 * price_2

                if (total_spend_2 > total_spend_1) and (
                    overall_contrib_2 < overall_contrib_1
                ):
                    monotonic_inc_contrib_overall.append(False)
                else:
                    monotonic_inc_contrib_overall.append(True)

            monotonic_inc_contrib_tactic_bool = all(monotonic_inc_contrib_tactic)
            monotonic_inc_contrib_overall_bool = all(monotonic_inc_contrib_overall)

            train_error = Y_tilde_train - np.dot(
                beta[non_media_idx], X_tilde[non_media_idx]
            )
            valid_error = Y_tilde_valid - np.dot(
                beta[non_media_idx], X_tilde_valid[non_media_idx]
            )

            train_mape = (
                np.abs(train_error / df_by_sbu[self.outcome][: self.train_end_index])
                * 100
            ).mean()
            valid_mape = (
                np.abs(valid_error / df_by_sbu[self.outcome][self.train_end_index :])
                * 100
            ).mean()

            ss_tot_train = (
                (
                    df_by_sbu[self.outcome][: self.train_end_index]
                    - df_by_sbu[self.outcome][: self.train_end_index].mean()
                )
                ** 2
            ).sum()
            ss_tot_valid = (
                (
                    df_by_sbu[self.outcome][self.train_end_index :]
                    - df_by_sbu[self.outcome][self.train_end_index :].mean()
                )
                ** 2
            ).sum()

            r_sq_train = 1 - (train_error**2).sum() / ss_tot_train
            r_sq_valid = 1 - (valid_error**2).sum() / ss_tot_valid

            if (beta[non_media_idx] > 0).sum() == self.num_media_vars:
                driver_col += self.media_variables
                solution_number_col += [i] * len(self.media_variables)
                initial_solution_col += list(self.initial_solution)
                on_air_days_res += list(on_air_days_perc.values())
                iroas_res += list(iroas.values())
                iroas_in_bound_res += list(iroas_in_bound.values())
                transf_res += list(transformations.values())
                hf_res += list(hf.values())
                inf_res += list(inf.values())
                sc_res += list(sc.values())
                lg_res += list(lg.values())
                thres_sat_res += list(thres_sat.values())
                thresh_res += list(thr.values())
                sat_res += list(sat.values())
                days_beyon_sat_res += list(days_beyond_saturation.values())
                days_below_thresh_res += list(days_below_threshold.values())
                sat_acceptable_res += list(saturation_acceptable.values())
                thresh_acceptable_res += list(threshold_acceptable.values())

                overall_iroas_col += [overall_iroas] * len(self.media_variables)
                train_rsq += [r_sq_train] * len(self.media_variables)
                train_mp += [train_mape] * len(self.media_variables)
                valid_rsq += [r_sq_valid] * len(self.media_variables)
                valid_mp += [valid_mape] * len(self.media_variables)
                obj_fn_loss = sol[-1]
                obj_value_col += [obj_fn_loss] * len(self.media_variables)
                seed_col += [self.seed] * len(self.media_variables)
                coeff += list(coefficient.values())
                inf_pt_y += list(inflection_point_y.values())
                dev_inf_res += list(dev_from_inf.values())
                sum_inf_dev += [inf_dev_arr.sum()] * len(self.media_variables)
                # inf_dev_acceptable_res += list(inf_deviation_acceptable.values())
                roas_dev_res += list(dev_from_iroas_prior.values())
                DE_sol += list(sol)
                sum_iroas_dev += [
                    np.asarray(list(dev_from_iroas_prior.values())).sum()
                ] * len(self.media_variables)

                result_data = {
                    "Seed": seed_col,
                    "sbu_name": [self.sbu_list[sbu_idx]]
                    * len(solution_number_col),
                    "Solution_number": solution_number_col,
                    "Non_media_set": [self.base_num] * len(solution_number_col),
                    "Media_tactic": driver_col,
                    "Coefficient": coeff,
                    "Tactic_iRoAS": iroas_res,
                    "Overall_iroas": overall_iroas_col,
                    "Tactic_iRoAS_dev_from_pior": roas_dev_res,
                    "Sum_deviation_from_prior": sum_iroas_dev,
                    "Tactic_iRoAS_in_bound": iroas_in_bound_res,
                    "YoY_Monotonic_tactic": [monotonic_inc_contrib_tactic_bool]
                    * len(solution_number_col),
                    "YoY_Monotonic_overall": [monotonic_inc_contrib_overall_bool]
                    * len(solution_number_col),
                    "Train_R_Square": train_rsq,
                    "Train_Mape": train_mp,
                    "Validation_R_Square": valid_rsq,
                    "Validation_Mape": valid_mp,
                    "Media_transformation (hf, inf, sc, lg)": transf_res,
                    "Halflife": hf_res,
                    "Inflection": inf_res,
                    "Scale": sc_res,
                    "Lag": lg_res,
                    "Threshold_Saturation": thres_sat_res,
                    "Threshold": thresh_res,
                    "Saturation": sat_res,
                    "Inflection_Point": inf_pt_y,
                    "Perc_on_air_days": on_air_days_res,
                    "Perc_days_beyond_saturation": days_beyon_sat_res,
                    "Perc_days_below_threshold": days_below_thresh_res,
                    "Deviation_from_inflection": dev_inf_res,
                    "Sum_dev_from_inflection": sum_inf_dev,
                    "Acceptable_saturation": sat_acceptable_res,
                    "Acceptable_threshold": thresh_acceptable_res,
                    # "Acceptable_inflection_dev": inf_dev_acceptable_res,
                    "DE_objective_value": obj_value_col,
                }

                results = pd.DataFrame.from_dict(result_data)
                non_media_df = non_media_df.append(results)

        return non_media_df


    # def save_solutions(self, seed):
    #     self.run_diagnostics()
    #     sbu_level_sol = {}
    #     selected_sol = self.solution.saved_solutions
    #     iteration_sols_count = len(selected_sol)
    #     print("saved solution at end of iterations:", len(selected_sol),"\n")

    #     for sbu in self.sbu_list:    
    #         try:
    #             interim_sols = [filename for filename in os.listdir(self.folder_path) if filename.startswith(f"interim_sol_{sbu}")]
    #             solutions_res = []
    #             for file_name in interim_sols:
    #                 file = os.path.join(self.folder_path, file_name)
    #                 objects = []
    #                 with open(file, 'rb') as f:
    #                     while True:
    #                         try:
    #                             obj = pickle.load(f)
    #                             objects.append(obj)
    #                         except EOFError:
    #                             break
    #                 solutions_res += objects
                                 
    #             combined_sol = [l.tolist() for l in (selected_sol + solutions_res)]
    #             combined_sol.sort()
    #             combined_sol = list(combined_sol for combined_sol,_ in itertools.groupby(combined_sol))                    
    #             combined_sol = [np.asarray(arr) for arr in combined_sol]
    #         except:
    #             print("no interim solutions for sbu", sbu)
    #         sbu_level_sol[sbu] = combined_sol
    #         print(f"Total solutions for sbu {sbu} = {len(combined_sol)}")# premium changes for consistency testing

    #     for sbu, sols in sbu_level_sol.items():
    #         print(sbu, "number of solutions loaded from pickle file", abs(len(sols) - iteration_sols_count))


    #     for sbu_idx in range(len(self.sbu_list)):
    #         sbu_df = pd.DataFrame()
    #         df_by_sbu = self.data[self.data["SBU"] == self.sbu_list[sbu_idx]]
    #         non_media_set = []
    #         print("\n sbu", self.sbu_list[sbu_idx])
    #         for i, sol in enumerate(sbu_level_sol[self.sbu_list[sbu_idx]]):
    #             non_media_df = pd.DataFrame()

    #             (
    #                 beta,
    #                 transformed_media,
    #                 transformed_total,
    #                 hf,
    #                 inf,
    #                 sc,
    #                 lg,
    #                 thr,
    #                 sat,
    #                 X_tilde,
    #                 X_tilde_all,
    #             ) = self.get_params(
    #                 sol[:-1],
    #                 sbu_idx,
    #                 self.media_variables,
    #                 df_by_sbu,
    #                 self.transformed_var_actual
    #             )
    #             if i < 300:
    #                 print(f"Beta for solution {i} : {beta}")

    #             X_tilde_valid = X_tilde_all[:, :, self.train_end_index :]
    #             #         transformed_validation_media = transformed_total[train_end_index:]

    #             for non_media_idx in range(self.num_non_media_vars):
    #                 Y_tilde_train = self.pre_processed_matrix_Y_kj[sbu_idx][
    #                     non_media_idx
    #                 ][: self.train_end_index]
    #                 Y_tilde_valid = self.pre_processed_matrix_Y_kj[sbu_idx][
    #                     non_media_idx
    #                 ][self.train_end_index :]

    #                 (
    #                     total_spend,
    #                     total_cont,
    #                     total_train_outcome,
    #                     total_valid_outcome,
    #                 ) = (0, 0, 0, 0)
    #                 (
    #                     solution_number_col,
    #                     driver_col,
    #                     seed_col,
    #                     coeff,
    #                     overall_iroas_col,
    #                     initial_solution_col,
    #                     obj_value_col,
    #                 ) = ([], [], [], [], [], [], [])
    #                 train_rsq, train_mp, valid_rsq, valid_mp = [], [], [], []
    #                 iroas_res, DE_sol, transf_res, thres_sat_res = [], [], [], []
    #                 iroas, transformations, coefficient, thres_sat = {}, {}, {}, {}

    #                 price = df_by_sbu["PRICE"][: self.train_end_index].mean()

    #                 for idx in range(self.num_media_vars):
    #                     media_var = self.media_variables[idx]
    #                     # spend_var = self.media_variables[idx][:-4] + "_SPEND"
    #                     if "_IMP" in media_var:
    #                         spend_var = media_var.replace("_IMP", "_SPEND")
    #                     else:
    #                         spend_var = media_var.replace("_CLK", "_SPEND")

    #                     coef = beta[non_media_idx][idx]

    #                     ### media
    #                     term = coef * transformed_media[idx]
    #                     total_train_outcome += term

    #                     valid_term = (
    #                         coef * transformed_total[idx][self.train_end_index :]
    #                     )
    #                     total_valid_outcome += valid_term

    #                     if not media_var.startswith('M_NAT'):
    #                         total_cont += term.sum()
    #                     iroas[self.media_variables[idx]] = (
    #                         term.sum() * price
    #                     ) / df_by_sbu[spend_var][: self.train_end_index].sum()
                        
    #                     if not media_var.startswith('M_NAT'):
    #                         total_spend += df_by_sbu[spend_var][
    #                             : self.train_end_index
    #                         ].sum()

    #                     transformations[self.media_variables[idx]] = [
    #                         hf[self.media_variables[idx]],
    #                         inf[self.media_variables[idx]],
    #                         sc[self.media_variables[idx]],
    #                         lg[self.media_variables[idx]],
    #                     ]
    #                     thres_sat[self.media_variables[idx]] = [
    #                         thr[self.media_variables[idx]],
    #                         sat[self.media_variables[idx]],
    #                     ]
    #                     coefficient[self.media_variables[idx]] = beta[non_media_idx][
    #                         idx
    #                     ]

    #                 overall_iroas = total_cont * price / total_spend

    #                 # non_media_coef = self.sbu_non_media_coef[self.sbu_list[sbu_idx]][non_media_idx]

    #                 ##################### fit metrics ########################################
    #                 train_error = Y_tilde_train - np.dot(beta[non_media_idx], X_tilde[non_media_idx])
    #                 valid_error = Y_tilde_valid - np.dot(
    #                     beta[non_media_idx], X_tilde_valid[non_media_idx]
    #                 )

    #                 train_mape = np.abs(train_error / Y_tilde_train) * 100
    #                 valid_mape = np.abs(valid_error / Y_tilde_valid) * 100

    #                 train_mape = train_mape.mean()
    #                 valid_mape = valid_mape.mean()

    #                 ss_tot_train = (
    #                     df_by_sbu[self.outcome][: self.train_end_index]
    #                     - df_by_sbu[self.outcome][: self.train_end_index].mean()
    #                 )# Janhavi : premium changes
    #                 ss_tot_train = ss_tot_train * ss_tot_train
    #                 ss_tot_train = ss_tot_train.sum()

    #                 ss_tot_valid = (
    #                     df_by_sbu[self.outcome][self.train_end_index :]
    #                     - df_by_sbu[self.outcome][self.train_end_index :].mean()
    #                 )# Janhavi : premium changes
    #                 ss_tot_valid = ss_tot_valid * ss_tot_valid
    #                 ss_tot_valid = ss_tot_valid.sum()

    #                 train_error = train_error * train_error
    #                 train_error = train_error.sum()
    #                 r_sq_train = 1 - train_error / ss_tot_train

    #                 valid_error = valid_error * valid_error
    #                 valid_error = valid_error.sum()
    #                 r_sq_valid = 1 - valid_error / ss_tot_valid
    #                 #########################################################################
    #                 if (beta[non_media_idx] > 0).sum() == self.num_media_vars:
    #                     driver_col += self.media_variables
    #                     solution_number_col += [i] * len(self.media_variables)
    #                     initial_solution_col += list(self.initial_solution)

    #                     iroas_res += list(iroas.values())
    #                     transf_res += list(transformations.values())
    #                     thres_sat_res += list(thres_sat.values())

    #                     overall_iroas_col += [overall_iroas] * len(self.media_variables)
    #                     train_rsq += [r_sq_train] * len(self.media_variables)
    #                     train_mp += [train_mape] * len(self.media_variables)
    #                     valid_rsq += [r_sq_valid] * len(self.media_variables)
    #                     valid_mp += [valid_mape] * len(self.media_variables)
    #                     obj_fn_loss = sol[-1]
    #                     obj_value_col += [obj_fn_loss] * len(self.media_variables)
    #                     seed_col += [seed] * len(self.media_variables)
    #                     coeff += list(coefficient.values())
    #                     DE_sol += list(sol)

    #                     non_media_set += [non_media_idx] * len(solution_number_col)
    #                     result_data = {
    #                         "Seed": seed_col,
    #                         "SBU_name": [self.sbu_list[sbu_idx]]
    #                         * len(solution_number_col),
    #                         "Solution_number": solution_number_col,
    #                         "Non_media_set": [non_media_idx] * len(solution_number_col),
    #                         "Media_tactic": driver_col,
    #                         "Coefficient": coeff,
    #                         "Tactic_iRoAS": iroas_res,
    #                         "Overall_iroas": overall_iroas_col,
    #                         "Train_R_Square": train_rsq,
    #                         "Train_Mape": train_mp,
    #                         "Validation_R_Square": valid_rsq,
    #                         "Validation_Mape": valid_mp,
    #                         "Media_transformation (hf, inf, sc, lg)": transf_res,
    #                         "Threshold_Saturation": thres_sat_res,
    #                         "DE_objective_value": obj_value_col,
    #                     }

    #                     results = pd.DataFrame.from_dict(result_data)

    #                     non_media_df = non_media_df.append(results)
    #             sbu_df = sbu_df.append(non_media_df)

    #         filename = (
    #             self.folder_path
    #             + "/results_"
    #             + str(self.sbu_list[sbu_idx])
    #             + "_"
    #             + str(seed)
    #             + ".csv"
    #         )
    #         sbu_df.to_csv(filename, index=False)
    #         print("filename:", filename, "\n")

    #     sol_filename = self.folder_path + "/solutions_" + str(seed) + ".txt"
    #     print("sol_filename:", sol_filename, "\n")
    #     i = 0
    #     with open(sol_filename, "w") as testfile:
    #         for row in self.solution.saved_solutions:
    #             i += 1
    #             testfile.write(str(i) + "\n")
    #             testfile.write(",".join([str(a) for a in row]) + "\n" + "\n")

    #     for sbu in self.sbu_list:
    #         try:
    #             df = pd.read_csv(
    #                 self.folder_path
    #                 + "/results_"
    #                 + str(sbu)
    #                 + "_"
    #                 + str(seed)
    #                 + ".csv"
    #             )
    #             print(
    #                 sbu, ":", len(list(df["Solution_number"].unique())), "solutions"
    #             )
    #         except:
    #             print(
    #                 "no solution found for sbu",
    #                 sbu,
    #                 "as no solution found with all positive coefficients",
    #             )

    def save_solutions(self):
        pool = mp.Pool(mp.cpu_count())

        for sbu_idx in range(len(self.sbu_list)):
            sbu_df = pd.DataFrame()
            df_by_sbu = self.data[self.data["SBU"] == self.sbu_list[sbu_idx]]
            print("\n sbu", self.sbu_list[sbu_idx])
            tasks = [
                (df_by_sbu, sbu_idx, self.YoY_comparison, i, sol)
                for i, sol in enumerate(
                    self.sbu_level_sol[self.sbu_list[sbu_idx]]
                )
            ]

            non_media_dfs = pool.map(self.process_solution, tasks)
            for non_media_df in non_media_dfs:
                sbu_df = sbu_df.append(non_media_df)

            filename = f"{self.folder_path}/results_{self.sbu_list[sbu_idx]}_{self.seed}.csv"
            sbu_df.to_csv(filename, index=False)
            print("filename:", filename, "\n")

        pool.close()
        pool.join()


    def save_txt(self):
        sol_filename = self.folder_path + "/solutions_" + str(self.seed) + ".txt"
        print("sol_filename:", sol_filename, "\n")
        i = 0
        with open(sol_filename, "w") as testfile:
            for row in self.solution.saved_solutions:
                i += 1
                testfile.write(str(i) + "\n")
                testfile.write(",".join([str(a) for a in row]) + "\n" + "\n")

        for sbu in self.sbu_list:
            try:
                df = pd.read_csv(
                    self.folder_path
                    + "/results_"
                    + str(sbu)
                    + "_"
                    + str(self.seed)
                    + ".csv"
                )
                print(
                    sbu,
                    ":",
                    len(list(df["Solution_number"].unique())),
                    "final solutions dumped to csv!",
                )
            except:
                print(
                    "no solution found for sbu",
                    sbu,
                    "as no solution found with all positive coefficients",
                )


    def get_spend_summary(self):
        ### Overall category level ###
        (
            self.min_spend,
            self.max_spend,
            self.mean_spend,
            self.median_spend,
            self.spend_share,
            self.spend_vars,
        ) = ([], [], [], [], [], [])

        for media_var in self.media_variables:
            if "_IMP" in media_var:
                spend_var = media_var.replace("_IMP", "_SPEND")
            else:
                spend_var = media_var.replace("_CLK", "_SPEND")
            self.spend_vars.append(spend_var)

        total_spend = self.data[self.spend_vars].sum().sum()

        for spend_var in self.spend_vars:
            self.min_spend.append(self.data[spend_var].min())
            self.max_spend.append(self.data[spend_var].max())
            self.mean_spend.append(self.data[spend_var].mean())
            self.median_spend.append(self.data[spend_var].median())
            self.spend_share.append(
                round(self.data[spend_var].sum() / total_spend * 100, 2)
            )

    def display_summary_1(self, seed, target_threshold, target_saturation):
        self.get_spend_summary()
        self.no_sol_sbu = []
        self.overall_iroas, self.tactic_iroas, self.tactic_coeff = {}, {}, {}
        for sbu in self.sbu_list:
            try:
                df = pd.read_csv(
                    self.folder_path
                    + "/results_"
                    + str(sbu)
                    + "_"
                    + str(seed)
                    + ".csv"
                )
                print(f"Summary for sbu {sbu}:")
                display(df.describe())
                df["delta_iroas"] = abs(
                    df["Tactic_iRoAS"]
                    - np.tile(self.media_iroas_prior, int(len(df["Tactic_iRoAS"]) / self.num_media_vars))
                )# Janhavi : premium changes
                df["delta_coef"] = abs(
                    df["Coefficient"]
                    - np.tile(self.coef_mean_prior, int(len(df["Coefficient"]) / self.num_media_vars))
                )# Janhavi : premium changes
                mean_vals = (
                    df[["delta_iroas", "delta_coef", "Solution_number"]]
                    .groupby("Solution_number")
                    .mean()
                    .to_dict()
                )
                sol_num_closest_iroas_to_mean = min(
                    mean_vals["delta_iroas"], key=mean_vals["delta_iroas"].get
                )
                try:
                    iroas_min_vals = sorted(
                        mean_vals["delta_iroas"], key=mean_vals["delta_iroas"].get
                    )[:5]
                    coef_min_vals = sorted(
                        mean_vals["delta_coef"], key=mean_vals["delta_coef"].get
                    )[:5]

                    common_sols = list(
                        set(iroas_min_vals).intersection(set(coef_min_vals))
                    )
                    if len(common_sols) > 0:
                        sol_num = (
                            df[df["Solution_number"].isin(common_sols) == True][
                                df["DE_objective_value"]
                                == df["DE_objective_value"].min()
                            ]["Solution_number"]
                            .unique()
                            .max()
                        )
                    else:
                        sol_num = iroas_min_vals[0]
                except:
                    sol_num = sol_num_closest_iroas_to_mean

                print("SBU:", sbu, ": Solution_number:", sol_num)
                Inflection = df[df["Solution_number"] == sol_num][
                    "Media_transformation (hf, inf, sc, lg)"
                ][:self.num_media_vars]
                Thresh_sat = df[df["Solution_number"] == sol_num][
                    "Threshold_Saturation"
                ][:self.num_media_vars]
                self.tactic_iroas[sbu] = df[df["Solution_number"] == sol_num][
                    "Tactic_iRoAS"
                ][:self.num_media_vars]
                self.overall_iroas[sbu] = df[df["Solution_number"] == sol_num][
                    "Overall_iroas"
                ][:self.num_media_vars]
                self.tactic_coeff[sbu] = df[df["Solution_number"] == sol_num][
                    "Coefficient"
                ][:self.num_media_vars]

                self.thresh_arr, self.inf_arr, self.sat_arr = [], [], []
                for var in range(len(self.media_variables)):
                    self.thresh_arr.append(ast.literal_eval(Thresh_sat.values[var])[0])
                    self.inf_arr.append(ast.literal_eval(Inflection.values[var])[1])
                    self.sat_arr.append(ast.literal_eval(Thresh_sat.values[var])[1])
                result_dict = {
                    "media_tactic": self.media_variables,
                    "target_threshold": target_threshold,
                    "target_saturation": target_saturation,
                    "Threshold": self.thresh_arr,
                    "Inflection": self.inf_arr,
                    "Saturation": self.sat_arr,
                    "Min_spend": self.min_spend,
                    "Max_spend": self.max_spend,
                    "Median_spend": self.median_spend,
                    "Mean_spend": self.mean_spend,
                    "Spend_share": self.spend_share,
                }
                table_1 = pd.DataFrame.from_dict(result_dict)
                display(table_1)
            except:
                self.no_sol_sbu.append(sbu)
                print("\n skipping sbu", sbu, "\n")

    def display_summary_2(self):
        ### brand level ###
        table_2 = pd.DataFrame()
        for sbu in self.sbu_list:
            try:
                (
                    b_min_spend,
                    b_max_spend,
                    b_mean_spend,
                    b_median_spend,
                    b_spend_share,
                    b_on_air,
                ) = ([], [], [], [], [], [])
                b_below_thresh, b_above_sat = [], []
                b_data = self.data[self.data["SBU"] == sbu].copy()
                b_total_spend = b_data[self.spend_vars].sum().sum()

                for var in range(len(self.spend_vars)):
                    if "SEARCH" in self.spend_vars[var] or "M_SP" in self.spend_vars[var] or "M_SBA" in self.spend_vars[var]:# Janhavi : premium changes
                        tactic = self.spend_vars[var].replace("_SPEND", "_CLK")
                    else:
                        tactic = self.spend_vars[var].replace("_SPEND", "_IMP")
                    b_min_spend.append(b_data[self.spend_vars[var]].min())
                    b_max_spend.append(b_data[self.spend_vars[var]].max())
                    b_mean_spend.append(b_data[self.spend_vars[var]].mean())
                    b_median_spend.append(b_data[self.spend_vars[var]].median())
                    b_spend_share.append(
                        round(
                            b_data[self.spend_vars[var]].sum() / b_total_spend * 100, 2
                        )
                    )
                    b_on_air.append(
                        round(
                            len(b_data[b_data[self.spend_vars[var]] > 0])
                            / len(b_data)
                            * 100,
                            2,
                        )
                    )

                    b_on_air_df = b_data[b_data[tactic] > 0].copy()
                    if sbu not in self.no_sol_sbu:
                        b_below_thresh.append(
                            round(
                                len(
                                    b_on_air_df[
                                        b_on_air_df[tactic] < self.thresh_arr[var]
                                    ]
                                )
                                / len(b_on_air_df)
                                * 100,
                                2,
                            )
                        )
                        b_above_sat.append(
                            round(
                                len(
                                    b_on_air_df[b_on_air_df[tactic] > self.sat_arr[var]]
                                )
                                / len(b_on_air_df)
                                * 100,
                                2,
                            )
                        )
                    else:
                        b_below_thresh.append(math.nan)
                        b_above_sat.append(math.nan)

                result_dict = {
                    "sbu": [sbu] * self.num_media_vars, # Janhavi : premium changes
                    "media_tactic": self.spend_vars,
                    "Min_spend": b_min_spend,
                    "Max_spend": b_max_spend,
                    "Median_spend": b_median_spend,
                    "Mean_spend": b_mean_spend,
                    "Spend_share": b_spend_share,
                    "Tactic_iroas": self.tactic_iroas[sbu],
                    "Overall_iroas": self.overall_iroas[sbu],
                    "Tactic_iroas_prior": list(self.media_iroas_prior),
                    "Tactic_coefficient": self.tactic_coeff[sbu],
                    "Coeff_mean_prior": list(self.coef_mean_prior),
                    "On air days": b_on_air,
                    "%days below threshold": b_below_thresh,
                    "%days above saturation": b_above_sat,
                }

                table_temp = pd.DataFrame.from_dict(result_dict)
                table_2 = table_2.append(table_temp)
            except:
                print("\n skipping sbu", sbu, "\n")
        display(table_2)




    def gompertz_logistic_saturation_pts(self, df, Media_var, inflection, scale):
        Point = pd.DataFrame({'Media':[Media_var]})  
        # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
        Point['Saturation Point using Logistic'] = (4.59511985013/(scale) + inflection) * df.mean()
        saturation = Point[['Saturation Point using Logistic']].min(axis= 1)            
        return saturation.values[0]

    def gompertz_logistic_threshold_pts(self, df,Media_var, inflection,scale):
        Point = pd.DataFrame({'Media':[Media_var]})  
        # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
        if scale*inflection < 4.59511985013:
            Point['Threshold Point using Logistic'] = 0
        else:
            Point['Threshold Point using Logistic'] = (-4.59511985013/(scale) + inflection) * df.mean()
        threshold = Point[['Threshold Point using Logistic']].max(axis = 1)        
        return threshold.values[0]