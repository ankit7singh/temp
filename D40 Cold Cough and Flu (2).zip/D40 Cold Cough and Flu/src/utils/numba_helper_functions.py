#!/usr/bin/env python
# coding: utf-8
# author: Mayukh Maitra

from numba import njit
from numba import njit,numba, literally, jit, objmode
from numba.typed import List
import numpy as np
import math

@njit(cache=True)
def recursive_filter(x, ar_coeff):
    n = len(x)
    y = np.zeros(n)
    y[0] = x[0]
    for i in range(1,n):
        y[i] = ar_coeff * y[i-1] + x[i]
    return y

@njit(cache=True)           
def lag_transformation(var, lag):
    lag_variable = np.append(np.zeros(int(lag)), var[:-lag])
    return lag_variable

@njit(cache=True)
def halflife_transformation(var, halflife):
    retention = np.exp(math.log(0.5)/halflife)        
    transformed_var = var * (1 - retention)
    transformed_var[np.isnan(transformed_var)] = 0
    transformed_var = recursive_filter(transformed_var, retention)
    return transformed_var

@njit(cache=True)
def variance_calculation(arr):
    var = np.mean(np.abs(arr - np.mean(arr))**2)
    return var

@njit(cache=True)   
def matrixmult(A, B):
    rows_A = A.shape[0]
    cols_A = A.shape[1]
    rows_B = B.shape[0]
    cols_B = B.shape[1]
    C = [[0 for row in range(cols_B)] for col in range(rows_A)]
    for i in range(rows_A):
        for j in range(cols_B):
            for k in range(cols_A):
                C[i][j] += A[i][k] * B[k][j]
    return np.array(C)

@njit(cache = True)
def multiply_np(m1, m2):
    arr = []
    for row in m1:
        total = 0
        for i in range(len(row)):
            total += row[i] * m2[i]
        arr.append(total)
    return arr

@njit(cache = True)
def find_subarray_with_element(array,element):
    subarrays = []
    for i in range(array.shape[0]):
        for j in range(array.shape[1]):
            if array[i,j] == element:
                subarrays.append(array[i])
                break
    return (subarrays)

@njit(cache = False)
def get_scurve_params(transformed_var, on_air_df, scale, inflection):
    
    on_air_df = on_air_df[~np.isnan(on_air_df)]
    
    saturation_point = (4.59511985013/(scale) + inflection) * transformed_var.mean()

    # threshold point
    if scale*inflection < 4.59511985013:
        threshold_point = 0
    else:
        threshold_point = (-4.59511985013/(scale) + inflection) * transformed_var.mean()
            
    # on_air_days = on_air_df.shape[0]
    below_threshold_days = np.nanmean(on_air_df <= threshold_point)
    beyond_saturation_days = np.nanmean(on_air_df > saturation_point)
    
    s_curve_params = np.zeros(2)
    s_curve_params[0] = below_threshold_days
    s_curve_params[1] = beyond_saturation_days
    
    return s_curve_params
