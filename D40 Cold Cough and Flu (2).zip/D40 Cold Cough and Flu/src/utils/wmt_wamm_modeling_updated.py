#!/usr/bin/env python
# coding: utf-8
# author: Mayukh Maitra

import ast
import math
import os
import pickle
import sys
from datetime import datetime
import itertools

import _differentialevolution_ols as differential_evolution
import numba
import numpy as np
import pandas as pd
from IPython.display import display
from numba import jit, literally, njit, numba, objmode
from numba.typed import List
from numba_helper_functions import *
from numpy.linalg import inv, pinv
from scipy.optimize import minimize
import multiprocessing as mp
from lite_non_media_utils_v3 import residual_calculation

module_path = os.path.abspath(os.path.join("../src/utils"))
if module_path not in sys.path:
    sys.path.append(module_path)

if os.path.abspath("../src/config_dir") not in sys.path:
    sys.path.append(os.path.abspath("../src/config_dir"))

if module_path not in sys.path:
    sys.path.append(module_path)

import warnings

warnings.filterwarnings("ignore")

date_format = "%Y-%m-%d"


def create_folder_with_version(directory_path):
    version = 1
    while os.path.exists(f"{directory_path}_v{version}_WMT_DE"):
        version += 1
    new_directory_path = f"{directory_path}_v{version}_WMT_DE"
    os.makedirs(new_directory_path)
    print(f"Create output folder : {new_directory_path}")
    return new_directory_path


class WAMM_Lite:
    def __init__(
        self,
        updated_stack,
        outcome,
        pre_processed_matrix_U_kj,
        pre_processed_matrix_Y_kj,
        coef_mean_prior,
        coef_var_prior,
        threshold_bounds,
        saturation_bounds,
        media_variables_all, # Category WAMM Change 
        national_media_variables,
        sbu_list,
        train_start,
        train_end,
        valid_start,
        valid_end,
        media_iroas_prior,
        folder_path,
        iroas_lb = None,# default to handle Lite
        iroas_ub = None,# default to handle lite
        use_iroas_penalty = False,
        iroas_penalty_multiplier = 1.0,
        is_premium=False,# premium changes
        lambda_denominator = 3, # value will be discarded if use_ridge==False
        use_sign_penalty = False, # if true, use_ridge is set to False
        apply_scaling = False,
        train_spend = [],# default to handle lite
        train_price = None, # default to handle lite
        l12_spend = None,
        iroas_dev_in_loss=False,
        YoY_comparison = None,
        common_s_curve = True,
        handle_added_value = False,
        fix_iterations=False,
        use_ridge=True,
        lambda_k=1.0,
        base_num = 0,
        non_media_variables=None,
        national_media_vars_lg_hf = None,
        wmc_media_var = [],
        solutions_filter = [],
        wmc_solution_arr = [],
        use_thresh_sat = False,
        term_2_weight = 1,
        term_2_1_weight = 1, 
        term_4_weight = 1,
        max_iterations = 500

) -> None:
        self.updated_stack = updated_stack
        self.outcome = outcome
        self.threshold_bounds = threshold_bounds
        self.saturation_bounds = saturation_bounds
        self.media_variables = media_variables_all  # category wamm change
        self.national_media_variables = national_media_variables
        self.num_media_vars = len(media_variables_all) # category wamm change
        self.sbu_list = sbu_list
        self.train_start = train_start
        self.train_end = train_end
        self.valid_start = valid_start
        self.valid_end = valid_end
        self.num_sbu = len(sbu_list)
        self.st_dt = datetime.strptime(train_start, date_format)
        self.train_end_dt = datetime.strptime(train_end, date_format)
        self.test_st_dt = datetime.strptime(valid_start, date_format)
        self.test_end_dt = datetime.strptime(valid_end, date_format)
        self.data = self.updated_stack.copy()
        self.train_end_index = (self.train_end_dt - self.st_dt).days + 1
        self.valid_start_index = (self.test_st_dt - self.st_dt).days
        self.valid_end_index = (self.test_end_dt - self.st_dt).days + 1
        self.pre_processed_matrix_U_kj = pre_processed_matrix_U_kj
        self.pre_processed_matrix_Y_kj = pre_processed_matrix_Y_kj
        self.num_non_media_vars = self.pre_processed_matrix_U_kj.shape[1]
        self.coef_mean_prior = coef_mean_prior
        self.coef_var_prior = coef_var_prior
        self.media_iroas_prior = media_iroas_prior
        self.folder_path = folder_path
        self.solution_arr = []
        self.lambda_k_arr = []
        self.prior_loss_arr = []
        self.scaled_prior = []
        self.scaling_factor = []
        # self.brand_non_media_coef = brand_non_media_coef
        self.split_interval = 365 # category wamm change
        self.solution_beta_arr = []
        self.solution_contri_arr = []
        self.solution_iroas_arr = []
        self.solution_l12_iroas_arr = []
        self.solution_iroas_penalty_arr = []
        self.iteration_logs = []
        self.fix_iterations = fix_iterations
        self.use_ridge = use_ridge
        self.is_premium = is_premium
        self.lambda_denominator = lambda_denominator # value will be discarded if use_ridge==False
        self.use_sign_penalty = use_sign_penalty
        self.iroas_lb = iroas_lb
        self.iroas_ub = iroas_ub
        self.train_spend = train_spend
        self.train_price = train_price
        self.l12_spend = l12_spend
        self.use_iroas_penalty = use_iroas_penalty
        self.iroas_penalty_multiplier = iroas_penalty_multiplier
        self.apply_scaling = apply_scaling
        self.iroas_dev_in_loss = iroas_dev_in_loss
        self.YoY_comparison = YoY_comparison
        self.common_s_curve = common_s_curve
        self.handle_added_value = handle_added_value
        self.base_num = base_num
        self.non_media_variables = non_media_variables
        self.num_wmc_media_var = len(wmc_media_var)
        self.wmc_media_var = wmc_media_var
        self.solutions_filter = solutions_filter
        self.wmc_solution_arr = wmc_solution_arr
        self.on_air_df = {}
        self.df_onair_list = []
        self.use_thresh_sat = use_thresh_sat

        for var in self.media_variables:
            df_var = self.data[[var]].copy()
            df_var.columns = ['Raw Variable']
            on_air_df = df_var[df_var['Raw Variable'] > 0]
            self.on_air_df[var] = on_air_df

        for i in range(len(self.media_variables)):
            self.df_onair_list.append(self.on_air_df[self.media_variables[i]])
        df_media_onair = pd.concat(self.df_onair_list, axis=1)
        df_media_onair = df_media_onair.to_numpy() 
        self.df_media_onair = df_media_onair.astype('float64')
        self.term_2_weight = term_2_weight
        self.term_2_1_weight = term_2_1_weight
        self.term_4_weight = term_4_weight
        self.max_iterations = max_iterations        

    def create_yoy_indices(self):
        print("Generating YoY indices")
        # l12_st = self.train_end_index - 365                               # NEW 4.10 -
        # p12_st = l12_st - 365                                             # NEW 4.10 -


        # NEW 4.10 + >>>
        from dateutil.relativedelta import relativedelta

        # Calculate dates for YoY comparison accounting for leap years
        train_end_minus_1yr = (self.train_end_dt + relativedelta(days=1)) - relativedelta(years=1)
        train_end_minus_2yr = (self.train_end_dt + relativedelta(days=1)) - relativedelta(years=2)

        # Convert dates to indices
        l12_st = (train_end_minus_1yr - self.st_dt).days
        p12_st = (train_end_minus_2yr - self.st_dt).days

        # NEW 4.10 + <<<

        if p12_st < 0:
            p12_st = 0
            p12_end = l12_st - 1
        else:
            # p12_end = p12_st + 365            # NEW 4.10 -
            p12_end = l12_st - 1                # NEW 4.10 +

        yoy_arr = [p12_st, p12_end, l12_st, self.train_end_index]

        # for k, v in self.YoY_comparison.items():
        #     yoy_arr = []

        #     for st, end in eval(v):

        #         yoy_arr.append((dt.strptime(st, date_format) - self.st_dt).days)
        #         yoy_arr.append(
        #             (dt.strptime(end, date_format) - self.st_dt).days + 1
        #         )
        # yoy_arr = list(self.YoY_comparison)
        # if (yoy_arr[1] - yoy_arr[0]) > (yoy_arr[3] - yoy_arr[2]):
        #     yoy_arr[1] = yoy_arr[0] + (yoy_arr[3] - yoy_arr[2])
        # elif (yoy_arr[1] - yoy_arr[0]) < (yoy_arr[3] - yoy_arr[2]):
        #     yoy_arr[3] = yoy_arr[2] + (yoy_arr[1] - yoy_arr[0])

        self.yoy_idx = np.asarray(yoy_arr)
        # print(self.yoy_idx)--Commented m0p01io

        print("Generating YoY spends")
        self.tactic_level_spends_y1 = []
        self.tactic_level_spends_y2 = []
        for spend_var in self.spend_variables:
            self.tactic_level_spends_y1.append(
                self.data[
                    (self.data.index >= self.yoy_idx[0])
                    & (self.data.index <= self.yoy_idx[1])                  # NEW 4.10 +
                    # & (self.data.index < self.yoy_idx[1])                 # NEW 4.10 -
                    ][spend_var].sum()
            )

            self.tactic_level_spends_y2.append(
                self.data[
                    (self.data.index >= self.yoy_idx[2])
                    & (self.data.index < self.yoy_idx[3])
                    ][spend_var].sum()
            )

        self.tactic_level_spends_y1 = np.asarray(self.tactic_level_spends_y1)
        self.tactic_level_spends_y2 = np.asarray(self.tactic_level_spends_y2)

        yoy_1_spends = (
            self.data[
                (self.data.index >= self.yoy_idx[0])
                & (self.data.index <= self.yoy_idx[1])                            # NEW 4.10 +
                # & (self.data.index < self.yoy_idx[1])                           # NEW 4.10 -
                ][self.spend_variables]
            .copy()
            .sum()
            .values
        )
        yoy_2_spends = (
            self.data[
                (self.data.index >= self.yoy_idx[2])
                & (self.data.index < self.yoy_idx[3])                   
                ][self.spend_variables]
            .copy()
            .sum()
            .values
        )
        self.yoy_1_spends = yoy_1_spends[self.wmc_idx].sum()
        self.yoy_2_spends = yoy_2_spends[self.wmc_idx].sum()
        print("YoY Period 1 Spends")
        # print(f"YoY Period 1 Spends : {self.yoy_1_spends}")--Commented m0p01io
        # print(f"YoY Period 2 Spends : {self.yoy_2_spends}")--Commented m0p01io

    def filter_wmc_media(self):

        wmc_variables = []
        non_wmc_variables = []
        cpd_var = []
        for i, var in enumerate(self.media_variables):
            if (
                var.startswith("M_ON_DIS")
                or var.startswith("M_OFF_DIS")
                or var.startswith("M_SP_")
                or var.startswith("M_SBA")  ## was missing
                or var.startswith("M_SV_")
                or var.startswith("M_INSTORE_")
            ):
                wmc_variables.append(i)
            else:
                non_wmc_variables.append(i)
            if ("CATTO" in var) or ("HPLO" in var) or ("HPGTO" in var):
                cpd_var.append(1)
            else:
                cpd_var.append(0)

        print(f"All Media variables : {self.media_variables}")
        print(f"WMC indices: {wmc_variables}")
        print(
            f"non-WMC indices: {non_wmc_variables}"
        )  ## was showing wmc variables itself
        self.wmc_idx = np.array(wmc_variables)
        self.cpd_var = np.array(cpd_var)
        self.wmt_media_idx = np.array(non_wmc_variables)

    def create_ga_bounds(self):
        self.ga_bounds_media = {}
        #self.wmt_media_idx = []
        for media_idx,var in enumerate(self.media_variables):

            if "WMT" in var:
                if "_IMP" in var:
                    halflife_bounds_var = [0, 5]
                    lag_bounds_var = [0, 8]
                    if not self.use_thresh_sat:
                        inflection_bounds = [0, 5]
                        scale_bounds = [0, 5]
                    lambda_bounds = [0, 1]
                elif "_CLK" in var:
                    halflife_bounds_var = [0, 5]
                    lag_bounds_var = [0, 5]
                    if not self.use_thresh_sat:
                        inflection_bounds = [0, 5]
                        scale_bounds = [0, 5]
                    lambda_bounds = [0, 1]
                else:
                    # TODO : error out if the media variable name is invalid
                    print(f"Invalid media variable name : {var}")
                
                #self.wmt_media_idx.append(media_idx)
            else:
                lambda_bounds = [0, 1]
            
            if not self.use_thresh_sat:

                if "WMT" in var:
                    self.ga_bounds_media[var] = {
                        "halflife_bounds": halflife_bounds_var,
                        "inflection_bounds": inflection_bounds,
                        "scale_bounds": scale_bounds,
                        "lag_bounds": lag_bounds_var,
                        "lambda_bounds": lambda_bounds
                    }
                    

                else:
                     self.ga_bounds_media[var] = {"lambda_bounds":lambda_bounds
                }  
                     
            else:

                if "WMT" in var:
                    self.ga_bounds_media[var] = {
                    "halflife_bounds": halflife_bounds_var,
                    "threshold_bounds": list(self.threshold_bounds[media_idx]),
                    "saturation_bounds": list(self.saturation_bounds[media_idx]),
                    "lag_bounds": lag_bounds_var,
                    "lambda_bounds":lambda_bounds
                }
                    
                
                else:
                     self.ga_bounds_media[var] = {"lambda_bounds":lambda_bounds
                }                                  

    def get_spend_variables(self):
        self.spend_variables = []
        for i in range(len(self.media_variables)):
            if "_IMP" in self.media_variables[i]:
                spend_var = self.media_variables[i].replace("_IMP", "_SPEND")
            else:
                spend_var = self.media_variables[i].replace("_CLK", "_SPEND")
            self.spend_variables.append(spend_var)

    def get_initial_solution(self):
        # halflife, threshold, saturation, lag
        self.init_sol_raw_list = []
        i = 0
        np.random.seed(42)
        for var in self.media_variables:
            if "WMT" in var:
                self.init_sol_raw_list.append(
                    np.random.uniform(
                        self.ga_bounds_media[var]["halflife_bounds"][0],
                        self.ga_bounds_media[var]["halflife_bounds"][1],
                    )
                )  # halflife
                if not self.use_thresh_sat:

                    self.init_sol_raw_list.append(
                        np.random.uniform(
                            self.ga_bounds_media[var]["inflection_bounds"][0],
                            self.ga_bounds_media[var]["inflection_bounds"][1],
                        )
                    )  # inflection
                    self.init_sol_raw_list.append(
                        np.random.uniform(
                            self.ga_bounds_media[var]["scale_bounds"][0],
                            self.ga_bounds_media[var]["scale_bounds"][1],
                        )
                    )  #  scale

                else:

                    self.init_sol_raw_list.append(
                        np.random.uniform(
                            self.ga_bounds_media[var]["threshold_bounds"][0],
                            self.ga_bounds_media[var]["threshold_bounds"][1],
                        )
                    )  # threshold
                    self.init_sol_raw_list.append(
                        np.random.uniform(
                            self.ga_bounds_media[var]["saturation_bounds"][0],
                            self.ga_bounds_media[var]["saturation_bounds"][1],
                        )
                    )  #  saturation
                self.init_sol_raw_list.append(
                    np.random.randint(
                        self.ga_bounds_media[var]["lag_bounds"][0],
                        self.ga_bounds_media[var]["lag_bounds"][1],
                    )
                )  # lag
            self.init_sol_raw_list.append(
                np.random.uniform(
                    self.ga_bounds_media[var]["lambda_bounds"][0],
                    self.ga_bounds_media[var]["lambda_bounds"][1],
                )
            )  # lambda

            i += 1

        self.initial_solution = np.asarray(self.init_sol_raw_list).astype(float)

    def data_prep(self):

        self.create_ga_bounds()
        self.get_spend_variables()
        self.get_initial_solution()

        # generate WMC & non-WMC media list. non-WMC includes M_NAT* and M_WMT* media variables
        self.filter_wmc_media()
        self.create_yoy_indices()

        ## USE numba ######################################################################
        #### pandas to numpy media
        self.df_data_by_sbu = []
        self.outcome_by_sbu = []
        self.start_idx = 0
        self.end_idx = len(self.data) / len(self.sbu_list)
        for i in range(len(self.sbu_list)):
            temp_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.media_variables].copy()
            outcome_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.outcome].copy()
            temp_data = temp_data.to_numpy().astype("float64")
            outcome_data = outcome_data.to_numpy().astype("float64")
            self.df_data_by_sbu.append(temp_data)
            self.outcome_by_sbu.append(outcome_data)
            self.start_idx = self.end_idx * (i + 1)
        self.df_data_by_sbu = np.asarray(self.df_data_by_sbu)
        self.outcome_by_sbu = np.asarray(self.outcome_by_sbu)

        self.transformed_var_actual = self.df_data_by_sbu.copy()
        self.outcome_by_sbu_actual = self.outcome_by_sbu.copy()
        ######################################################################

        #### pandas to numpy media train data
        self.df_train_data = []
        for sbu_data in self.df_data_by_sbu:
            self.df_train_data.append(sbu_data[: self.train_end_index])
        self.df_train_data = np.asarray(self.df_train_data)
        ######################################################################

        #### pandas to numpy spend
        self.df_media_spend_by_sbu = []
        self.start_idx = 0
        self.end_idx = len(self.data) / len(self.sbu_list)
        for i in range(len(self.sbu_list)):
            temp_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.spend_variables].copy()
            temp_data = temp_data.to_numpy().astype("float64")
            self.df_media_spend_by_sbu.append(temp_data)
            self.start_idx = self.end_idx * (i + 1)
        self.df_media_spend_by_sbu = np.asarray(self.df_media_spend_by_sbu)
        self.transformed_spend_var_actual = (self.df_media_spend_by_sbu > 0).astype(int)
        ######################################################################

        #### pandas to numpy outcome
        self.df_outcome_by_sbu = []
        self.start_idx = 0
        self.end_idx = len(self.data) / len(self.sbu_list)
        for i in range(len(self.sbu_list)):
            temp_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.outcome].copy()
            temp_data = temp_data.to_numpy().astype("float64")
            self.df_outcome_by_sbu.append(temp_data)
            self.start_idx = self.end_idx * (i + 1)
        self.df_outcome_by_sbu = np.asarray(self.df_outcome_by_sbu)
        ######################################################################

    def get_bnds_dict(self):
        self.bnds_dict = {}
        print(self.national_media_variables)
        for i in self.media_variables:
            if "WMT" in i:
                if not self.use_thresh_sat:
                    self.bnds_dict[i] = [
                        tuple(self.ga_bounds_media[i]["halflife_bounds"]),
                        tuple(self.ga_bounds_media[i]["inflection_bounds"]),
                        tuple(self.ga_bounds_media[i]["scale_bounds"]),
                        tuple(self.ga_bounds_media[i]["lag_bounds"]),
                        tuple(self.ga_bounds_media[i]["lambda_bounds"])
                    ]
                else:
                    self.bnds_dict[i] = [
                        tuple(self.ga_bounds_media[i]["halflife_bounds"]),
                        tuple(self.ga_bounds_media[i]["threshold_bounds"]),
                        tuple(self.ga_bounds_media[i]["saturation_bounds"]),
                        tuple(self.ga_bounds_media[i]["lag_bounds"]),
                        tuple(self.ga_bounds_media[i]["lambda_bounds"]),
                    ]
            else:
                self.bnds_dict[i] = [tuple(self.ga_bounds_media[i]["lambda_bounds"]),
                    ]
        print(self.ga_bounds_media)
        self.bnds = []
        for k in self.bnds_dict:
            self.bnds += self.bnds_dict[k]

    def run_DE(
        self,
        seed,
        num_sbu,
        num_media_vars,
        train_end_index,
        valid_start_index,
        valid_end_index, 
        transformed_var_actual,
        transformed_spend_var_actual,
        pre_processed_matrix_U_kj,
        pre_processed_matrix_Y_kj,
        num_non_media_vars,
        coef_mean_prior,
        outcome_by_sbu,
        bnds,
        initial_solution,
        global_opt=True,
        solution_save=False,
        media_roas_prior=None,
        use_ridge = True,
        is_premium = False,
        lambda_denominator = 1,
        use_sign_penalty = False,
        use_iroas_penalty = False,
        iroas_penalty_multiplier = 1.0,
        iroas_lb = None,
        iroas_ub = None,
        train_spend = None,
        train_price = None,
        l12_spend = None,
        handle_added_value = False,
        media_variables=[],
        data=None,
        national_media_variables = [],
        wmc_solution_arr = [],
        on_air_days = None,
        use_thresh_sat = False,
        wmc_idx=None,
        wmt_media_idx = None,
        cpd_var = None,
        yoy_idx= None,
        yoy_1_spend= None,
        yoy_2_spend= None,
        yoy_1_tactic_spend= None,
        yoy_2_tactic_spend= None,
        term_2_weight = 1,
        term_2_1_weight = 1,
        term_4_weight = 1

    ):
        self.obj_loss = 10e100        
        def save_intermediate_solution(
            sbu_idx,
            hf_arr,
            thr_arr,
            sat_arr,
            lag_arr,
            lambda_k_arr,
            lambda_k,
            scl,
            infl,
            total_loss,
            debug_flag,
            beta_j,
            beta_unscaled,
            Tactic_iRoAS,
            Overall_iRoAS,
            iroas_dev_from_prior,
            train_mape,
            valid_mape,
            r_sq_train,
            r_sq_valid,
            media_contrib_1,
            media_spend_1,
            media_contrib_2,
            media_spend_2,
            media_iroas_1,
            media_iroas_2,
            overall_contrib_1,
            overall_contrib_2,
            overall_iroas_1,
            overall_iroas_2,
            monotonic_inc_contrib_tactic_bool,
            monotonic_inc_contrib_overall_bool,
        ):

            iterim_sol_arr = [
                hf_arr.copy(),
                thr_arr.copy(),
                sat_arr.copy(),
                lag_arr.copy(),
                lambda_k_arr.copy(),
                lambda_k.copy(),
                scl.copy(),
                infl.copy(),
                beta_j.copy(),  # np array size=len(media_variables)
                beta_unscaled.copy(),  # np array size=len(media_variables)
                Tactic_iRoAS.copy(),  # np array size=len(media_variables)
                np.array(
                    [Overall_iRoAS] * len(Tactic_iRoAS)
                ),  # np array size=len(media_variables)
                iroas_dev_from_prior.copy(),  # np array size=len(media_variables)
                np.array([train_mape] * len(Tactic_iRoAS)),
                np.array([valid_mape] * len(Tactic_iRoAS)),
                np.array([r_sq_train] * len(Tactic_iRoAS)),
                np.array([r_sq_valid] * len(Tactic_iRoAS)),
                np.asarray(media_contrib_1),
                np.asarray(media_spend_1),
                np.asarray(media_contrib_2),
                np.asarray(media_spend_2),
                np.asarray(media_iroas_1),
                np.asarray(media_iroas_2),
                np.array([overall_contrib_1] * len(Tactic_iRoAS)),
                np.array([overall_contrib_2] * len(Tactic_iRoAS)),
                np.array([overall_iroas_1] * len(Tactic_iRoAS)),
                np.array([overall_iroas_2] * len(Tactic_iRoAS)),
                np.array(monotonic_inc_contrib_tactic_bool),
                np.array(monotonic_inc_contrib_overall_bool * len(Tactic_iRoAS)),
                np.array([total_loss] * len(Tactic_iRoAS)),
            ]

            with open(
                os.path.join(
                    self.folder_path,
                    f"interim_sol_{self.sbu_list[sbu_idx]}_{debug_flag}.pkl",
                ),
                "ab",
            ) as f:
                pickle.dump(iterim_sol_arr, f)

        @njit(cache = True)
        def get_scurve_params(transformed_var, on_air_df, scale, inflection):
            
            on_air_df = on_air_df[~np.isnan(on_air_df)]
            
            saturation_point = (4.59511985013/(scale) + inflection) * transformed_var.mean()

            # threshold point
            if scale*inflection < 4.59511985013:
                threshold_point = 0
            else:
                threshold_point = (-4.59511985013/(scale) + inflection) * transformed_var.mean()
                    
            # on_air_days = on_air_df.shape[0]
            below_threshold_days = np.nanmean(on_air_df <= threshold_point)
            beyond_saturation_days = np.nanmean(on_air_df > saturation_point)
            
            s_curve_params = np.zeros(2)
            s_curve_params[0] = below_threshold_days
            s_curve_params[1] = beyond_saturation_days
            
            return s_curve_params
        
        def gompertz_logistic_saturation_pts(df, Media_var, inflection, scale):
            Point = pd.DataFrame({'Media':[Media_var]})  
            # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
            Point['Saturation Point using Logistic'] = (4.59511985013/(scale) + inflection) * df.mean()
            saturation = Point[['Saturation Point using Logistic']].min(axis= 1)            
            return saturation.values[0]

        def gompertz_logistic_threshold_pts(df,Media_var, inflection,scale):
            Point = pd.DataFrame({'Media':[Media_var]})  
            # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
            if scale*inflection < 4.59511985013:
                Point['Threshold Point using Logistic'] = 0
            else:
                Point['Threshold Point using Logistic'] = (-4.59511985013/(scale) + inflection) * df.mean()
            threshold = Point[['Threshold Point using Logistic']].max(axis = 1)        
            return threshold.values[0]


        def save_iteration_log(sbu_idx, log_details, SST, term_1, term_2, term_2_1, term_3, term_4, scurve_penalty,min_loss):

                iteration_log_arr = [list(self.solution_arr), 
                                     [sbu_idx,log_details,SST,term_1,term_2,term_2_1,term_3,term_4,scurve_penalty,min_loss],
                                     list(self.solution_beta_arr),
                                     list(self.solution_contri_arr),
                                     list(self.solution_iroas_arr),
                                     list(self.solution_iroas_penalty_arr),
                                     list(self.lambda_k_arr),
                                     list(self.prior_loss_arr),
                                     list(self.scaled_prior),
                                     list(self.scaling_factor),]                
                self.iteration_logs.append(iteration_log_arr.copy())


        @njit(cache=True)
        def optimization_fn_numba(x, debug_flag=0, log_details=0):

            total_loss, log_solution_total, beta_delta = 0, 0, 0
            sbu_losses = np.zeros(num_sbu)
            hf_arr = np.zeros(num_media_vars)
            thr_arr = np.zeros(num_media_vars)
            sat_arr = np.zeros(num_media_vars)
            lag_arr = np.zeros(num_media_vars)
            lambda_k_arr = np.zeros(num_media_vars)
            sc = np.zeros(num_media_vars)
            inf = np.zeros(num_media_vars)
            Beta_j = np.zeros(num_media_vars)
            Tactic_iRoAS = np.zeros(num_media_vars)
            Overall_iRoAS = 0.0  # np.zeros(num_media_vars)
            iroas_dev_from_prior = np.zeros(num_media_vars)
            media_length = len(transformed_var_actual[0])
            train_mape = 0.0
            valid_mape = 0.0
            r_sq_train = 0.0
            r_sq_valid = 0.0
            Beta_unscaled = np.zeros((num_non_media_vars, num_media_vars))
            scaling_factor_arr = np.zeros(num_media_vars)

            with objmode():
                self.solution_arr = x.copy()
            for sbu_idx in range(num_sbu):
                transformed_media = np.zeros((num_media_vars, train_end_index))
                transformed_media_total = np.zeros((num_media_vars, media_length))
                lambda_k = np.zeros(num_media_vars)
                scaled_prior = np.zeros(num_media_vars)
                scurve_penalty_thr_bnd = np.array([0.3] * num_media_vars)
                scurve_penalty_sat_bnd = np.array([0.3] * num_media_vars)
                s_curve_dic_thr = np.zeros(num_media_vars)
                s_curve_dic_sat = np.zeros(num_media_vars)

                i, j = 0, 0 
                SST = np.sum(
                    (outcome_by_sbu[sbu_idx] - np.mean(outcome_by_sbu[sbu_idx]))
                    ** 2
                )
                ## SST -> sum(sq(outcome - mean(outcome)))
                ### Getting media transformations ###
                sepehr_fc_list = np.zeros(num_media_vars)
                # scaling_factor_list = np.zeros(num_media_vars)
                for media_var_idx in range(num_media_vars):
                    if media_var_idx in wmt_media_idx:

                        j += 5
                        decision_vars = x[i:j]  # halflife, threshold, saturation, lag
                        
                        if not use_thresh_sat:
                            halflife, inflection, scale, lag, lambda_k_ = (
                                decision_vars[0],
                                decision_vars[1],
                                decision_vars[2],
                                int(decision_vars[3]),
                                decision_vars[4]
                            )
                            inf[media_var_idx] = inflection
                            sc[media_var_idx] = scale
                            hf_arr[media_var_idx] = halflife
                            lag_arr[media_var_idx] = lag
                            lambda_k_arr[media_var_idx] = lambda_k_
                        else:
                            halflife, threshold, saturation, lag, lambda_k_ = (
                                decision_vars[0],
                                decision_vars[1],
                                decision_vars[2],
                                int(decision_vars[3]),
                                decision_vars[4]
                            )        
                            thr_arr[media_var_idx] = threshold
                            sat_arr[media_var_idx] = saturation
                            hf_arr[media_var_idx] = halflife
                            lag_arr[media_var_idx] = lag
                            lambda_k_arr[media_var_idx] = lambda_k_                    
                        #x_updated = np.append(decision_vars)
                        # Running actual transformations
                        transformed_var = transformed_var_actual[sbu_idx][
                            :, media_var_idx
                        ]
                        transformed_spend = transformed_spend_var_actual[sbu_idx][
                            :, media_var_idx
                        ]
                        if handle_added_value:
                            transformed_var = (
                                transformed_var * transformed_spend
                            )  ### ignore spend = 0 for added value

                        if lag != 0:
                            transformed_var = lag_transformation(transformed_var, lag)
                        if halflife != 0:
                            transformed_var = halflife_transformation(
                                transformed_var, halflife
                            )
                        var_mean = transformed_var.mean()

                        # calculate scale and inflection
                        if not use_thresh_sat:
                            if (scale != 0) and (inflection != 0):
                                transformed_var_scaled = transformed_var / var_mean
                                saturation_term = scale * (inflection - transformed_var_scaled)
                                scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (
                                    1 + np.exp(scale * inflection)
                                )
                                scurve_var_mean = scurve_var[:train_end_index].mean()
                                transformed_var = scurve_var * var_mean / scurve_var_mean

                                saturation_point = (4.59511985013/(scale) + inflection) * transformed_var.mean()

                                # threshold point
                                if scale*inflection < 4.59511985013:
                                    threshold_point = 0
                                else:
                                    threshold_point = (-4.59511985013/(scale) + inflection) * transformed_var.mean()

                                #saturation point
                                thr_arr[media_var_idx] = threshold_point           
                    
                                # threshold point
                                sat_arr[media_var_idx] = saturation_point
                        else:
                            if var_mean > 0:
                                inflection = (saturation + threshold) / (2 * var_mean)
                            else:
                                inflection = 0
                            if (saturation - threshold) > 0:
                                scale = ((2 * var_mean) * 4.59511985013) / (
                                    saturation - threshold
                                )
                            else:
                                scale = 0
                            if (scale != 0) and (inflection != 0):
                                transformed_var_scaled = transformed_var / var_mean
                                saturation_term = scale * (inflection - transformed_var_scaled)
                                scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (
                                    1 + np.exp(scale * inflection)
                                )
                                scurve_var_mean = scurve_var[:train_end_index].mean()
                                transformed_var = scurve_var * var_mean / scurve_var_mean
                            inf[media_var_idx] = inflection
                            sc[media_var_idx] = scale
                        # transformed_var_cpy = transformed_var.copy()
                        # lower_perc = np.percentile(transformed_var_cpy,5)
                        # upper_perc = np.percentile(transformed_var_cpy,95)
                        # transformed_var_cpy[transformed_var_cpy > upper_perc] = upper_perc
                        # transformed_var = transformed_var_cpy

                        # calculate scaling factor here
                        
                        scaling_factor = max(transformed_var) - min(transformed_var)
                        transformed_var = (
                            transformed_var - min(transformed_var)
                        ) / scaling_factor
                        sepehr_fc = transformed_var.std() / transformed_var.mean()

                        transformed_media_total[media_var_idx] = np.asarray(transformed_var)
                        transformed_var = transformed_var[:train_end_index]
                        transformed_media[media_var_idx] = np.asarray(
                            transformed_var
                        )  # X_mk
                        if use_ridge:
                            scaled_prior[media_var_idx] = (
                            coef_mean_prior[media_var_idx] * scaling_factor
                        )
                            lambda_k[media_var_idx] = (
                                lambda_k_ / ((sepehr_fc * scaled_prior[media_var_idx])**2)
                                
                            )
                            # sepehr_fc_list[media_var_idx] = sepehr_fc
                            scaling_factor_arr[media_var_idx] = scaling_factor
                        else:
                            lambda_k[media_var_idx] = 0.0
                            scaled_prior[media_var_idx] = 0.0
                        i += 5
                        #j += 5
                    
                    else:
                        
                        j += 1
                        decision_vars = x[i:j]
                        lambda_k_ = decision_vars[0]
                        lambda_k_arr[media_var_idx] = lambda_k_

                        transformed_var = transformed_var_actual[sbu_idx][
                            :, media_var_idx
                        ]
                        transformed_spend = transformed_spend_var_actual[sbu_idx][
                            :, media_var_idx
                        ]
                        df_media_onair_var = on_air_days[:, media_var_idx]
                        if handle_added_value:
                            transformed_var = (
                                transformed_var * transformed_spend
                            )  ### ignore spend = 0 for added value
                        halflife = wmc_solution_arr[media_var_idx][-5]
                        inflection = wmc_solution_arr[media_var_idx][-4]
                        scale = wmc_solution_arr[media_var_idx][-3]
                        lag = wmc_solution_arr[media_var_idx][-2]

                        inf[media_var_idx] = inflection
                        sc[media_var_idx] = scale
                        hf_arr[media_var_idx] = halflife
                        lag_arr[media_var_idx] = lag

                        saturation_point = (4.59511985013/(scale) + inflection) * transformed_var.mean()

                        # threshold point
                        if scale*inflection < 4.59511985013:
                            threshold_point = 0
                        else:
                            threshold_point = (-4.59511985013/(scale) + inflection) * transformed_var.mean()

                        #saturation point
                        thr_arr[media_var_idx] = threshold_point           
            
                        # threshold point
                        sat_arr[media_var_idx] = saturation_point
                        #lambda_k_ = wmc_solution_arr[media_var_idx][-1]
                        # calculate scaling factor here
                        
                        s_curve_params = get_scurve_params(transformed_var, df_media_onair_var, scale, inflection)
                        s_curve_dic_thr[media_var_idx] = s_curve_params[0]
                        s_curve_dic_sat[media_var_idx] = s_curve_params[1] 
                        scaling_factor = max(transformed_var) - min(transformed_var)
                        transformed_var = (
                            transformed_var - min(transformed_var)
                        ) / scaling_factor
                        sepehr_fc = transformed_var.std() / transformed_var.mean()

                        transformed_media_total[media_var_idx] = np.asarray(transformed_var)
                        transformed_var = transformed_var[:train_end_index]
                        transformed_media[media_var_idx] = np.asarray(
                            transformed_var
                        )  # X_mk
                        if use_ridge:
                            scaled_prior[media_var_idx] = (
                            coef_mean_prior[media_var_idx] * scaling_factor
                        )
                            lambda_k[media_var_idx] = lambda_k_ / ((sepehr_fc * scaled_prior[media_var_idx])**2)
                            scaling_factor_arr[media_var_idx] = scaling_factor
                        else:
                            lambda_k[media_var_idx] = 0.0
                            scaled_prior[media_var_idx] = 0.0
                        i += 1
                        # j += 1


                ### Caclulating media Betas for each set of non media variables ###
                X_tilde = np.zeros(
                    (num_non_media_vars, num_media_vars, train_end_index)
                )
                X_tilde_all = np.zeros(
                    (num_non_media_vars, num_media_vars, media_length)
                )
                X_tilde_valid = np.zeros(
                    (num_non_media_vars, num_media_vars, valid_end_index - valid_start_index)
                )
                Beta = np.zeros((num_non_media_vars, num_media_vars))
                pos_coeffs_j = []
                log_solution = 0
                for non_media_idx in range(num_non_media_vars):
                    U_kj = pre_processed_matrix_U_kj[sbu_idx][non_media_idx][
                        :train_end_index, :train_end_index
                    ]
                    Y_kj = pre_processed_matrix_Y_kj[sbu_idx][non_media_idx][
                        :train_end_index
                    ]
                    Y_kj_valid = pre_processed_matrix_Y_kj[sbu_idx][non_media_idx][
                        valid_start_index:valid_end_index
                    ]
                    std_y = Y_kj.std()
                    var_y = std_y **2

                    X_tilde_j = np.zeros((num_media_vars, train_end_index))
                    X_tilde_j_all = np.zeros((num_media_vars, media_length))

                    for i in range(num_media_vars):

                        #train_data = data[:train_end_index].copy()
                        data_upd = data.astype(np.float64).copy()
                        trans_med_tot = (
                                                    transformed_media_total[i].astype(np.float64).copy()
                                                    )
                        beta = (
                                    np.linalg.inv(data_upd.T @ data_upd)
                                    @ data_upd.T
                                    @ trans_med_tot.T
                                    )
                        fitted_values = data_upd @ beta
                        
                        X_tilde_j_all[i] = trans_med_tot - fitted_values
                    
                    X_tilde_all[non_media_idx] = np.asarray(X_tilde_j_all)

                    X_tilde[non_media_idx] = X_tilde_all[non_media_idx][
                        :, :train_end_index
                    ]
                    X_tilde_valid[non_media_idx] = X_tilde_all[non_media_idx][
                        :, valid_start_index:valid_end_index
                    ]

                    I = np.identity(num_media_vars)
                    for i in range(num_media_vars):
                        X_var_i = np.var(X_tilde_j[i])
                        # lambda_k[i] = lambda_k[i] * var_y
                        if i in wmt_media_idx:
                            lambda_k[i] = var_y * lambda_k[i]
                        else:
                            lambda_k[i] = var_y * lambda_k[i]

                        I[i][i] = lambda_k[i]

                    val_2 = np.dot(
                        X_tilde[non_media_idx], X_tilde[non_media_idx].transpose()
                    )

                    P_mkj = inv(I + val_2)

                    Q_mkj = np.dot(X_tilde[non_media_idx], Y_kj) + np.dot(
                        I, scaled_prior
                    )

                    Beta_j = np.dot(P_mkj, Q_mkj)
                    Beta[non_media_idx] = Beta_j
                    if log_details > 0:
                        with objmode():
                            self.solution_beta_arr = Beta_j.copy()
                    if (Beta_j > 0).sum() > 0:
                        pos_coeffs_j.append((Beta_j > 0).sum())
                    else:
                        pos_coeffs_j.append(0)

                    if (Beta_j > 0).sum() == num_media_vars:

                        log_solution = 1
                        Beta_unscaled[non_media_idx] = Beta_j / scaling_factor_arr
                
                count_pos_coef = max(pos_coeffs_j)
                J_star = np.array(
                    [i for i, num in enumerate(pos_coeffs_j) if num == count_pos_coef]
                )
                
                ### Penalize more for CPD Tactics, and keep multiplier 1 for non CPD
                cpd_iroas_penalty = np.where(
                            cpd_var >0,5,1
                        )

                ### Calculating objective function loss ###
                min_loss = np.inf
                for i in J_star:
                    term_1 = np.sum(
                        np.square(
                            pre_processed_matrix_Y_kj[sbu_idx][i][:train_end_index]
                            - np.dot(Beta[i], X_tilde[i])
                        )
                    )
                    term_2 = term_2_weight * (lambda_k * np.square(Beta[i] - scaled_prior)).sum()
                    prior_loss = np.square(Beta[i] - scaled_prior)
                    # calculate iroas_penalty
                    term_3, term_2_1 = 0.0, 0.0

                    if use_iroas_penalty:

                        contribution = Beta[i] * transformed_media.sum(axis=1)
                        #contribution_l12 = Beta[i] * transformed_media[:,train_end_index-365:train_end_index].sum(axis=1)
                        iroas = contribution * train_price / train_spend
                        #iroas_l12 = contribution_l12 * train_price / l12_spend
                        #iroas_l12[-len(wmt_media_idx):] = iroas[-len(wmt_media_idx):]

                        # Provision for national media and wmt media
                        Overall_iRoAS = (
                            contribution[wmc_idx].sum()
                            * train_price[0]
                            / train_spend[wmc_idx].sum()
                        )

                        Tactic_iRoAS = iroas
                        sign_penalty =  np.where(
                            Beta[i] <0,10000,1
                        )

                        iroas_dev_from_prior = (np.square(iroas - media_roas_prior)
                        )

                        ## use to penalize cpd more
                        # iroas_dev_from_prior = (cpd_iroas_penalty*np.square(iroas - media_roas_prior)
                        # )                        
                        term_2_1 = iroas_dev_from_prior.sum()*term_2_1_weight
                        
                        
                        iroas_penalty = np.where(
                            (iroas >= iroas_lb) & (iroas <= iroas_ub), 0, 1
                        )
                        scurve_penalty = np.where(
                            np.logical_and(s_curve_dic_thr <= scurve_penalty_thr_bnd,
                                          s_curve_dic_sat <= scurve_penalty_sat_bnd
                            ), 0, 1
                        )
                        if log_details > 0:
                            with objmode():
                                self.solution_contri_arr = contribution.copy()
                                self.solution_iroas_arr = iroas.copy()
                                self.solution_iroas_penalty_arr = iroas_penalty.copy()
                                self.lambda_k_arr = lambda_k.copy()
                                self.prior_loss_arr = prior_loss.copy()
                                self.scaled_prior = scaled_prior.copy()
                                self.scaling_factor = scaling_factor_arr.copy()                                
                        # sum up the penalty and scale to [0,1]
                        term_3 = iroas_penalty.sum() / num_media_vars
                        term_4 = ((num_media_vars-count_pos_coef)/num_media_vars) * term_4_weight
                        # term_5 = 100 * scurve_penalty.sum() / num_media_vars
    
                        if log_solution > 0:
                            train_error = Y_kj - np.dot(Beta[i], X_tilde[i])
                            train_mape = (
                                np.abs(
                                    train_error
                                    / outcome_by_sbu[sbu_idx][:train_end_index]
                                )
                                * 100
                            ).mean()


                            ss_tot_train = (
                                (
                                    outcome_by_sbu[sbu_idx][:train_end_index]
                                    - np.mean(
                                       outcome_by_sbu[sbu_idx][:train_end_index]
                                    )
                                )
                                ** 2
                            ).sum()


                            r_sq_train = 1 - (train_error**2).sum() / ss_tot_train

                            if len(outcome_by_sbu[sbu_idx][valid_start_index:valid_end_index]) == 0:
                                valid_error = np.nan    
                                valid_mape = np.nan 
                                ss_tot_valid = np.nan 
                                r_sq_valid = np.nan 
                            else:
                                valid_error = Y_kj_valid - np.dot(Beta[i], X_tilde_valid[i])
                                valid_mape = (
                                np.abs(
                                    valid_error
                                    / outcome_by_sbu[sbu_idx][valid_start_index:valid_end_index]
                                )
                                * 100
                                ).mean()
                                ss_tot_valid = (
                                (
                                    outcome_by_sbu[sbu_idx][valid_start_index:valid_end_index]
                                    - np.mean(
                                        outcome_by_sbu[sbu_idx][valid_start_index:valid_end_index]
                                    )
                                )
                                ** 2
                                ).sum()
                                r_sq_valid = 1 - (valid_error**2).sum() / ss_tot_valid

                    loss = (
                        term_1 / SST
                        + term_2 / SST
                        + term_2_1
                        + (term_3 * iroas_penalty_multiplier)
                        + term_4
                        #+ term_5
                    )
                    x_updated = np.concatenate((wmc_solution_arr[:,:-1], x[:num_media_vars-len(wmt_media_idx)].reshape(-1,1)), axis =1)
                    x_updated = np.append(x_updated,x[num_media_vars-len(wmt_media_idx):])                     

                    with objmode():
                        self.solution_arr = x_updated.copy()


                    min_loss = min(min_loss, loss)
                    if log_details > 0:
                        print("term_3")
                        print(term_3 * iroas_penalty_multiplier)
                        print("term_4")
                        print(term_4)
                        print("term_2_1")
                        print(term_2_1)                       
                        with objmode():
                            save_iteration_log(
                                sbu_idx,
                                log_details,
                                SST,
                                term_1,
                                (lambda_k * np.square(Beta[i] - scaled_prior)),
                                np.square(iroas - media_roas_prior),
                                term_3,
                                term_4,
                                scurve_penalty,
                                min_loss
                            )

                if (log_solution > 0) and (term_1 / SST <= 0.3) and term_3 <= 0.4:
                        with objmode():
                            (
                                monotonic_inc_contrib_overall_bool,
                                monotonic_inc_contrib_tactic_bool,
                            ) = ([], [])

                            idx1, idx2, idx3, idx4 = (
                                yoy_idx[0],
                                yoy_idx[1],
                                yoy_idx[2],
                                yoy_idx[3],
                            )

                            total_cont_1, total_cont_2, total_spend_1, total_spend_2 = (
                                0,
                                0,
                                0,
                                0,
                            )
                            (
                                overall_contrib_1,
                                overall_iroas_1,
                                overall_contrib_2,
                                overall_iroas_2,
                            ) = (
                                0,
                                0,
                                0,
                                0,
                            )
                            (
                                media_contrib_1,
                                media_contrib_2,
                                media_iroas_1,
                                media_iroas_2,
                            ) = ([], [], [], [])
                            for idx in range(num_media_vars):

                                media_var = media_variables[idx]
                                coef = Beta[i][idx]
                                if idx in wmc_idx:
                                    total_cont_1 += (
                                        coef
                                        * transformed_media_total[idx][
                                            idx1 : idx2 + 1
                                        ].sum()
                                    )
                                    total_cont_2 += (
                                        coef
                                        * transformed_media_total[idx][
                                            idx3 : idx4                                     # NEW 4.10
                                        ].sum()
                                    )
                                    total_spend_1 += yoy_1_tactic_spend[idx]
                                    total_spend_2 += yoy_2_tactic_spend[idx]

                                media_contrib_1.append(
                                    (
                                        coef
                                        * transformed_media_total[idx][
                                            idx1 : idx2 + 1
                                        ].sum()
                                    )
                                )
                                media_contrib_2.append(
                                    (
                                        coef
                                        * transformed_media_total[idx][
                                            idx3 : idx4                                    # NEW 4.10
                                        ].sum()
                                    )
                                )

                                media_iroas_1.append(
                                    (
                                        media_contrib_1[idx]
                                        * train_price[0]
                                        / yoy_1_tactic_spend[idx]
                                    )
                                )
                                media_iroas_2.append(
                                    (
                                        media_contrib_2[idx]
                                        * train_price[0]
                                        / yoy_2_tactic_spend[idx]
                                    )
                                )
                                if (
                                    idx in wmc_idx
                                    and ("_IMP" in media_var)
                                    and (
                                        "_WMT" not in media_var
                                        or "_NAT" not in media_var
                                    )
                                ):
                                    if (
                                        (
                                            yoy_2_tactic_spend[idx].sum()
                                            > yoy_1_tactic_spend[idx].sum()
                                        )
                                        and (
                                            media_contrib_2[idx] < media_contrib_1[idx]
                                        )
                                    ) or (
                                        (
                                            yoy_2_tactic_spend[idx].sum()
                                            < yoy_1_tactic_spend[idx].sum()
                                        )
                                        and (
                                            media_contrib_2[idx] > media_contrib_1[idx]
                                        )
                                    ):
                                        monotonic_inc_contrib_tactic_bool.append(0)
                                    else:
                                        monotonic_inc_contrib_tactic_bool.append(1)
                                elif (idx in wmc_idx) and (
                                    "_WMT" not in media_var or "_NAT" not in media_var
                                ):
                                    if (
                                        yoy_2_tactic_spend[idx].sum()
                                        > yoy_1_tactic_spend[idx].sum()
                                    ) and (media_contrib_2[idx] < media_contrib_1[idx]):
                                        monotonic_inc_contrib_tactic_bool.append(0)
                                    else:
                                        monotonic_inc_contrib_tactic_bool.append(1)
                                else:
                                    monotonic_inc_contrib_tactic_bool.append(1)

                            overall_contrib_1 = total_cont_1
                            overall_contrib_2 = total_cont_2
                            overall_iroas_1 = (
                                overall_contrib_1 * train_price[0] / total_spend_1
                            )
                            overall_iroas_2 = (
                                overall_contrib_2 * train_price[0] / total_spend_2
                            )
                            if (total_spend_2 > total_spend_1) and (
                                overall_contrib_2 < overall_contrib_1
                            ):
                                monotonic_inc_contrib_overall_bool.append(0)
                            else:
                                monotonic_inc_contrib_overall_bool.append(1)

                            save_intermediate_solution(
                                sbu_idx,
                                hf_arr,
                                thr_arr,
                                sat_arr,
                                lag_arr,
                                lambda_k_arr,
                                lambda_k,  ## placeholder for lambda decision variable, currently only zeroes
                                sc,
                                inf,
                                min_loss,
                                debug_flag,
                                Beta[i],
                                Beta_unscaled[i],
                                Tactic_iRoAS,
                                Overall_iRoAS,
                                iroas_dev_from_prior,
                                train_mape,
                                valid_mape,
                                r_sq_train,
                                r_sq_valid,
                                media_contrib_1,
                                yoy_1_tactic_spend,
                                media_contrib_2,
                                yoy_2_tactic_spend,
                                media_iroas_1,
                                media_iroas_2,
                                overall_contrib_1,
                                overall_contrib_2,
                                overall_iroas_1,
                                overall_iroas_2,
                                monotonic_inc_contrib_tactic_bool,
                                monotonic_inc_contrib_overall_bool,
                            )

                if is_premium and use_sign_penalty:
                    sbu_losses[sbu_idx] = min_loss * 1.0 - max(pos_coeffs_j)
                else:
                    sbu_losses[sbu_idx] = min_loss
                log_solution_total += log_solution

            for i in range(num_sbu):
                total_loss += sbu_losses[i]

            return total_loss


        if solution_save:
            return optimization_fn_numba(initial_solution)

        if global_opt:
            solution = differential_evolution.differential_evolution(
                optimization_fn_numba,
                bnds,
                maxiter = self.max_iterations,
                popsize = 15,
                seed=seed,
                workers=1,
                tol=0.01,
                disp=True,
                updating="deferred",
                mutation=(0.5, 1.5),
                strategy="best1bin",
                recombination=0.7,
                x0=initial_solution,
                polish=False,
                fix_iterations=self.fix_iterations
            )
        else:
            solution = minimize(
                optimization_fn_numba,
                initial_solution,
                bounds=bnds,
                method="SLSQP",
                options={"disp": True},
            )

        solution.saved_solutions.append(
            np.concatenate((solution.x, np.array([optimization_fn_numba(solution.x)])))
        )

        return solution

    def run_optimizer(self, seed, global_opt=True):
        self.solution = self.run_DE(
            seed,
            self.num_sbu,
            self.num_media_vars,
            self.train_end_index,
            self.valid_start_index,
            self.valid_end_index, 
            self.transformed_var_actual,
            self.transformed_spend_var_actual,
            self.pre_processed_matrix_U_kj,
            self.pre_processed_matrix_Y_kj,
            self.num_non_media_vars,
            self.coef_mean_prior,
            self.outcome_by_sbu_actual,
            self.bnds,
            self.initial_solution,
            global_opt,
            media_roas_prior=self.media_iroas_prior,
            use_ridge = self.use_ridge,
            is_premium = self.is_premium,
            lambda_denominator = self.lambda_denominator, 
            use_sign_penalty = self.use_sign_penalty,
            use_iroas_penalty = self.use_iroas_penalty,
            iroas_penalty_multiplier = self.iroas_penalty_multiplier,
            iroas_lb = self.iroas_lb,
            iroas_ub = self.iroas_ub, 
            train_spend = self.train_spend,
            train_price = self.train_price,
            l12_spend = self.l12_spend,
            handle_added_value = self.handle_added_value,
            media_variables=self.media_variables,
            data=np.asarray(self.data[self.non_media_variables]),
            national_media_variables = self.national_media_variables,
            wmc_solution_arr = self.wmc_solution_arr,
            on_air_days = self.df_media_onair,
            use_thresh_sat = self.use_thresh_sat,
            wmc_idx=self.wmc_idx,
            wmt_media_idx = self.wmt_media_idx,
            cpd_var = self.cpd_var,
            yoy_idx=self.yoy_idx,
            yoy_1_spend=self.yoy_1_spends,
            yoy_2_spend=self.yoy_2_spends,
            yoy_1_tactic_spend=self.tactic_level_spends_y1,
            yoy_2_tactic_spend=self.tactic_level_spends_y2,
            term_2_weight = self.term_2_weight,
            term_2_1_weight = self.term_2_1_weight, 
            term_4_weight = self.term_4_weight
        )

    def run_diagnostics(self): # willl only work with single brand and single base

        if self.is_premium:
            solutions_list = []
            # sol_details : brand_idx,log_details,SST,term_1,term_2,term_3,min_loss
            transformation_arr, iteration_number, sst, term_1, term_2, term_2_1, term_3, min_loss = [], [], [], [], [], [], [], []
            for sol in self.iteration_logs:
                term_1_by_sst = sol[1][3]/sol[1][2]
                term_2_by_sst = sol[1][4]/sol[1][2]

                transformation_arr = np.reshape(sol[0],(self.num_media_vars,5)).tolist()
                iteration_log_result_dict = {
                            
                            "SBU_name": self.sbu_list[0],
                            "Iteration_number": sol[1][1],
                            "sst" : sol[1][2],
                            "term_1" : sol[1][3],
                            "term_1_by_sst" : term_1_by_sst,
                            "term_2" : sol[1][4],
                            "term_2_by_sst" : term_2_by_sst,
                            "term_2_1": sol[1][5],
                            "term_3": sol[1][6],
                            "term_4":sol[1][7],
                            "scurve_penalty":sol[1][8],
                            "min_loss" : sol[1][9],
                            "media_variable" : self.media_variables,
                            "Tactic_iroas" : sol[4],
                            "Tactic_contribution" : sol[3],
                            "Tactic_coef" : sol[2],
                            "Tactic_iroas_penalty" : sol[5],
                            "Tactic_lambda_k" : sol[6],
                            "B - B0 Square" : sol[7],
                            "Scaled_prior" : sol[8],
                            "Scaling_factor" : sol[9],
                            "Transformation": transformation_arr

                        }
                iteration_log_results = pd.DataFrame.from_dict(iteration_log_result_dict)
                solutions_list.append(iteration_log_results)

            try:
                combined_iteration_log = pd.concat(solutions_list)
                combined_iteration_log.to_csv(
                    f"{self.folder_path}/iteration_log_details.csv", index=False
                )
            except:
                print("No intermediate log to save \n")
                
    def make_hashable(self, item):
        if isinstance(item, np.ndarray):
            return tuple(item.ravel())  # Convert numpy array to a flattened tuple
        elif isinstance(item, list):
            return tuple(
                self.make_hashable(sub_item) for sub_item in item
            )  # Recursively convert lists
        else:
            return item  # If it's not an array or list, leave it as it is

    def load_pickle_files(self, seed):
        self.seed = seed
        self.sbu_level_sol = {}
        for sbu in self.sbu_list:
            try:
                interim_sols = [
                    filename
                    for filename in os.listdir(self.folder_path)
                    if filename.startswith(f"interim_sol_{sbu}")
                ]
                sol_nums = sorted(
                    [int(i.split("_")[-1].split(".pkl")[0]) for i in interim_sols],
                    reverse=True,
                )
                solutions_res = []
                for sol_name in sol_nums:
                    file_name = f"interim_sol_{sbu}_{sol_name}.pkl"
                    # print(f"reading {file_name}")
                    file = os.path.join(self.folder_path, file_name)
                    objects = []
                    with open(file, "rb") as f:
                        while True:
                            try:
                                obj = pickle.load(f)
                                objects.append(obj)
                            except EOFError:
                                break
                    solutions_res += objects

                seen = set()
                combined_sol = []
                for inner_list in solutions_res:
                    hashable_list = tuple(self.make_hashable(inner_list))
                    if hashable_list not in seen:
                        seen.add(hashable_list)
                        combined_sol.append(inner_list)
                print(f"length of single solution : {len(combined_sol[0])}")
            except:
                print("no interim solutions for sbu", sbu)
            self.sbu_level_sol[sbu] = combined_sol

        for sbu, sols in self.sbu_level_sol.items():
            print(
                sbu,
                "number of solutions loaded from pickle file",
                abs(len(self.sbu_level_sol[sbu])),
                "\n",
            )
        print("saving iteration logs \n")
        self.run_diagnostics()
        print("************* saving iteration logs - Done ************* \n")

    def save_txt(self):
        sol_filename = self.folder_path + "/solutions_" + str(self.seed) + ".txt"
        print("sol_filename:", sol_filename, "\n")
        i = 0
        with open(sol_filename, "w") as testfile:
            for row in self.solution.saved_solutions:
                i += 1
                testfile.write(str(i) + "\n")
                testfile.write(",".join([str(a) for a in row]) + "\n" + "\n")

        for sbu in self.sbu_list:
            try:
                df = pd.read_csv(
                    self.folder_path
                    + "/results_"
                    + str(sbu)
                    + "_"
                    + str(self.seed)
                    + ".csv"
                )
                print(
                    sbu,
                    ":",
                    len(list(df["Solution_number"].unique())),
                    "final solutions dumped to csv!",
                )
            except:
                print(
                    "no solution found for sbu",
                    sbu,
                    "as no solution found with all positive coefficients",
                )

    def gompertz_logistic_saturation_pts(self, df, Media_var, inflection, scale):
        Point = pd.DataFrame({'Media':[Media_var]})  
        # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
        Point['Saturation Point using Logistic'] = (4.59511985013/(scale) + inflection) * df.mean()
        saturation = Point[['Saturation Point using Logistic']].min(axis= 1)            
        return saturation.values[0]

    def gompertz_logistic_threshold_pts(self, df,Media_var, inflection,scale):
        Point = pd.DataFrame({'Media':[Media_var]})  
        # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
        if scale*inflection < 4.59511985013:
            Point['Threshold Point using Logistic'] = 0
        else:
            Point['Threshold Point using Logistic'] = (-4.59511985013/(scale) + inflection) * df.mean()
        threshold = Point[['Threshold Point using Logistic']].max(axis = 1)        
        return threshold.values[0]
    

def create_missing_media_transformations_new(df, media_vars, trans_start_date= None, trans_end_date= None):
    ''' 
    Creates the mising media transformation 
    
    Params
        media_vars : List of all media variables 
    '''
    # Creates the missing media transformations
    ## added:09.29.2022, jangho, for sliders
    media_variables = media_vars
    sat = {}
    thr = {}
    inf = {}
    if trans_start_date is None:
        trans_start_date = trans_start_date
        
    if trans_end_date is None:
        trans_end_date = trans_end_date
        
    for var in media_vars:
        
        if 'WMT' in var:
            print("WMT variable found : Use Solution from only WMC variables")
            lag = int(float(var.split("_")[-1]))
            
            halflife = float(var.split("_")[-4])
            sscurve_inflection = float(var.split("_")[-3])
            sscurve_scale = float(var.split("_")[-2])

            orig_media_var = var.split("_")[:-4]
            orig_media_var = '_'.join([str(elem) for elem in orig_media_var])
            
            # Saving the numbers on the required period defined by trans_start_date and trans_end_date
            df_filtered = df
            transformed_var = df_filtered[orig_media_var]
            var_mean_og = df_filtered[orig_media_var].mean()
            # Saving the means on the filtered dataset
            var_mean = transformed_var.mean()
            sepehr_fc = transformed_var.std() / transformed_var.mean()

            scaling_factor = max(transformed_var) - min(transformed_var)


            sat[var] = np.quantile(a=transformed_var, q=0.90)                                    

            thr[var] = np.quantile(a=transformed_var, q=0.10)

            inf[var] = (sat[var] + thr[var])/2                    


            df[orig_media_var] = transformed_var
            df[orig_media_var + '_scaling_factor'] = scaling_factor
            df[orig_media_var + '_sepehr_fc'] = sepehr_fc
            df[orig_media_var + '_transformed_mean'] = var_mean
            
            df[orig_media_var + '_transformed_Threshold'] = thr[var]
            df[orig_media_var + '_transformed_Saturation'] = sat[var]
            df[orig_media_var + '_transformed_Inflection'] = inf[var]
            df[orig_media_var + '_original_mean'] = var_mean_og

        else:
            lag = int(float(var.split("_")[-1]))
            halflife = float(var.split("_")[-4])
            sscurve_inflection = float(var.split("_")[-3])
            sscurve_scale = float(var.split("_")[-2])
            orig_media_var = var.split("_")[:-4]
            orig_media_var = '_'.join([str(elem) for elem in orig_media_var])
            
            # Saving the numbers on the required period defined by trans_start_date and trans_end_date
            df_filtered = df
            transformed_var = df_filtered[orig_media_var]
            var_mean_og = df_filtered[orig_media_var].mean()
            # Saving the means on the filtered dataset
            if lag != 0: 
                transformed_var = lag_transformation_no_numba(transformed_var, int(lag))

                
            if halflife != 0:
                transformed_var = halflife_transformation_no_numba(transformed_var, halflife)
            
            var_mean = transformed_var.mean()

            if (sscurve_scale != 0) and (sscurve_inflection != 0):
                transformed_var_scaled = transformed_var/var_mean
                saturation_term = sscurve_scale * (sscurve_inflection - transformed_var_scaled)
                scurve_var = 1/(1+np.exp(saturation_term))-1/(1+np.exp(sscurve_scale * sscurve_inflection))
                scurve_var_mean = scurve_var.mean()
                transformed_var = scurve_var * var_mean / scurve_var_mean

            sepehr_fc = transformed_var.std() / transformed_var.mean()

            scaling_factor = max(transformed_var) - min(transformed_var)

            sat[var] = gompertz_logistic_saturation_pts(transformed_var, 'Raw Variable',
                                                                    sscurve_inflection, sscurve_scale)                    

            thr[var] = gompertz_logistic_threshold_pts(transformed_var, 'Raw Variable', 
                                                        sscurve_inflection, sscurve_scale)

            inf[var] = (sat[var] + thr[var])/2                    
            # threshold point

            # transformed_var = (
            #     transformed_var - min(transformed_var)
            # ) / scaling_factor

            df[orig_media_var] = transformed_var
            df[orig_media_var + '_scaling_factor'] = scaling_factor
            df[orig_media_var + '_sepehr_fc'] = sepehr_fc
            df[orig_media_var + '_transformed_mean'] = var_mean
            
            df[orig_media_var + '_transformed_Threshold'] = thr[var]
            df[orig_media_var + '_transformed_Saturation'] = sat[var]
            df[orig_media_var + '_transformed_Inflection'] = inf[var]
            df[orig_media_var + '_original_mean'] = var_mean_og

    return df

def gompertz_logistic_saturation_pts(df, Media_var, inflection, scale):
    Point = pd.DataFrame({'Media':[Media_var]})  
    # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
    Point['Saturation Point using Logistic'] = (4.59511985013/(scale) + inflection) * df.mean()
    saturation = Point[['Saturation Point using Logistic']].min(axis= 1)            
    return saturation.values[0]

def gompertz_logistic_threshold_pts(df,Media_var, inflection,scale):
    Point = pd.DataFrame({'Media':[Media_var]})  
    # 4.59511985013 for 99% saturation and 2.944438979 for 95% saturation
    if scale*inflection < 4.59511985013:
        Point['Threshold Point using Logistic'] = 0
    else:
        Point['Threshold Point using Logistic'] = (-4.59511985013/(scale) + inflection) * df.mean()
    threshold = Point[['Threshold Point using Logistic']].max(axis = 1)        
    return threshold.values[0]

def lag_transformation_no_numba(var, lag):
    lag_variable = np.append(np.zeros(int(lag)), var[:-lag])
    return lag_variable

def halflife_transformation_no_numba(var, halflife):
    retention = np.exp(math.log(0.5)/halflife)        
    transformed_var = var * (1 - retention)
    transformed_var[np.isnan(transformed_var)] = 0
    transformed_var = recursive_filter_no_numba(transformed_var, retention)
    return transformed_var

def recursive_filter_no_numba(x, ar_coeff):
    n = len(x)
    y = np.zeros(n)
    y[0] = x[0]
    for i in range(1,n):
        y[i] = ar_coeff * y[i-1] + x[i]
    return y