#!/usr/bin/env python
# coding: utf-8
# author: Mayukh Maitra

import ast
import math
import os
import pickle
import sys
from datetime import datetime
import itertools

import _differentialevolution_ols as differential_evolution
import numba
import numpy as np
import pandas as pd
from IPython.display import display
from numba import jit, literally, njit, numba, objmode
from numba.typed import List
from numba_helper_functions import *
from numpy.linalg import inv, pinv
from scipy.optimize import minimize
import multiprocessing as mp

module_path = os.path.abspath(os.path.join("../src/utils"))
if module_path not in sys.path:
    sys.path.append(module_path)

if os.path.abspath("../src/config_dir") not in sys.path:
    sys.path.append(os.path.abspath("../src/config_dir"))

if module_path not in sys.path:
    sys.path.append(module_path)

import warnings

warnings.filterwarnings("ignore")

date_format = "%Y-%m-%d"


def create_folder_with_version(directory_path):
    version = 1
    while os.path.exists(f"{directory_path}_v{version}"):
        version += 1
    new_directory_path = f"{directory_path}_v{version}"
    os.makedirs(new_directory_path)
    print(f"Create output folder : {new_directory_path}")
    return new_directory_path


class WAMM_Lite:
    def __init__(
        self,
        updated_stack,
        outcome,
        pre_processed_matrix_U_kj,
        pre_processed_matrix_Y_kj,
        coef_mean_prior,
        coef_var_prior,
        threshold_bounds,
        saturation_bounds,
        media_variables_og,  # Category WAMM Change
        media_variables_all, # Category WAMM Change 
        split_dictionary,   # Category WAMM Change
        sbu_list,
        train_start,
        train_end,
        valid_start,
        valid_end,
        media_iroas_prior,
        folder_path,
        iroas_lb = None,# default to handle Lite
        iroas_ub = None,# default to handle lite
        use_iroas_penalty = False,
        iroas_penalty_multiplier = 1.0,
        is_premium=False,# premium changes
        lambda_denominator = 3, # value will be discarded if use_ridge==False
        use_sign_penalty = False, # if true, use_ridge is set to False
        apply_scaling = False,
        train_spend = [],# default to handle lite
        train_price = None, # default to handle lite
        iroas_dev_in_loss=False,
        YoY_comparison = None,
        common_s_curve = True,
        handle_added_value = False,
        fix_iterations=False,
        use_ridge=True,
        lambda_k=1.0
) -> None:
        self.updated_stack = updated_stack
        self.outcome = outcome
        self.threshold_bounds = threshold_bounds
        self.saturation_bounds = saturation_bounds
        self.media_variables = media_variables_all  # category wamm change
        self.num_media_vars = len(media_variables_all) # category wamm change
        self.media_variables_og = media_variables_og # category wamm change
        self.num_media_vars_og = len(media_variables_og) # category wamm change
        self.sbu_list = sbu_list
        self.train_start = train_start
        self.train_end = train_end
        self.valid_start = valid_start
        self.valid_end = valid_end
        self.num_sbu = len(sbu_list)
        self.st_dt = datetime.strptime(train_start, date_format)
        self.train_end_dt = datetime.strptime(train_end, date_format)
        self.test_st_dt = datetime.strptime(valid_start, date_format)
        self.test_end_dt = datetime.strptime(valid_end, date_format)
        self.data = self.updated_stack.copy()
        self.train_end_index = (self.train_end_dt - self.st_dt).days + 1
        self.pre_processed_matrix_U_kj = pre_processed_matrix_U_kj
        self.pre_processed_matrix_Y_kj = pre_processed_matrix_Y_kj
        self.num_non_media_vars = self.pre_processed_matrix_U_kj.shape[1]
        self.coef_mean_prior = coef_mean_prior
        self.coef_var_prior = coef_var_prior
        self.media_iroas_prior = media_iroas_prior
        self.folder_path = folder_path
        self.solution_arr = []
        # self.brand_non_media_coef = brand_non_media_coef
        self.split_dictionary = split_dictionary # category wamm change
        self.split_interval = 365 # category wamm change
        self.solution_beta_arr = []
        self.solution_contri_arr = []
        self.solution_iroas_arr = []
        self.solution_iroas_penalty_arr = []
        self.iteration_logs = []
        self.fix_iterations = fix_iterations
        self.use_ridge = use_ridge
        self.is_premium = is_premium
        self.lambda_denominator = lambda_denominator # value will be discarded if use_ridge==False
        self.use_sign_penalty = use_sign_penalty
        self.iroas_lb = iroas_lb
        self.iroas_ub = iroas_ub
        self.train_spend = train_spend
        self.train_price = train_price
        self.use_iroas_penalty = use_iroas_penalty
        self.iroas_penalty_multiplier = iroas_penalty_multiplier
        self.apply_scaling = apply_scaling
        self.iroas_dev_in_loss = iroas_dev_in_loss
        self.YoY_comparison = YoY_comparison
        self.common_s_curve = common_s_curve
        self.handle_added_value = handle_added_value
        self.lambda_k_val = lambda_k

    def create_ga_bounds(self):
        self.ga_bounds_media = {}
        for media_idx,var in enumerate(self.media_variables):
            if "_IMP" in var:
                halflife_bounds_var = [0, 5]
                lag_bounds_var = [0, 6]
            elif "_CLK" in var:
                halflife_bounds_var = [0, 5]
                lag_bounds_var = [0, 3]
            else:
                # TODO : error out if the media variable name is invalid
                print(f"Invalid media variable name : {var}")
            self.ga_bounds_media[var] = {
                "halflife_bounds": halflife_bounds_var,
                "threshold_bounds": list(self.threshold_bounds[media_idx]),
                "saturation_bounds": list(self.saturation_bounds[media_idx]),
                "lag_bounds": lag_bounds_var,
            }# Janhavi : premium changes

    def get_spend_variables(self):
        self.spend_variables = []
        for i in range(len(self.media_variables)):
            if "_IMP" in self.media_variables[i]:
                spend_var = self.media_variables[i].replace("_IMP", "_SPEND")
            else:
                spend_var = self.media_variables[i].replace("_CLK", "_SPEND")
            self.spend_variables.append(spend_var)

    def get_initial_solution(self):
        # halflife, threshold, saturation, lag
        self.init_sol_raw_list = []
        i = 0
        np.random.seed(42)
        for var in self.media_variables:
            self.init_sol_raw_list.append(
                np.random.uniform(
                    self.ga_bounds_media[var]["halflife_bounds"][0],
                    self.ga_bounds_media[var]["halflife_bounds"][1],
                )
            )  # halflife
            self.init_sol_raw_list.append(
                np.random.uniform(
                    self.ga_bounds_media[var]["threshold_bounds"][0],
                    self.ga_bounds_media[var]["threshold_bounds"][1],
                )
            )  # threshold
            self.init_sol_raw_list.append(
                np.random.uniform(
                    self.ga_bounds_media[var]["saturation_bounds"][0],
                    self.ga_bounds_media[var]["saturation_bounds"][1],
                )
            )  #  saturation
            self.init_sol_raw_list.append(
                np.random.randint(
                    self.ga_bounds_media[var]["lag_bounds"][0],
                    self.ga_bounds_media[var]["lag_bounds"][1],
                )
            )  # lag
            i += 1

        self.initial_solution = np.asarray(self.init_sol_raw_list).astype(np.float)

    def data_prep(self):

        self.create_ga_bounds()
        self.get_spend_variables()
        self.get_initial_solution()

        ## USE numba ######################################################################
        #### pandas to numpy media
        self.df_data_by_sbu = []
        self.outcome_by_sbu = []
        self.start_idx = 0
        self.end_idx = len(self.data) / len(self.sbu_list)
        for i in range(len(self.sbu_list)):
            temp_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.media_variables].copy()
            outcome_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.outcome].copy()
            temp_data = temp_data.to_numpy().astype("float64")
            outcome_data = outcome_data.to_numpy().astype("float64")
            self.df_data_by_sbu.append(temp_data)
            self.outcome_by_sbu.append(outcome_data)
            self.start_idx = self.end_idx * (i + 1)
        self.df_data_by_sbu = np.asarray(self.df_data_by_sbu)
        self.outcome_by_sbu = np.asarray(self.outcome_by_sbu)

        self.transformed_var_actual = self.df_data_by_sbu.copy()
        self.outcome_by_sbu_actual = self.outcome_by_sbu.copy()
        ######################################################################

        #### pandas to numpy media train data
        self.df_train_data = []
        for sbu_data in self.df_data_by_sbu:
            self.df_train_data.append(sbu_data[: self.train_end_index])
        self.df_train_data = np.asarray(self.df_train_data)
        ######################################################################

        #### pandas to numpy spend
        self.df_media_spend_by_sbu = []
        self.start_idx = 0
        self.end_idx = len(self.data) / len(self.sbu_list)
        for i in range(len(self.sbu_list)):
            temp_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.spend_variables].copy()
            temp_data = temp_data.to_numpy().astype("float64")
            self.df_media_spend_by_sbu.append(temp_data)
            self.start_idx = self.end_idx * (i + 1)
        self.df_media_spend_by_sbu = np.asarray(self.df_media_spend_by_sbu)
        self.transformed_spend_var_actual = (self.df_media_spend_by_sbu > 0).astype(int)
        ######################################################################

        #### pandas to numpy outcome
        self.df_outcome_by_sbu = []
        self.start_idx = 0
        self.end_idx = len(self.data) / len(self.sbu_list)
        for i in range(len(self.sbu_list)):
            temp_data = self.data[
                (self.data.index >= self.start_idx)
                & (self.data.index < self.end_idx * (i + 1))
            ][self.outcome].copy()
            temp_data = temp_data.to_numpy().astype("float64")
            self.df_outcome_by_sbu.append(temp_data)
            self.start_idx = self.end_idx * (i + 1)
        self.df_outcome_by_sbu = np.asarray(self.df_outcome_by_sbu)
        ######################################################################

        #### Category WAMM : Per SBU : Creating groups of spliited Media on index > for S - Curve consistency
        
        self.split_media_index = []
        for i in range(len(self.sbu_list)):
            for key, value in self.split_dictionary.items(): 
                media_all = np.array(self.media_variables)
                a = np.array(value)
                sorter = np.argsort(media_all)
                self.split_media_index.append(sorter[np.searchsorted(media_all, a, sorter=sorter)])
        self.split_media_index = np.array(self.split_media_index)

    def get_bnds_dict(self):
        self.bnds_dict = {}
        for i in self.media_variables:
            self.bnds_dict[i] = [
                tuple(self.ga_bounds_media[i]["halflife_bounds"]),
                tuple(self.ga_bounds_media[i]["threshold_bounds"]),
                tuple(self.ga_bounds_media[i]["saturation_bounds"]),
                tuple(self.ga_bounds_media[i]["lag_bounds"]),
            ]
        self.bnds = []
        for k in self.bnds_dict:
            self.bnds += self.bnds_dict[k]

    def run_DE(
        self,
        seed,
        num_sbu,
        num_media_vars,
        num_media_vars_og,
        train_end_index,
        transformed_var_actual,
        transformed_spend_var_actual,
        pre_processed_matrix_U_kj,
        pre_processed_matrix_Y_kj,
        num_non_media_vars,
        coef_mean_prior,
        coef_var_prior,
        outcome_by_sbu,
        bnds,
        initial_solution,
        split_media_index,
        lambda_k_val,
        iroas_dev_in_loss,
        global_opt=True,
        solution_save=False,
        media_roas_prior=None,
        use_ridge = True,
        is_premium = False,
        lambda_denominator = 3,
        apply_scaling = True,
        use_sign_penalty = False,
        use_iroas_penalty = False,
        iroas_penalty_multiplier = 1.0,
        iroas_lb = None,
        iroas_ub = None,
        train_spend = None,
        train_price = None,
        common_s_curve = True,
        handle_added_value = False
    ):
        self.obj_loss = 10e100        
        def save_intermediate_solution(sbu_idx, x, total_loss, debug_flag):
            with objmode():
                iterim_sol_arr = np.concatenate((x.copy(), np.array([total_loss])))
                # self.solution_arr.append(iterim_sol_arr.copy())
                with open(
                    os.path.join(
                        self.folder_path,
                        f"interim_sol_{self.sbu_list[sbu_idx]}_{debug_flag}.pkl",
                    ),
                    "ab",
                ) as f:
                    pickle.dump(iterim_sol_arr, f)

        def save_iteration_log(sbu_idx, log_details, SST, term_1, term_2, term_2_1, term_3, min_loss):

                iteration_log_arr = [list(self.solution_arr), 
                                     [sbu_idx,log_details,SST,term_1,term_2,term_2_1,term_3,min_loss],
                                     list(self.solution_beta_arr),
                                     list(self.solution_contri_arr),
                                     list(self.solution_iroas_arr),
                                     list(self.solution_iroas_penalty_arr)]                
                self.iteration_logs.append(iteration_log_arr.copy())

        @njit(cache=False)
        def optimization_fn_numba(x, debug_flag=0,log_details=1):
            total_loss, log_solution_total, beta_delta = 0, 0, 0
            sbu_losses = np.zeros(num_sbu)
            with objmode():
                self.solution_arr = x.copy()
            for sbu_idx in range(num_sbu):
                transformed_media = np.zeros((num_media_vars, train_end_index))
                lambda_k = np.zeros(num_media_vars)
                recal_flag = False
                scaled_prior = np.zeros(num_media_vars)
                i, j = 0, 4
                SST = np.sum(
                    (outcome_by_sbu[sbu_idx] - np.mean(outcome_by_sbu[sbu_idx]))
                    ** 2
                )
                sepehr_fc_list = np.zeros(num_media_vars)
                ## SST -> sum(sq(outcome - mean(outcome)))
                ### Getting media transformations ###
                for media_var_idx in range(num_media_vars): 
                    decision_vars = x[i:j]  # halflife, threshold, saturation, lag
                    halflife, threshold, saturation, lag = (
                        decision_vars[0],
                        decision_vars[1],
                        decision_vars[2],
                        int(decision_vars[3]),
                    )
                    # Running actual transformations

                    # Category WAMM : For buckets in split_media_index : S curve transformations are same
                    split_group = find_subarray_with_element(split_media_index,media_var_idx)

                    # transformed_var = transformed_var_actual[sbu_idx][
                    #     :, media_var_idx
                    #     ]
                    # transformed_spend = transformed_spend_var_actual[sbu_idx][
                    #     :, media_var_idx
                    # ]
                    # if handle_added_value:
                    #     transformed_var = transformed_var * transformed_spend ### ignore spend = 0 for added value 
                    
                    if len(split_group) != 0:
                        if recal_flag == False:
                            # Get the Original Variable from Splitted group                  
                            split_group_id = split_group[0]
                            media_split_columns = transformed_var_actual[sbu_idx][:,split_group_id]
                            transformed_var = np.sum(media_split_columns,axis=1)

                            # Calculate the Lag, Hf, Sat, Thre on Combined original variable
                            if lag != 0:
                                transformed_var = lag_transformation(transformed_var, lag)
                            if halflife != 0:
                                transformed_var = halflife_transformation(
                                    transformed_var, halflife
                                )
                            var_mean = transformed_var.mean()

                            if var_mean > 0:
                                inflection = (saturation + threshold) / (2 * var_mean)
                            else:
                                inflection = 0
                            if (saturation - threshold) > 0:
                                scale = ((2 * var_mean) * 4.59511985013) / (
                                    saturation - threshold
                                )
                            else:
                                scale = 0
                            if (scale != 0) and (inflection != 0):
                                transformed_var_scaled = transformed_var / var_mean
                                saturation_term = scale * (inflection - transformed_var_scaled)
                                scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (
                                    1 + np.exp(scale * inflection)
                                )
                                scurve_var_mean = scurve_var[:train_end_index].mean()
                                transformed_var = scurve_var * var_mean / scurve_var_mean

                            if apply_scaling:
                                scaling_factor = max(transformed_var) - min(transformed_var)
                                transformed_var = (
                                    transformed_var
                                    - min(transformed_var)
                                ) / scaling_factor                    

                            transformed_var = transformed_var[:train_end_index]
                            temp_transformed_var_lg_hf = transformed_var

                            # Split the transformed original variable
                            indices = np.nonzero(transformed_var_actual[sbu_idx][:,media_var_idx])[0]
                            start_index = indices[0]
                            end_index = indices[-1]


                            temp_scale_var = np.zeros(len(transformed_var_actual[sbu_idx][:,media_var_idx]))
                            
                            temp_scale_var[start_index:end_index] = transformed_var[start_index:end_index]          # transformed_var is only splitted var by index                        
                            transformed_var = temp_scale_var

                            # Store the Lg, Hf, Thr, Sat
                            # x_temp = x
                            halflife_temp, threshold_temp, saturation_temp, lag_temp = (halflife, threshold, saturation, lag)
                            recal_flag = True

                            transformed_media[media_var_idx] = np.asarray(
                                transformed_var
                            )  # X_mk
                            sepehr_fc = transformed_var.std()/ transformed_var.mean()


                            if use_ridge:

                                scaled_prior[media_var_idx] = coef_mean_prior[media_var_idx]*scaling_factor
                                lambda_k[media_var_idx] = (
                                    1 / (sepehr_fc * scaled_prior[media_var_idx]) ** 2
                                    if lambda_k_val
                                    else variance_calculation(outcome_by_sbu[sbu_idx])
                                    / (lambda_denominator)
                                )
                                sepehr_fc_list[media_var_idx] = sepehr_fc
                            
                            else:
                                lambda_k[media_var_idx] = 0.0
                                scaled_prior[media_var_idx] = 0.0                                
                            
                            # print('------' + str(media_var_idx) + '-----')
                            # print([halflife, threshold, saturation, lag])

                        else:
                            # x = x_temp
                            halflife, threshold, saturation, lag = (halflife_temp, threshold_temp, saturation_temp, lag_temp)

                            transformed_var = temp_transformed_var_lg_hf

                            # Split the transformed variable
                            indices = np.nonzero(transformed_var_actual[sbu_idx][:,media_var_idx])[0]
                            start_index = indices[0]
                            end_index = indices[-1]

                            temp_scale_var = np.zeros(len(transformed_var_actual[sbu_idx][:,media_var_idx]))
                            temp_scale_var[start_index:end_index] = transformed_var[start_index:end_index]          # transformed_var is only splitted var by index                        
                            transformed_var = temp_scale_var


                            transformed_media[media_var_idx] = np.asarray(
                                transformed_var
                            )  # X_mk

                            sepehr_fc = transformed_var.std()/ transformed_var.mean()
                            if use_ridge:
                            
                                scaled_prior[media_var_idx] = coef_mean_prior[media_var_idx]*scaling_factor
                                lambda_k[media_var_idx] = (
                                    1 / (sepehr_fc * scaled_prior[media_var_idx]) ** 2
                                    if lambda_k_val
                                    else variance_calculation(outcome_by_sbu[sbu_idx])
                                    / (lambda_denominator)
                                )
                                sepehr_fc_list[media_var_idx] = sepehr_fc
                            
                            else:
                                lambda_k[media_var_idx] = 0.0
                                scaled_prior[media_var_idx] = 0.0                                

                            if split_group[0][-1] == media_var_idx:                         ## if media_index is last in the group : set flag to false 
                                recal_flag = False

                            # print('------' + str(media_var_idx) + '-----')
                            # print([halflife, threshold, saturation, lag])


                        ## Category WAMM : var_mean for splitted variables individually

                        # indices = np.nonzero(transformed_var_actual[sbu_idx][:,media_var_idx])[0]
                        # start_index = indices[0]
                        # end_index = indices[-1]

                        # temp_scale_var = np.zeros(len(transformed_var))
                        # temp_scale_var[start_index:end_index] = transformed_var[start_index:end_index]          # transformed_var is only splitted var by index                        
                        # transformed_var = temp_scale_var
                        # print('-----------')                    
                        # print(media_var_idx)
                        # print(x)

                    else:
                        transformed_var = transformed_var_actual[sbu_idx][
                            :, media_var_idx
                        ]
                        
                        if lag != 0:
                            transformed_var = lag_transformation(transformed_var, lag)
                        if halflife != 0:
                            transformed_var = halflife_transformation(
                                transformed_var, halflife
                            )

                        var_mean = transformed_var.mean()

                        # calculate scale and inflection
                        if var_mean > 0:
                            inflection = (saturation + threshold) / (2 * var_mean)
                        else:
                            inflection = 0
                        if (saturation - threshold) > 0:
                            scale = ((2 * var_mean) * 4.59511985013) / (
                                saturation - threshold
                            )
                        else:
                            scale = 0
                        if (scale != 0) and (inflection != 0):
                            transformed_var_scaled = transformed_var / var_mean
                            saturation_term = scale * (inflection - transformed_var_scaled)
                            scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (
                                1 + np.exp(scale * inflection)
                            )
                            scurve_var_mean = scurve_var[:train_end_index].mean()
                            transformed_var = scurve_var * var_mean / scurve_var_mean

                        
                        if apply_scaling:
                            scaling_factor = max(transformed_var) - min(transformed_var)
                            transformed_var = (
                                transformed_var
                                - min(transformed_var)
                            ) / scaling_factor                    
                        
                        transformed_var = transformed_var[:train_end_index]
                        transformed_media[media_var_idx] = np.asarray(
                            transformed_var
                        )  # X_mk
                        sepehr_fc = transformed_var.std()/ transformed_var.mean()
                        if use_ridge:

                            scaled_prior[media_var_idx] = coef_mean_prior[media_var_idx]*scaling_factor
                            lambda_k[media_var_idx] = (
                                1 / (sepehr_fc * scaled_prior[media_var_idx]) ** 2
                                if lambda_k_val
                                else variance_calculation(outcome_by_sbu[sbu_idx])
                                / (lambda_denominator)
                            )
                            sepehr_fc_list[media_var_idx] = sepehr_fc

                        else:
                            lambda_k[media_var_idx] = 0.0
                            scaled_prior[media_var_idx] = 0.0                                
                        recal_flag = False

                        # print('------' + str(media_var_idx) + '-----')
                        # print([halflife, threshold, saturation, lag])
                        # print('-----------')                    
                        # print(media_var_idx)
                        # print(x)


                    i += 4
                    j += 4

                #     # Spread S-curve for splitted variables

                    # print('lambda_k : ' + str(media_var_idx))
                    # print((lambda_k[media_var_idx]))

                    # print('variance y_tilde : ' + str(media_var_idx))
                    # print((variance_calculation(outcome_by_sbu[sbu_idx])))

                    # print('Coef Var : '  + str(media_var_idx))
                    # print((sepehr_fc_list[media_var_idx]))

                    # print('Scaled   : '  + str(media_var_idx))
                    # print((scaled_prior[media_var_idx]))
                ### Caclulating media Betas for each set of non media variables ###
                ### Category WAMM : Media Coefficients will be different for each Splitted variable

                X_tilde = np.zeros((num_non_media_vars, num_media_vars, train_end_index))
                Beta = np.zeros((num_non_media_vars, num_media_vars))
                pos_coeffs_j = []
                neg_coeff_var = []
                log_solution = 0
                for non_media_idx in range(num_non_media_vars):
                    U_kj = pre_processed_matrix_U_kj[sbu_idx][non_media_idx][
                        :train_end_index, :train_end_index
                    ]
                    Y_kj = pre_processed_matrix_Y_kj[sbu_idx][non_media_idx][
                        :train_end_index
                    ]

                    var_y = Y_kj.std()
                    var_y = var_y**2

                    X_tilde_j = np.zeros((num_media_vars, train_end_index))

                    for i in range(num_media_vars):
                        X_tilde_j[i] = (U_kj * transformed_media[i]).sum(axis=1)

                    X_tilde[non_media_idx] = np.asarray(X_tilde_j)

                    I = np.identity(num_media_vars)
                    for i in range(num_media_vars):
                        lambda_k[i] = lambda_k[i] * var_y

                        if lambda_k[i] < 0.01:
                            lambda_k[i] = 1
                        if lambda_k[i] > 30:
                            lambda_k[i] = 30


                        I[i][i] = lambda_k[i]

                    val_2 = np.dot(
                        X_tilde[non_media_idx], X_tilde[non_media_idx].transpose()
                    )

                    P_mkj = inv(I + val_2)

                    Q_mkj = np.dot(X_tilde[non_media_idx], Y_kj) + np.dot(
                        lambda_k, scaled_prior
                    )

                    Beta_j = np.dot(P_mkj, Q_mkj)
                    Beta[non_media_idx] = Beta_j
                    
                    if log_details > 0:
                        with objmode():
                            self.solution_beta_arr = Beta_j.copy()                    
                    if (Beta_j > 0).sum() > 0:
                        pos_coeffs_j.append((Beta_j > 0).sum())
                    else:
                        pos_coeffs_j.append(0)
                        neg_coeff_var.append(media_var_idx)
                    if (Beta_j > 0).sum() == num_media_vars:
                        log_solution = 1

                count_pos_coef = max(pos_coeffs_j)
                J_star = np.array([
                    i for i, num in enumerate(pos_coeffs_j) if num == count_pos_coef
                ])

                ### Calculating objective function loss ###
                min_loss = np.inf
                for i in J_star:
                    term_1 = np.sum(
                        np.square(
                            pre_processed_matrix_Y_kj[sbu_idx][i][:train_end_index]
                            - np.dot(Beta[i], X_tilde[i])))
                    term_2 = ((lambda_k * np.square(Beta[i] - scaled_prior)).sum())
                    term_3, term_2_1 = 0.0, 0.0
                    if use_iroas_penalty:       ### CAT WAMM : train_price entire model
                        contribution = Beta[i]*transformed_media.sum(axis=1)
                        iroas = contribution * train_price / train_spend
                        term_2_1 = (
                            lambda_k * np.square(iroas - media_roas_prior)
                        ).sum()
                        iroas_penalty = np.where((iroas>=iroas_lb) & (iroas<=iroas_ub),0,1)
                        if log_details > 0:
                            with objmode():
                                self.solution_contri_arr = contribution.copy()
                                self.solution_iroas_arr = iroas.copy()
                                self.solution_iroas_penalty_arr = iroas_penalty.copy()
                        # sum up the penalty and scale to [0,1]
                        term_3 = iroas_penalty.sum()/num_media_vars


                    if iroas_dev_in_loss:
                        loss = (
                            term_1 / SST
                            + term_2 / SST
                            + term_2_1
                            + (term_3 * iroas_penalty_multiplier)
                        )
                    else:
                        loss = (
                            term_1 / SST
                            + term_2 / SST
                            + (term_3 * iroas_penalty_multiplier)
                        )

                    min_loss = min(min_loss, loss)
                    if (log_details > 0):
                        with objmode():
                            save_iteration_log(sbu_idx, log_details, SST, term_1, term_2, term_2_1, term_3, min_loss)   

                if (log_solution > 0) and (term_1 / SST <= 0.3) and (term_3 <= 0.3):
                    with objmode():
                        save_intermediate_solution(sbu_idx, x, term_3, debug_flag)

                if is_premium and use_sign_penalty:
                    sbu_losses[sbu_idx] = min_loss * 1.0 + (1-max(pos_coeffs_j)/num_media_vars) 
                else:
                    sbu_losses[sbu_idx] = min_loss
                log_solution_total += log_solution

            for i in range(num_sbu):
                total_loss += sbu_losses[i]  # /np.max(brand_losses)
            
            return total_loss

        if solution_save:
            return optimization_fn_numba(initial_solution)

        if global_opt:
            solution = differential_evolution.differential_evolution(
                optimization_fn_numba,
                bnds,
                maxiter = 100,
                popsize=15,
                seed=seed,
                workers=7,
                tol=0.01,
                disp=True,
                updating="deferred", 
                mutation=(0.5, 1.5),
                strategy="best1bin",
                recombination=0.8,
                x0=initial_solution,
                polish=False,
                fix_iterations=self.fix_iterations
            )
        else:
            solution = minimize(
                optimization_fn_numba,
                initial_solution,
                bounds=bnds,
                method="SLSQP",
                options={"disp": True},
            )

        solution.saved_solutions.append(
            np.concatenate((solution.x, np.array([optimization_fn_numba(solution.x)])))
        )

        return solution

    def run_optimizer(self, seed, global_opt=True):
        self.solution = self.run_DE(
            seed,
            self.num_sbu,
            self.num_media_vars,
            self.num_media_vars_og,
            self.train_end_index,
            self.transformed_var_actual,
            self.transformed_spend_var_actual,
            self.pre_processed_matrix_U_kj,
            self.pre_processed_matrix_Y_kj,
            self.num_non_media_vars,
            self.coef_mean_prior,
            self.coef_var_prior,
            self.outcome_by_sbu_actual,
            self.bnds,
            self.initial_solution,
            self.split_media_index,
            self.lambda_k_val,
            self.iroas_dev_in_loss,
            global_opt,
            media_roas_prior=self.media_iroas_prior,
            use_ridge = self.use_ridge,
            is_premium = self.is_premium,
            lambda_denominator = self.lambda_denominator, 
            use_sign_penalty = self.use_sign_penalty,
            use_iroas_penalty = self.use_iroas_penalty,
            iroas_penalty_multiplier = self.iroas_penalty_multiplier,
            iroas_lb = self.iroas_lb,
            iroas_ub = self.iroas_ub, 
            train_spend = self.train_spend,
            train_price = self.train_price,
            common_s_curve= self.common_s_curve,
            handle_added_value = self.handle_added_value
        )

    ################################ Solution Processing ################################

    def get_beta(
        self,
        pre_processed_matrix_U_kj,
        pre_processed_matrix_Y_kj,
        transformed_media,
        lambda_k,
        transformed_total,
        sbu_idx,
        scaled_prior
    ):
        ### Caclulating media Betas for each set of non media variables ###
        X_tilde = np.zeros((self.num_non_media_vars, self.num_media_vars, self.train_end_index))
        X_tilde_all = np.zeros((self.num_non_media_vars, self.num_media_vars, len(transformed_total[0])))

        Beta = np.zeros((self.num_non_media_vars, self.num_media_vars))

        for non_media_idx in range(self.num_non_media_vars):
            U_kj = pre_processed_matrix_U_kj[sbu_idx][non_media_idx][
                : self.train_end_index, : self.train_end_index
            ]
            U_kj_all = pre_processed_matrix_U_kj[sbu_idx][non_media_idx][:, :]

            Y_kj = pre_processed_matrix_Y_kj[sbu_idx][non_media_idx][
                : self.train_end_index
            ]
            
            var_y = (Y_kj.std()) ** 2
            
            X_tilde_j = np.zeros((self.num_media_vars, self.train_end_index))
            X_tilde_j_all = np.zeros((self.num_media_vars, len(transformed_total[0])))

            for i in range(self.num_media_vars):
                X_tilde_j[i] = (U_kj * transformed_media[i]).sum(axis=1)

            for i in range(self.num_media_vars):
                X_tilde_j_all[i] = (U_kj_all * transformed_total[i]).sum(axis=1)

            X_tilde[non_media_idx] = np.asarray(X_tilde_j)
            X_tilde_all[non_media_idx] = np.asarray(X_tilde_j_all)

            I = np.identity(self.num_media_vars)
            for i in range(self.num_media_vars):
                lambda_k[i] = var_y * lambda_k[i]

                if lambda_k[i] < 0.01:
                    lambda_k[i] = 1
                if lambda_k[i] > 30:
                    lambda_k[i] = 30


                I[i][i] = lambda_k[i]

            val_2 = np.dot(
                X_tilde[non_media_idx], X_tilde[non_media_idx].transpose()
            )

            P_mkj = inv(I + val_2)

            Q_mkj = np.dot(X_tilde[non_media_idx], Y_kj) + np.dot(
                lambda_k, scaled_prior
            )

            Beta_j = np.dot(P_mkj, Q_mkj)
            Beta[non_media_idx] = Beta_j

        return Beta, X_tilde, X_tilde_all

    def get_params(
        self, solution, sbu_idx, media_variables, df_by_sbu, transformed_var_actual, transformed_spend_var_actual
    ):
        # halflife, threshold, saturation, lag
        i = 0
        j = 4
        hf, inf, sc, lg, thr, sat = {}, {}, {}, {}, {}, {}
        df_filtered = df_by_sbu.copy()
        transformed_media = np.zeros((self.num_media_vars, self.train_end_index))
        transformed_total = np.zeros((self.num_media_vars, len(transformed_var_actual[0])))
        
        scaled_prior = np.zeros(len(media_variables))
        lambda_k = np.zeros(self.num_media_vars)
        SST = np.sum(
            (
                self.outcome_by_sbu[sbu_idx]
                - np.mean(self.outcome_by_sbu[sbu_idx])
            )
            ** 2
        )
        for media_var_idx in range(self.num_media_vars):

            decision_vars = solution[i:j]

            hf[media_variables[media_var_idx]], halflife = (
                decision_vars[0],
                decision_vars[0],
            )

            thr[media_variables[media_var_idx]], threshold = (
                decision_vars[1],
                decision_vars[1],
            )
            sat[media_variables[media_var_idx]], saturation = (
                decision_vars[2],
                decision_vars[2],
            )
            lg[media_variables[media_var_idx]], lag = int(decision_vars[3]), int(
                decision_vars[3]
            )

            transformed_var = transformed_var_actual[sbu_idx][:, media_var_idx]

            transformed_spend = transformed_spend_var_actual[sbu_idx][
                        :, media_var_idx
                    ]
            if self.handle_added_value:
                transformed_var = transformed_var * transformed_spend ### ignore spend = 0 for added value

            if lag != 0:
                transformed_var = lag_transformation(transformed_var, lag)
            if halflife != 0:
                transformed_var = halflife_transformation(transformed_var, halflife)

            var_mean = transformed_var.mean()

            # calculate scale and inflection
            if var_mean > 0:
                inflection = (saturation + threshold) / (2 * var_mean)
            else:
                inflection = 0
            inf[media_variables[media_var_idx]] = inflection
            if (saturation - threshold) > 0:
                scale = ((2 * var_mean) * 4.59511985013) / (saturation - threshold)
            else:
                scale = 0
            sc[media_variables[media_var_idx]] = scale

            if (scale != 0) and (inflection != 0):
                transformed_var_scaled = transformed_var / var_mean
                saturation_term = scale * (inflection - transformed_var_scaled)
                scurve_var = 1 / (1 + np.exp(saturation_term)) - 1 / (
                    1 + np.exp(scale * inflection)
                )
                scurve_var_mean = scurve_var[: self.train_end_index].mean()
                transformed_var = scurve_var * var_mean / scurve_var_mean

            scaling_factor = max(transformed_var) - min(transformed_var)
            sepehr_fc = transformed_var.std()/transformed_var.mean()
            # scaling_factor = np.percentile(transformed_var, 99) - np.percentile(transformed_var, 1)            
            
            transformed_var = (transformed_var - min(transformed_var)) / scaling_factor
            #sepehr_fc = transformed_var.std()/ transformed_var.mean()
            transformed_total[media_var_idx] = np.asarray(transformed_var)
            transformed_var = transformed_var[: self.train_end_index]
            transformed_media[media_var_idx] = np.asarray(transformed_var)  # X_mk
            if self.use_ridge:

                scaled_prior[media_var_idx] = (
                    self.coef_mean_prior[media_var_idx] * scaling_factor
                )
                lambda_k[media_var_idx] = (#variance_calculation(self.outcome_by_brand[brand_idx])
                    1 /(sepehr_fc * scaled_prior[media_var_idx])**2#self.lambda_k_val
                    if self.lambda_k_val
                    else variance_calculation(self.outcome_by_brand[sbu_idx])
                    / (self.lambda_denominator)
                )  # Lambda_mk

                if lambda_k[media_var_idx] < 0.01:
                    lambda_k[media_var_idx] = 1
                if lambda_k[media_var_idx] > 30:
                    lambda_k[media_var_idx] = 30



            else:
                lambda_k[media_var_idx] = 0.0
                scaled_prior[media_var_idx] = 0.0

            i += 4
            j += 4

        beta, X_tilde, X_tilde_all = self.get_beta(
            self.pre_processed_matrix_U_kj,
            self.pre_processed_matrix_Y_kj,
            transformed_media,
            lambda_k,
            transformed_total,
            sbu_idx,
            scaled_prior
        )

        return (
            beta,
            transformed_media,
            transformed_total,
            hf,
            inf,
            sc,
            lg,
            thr,
            sat,
            X_tilde,
            X_tilde_all,
        )

    def run_diagnostics(self): # willl only work with single brand and single base

        if self.is_premium:
            solutions_list = []
            # sol_details : brand_idx,log_details,SST,term_1,term_2,term_3,min_loss
            transformation_arr, iteration_number, sst, term_1, term_2, term_2_1, term_3, min_loss = [], [], [], [], [], [], [], []
            for sol in self.iteration_logs:
                term_1_by_sst = sol[1][3]/sol[1][2]
                term_2_by_sst = sol[1][4]/sol[1][2]
                transformation_arr = np.reshape(sol[0],(self.num_media_vars,4)).tolist()
                iteration_log_result_dict = {
                            
                            "Brand_name": self.sbu_list[0],
                            "Iteration_number": sol[1][1],
                            "sst" : sol[1][2],
                            "term_1" : sol[1][3],
                            "term_1_by_sst" : term_1_by_sst,
                            "term_2" : sol[1][4],
                            "term_2_by_sst" : term_2_by_sst,
                            "term_2_1": sol[1][5],
                            "term_3" : sol[1][5],
                            "min_loss" : sol[1][6],
                            "media_variable" : self.media_variables,
                            "Tactic_iroas" : sol[4],
                            "Tactic_contri" : sol[3],
                            "Tactic_coef" : sol[2],
                            "Tactic_iroas_penalty" : sol[5],
                            "Transformation": transformation_arr

                        }
                iteration_log_results = pd.DataFrame.from_dict(iteration_log_result_dict)
                solutions_list.append(iteration_log_results)

            combined_iteration_log = pd.concat(solutions_list)
            
            combined_iteration_log.to_csv(f"{self.folder_path}/iteration_log_details.csv",index=False)

    def load_pickle_files(self, seed):
        self.seed = seed
        self.sbu_level_sol = {}
        selected_sol = self.solution.saved_solutions
        iteration_sols_count = len(selected_sol)
        print("saved solution at end of iterations:", len(selected_sol), "\n")
        for sbu in self.sbu_list:
            try:
                interim_sols = [
                    filename
                    for filename in os.listdir(self.folder_path)
                    if filename.startswith(f"interim_sol_{sbu}")
                ]
                solutions_res = []
                for file_name in interim_sols:
                    file = os.path.join(self.folder_path, file_name)
                    objects = []
                    with open(file, "rb") as f:
                        while True:
                            try:
                                obj = pickle.load(f)
                                objects.append(obj)
                            except EOFError:
                                break
                    solutions_res += objects

                combined_sol = [l.tolist() for l in (selected_sol + solutions_res)]
                combined_sol.sort()
                combined_sol = list(
                    combined_sol for combined_sol, _ in itertools.groupby(combined_sol)
                )
                combined_sol = [np.asarray(arr) for arr in combined_sol]
            except:
                print("no interim solutions for sbu", sbu)
            self.sbu_level_sol[sbu] = combined_sol

        for sbu, sols in self.sbu_level_sol.items():
            print(
                sbu,
                "number of solutions loaded from pickle file",
                abs(len(sols) - iteration_sols_count),
                "\n"
            )
        print("saving iteration logs \n")
        self.run_diagnostics()
        print("************* saving iteration logs - Done ************* \n")


    def process_solution(self, args):
        (df_by_sbu, sbu_idx, YoY_comparison, i, sol) = args
        df_yoy_sets = []
        for k, v in YoY_comparison.items():
            sub_dfs = []
            for st, end in eval(v):
                idx = (df_by_sbu["Date"] >= st) & (df_by_sbu["Date"] <= end)
                st_idx = df_by_sbu[idx].index.min()
                end_idx = df_by_sbu[idx].index.max()
                sub_dfs.append((st_idx, end_idx))
            df_yoy_sets.append(sub_dfs)

        non_media_df = pd.DataFrame()
        (
            beta,
            transformed_media,
            transformed_total,
            hf,
            inf,
            sc,
            lg,
            thr,
            sat,
            X_tilde,
            X_tilde_all,
        ) = self.get_params(
            sol[:-1],
            sbu_idx,
            self.media_variables,
            df_by_sbu,
            self.transformed_var_actual,
            self.transformed_spend_var_actual
        )
        X_tilde_valid = X_tilde_all[:, :, self.train_end_index :]

        for non_media_idx in range(self.num_non_media_vars):
            Y_tilde_train = self.pre_processed_matrix_Y_kj[sbu_idx][non_media_idx][
                : self.train_end_index
            ]
            Y_tilde_valid = self.pre_processed_matrix_Y_kj[sbu_idx][non_media_idx][
                self.train_end_index :
            ]

            total_spend, total_cont, total_train_outcome, total_valid_outcome = (
                0,
                0,
                0,
                0,
            )
            (
                solution_number_col,
                driver_col,
                seed_col,
                coeff,
                overall_iroas_col,
                inf_pt_y,
            ) = (
                [],
                [],
                [],
                [],
                [],
                [],
            )
            initial_solution_col, obj_value_col = ([], [])
            train_rsq, train_mp, valid_rsq, valid_mp = [], [], [], []
            iroas_res, DE_sol, transf_res, thres_sat_res = [], [], [], []
            (
                iroas,
                media_iroas_arr,
                transformations,
                coefficient,
                thres_sat,
                inflection_point_y,
            ) = (
                {},
                [],
                {},
                {},
                {},
                {},
            )
            hf_res, inf_res, sc_res, lg_res, thresh_res, sat_res = (
                [],
                [],
                [],
                [],
                [],
                [],
            )

            price = df_by_sbu["PRICE"][: self.train_end_index].mean()

            for idx in range(self.num_media_vars):
                media_var = self.media_variables[idx]
                if "_IMP" in self.media_variables[idx]:
                    spend_var = self.media_variables[idx].replace("_IMP", "_SPEND")
                else:
                    spend_var = self.media_variables[idx].replace("_CLK", "_SPEND")



                coef = beta[non_media_idx][idx]

                term = coef * transformed_media[idx]
                total_train_outcome += term

                valid_term = coef * transformed_total[idx][self.train_end_index :]
                total_valid_outcome += valid_term

                total_cont += term.sum()
                iroas_val = (term.sum() * price) / df_by_sbu[spend_var][
                    : self.train_end_index
                ].sum()
                iroas[self.media_variables[idx]] = iroas_val
                media_iroas_arr.append(iroas_val)
                total_spend += df_by_sbu[spend_var][: self.train_end_index].sum()

                transformations[self.media_variables[idx]] = [
                    hf[self.media_variables[idx]],
                    inf[self.media_variables[idx]],
                    sc[self.media_variables[idx]],
                    lg[self.media_variables[idx]],
                ]
                thres_sat[self.media_variables[idx]] = [
                    thr[self.media_variables[idx]],
                    sat[self.media_variables[idx]],
                ]
                coefficient[self.media_variables[idx]] = beta[non_media_idx][idx]
                inflection_point_y[self.media_variables[idx]] = (
                    inf[self.media_variables[idx]]
                    * df_by_sbu[self.media_variables[idx]].mean()
                )

            overall_iroas = total_cont * price / total_spend

            ### Monotonic Incremental Contribution in Spend YoY
            monotonic_inc_contrib_overall, monotonic_inc_contrib_tactic = [], []
            for sub_dfs in df_yoy_sets:
                idx1, idx2, idx3, idx4 = (
                    sub_dfs[0][0],
                    sub_dfs[0][1],
                    sub_dfs[1][0],
                    sub_dfs[1][1],
                )
                df_1 = df_by_sbu[idx1 : idx2 + 1]
                df_2 = df_by_sbu[idx3 : idx4 + 1]
                price_1, price_2 = df_1["PRICE"].mean(), df_2["PRICE"].mean()
                total_cont_1, total_cont_2, total_spend_1, total_spend_2 = 0, 0, 0, 0
                media_contrib_1, media_spend_1, media_contrib_2, media_spend_2 = (
                    {},
                    {},
                    {},
                    {},
                )

                for idx in range(self.num_media_vars):
                    media_var = self.media_variables[idx]
                    if "_IMP" in self.media_variables[idx]:
                        spend_var = self.media_variables[idx].replace("_IMP", "_SPEND")
                    else:
                        spend_var = self.media_variables[idx].replace("_CLK", "_SPEND")


                    total_cont_1 += coef * transformed_total[idx][idx1 : idx2 + 1].sum()
                    total_cont_2 += coef * transformed_total[idx][idx3 : idx4 + 1].sum()

                    media_spend_1[media_var] = df_1[spend_var].sum()
                    total_spend_1 += df_1[spend_var].sum()
                    media_spend_2[media_var] = df_2[spend_var].sum()
                    total_spend_2 += df_2[spend_var].sum()

                    media_contrib_1[media_var] = (
                        coef * transformed_total[idx][idx1 : idx2 + 1].sum()
                    ) * price_1
                    media_contrib_2[media_var] = (
                        coef * transformed_total[idx][idx3 : idx4 + 1].sum()
                    ) * price_2

                    if "_IMP" in media_var:
                        if (
                            (media_spend_2[media_var] > media_spend_1[media_var])
                            and (
                                media_contrib_2[media_var] < media_contrib_1[media_var]
                            )
                        ) or (
                            (media_spend_2[media_var] < media_spend_1[media_var])
                            and (
                                media_contrib_2[media_var] > media_contrib_1[media_var]
                            )
                        ):
                            monotonic_inc_contrib_tactic.append(False)
                        else:
                            monotonic_inc_contrib_tactic.append(True)
                    else:
                        if (media_spend_2[media_var] > media_spend_1[media_var]) and (
                            media_contrib_2[media_var] < media_contrib_1[media_var]
                        ):
                            monotonic_inc_contrib_tactic.append(False)
                        else:
                            monotonic_inc_contrib_tactic.append(True)
                overall_contrib_1 = total_cont_1 * price_1
                overall_contrib_2 = total_cont_2 * price_2

                if (total_spend_2 > total_spend_1) and (
                    overall_contrib_2 < overall_contrib_1
                ):
                    monotonic_inc_contrib_overall.append(False)
                else:
                    monotonic_inc_contrib_overall.append(True)

            monotonic_inc_contrib_tactic_bool = all(monotonic_inc_contrib_tactic)
            monotonic_inc_contrib_overall_bool = all(monotonic_inc_contrib_overall)

            train_error = Y_tilde_train - np.dot(
                beta[non_media_idx], X_tilde[non_media_idx]
            )
            valid_error = Y_tilde_valid - np.dot(
                beta[non_media_idx], X_tilde_valid[non_media_idx]
            )

            train_mape = (
                np.abs(train_error / df_by_sbu[self.outcome][: self.train_end_index])
                * 100
            ).mean()
            valid_mape = (
                np.abs(valid_error / df_by_sbu[self.outcome][self.train_end_index :])
                * 100
            ).mean()

            ss_tot_train = (
                (
                    df_by_sbu[self.outcome][: self.train_end_index]
                    - df_by_sbu[self.outcome][: self.train_end_index].mean()
                )
                ** 2
            ).sum()
            ss_tot_valid = (
                (
                    df_by_sbu[self.outcome][self.train_end_index :]
                    - df_by_sbu[self.outcome][self.train_end_index :].mean()
                )
                ** 2
            ).sum()

            r_sq_train = 1 - (train_error**2).sum() / ss_tot_train
            r_sq_valid = 1 - (valid_error**2).sum() / ss_tot_valid

            if (
                ((beta[non_media_idx] > 0).sum() == self.num_media_vars)
            ):
                driver_col += self.media_variables
                solution_number_col += [i] * len(self.media_variables)
                initial_solution_col += list(self.initial_solution)

                iroas_res += list(iroas.values())
                transf_res += list(transformations.values())
                hf_res += list(hf.values())
                inf_res += list(inf.values())
                sc_res += list(sc.values())
                lg_res += list(lg.values())
                thres_sat_res += list(thres_sat.values())
                thresh_res += list(thr.values())
                sat_res += list(sat.values())

                overall_iroas_col += [overall_iroas] * len(self.media_variables)
                train_rsq += [r_sq_train] * len(self.media_variables)
                train_mp += [train_mape] * len(self.media_variables)
                valid_rsq += [r_sq_valid] * len(self.media_variables)
                valid_mp += [valid_mape] * len(self.media_variables)
                obj_fn_loss = sol[-1]
                obj_value_col += [obj_fn_loss] * len(self.media_variables)
                seed_col += [self.seed] * len(self.media_variables)
                coeff += list(coefficient.values())
                inf_pt_y += list(inflection_point_y.values())
                DE_sol += list(sol)

                result_data = {
                    "Seed": seed_col,
                    "Sbu_name": [self.sbu_list[sbu_idx]]
                    * len(solution_number_col),
                    "Solution_number": solution_number_col,
                    "Non_media_set": [non_media_idx] * len(solution_number_col),
                    "Media_tactic": driver_col,
                    "Coefficient": coeff,
                    "Tactic_iRoAS": iroas_res,
                    "Overall_iroas": overall_iroas_col,
                    "YoY_Monotonic_tactic": [monotonic_inc_contrib_tactic_bool]
                    * len(solution_number_col),
                    "YoY_Monotonic_overall": [monotonic_inc_contrib_overall_bool]
                    * len(solution_number_col),
                    "Train_R_Square": train_rsq,
                    "Train_Mape": train_mp,
                    "Validation_R_Square": valid_rsq,
                    "Validation_Mape": valid_mp,
                    "Media_transformation (hf, inf, sc, lg)": transf_res,
                    "Halflife": hf_res,
                    "Inflection": inf_res,
                    "Scale": sc_res,
                    "Lag": lg_res,
                    "Threshold_Saturation": thres_sat_res,
                    "Threshold": thresh_res,
                    "Saturation": sat_res,
                    "Inflection_Point": inf_pt_y,
                    "DE_objective_value": obj_value_col,
                }

                results = pd.DataFrame.from_dict(result_data)
                non_media_df = non_media_df.append(results)

        return non_media_df


    # def save_solutions(self, seed):
    #     self.run_diagnostics()
    #     sbu_level_sol = {}
    #     selected_sol = self.solution.saved_solutions
    #     iteration_sols_count = len(selected_sol)
    #     print("saved solution at end of iterations:", len(selected_sol),"\n")

    #     for sbu in self.sbu_list:    
    #         try:
    #             interim_sols = [filename for filename in os.listdir(self.folder_path) if filename.startswith(f"interim_sol_{sbu}")]
    #             solutions_res = []
    #             for file_name in interim_sols:
    #                 file = os.path.join(self.folder_path, file_name)
    #                 objects = []
    #                 with open(file, 'rb') as f:
    #                     while True:
    #                         try:
    #                             obj = pickle.load(f)
    #                             objects.append(obj)
    #                         except EOFError:
    #                             break
    #                 solutions_res += objects
                                 
    #             combined_sol = [l.tolist() for l in (selected_sol + solutions_res)]
    #             combined_sol.sort()
    #             combined_sol = list(combined_sol for combined_sol,_ in itertools.groupby(combined_sol))                    
    #             combined_sol = [np.asarray(arr) for arr in combined_sol]
    #         except:
    #             print("no interim solutions for sbu", sbu)
    #         sbu_level_sol[sbu] = combined_sol
    #         print(f"Total solutions for sbu {sbu} = {len(combined_sol)}")# premium changes for consistency testing

    #     for sbu, sols in sbu_level_sol.items():
    #         print(sbu, "number of solutions loaded from pickle file", abs(len(sols) - iteration_sols_count))


    #     for sbu_idx in range(len(self.sbu_list)):
    #         sbu_df = pd.DataFrame()
    #         df_by_sbu = self.data[self.data["SBU"] == self.sbu_list[sbu_idx]]
    #         non_media_set = []
    #         print("\n sbu", self.sbu_list[sbu_idx])
    #         for i, sol in enumerate(sbu_level_sol[self.sbu_list[sbu_idx]]):
    #             non_media_df = pd.DataFrame()

    #             (
    #                 beta,
    #                 transformed_media,
    #                 transformed_total,
    #                 hf,
    #                 inf,
    #                 sc,
    #                 lg,
    #                 thr,
    #                 sat,
    #                 X_tilde,
    #                 X_tilde_all,
    #             ) = self.get_params(
    #                 sol[:-1],
    #                 sbu_idx,
    #                 self.media_variables,
    #                 df_by_sbu,
    #                 self.transformed_var_actual
    #             )
    #             if i < 300:
    #                 print(f"Beta for solution {i} : {beta}")

    #             X_tilde_valid = X_tilde_all[:, :, self.train_end_index :]
    #             #         transformed_validation_media = transformed_total[train_end_index:]

    #             for non_media_idx in range(self.num_non_media_vars):
    #                 Y_tilde_train = self.pre_processed_matrix_Y_kj[sbu_idx][
    #                     non_media_idx
    #                 ][: self.train_end_index]
    #                 Y_tilde_valid = self.pre_processed_matrix_Y_kj[sbu_idx][
    #                     non_media_idx
    #                 ][self.train_end_index :]

    #                 (
    #                     total_spend,
    #                     total_cont,
    #                     total_train_outcome,
    #                     total_valid_outcome,
    #                 ) = (0, 0, 0, 0)
    #                 (
    #                     solution_number_col,
    #                     driver_col,
    #                     seed_col,
    #                     coeff,
    #                     overall_iroas_col,
    #                     initial_solution_col,
    #                     obj_value_col,
    #                 ) = ([], [], [], [], [], [], [])
    #                 train_rsq, train_mp, valid_rsq, valid_mp = [], [], [], []
    #                 iroas_res, DE_sol, transf_res, thres_sat_res = [], [], [], []
    #                 iroas, transformations, coefficient, thres_sat = {}, {}, {}, {}

    #                 price = df_by_sbu["PRICE"][: self.train_end_index].mean()

    #                 for idx in range(self.num_media_vars):
    #                     media_var = self.media_variables[idx]
    #                     # spend_var = self.media_variables[idx][:-4] + "_SPEND"
    #                     if "_IMP" in media_var:
    #                         spend_var = media_var.replace("_IMP", "_SPEND")
    #                     else:
    #                         spend_var = media_var.replace("_CLK", "_SPEND")

    #                     coef = beta[non_media_idx][idx]

    #                     ### media
    #                     term = coef * transformed_media[idx]
    #                     total_train_outcome += term

    #                     valid_term = (
    #                         coef * transformed_total[idx][self.train_end_index :]
    #                     )
    #                     total_valid_outcome += valid_term

    #                     if not media_var.startswith('M_NAT'):
    #                         total_cont += term.sum()
    #                     iroas[self.media_variables[idx]] = (
    #                         term.sum() * price
    #                     ) / df_by_sbu[spend_var][: self.train_end_index].sum()
                        
    #                     if not media_var.startswith('M_NAT'):
    #                         total_spend += df_by_sbu[spend_var][
    #                             : self.train_end_index
    #                         ].sum()

    #                     transformations[self.media_variables[idx]] = [
    #                         hf[self.media_variables[idx]],
    #                         inf[self.media_variables[idx]],
    #                         sc[self.media_variables[idx]],
    #                         lg[self.media_variables[idx]],
    #                     ]
    #                     thres_sat[self.media_variables[idx]] = [
    #                         thr[self.media_variables[idx]],
    #                         sat[self.media_variables[idx]],
    #                     ]
    #                     coefficient[self.media_variables[idx]] = beta[non_media_idx][
    #                         idx
    #                     ]

    #                 overall_iroas = total_cont * price / total_spend

    #                 # non_media_coef = self.sbu_non_media_coef[self.sbu_list[sbu_idx]][non_media_idx]

    #                 ##################### fit metrics ########################################
    #                 train_error = Y_tilde_train - np.dot(beta[non_media_idx], X_tilde[non_media_idx])
    #                 valid_error = Y_tilde_valid - np.dot(
    #                     beta[non_media_idx], X_tilde_valid[non_media_idx]
    #                 )

    #                 train_mape = np.abs(train_error / Y_tilde_train) * 100
    #                 valid_mape = np.abs(valid_error / Y_tilde_valid) * 100

    #                 train_mape = train_mape.mean()
    #                 valid_mape = valid_mape.mean()

    #                 ss_tot_train = (
    #                     df_by_sbu[self.outcome][: self.train_end_index]
    #                     - df_by_sbu[self.outcome][: self.train_end_index].mean()
    #                 )# Janhavi : premium changes
    #                 ss_tot_train = ss_tot_train * ss_tot_train
    #                 ss_tot_train = ss_tot_train.sum()

    #                 ss_tot_valid = (
    #                     df_by_sbu[self.outcome][self.train_end_index :]
    #                     - df_by_sbu[self.outcome][self.train_end_index :].mean()
    #                 )# Janhavi : premium changes
    #                 ss_tot_valid = ss_tot_valid * ss_tot_valid
    #                 ss_tot_valid = ss_tot_valid.sum()

    #                 train_error = train_error * train_error
    #                 train_error = train_error.sum()
    #                 r_sq_train = 1 - train_error / ss_tot_train

    #                 valid_error = valid_error * valid_error
    #                 valid_error = valid_error.sum()
    #                 r_sq_valid = 1 - valid_error / ss_tot_valid
    #                 #########################################################################
    #                 if (beta[non_media_idx] > 0).sum() == self.num_media_vars:
    #                     driver_col += self.media_variables
    #                     solution_number_col += [i] * len(self.media_variables)
    #                     initial_solution_col += list(self.initial_solution)

    #                     iroas_res += list(iroas.values())
    #                     transf_res += list(transformations.values())
    #                     thres_sat_res += list(thres_sat.values())

    #                     overall_iroas_col += [overall_iroas] * len(self.media_variables)
    #                     train_rsq += [r_sq_train] * len(self.media_variables)
    #                     train_mp += [train_mape] * len(self.media_variables)
    #                     valid_rsq += [r_sq_valid] * len(self.media_variables)
    #                     valid_mp += [valid_mape] * len(self.media_variables)
    #                     obj_fn_loss = sol[-1]
    #                     obj_value_col += [obj_fn_loss] * len(self.media_variables)
    #                     seed_col += [seed] * len(self.media_variables)
    #                     coeff += list(coefficient.values())
    #                     DE_sol += list(sol)

    #                     non_media_set += [non_media_idx] * len(solution_number_col)
    #                     result_data = {
    #                         "Seed": seed_col,
    #                         "SBU_name": [self.sbu_list[sbu_idx]]
    #                         * len(solution_number_col),
    #                         "Solution_number": solution_number_col,
    #                         "Non_media_set": [non_media_idx] * len(solution_number_col),
    #                         "Media_tactic": driver_col,
    #                         "Coefficient": coeff,
    #                         "Tactic_iRoAS": iroas_res,
    #                         "Overall_iroas": overall_iroas_col,
    #                         "Train_R_Square": train_rsq,
    #                         "Train_Mape": train_mp,
    #                         "Validation_R_Square": valid_rsq,
    #                         "Validation_Mape": valid_mp,
    #                         "Media_transformation (hf, inf, sc, lg)": transf_res,
    #                         "Threshold_Saturation": thres_sat_res,
    #                         "DE_objective_value": obj_value_col,
    #                     }

    #                     results = pd.DataFrame.from_dict(result_data)

    #                     non_media_df = non_media_df.append(results)
    #             sbu_df = sbu_df.append(non_media_df)

    #         filename = (
    #             self.folder_path
    #             + "/results_"
    #             + str(self.sbu_list[sbu_idx])
    #             + "_"
    #             + str(seed)
    #             + ".csv"
    #         )
    #         sbu_df.to_csv(filename, index=False)
    #         print("filename:", filename, "\n")

    #     sol_filename = self.folder_path + "/solutions_" + str(seed) + ".txt"
    #     print("sol_filename:", sol_filename, "\n")
    #     i = 0
    #     with open(sol_filename, "w") as testfile:
    #         for row in self.solution.saved_solutions:
    #             i += 1
    #             testfile.write(str(i) + "\n")
    #             testfile.write(",".join([str(a) for a in row]) + "\n" + "\n")

    #     for sbu in self.sbu_list:
    #         try:
    #             df = pd.read_csv(
    #                 self.folder_path
    #                 + "/results_"
    #                 + str(sbu)
    #                 + "_"
    #                 + str(seed)
    #                 + ".csv"
    #             )
    #             print(
    #                 sbu, ":", len(list(df["Solution_number"].unique())), "solutions"
    #             )
    #         except:
    #             print(
    #                 "no solution found for sbu",
    #                 sbu,
    #                 "as no solution found with all positive coefficients",
    #             )

    def save_solutions(self):
        pool = mp.Pool(mp.cpu_count())

        for sbu_idx in range(len(self.sbu_list)):
            sbu_df = pd.DataFrame()
            df_by_sbu = self.data[self.data["SBU"] == self.sbu_list[sbu_idx]]
            print("\n sbu", self.sbu_list[sbu_idx])
            tasks = [
                (df_by_sbu, sbu_idx, self.YoY_comparison, i, sol)
                for i, sol in enumerate(
                    self.sbu_level_sol[self.sbu_list[sbu_idx]]
                )
            ]

            non_media_dfs = pool.map(self.process_solution, tasks)
            for non_media_df in non_media_dfs:
                sbu_df = sbu_df.append(non_media_df)

            filename = f"{self.folder_path}/results_{self.sbu_list[sbu_idx]}_{self.seed}.csv"
            sbu_df.to_csv(filename, index=False)
            print("filename:", filename, "\n")

        pool.close()
        pool.join()


    def save_txt(self):
        sol_filename = self.folder_path + "/solutions_" + str(self.seed) + ".txt"
        print("sol_filename:", sol_filename, "\n")
        i = 0
        with open(sol_filename, "w") as testfile:
            for row in self.solution.saved_solutions:
                i += 1
                testfile.write(str(i) + "\n")
                testfile.write(",".join([str(a) for a in row]) + "\n" + "\n")

        for sbu in self.sbu_list:
            try:
                df = pd.read_csv(
                    self.folder_path
                    + "/results_"
                    + str(sbu)
                    + "_"
                    + str(self.seed)
                    + ".csv"
                )
                print(
                    sbu,
                    ":",
                    len(list(df["Solution_number"].unique())),
                    "final solutions dumped to csv!",
                )
            except:
                print(
                    "no solution found for sbu",
                    sbu,
                    "as no solution found with all positive coefficients",
                )


    def get_spend_summary(self):
        ### Overall category level ###
        (
            self.min_spend,
            self.max_spend,
            self.mean_spend,
            self.median_spend,
            self.spend_share,
            self.spend_vars,
        ) = ([], [], [], [], [], [])

        for media_var in self.media_variables:
            if "_IMP" in media_var:
                spend_var = media_var.replace("_IMP", "_SPEND")
            else:
                spend_var = media_var.replace("_CLK", "_SPEND")
            self.spend_vars.append(spend_var)

        total_spend = self.data[self.spend_vars].sum().sum()

        for spend_var in self.spend_vars:
            self.min_spend.append(self.data[spend_var].min())
            self.max_spend.append(self.data[spend_var].max())
            self.mean_spend.append(self.data[spend_var].mean())
            self.median_spend.append(self.data[spend_var].median())
            self.spend_share.append(
                round(self.data[spend_var].sum() / total_spend * 100, 2)
            )

    def display_summary_1(self, seed, target_threshold, target_saturation):
        self.get_spend_summary()
        self.no_sol_sbu = []
        self.overall_iroas, self.tactic_iroas, self.tactic_coeff = {}, {}, {}
        for sbu in self.sbu_list:
            try:
                df = pd.read_csv(
                    self.folder_path
                    + "/results_"
                    + str(sbu)
                    + "_"
                    + str(seed)
                    + ".csv"
                )
                print(f"Summary for sbu {sbu}:")
                display(df.describe())
                df["delta_iroas"] = abs(
                    df["Tactic_iRoAS"]
                    - np.tile(self.media_iroas_prior, int(len(df["Tactic_iRoAS"]) / self.num_media_vars))
                )# Janhavi : premium changes
                df["delta_coef"] = abs(
                    df["Coefficient"]
                    - np.tile(self.coef_mean_prior, int(len(df["Coefficient"]) / self.num_media_vars))
                )# Janhavi : premium changes
                mean_vals = (
                    df[["delta_iroas", "delta_coef", "Solution_number"]]
                    .groupby("Solution_number")
                    .mean()
                    .to_dict()
                )
                sol_num_closest_iroas_to_mean = min(
                    mean_vals["delta_iroas"], key=mean_vals["delta_iroas"].get
                )
                try:
                    iroas_min_vals = sorted(
                        mean_vals["delta_iroas"], key=mean_vals["delta_iroas"].get
                    )[:5]
                    coef_min_vals = sorted(
                        mean_vals["delta_coef"], key=mean_vals["delta_coef"].get
                    )[:5]

                    common_sols = list(
                        set(iroas_min_vals).intersection(set(coef_min_vals))
                    )
                    if len(common_sols) > 0:
                        sol_num = (
                            df[df["Solution_number"].isin(common_sols) == True][
                                df["DE_objective_value"]
                                == df["DE_objective_value"].min()
                            ]["Solution_number"]
                            .unique()
                            .max()
                        )
                    else:
                        sol_num = iroas_min_vals[0]
                except:
                    sol_num = sol_num_closest_iroas_to_mean

                print("SBU:", sbu, ": Solution_number:", sol_num)
                Inflection = df[df["Solution_number"] == sol_num][
                    "Media_transformation (hf, inf, sc, lg)"
                ][:self.num_media_vars]
                Thresh_sat = df[df["Solution_number"] == sol_num][
                    "Threshold_Saturation"
                ][:self.num_media_vars]
                self.tactic_iroas[sbu] = df[df["Solution_number"] == sol_num][
                    "Tactic_iRoAS"
                ][:self.num_media_vars]
                self.overall_iroas[sbu] = df[df["Solution_number"] == sol_num][
                    "Overall_iroas"
                ][:self.num_media_vars]
                self.tactic_coeff[sbu] = df[df["Solution_number"] == sol_num][
                    "Coefficient"
                ][:self.num_media_vars]

                self.thresh_arr, self.inf_arr, self.sat_arr = [], [], []
                for var in range(len(self.media_variables)):
                    self.thresh_arr.append(ast.literal_eval(Thresh_sat.values[var])[0])
                    self.inf_arr.append(ast.literal_eval(Inflection.values[var])[1])
                    self.sat_arr.append(ast.literal_eval(Thresh_sat.values[var])[1])
                result_dict = {
                    "media_tactic": self.media_variables,
                    "target_threshold": target_threshold,
                    "target_saturation": target_saturation,
                    "Threshold": self.thresh_arr,
                    "Inflection": self.inf_arr,
                    "Saturation": self.sat_arr,
                    "Min_spend": self.min_spend,
                    "Max_spend": self.max_spend,
                    "Median_spend": self.median_spend,
                    "Mean_spend": self.mean_spend,
                    "Spend_share": self.spend_share,
                }
                table_1 = pd.DataFrame.from_dict(result_dict)
                display(table_1)
            except:
                self.no_sol_sbu.append(sbu)
                print("\n skipping sbu", sbu, "\n")

    def display_summary_2(self):
        ### brand level ###
        table_2 = pd.DataFrame()
        for sbu in self.sbu_list:
            try:
                (
                    b_min_spend,
                    b_max_spend,
                    b_mean_spend,
                    b_median_spend,
                    b_spend_share,
                    b_on_air,
                ) = ([], [], [], [], [], [])
                b_below_thresh, b_above_sat = [], []
                b_data = self.data[self.data["SBU"] == sbu].copy()
                b_total_spend = b_data[self.spend_vars].sum().sum()

                for var in range(len(self.spend_vars)):
                    if "SEARCH" in self.spend_vars[var] or "M_SP" in self.spend_vars[var] or "M_SBA" in self.spend_vars[var]:# Janhavi : premium changes
                        tactic = self.spend_vars[var].replace("_SPEND", "_CLK")
                    else:
                        tactic = self.spend_vars[var].replace("_SPEND", "_IMP")
                    b_min_spend.append(b_data[self.spend_vars[var]].min())
                    b_max_spend.append(b_data[self.spend_vars[var]].max())
                    b_mean_spend.append(b_data[self.spend_vars[var]].mean())
                    b_median_spend.append(b_data[self.spend_vars[var]].median())
                    b_spend_share.append(
                        round(
                            b_data[self.spend_vars[var]].sum() / b_total_spend * 100, 2
                        )
                    )
                    b_on_air.append(
                        round(
                            len(b_data[b_data[self.spend_vars[var]] > 0])
                            / len(b_data)
                            * 100,
                            2,
                        )
                    )

                    b_on_air_df = b_data[b_data[tactic] > 0].copy()
                    if sbu not in self.no_sol_sbu:
                        b_below_thresh.append(
                            round(
                                len(
                                    b_on_air_df[
                                        b_on_air_df[tactic] < self.thresh_arr[var]
                                    ]
                                )
                                / len(b_on_air_df)
                                * 100,
                                2,
                            )
                        )
                        b_above_sat.append(
                            round(
                                len(
                                    b_on_air_df[b_on_air_df[tactic] > self.sat_arr[var]]
                                )
                                / len(b_on_air_df)
                                * 100,
                                2,
                            )
                        )
                    else:
                        b_below_thresh.append(math.nan)
                        b_above_sat.append(math.nan)

                result_dict = {
                    "sbu": [sbu] * self.num_media_vars, # Janhavi : premium changes
                    "media_tactic": self.spend_vars,
                    "Min_spend": b_min_spend,
                    "Max_spend": b_max_spend,
                    "Median_spend": b_median_spend,
                    "Mean_spend": b_mean_spend,
                    "Spend_share": b_spend_share,
                    "Tactic_iroas": self.tactic_iroas[sbu],
                    "Overall_iroas": self.overall_iroas[sbu],
                    "Tactic_iroas_prior": list(self.media_iroas_prior),
                    "Tactic_coefficient": self.tactic_coeff[sbu],
                    "Coeff_mean_prior": list(self.coef_mean_prior),
                    "On air days": b_on_air,
                    "%days below threshold": b_below_thresh,
                    "%days above saturation": b_above_sat,
                }

                table_temp = pd.DataFrame.from_dict(result_dict)
                table_2 = table_2.append(table_temp)
            except:
                print("\n skipping sbu", sbu, "\n")
        display(table_2)
