import ast
import os
import sys
import warnings

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.stats as stats
import seaborn as sns
from fitter import Fitter
from scipy.stats import gaussian_kde, norm

warnings.filterwarnings("ignore")
from IPython.display import display

module_path = os.path.abspath(os.path.join("../src/utils"))
if module_path not in sys.path:
    sys.path.append(module_path)

if os.path.abspath("../src/config_dir") not in sys.path:
    sys.path.append(os.path.abspath("../src/config_dir"))

if module_path not in sys.path:
    sys.path.append(module_path)

from custom_mmm_modelling_ga import MMM_Modelling
from custom_modelling_plots_mod import ModellingPlots
from lite_wamm_modeling import create_folder_with_version

pd.set_option("display.max_columns", None)  # or 1000
pd.set_option("display.max_rows", None)  # or 1000
pd.set_option("display.max_colwidth", 199)  # or 199

data_dict = pd.read_excel("../data/input_data/WMG WAMM Project Data Dictionary_v19.xlsx")
modeling_parameters_shared_media_dictionary = {
    "IMP": "Impression",
    "SPEND": "Spend",
    "VIEW_IMP": "Viewable Impression",
    "CLK": "Click",
}
modeling_parameters_shared_media_hier_path = "../data/input_data/media_hierarchy.csv"
media_hier = pd.concat(
        [
            pd.read_csv(
                modeling_parameters_shared_media_hier_path.split(".csv")[0]
                + "_"
                + key
                + ".csv"
            )
            for key in modeling_parameters_shared_media_dictionary.keys()
        ],
        axis=0,
    )

other_variables = [] ## Ignore non media for S curves

def get_upd_media(media_variables, solution_arr):
    ### update media_vars with lag, halflife, inflection, scale
    i = 0
    j = 5
    media_var_upd = []
    coef = {}
    for var in media_variables:

        decision_vars = solution_arr[i:j]
        
        upd_var = var + '_' + str(int(decision_vars[4])) + '_' + str(decision_vars[1]) + '_' + str(decision_vars[2]) + '_' + str(decision_vars[3]) + '_0'
        media_var_upd.append(upd_var)
        coef[upd_var] = decision_vars[0]
        i += 5
        j += 5

    media_variables = media_var_upd
    return media_variables, coef

def get_5_point_summary(brand_df, brand_nm):
    print(f"Brand: {brand_nm}")
    media_tactics = brand_df["Media_tactic"].unique()
    bases = brand_df.Non_media_set.unique().tolist()
    selected_bases = []
    season = {"0": "MV_1", "1": "MV_2", "2": "MV_3", "3": "MV_4", "4": "MV_5", "5": "MV_6", "6": "MV_7", "7": "MV_8"
              , "8": "MV_9", "9": "MV_10"}
    for media in media_tactics:
        fig, axs = plt.subplots(1, len(bases), figsize=(15, 5))
        if len(bases) == 1:
            axs = [axs]
        for i, ax in enumerate(axs):
            filtered_df = brand_df[
                (brand_df["Non_media_set"] == bases[i])
                & (brand_df["Media_tactic"] == media)
            ]
            if len(filtered_df) > 0:
                selected_bases.append(bases[i])
                sns.histplot(data=filtered_df, x="Tactic_iRoAS", kde=True, ax=ax)
                ax.axvline(
                    filtered_df["Tactic_iRoAS"].mean(), color="r", linestyle="--"
                )
                ax.set_title(f"{media} / Base: {season[str(bases[i])]}")

                # Compute 5-point summary
                min_val = filtered_df["Tactic_iRoAS"].min()
                max_val = filtered_df["Tactic_iRoAS"].max()
                median_val = filtered_df["Tactic_iRoAS"].median()
                mean_val = filtered_df["Tactic_iRoAS"].mean()
                std_val = filtered_df["Tactic_iRoAS"].std()
                quartile1_val = filtered_df["Tactic_iRoAS"].quantile(0.25)
                quartile3_val = filtered_df["Tactic_iRoAS"].quantile(0.75)

                # Fit KDE and compute peak
                if filtered_df["Tactic_iRoAS"].dropna().shape[0] < 2:
                    peak_val = mean_val
                else:
                    kde = gaussian_kde(filtered_df["Tactic_iRoAS"].dropna())
                    x_vals = np.linspace(min_val, max_val, 1000)
                    peak_val = x_vals[np.argmax(kde(x_vals))]

                # Print 5-point summary and peak on the plot
                summary_text = f"Min: {round(min_val,2)}\nQ1: {round(quartile1_val, 2)}\nMedian: {round(median_val, 2)}\nMean: {round(mean_val, 2)}\nStd: {round(std_val, 2)} \nQ3: {round(quartile3_val, 2)}\nMax: {round(max_val, 2)}\nPeak: {round(peak_val, 2)}"
                ax.text(
                    0.95,
                    0.95,
                    summary_text,
                    transform=axs[i].transAxes,
                    verticalalignment="top",
                    horizontalalignment="right",
                )

        plt.tight_layout()
        plt.show()

    # Plot histogram of Overall iRoAS for different bases in one row
    fig, axs = plt.subplots(1, len(bases), figsize=(15, 5))
    max_overall_iroas = -float("inf")
    selected_base = 0
    if len(bases)==1:
        axs = [axs]
    for i, ax in enumerate(axs):
        df = brand_df[brand_df["Non_media_set"] == bases[i]]
        sns.histplot(data=df, x="Overall_iroas", kde=True, ax=ax)
        ax.axvline(df["Overall_iroas"].mean(), color="r", linestyle="--")
        ax.set_title(f"Overall_iroas: Base: {season[str(bases[i])]}")

        # Compute 5-point summary for Overall_iroas
        min_val = df["Overall_iroas"].min()
        max_val = df["Overall_iroas"].max()
        median_val = df["Overall_iroas"].median()
        mean_val = df["Overall_iroas"].mean()
        std_val = df["Overall_iroas"].std()
        quartile1_val = df["Overall_iroas"].quantile(0.25)
        quartile3_val = df["Overall_iroas"].quantile(0.75)
        if mean_val > max_overall_iroas:
            max_overall_iroas = max(mean_val, max_overall_iroas)
            selected_base = i
        # Fit KDE and compute peak for Overall_iroas
        # print(df['Overall_iroas'].shape)
        if df["Overall_iroas"].dropna().shape[0] < 4:
            peak_val = mean_val
        else:
            kde = gaussian_kde(df["Overall_iroas"].dropna())
            x_vals = np.linspace(min_val, max_val, 1000)
            peak_val = x_vals[np.argmax(kde(x_vals))]

        # Print 5-point summary and peak on the plot for Overall_iroas
        summary_text = f"Min: {round(min_val,2)}\nQ1: {round(quartile1_val, 2)}\nMedian: {round(median_val, 2)}\nMean: {round(mean_val, 2)}\nStd: {round(std_val, 2)} \nQ3: {round(quartile3_val, 2)}\nMax: {round(max_val, 2)}\nPeak: {round(peak_val, 2)}"
        ax.text(
            0.95,
            0.95,
            summary_text,
            transform=ax.transAxes,
            verticalalignment="top",
            horizontalalignment="right",
        )
    print(f'Max overall mean iroas is {max_overall_iroas} with base {selected_base}')
    plt.tight_layout()
    plt.show()
    return selected_base


def calculate_quantiles(df, brand, col_names, train_start, train_end):
    df["Date"] = pd.to_datetime(df["Date"])
    df.set_index("Date", inplace=True)

    avg_dic = {}
    for i in col_names:
        avg_dic[i] = []
    avg_dic["Brand"] = []
        

    # avg_dic = {col_names[0]: [], col_names[1]: [], col_names[2]: [], "Brand": []}
    avg_dic["Brand"].append(brand)

    tp = df[df["BRAND"] == brand]

    for col_name in col_names:
        tp_nzero = tp[tp[col_name] > 0]
        avg_dic[col_name].append(int(tp_nzero[col_name].mean()))

    avg_df = pd.DataFrame(avg_dic)
    
    df = df.sort_index().loc[train_start:train_end]
    stats = []
    for col_name in col_names:
        df_nonzero = df[df[col_name] != 0]
        perc_5 = int(df_nonzero[col_name].quantile(0.05))
        perc_95 = int(df_nonzero[col_name].quantile(0.95))
        mean = int(df_nonzero[col_name].mean())
        median = int(df_nonzero[col_name].quantile(0.5))
        Q1 = int(df_nonzero[col_name].quantile(0.25))
        Q3 = int(df_nonzero[col_name].quantile(0.75))
        stats.append([col_name, perc_5, perc_95, Q1, Q3, mean, median])

    stats_df = pd.DataFrame(
        stats,
        columns=[
            "Column",
            "5th_Quantile",
            "95th_Quantile",
            "Q1",
            "Q3",
            "Mean",
            "Median",
        ],
    )
    return stats_df


def shortlist_solutions(target_df, dictionary, brand, dev_threshold=0.3):    
    max_dev_strategy = False

    tact_median = {
        tc: target_df.loc[target_df.Media_tactic == tc, "Tactic_iRoAS"].median()
        for tc in target_df.Media_tactic.unique()
    }
    tact_mean = {
        tc: target_df.loc[target_df.Media_tactic == tc, "Tactic_iRoAS"].mean()
        for tc in target_df.Media_tactic.unique()
    }
    tact_q1 = {
        tc: target_df.loc[target_df.Media_tactic == tc, "Tactic_iRoAS"].quantile(0.25)
        for tc in target_df.Media_tactic.unique()
    }
    tact_q3 = {
        tc: target_df.loc[target_df.Media_tactic == tc, "Tactic_iRoAS"].quantile(0.75)
        for tc in target_df.Media_tactic.unique()
    }

    target_df[["Threshold", "Saturation"]] = pd.DataFrame(
        target_df.Threshold_Saturation.apply(
            lambda s: list(ast.literal_eval(s))
        ).tolist(),
        index=target_df.index,
    )

    target_df["iRoAS_Median"] = target_df["Media_tactic"].map(tact_median)
    target_df["iRoAS_Mean"] = target_df["Media_tactic"].map(tact_mean)
    target_df["Q1_iRoAS"] = target_df["Media_tactic"].map(tact_q1)
    target_df["Q3_iRoAS"] = target_df["Media_tactic"].map(tact_q3)
    target_df["Sat_Target"] = target_df["Media_tactic"].map(dictionary)
    target_df["tac_dev"] = (
        abs(target_df["Tactic_iRoAS"] - target_df["iRoAS_Median"])
        / target_df["iRoAS_Median"]
    )
    target_df["Inflection"] = (target_df["Saturation"] + target_df["Threshold"]) / 2
    target_df["Sat_Dev"] = target_df.apply(
        lambda row: (min((row["Saturation"] - row["Sat_Target"]), 0)) ** 2
        / row["Sat_Target"] ** 2,
        axis=1,
    )

    scores = target_df.groupby("Solution_number")["Sat_Dev"].sum().reset_index()
    scores.columns = ["Solution_number", "score_sat"]
    target_df = pd.merge(target_df, scores, on="Solution_number")

    scores = target_df.groupby("Solution_number")["tac_dev"].sum().reset_index()
    scores.columns = ["Solution_number", "score_iroas"]
    target_df = pd.merge(target_df, scores, on="Solution_number")
    target_df = target_df.sort_values("score_sat", ascending=True)
    t_summary = (
        target_df.groupby("Media_tactic")[["Saturation", "Inflection"]]
        .describe()
        .astype(int)
    )

    if max_dev_strategy:
        sol_select = [
            target_df.loc[target_df.Solution_number == i]
            for i in target_df.Solution_number.unique()
            if target_df.loc[target_df.Solution_number == i, "tac_dev"]
            .le(dev_threshold)
            .all()
        ]
    else:
        sol_select = []

        unique_solution_numbers = target_df["Solution_number"].unique()

        for solution_number in unique_solution_numbers:
            tp = target_df[target_df["Solution_number"] == solution_number]
            condition = (tp["Q1_iRoAS"] <= tp["Tactic_iRoAS"]) & (
                tp["Tactic_iRoAS"] <= tp["Q3_iRoAS"]
            )
            valid_row_count = condition.sum()
            if valid_row_count == 3:
                sol_select.append(tp)

    media_names = {
        "M_ON_DIS_TOTAL_IMP": "Onsite",
        "M_OFF_DIS_TOTAL_IMP": "Offsite",
        "M_SEARCH_CLK": "Search",
        "M_ON_DIS_TOTAL_UPD_IMP": "Onsite",
        "M_OFF_DIS_TOTAL_UPD_IMP": "Offsite",
        "M_SEARCH_UPD_CLK": "Search",
    }
    if len(sol_select) < 1:
        print(f"1. No Solutions for brand {brand} with deviation threshold {dev_threshold}")
        return [], None
    else:
        fin_df = pd.concat(sol_select)
        sol_select = [
            fin_df.loc[fin_df.Solution_number == i]
            for i in fin_df.Solution_number.unique()
            if fin_df.loc[fin_df.Solution_number == i, "tac_dev"]
            .le(dev_threshold)
            .all()
        ]
        if len(sol_select) < 1:
            print(f"2. No Solutions for brand {brand} with deviation threshold {dev_threshold}")
            return [], None
        else:
            fin_df = pd.concat(sol_select)
        fin_df["Media"] = fin_df["Media_tactic"].map(media_names)
        fin_df = fin_df[
            [
                "Solution_number",
                "Media",                
                "Tactic_iRoAS",                
                "Overall_iroas",
                "Saturation",
                "Inflection",
                "Sat_Target",
            ]
        ]
        fin_df.sort_values("Saturation", ascending=False)
        for col in fin_df.select_dtypes(include=[np.float]):
            fin_df[col] = fin_df[col].round(2)
        print("********************** Tactics summary **********************")
        display(t_summary)

        print("\n********************** Shortlisted Solutions **********************")        
        display(fin_df.sort_values(by=['Overall_iroas', 'Solution_number', 'Media'], ascending=[False, True, True]))

    selected_solutions = [
        sol_select[i].Solution_number.unique()[0] for i in range(len(sol_select))
    ]
    return selected_solutions, fin_df.sort_values(by=['Overall_iroas', 'Solution_number', 'Media'], ascending=[False, True, True])

def get_scurves(shortlisted_df, point_estimate_sol, media_variables, 
                data, train_start, train_end, test_start, test_end, folder_path):
    folder_path = folder_path + '/'
    selected_df = shortlisted_df[shortlisted_df["Solution_number"]==point_estimate_sol].copy()
    solution_arr = []
    for media in media_variables:
        solution_arr.append(selected_df[selected_df["Media_tactic"]==media]["Coefficient"].values[0])
        solution_arr += ast.literal_eval(selected_df[selected_df["Media_tactic"]==media]["Media_transformation (hf, inf, sc, lg)"].values[0])

    media_var_upd, coef = get_upd_media(media_variables, solution_arr)

    df = data.copy()
    df["Date"] = pd.to_datetime(df["Date"])
    df = df.rename(columns={'Date': 'index'})
    model_obj = MMM_Modelling(df, "O_UNIT", media_var_upd, other_variables, output_path= folder_path,
                                data_dict= data_dict, media_hier= media_hier, 
                                comment= 'Media Mix Model', solution = solution_arr,
                                start = train_start, end = train_end)
    model_obj.coefs_dict = coef
    # Creating train test split
    model_obj.create_train_test_split(
        train_start, train_end, test_start, test_end
    )
    # create all the media transformations

    model_obj.create_missing_media_transformations(
        media_var_upd, trans_start_date=train_start, trans_end_date=train_end
    )
    for c in media_var_upd:
            model_obj.df[c] = model_obj.df[c] + 1.e-15

    for c in media_var_upd:
        s = model_obj.df[ (model_obj.df["index"] >= train_start) & (model_obj.df["index"] <= train_end)][c].sum()
        if (s <= 0.0):
            print(c, s)

    model_obj.create_model_results(
            X_vars=media_var_upd, model_type="Manual Model 1"
        )
    model_obj.set_plot_point_position(
        inf_pt_pos="middle right",
        sat_pt_pos="top right",
        thres_pt_pos="middle right",
        avg_pt_pos="bottom right",
    )
    for media in media_var_upd:
        model_obj.plot_response_curve(
            media,
            model_label="Manual Model 1",
            start_date=train_start,
            end_date=train_end,
            threshold_calculator="logistic",
            saturation_calculator="logistic",
            spend=False,
            show_xy_labels=True,
            show_xyaxis_title=False,
            use_freezed_values=True,
            use_freezed_values_tp=True,
        )