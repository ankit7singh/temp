import pandas as pd
import json
import os
from lite_wamm_modeling import create_folder_with_version
from lite_non_media_utils_v1_1 import *
from lite_wamm_helper_functions import *
from IPython.display import display
class PremiumPreprocess:

    def __init__(self,config_file_path='../src/config_dir/premium_config_pooled.json'):
        file_data = open(config_file_path)
        self.config = json.load(file_data) 

        self.media_stack_path = self.config["media_stack_path"]
        self.non_media_stack_path = self.config["non_media_stack_path"]
        self.outcome = self.config["outcome_var"]
        self.media_vars = self.config["modeling_parameters"][self.outcome]["media_vars"]
        # self.dummy_vars = self.config[self.outcome]["dummy_vars"] #TODO : future scope
        self.essential_non_media = self.config["modeling_parameters"][self.outcome]["essential_non_media_vars"]
        self.excluded_brands = self.config["modeling_parameters"][self.outcome]["excluded_brands"]
        self.non_media_set = self.config["modeling_parameters"][self.outcome]["non_media_set"]
        self.lb = self.config["modeling_parameters"][self.outcome]["s_curve_bounds"]["lb"]
        self.ub = self.config["modeling_parameters"][self.outcome]["s_curve_bounds"]["ub"]
        self.target_r2 = self.config["modeling_parameters"][self.outcome]["target_r2"]
        self.train_start = self.config["modeling_parameters"][self.outcome]["train_start"]
        self.train_end = self.config["modeling_parameters"][self.outcome]["train_end"]
        self.valid_start = self.config["modeling_parameters"][self.outcome]["valid_start"]
        self.valid_end = self.config["modeling_parameters"][self.outcome]["valid_end"]
        self.output_path = self.config["output_path"]  
        self.use_pooled_bounds = self. config["modeling_parameters"][self.outcome]["use_pooled_bounds"]

    def load_data(self):
        data = pd.read_csv(
            self.media_stack_path,
            low_memory=False,
        )
        # filter data based on brand_list
        self.brand_list = sorted(list(data[~data["BRAND"].isin(self.excluded_brands)]["BRAND"].unique()))
        data = data[data["BRAND"].isin(self.brand_list)].reset_index(drop=True)

        self.non_media_stack = pd.read_csv(
            self.non_media_stack_path, low_memory=False
        )
        self.non_media_stack = self.non_media_stack.copy().fillna(0)
        data["Date"] = pd.to_datetime(data["Date"])  # Formatting the date
        self.non_media_stack["Date"] = pd.to_datetime(self.non_media_stack["Date"])  # Formatting the date

        # joining non media to the modeling stack
        self.data = data.merge(self.non_media_stack, how="left", on="Date", sort=False).sort_values(
            by=["BRAND", "Date"], ascending=True
        )


        # determine media variables - TODO change logic if needed
        self.media_variables = sorted(list(set(self.media_vars) & set(list(self.data.columns))))

        # determine dummy variables
        self.dummy_var_lst = list(self.non_media_stack.columns)
        # outcome_vars
        self.outcome_vars = [self.outcome]

    def preprocess_data(self):
        # TODO in-progress
        outcome = self.outcome
        media_variables = self.media_variables
        dummy_var_lst = self.dummy_var_lst #TODO : future scope
        essential_non_media = self.essential_non_media
        non_media_set = self.non_media_set
        use_pooled_bounds = self.use_pooled_bounds
        lb = self.lb
        ub = self.ub
        target_r2 = self.target_r2
        train_start = self.train_start
        train_end = self.train_end
        valid_start = self.valid_start
        valid_end = self.valid_end
        output_path = self.output_path
        outcome_vars = self.outcome_vars
        brand_list = self.brand_list

        print("Running WAMM Premium Preprocessing & Prior Estimation")
        print(f"Outcome Type : {outcome}")
        print(f"Candidate brands : {brand_list}")
        print(f"Media Variables : {media_variables}")
        print(f"Dummy variables : {dummy_var_lst}")
        print(f"essential_non_media_vars : {essential_non_media}")
        print(f"non_media_set : {non_media_set}")
        print(f"Training Start Date: {train_start}")
        print(f"Training End Date: {train_end}")
        print(f"Validation Start Date: {valid_start}")
        print(f"Validation End Date: {valid_end}")
        final_folder_path = create_folder_with_version(f"{output_path}/{outcome}")
        self.final_folder_path = final_folder_path
        data = self.data.copy()
        non_media_stack = self.non_media_stack.copy()
        data_pooled = data.copy()

        (
            self.pre_processed_matrix_U_kj,
            self.pre_processed_matrix_Y_kj,
            self.updated_stack,
            self.non_media_z_k,
            self.non_media_coef,
        ) = get_non_media_matrix(
            data.copy(),
            dummy_var_lst,
            essential_non_media,
            brand_list,
            outcome_vars,
            non_media_set,
            train_start,
            train_end,
            valid_start,
            valid_end,
            target_r2=target_r2,
        )
        # Add price column
        self.updated_stack["PRICE"] = self.updated_stack["O_SALE"] / self.updated_stack["O_UNIT"]
        updated_stack = self.updated_stack.copy()
        if use_pooled_bounds:
            threshold_bounds, saturation_bounds, target_threshold, target_saturation = (
                get_scurve_bounds(data_pooled.copy(), media_variables, lb=lb, ub=ub)
            )
        else:
            # Use the below commented section if you would like to use average threshold and saturation bounds
            threshold_bounds, saturation_bounds, target_threshold, target_saturation = (
                get_scurve_bounds_v1(data.copy(), brand_list, media_variables, lb=lb, ub=ub)
            )
        # alpha_o
        media_iroas_prior = get_media_iroas_prior(data.copy(), brand_list,outcome,media_variables,is_premium=True,debug_flag=False)

        # U_m, Sigma_m
        coef_mean_prior, coef_var_prior = get_media_coef_prior(
            updated_stack.copy(), media_iroas_prior, media_variables,is_premium=True
        ) 

        print(f"media_iroas_prior : {media_iroas_prior}")
        print(f"coef_mean_prior : {coef_mean_prior}")
        print(f"coef_var_prior : {coef_var_prior}")

        priors_info_dict = {}
        for m,var in enumerate(media_variables):
            priors_info_dict[var] = list(threshold_bounds[m])+list(saturation_bounds[m])+[target_threshold[m]]+[target_saturation[m]]+[media_iroas_prior[var]]+[coef_mean_prior[m]]+[coef_var_prior[m]]
        priors_info_df = pd.DataFrame.from_dict(priors_info_dict, orient='index').reset_index()
        priors_info_df.columns = ['media_variable','threshold_lb','threshold_ub','saturation_lb','saturation_ub','target_threshold','target_saturation','iroas_prior','coef_mean_prior','coef_var_prior']
        self.priors_info_df = priors_info_df.copy()
        display(self.priors_info_df)

    def generate_panel_data(self):

        # load variables
        pre_processed_matrix_U_kj = self.pre_processed_matrix_U_kj
        pre_processed_matrix_Y_kj = self.pre_processed_matrix_Y_kj
        brand_list = self.brand_list
        updated_stack = self.updated_stack.copy()
        priors_info_df = self.priors_info_df.copy()
        non_media_set = self.non_media_set
        final_folder_path = self.final_folder_path
        train_start = self.train_start
        train_end = self.train_end
        valid_start = self.valid_start
        valid_end = self.valid_end
        outcome = self.outcome
        media_variables = self.media_variables
        for k,brand in enumerate(brand_list):
    
            updated_stack_brand = updated_stack[updated_stack["BRAND"]==brand]
            brand_k_output_path = f"{final_folder_path}/{brand}"
            try:
                os.mkdir(brand_k_output_path)
                print(f"{brand_k_output_path} created")
            except:
                print(f"{brand_k_output_path} path already exists")
            modeling_stack_k_j_path = f"{brand_k_output_path}/modeling_stack.csv"
            priors_info_df_path = f"{brand_k_output_path}/priors_info.csv"
            updated_stack_brand.to_csv(modeling_stack_k_j_path)
            # media related updates
            priors_info_df.to_csv(priors_info_df_path,index=False)
            print(f"Writing to {brand_k_output_path}")
            for j in range(len(non_media_set)):
                brand_k_j_output_path = f"{brand_k_output_path}/z_{j}"
                try:
                    os.mkdir(brand_k_j_output_path)
                    print(f"{brand_k_j_output_path} created")
                except:
                    print(f"{brand_k_j_output_path} path already exists")

                U_kj = pre_processed_matrix_U_kj[k][j]
                Y_kj = pre_processed_matrix_Y_kj[k][j]
                np.savetxt(f"{brand_k_j_output_path}/U_kj.txt",U_kj)
                np.savetxt(f"{brand_k_j_output_path}/Y_kj.txt",Y_kj)
                
                # generate config for k,j
                config_jk = {}
                config_jk['brand_name']=brand
                config_jk['modeling_stack_path'] = modeling_stack_k_j_path
                config_jk['priors_info_path'] = priors_info_df_path
                config_jk['U_kj_path']=f"{brand_k_j_output_path}/U_kj.txt"
                config_jk['Y_kj_path']=f"{brand_k_j_output_path}/Y_kj.txt"
                config_jk['non_media_set_idx']=j
                config_jk['outcome']=outcome
                config_jk['train_start']=train_start
                config_jk['train_end']=train_end
                config_jk['valid_start']=valid_start
                config_jk['valid_end']=valid_end
                
                config_jk['media_vars'] = media_variables
                config_jk["non_media_z_k"] = self.non_media_z_k[brand][j]
                config_jk["non_media_coef"] = self.non_media_coef[brand][j]
                
                with open(f'{brand_k_j_output_path}/panel_config.json', 'w') as fp:
                    json_dumps_str = json.dumps(config_jk, indent=4)
                    print(json_dumps_str, file=fp)
        print(f"Premium preprocessing results saved to : {final_folder_path}")
        print("Final set of brands: ",self.brand_list)

class PremiumPanel:
    def __init__(self) -> None:
        # Placeholder class for panel level processing
        pass




