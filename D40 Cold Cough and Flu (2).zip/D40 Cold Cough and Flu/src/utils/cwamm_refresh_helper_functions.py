#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# author: Chandana Pasupuleti

"""
Created on Mon Mar 09, 2025

@author: c0p0ii4
"""

import pandas as pd
import numpy as np
import re
from sklearn.metrics import r2_score 
def clean_float(val):
    if isinstance(val, str):
        val = re.sub(r'np\.\w+\((.*?)\)', r'\1', val)
    return float(val) 

from datetime import datetime, timedelta 
import matplotlib.pyplot as plt
import importlib
from IPython.display import display
from model_outputs_05 import create_missing_media_transformations_new
from lite_wamm_modeling_sc_inf_updated import create_folder_with_version
from lite_non_media_utils_v3_Nat_Fit import get_non_media_matrix


class CWAMMRefresh: 
    def __init__(self,
                    SBU,
                    original_stack_path,
                    refresh_stack_path,
                    final_solution_path,
                    model_outputs_path,
                    iroas_iqr_path,
                    outcome,
                    train_start,
                    train_end,
                    valid_start,
                    valid_end,
                    refresh_start,
                    refresh_end,
                    handle_added_value,
                    show_non_media_fit = False,
                    # Thresholds for fit metrics
                    R2_THRESHOLD   = 0.7,
                    MAPE_THRESHOLD = 15.0 ,  # percentage units (matches sheet format)
                    BASE_R2_THRESHOLD = 0.50 ,  # Refresh Base (6 months) Fit R²: flag = True if r2 > 0.50
                    # Thresholds for airing flags
                    SPEND_SHARE_THRESHOLD   = 0.10 ,  # Contribution Spend Share (fraction 0-1): flag if > 10 %
                    OPTIMAL_RANGE_THRESHOLD = 50.0 ,  # Airing Optimal Range Days (%): flag if < 50 %
                 ):
        
        self.brand_nm = SBU 
        self.SBU = SBU 
        self.train_start = pd.to_datetime(train_start)
        self.train_end = pd.to_datetime(train_end)
        self.valid_start = pd.to_datetime(valid_start)
        self.valid_end = pd.to_datetime(valid_end)
        self.refresh_start = pd.to_datetime(refresh_start)
        self.refresh_end = pd.to_datetime(refresh_end)
        self.outcome = outcome
        self.handle_added_value = handle_added_value
        self.use_scaling = True ## when used unscaled coefficients for refresh, the predicted values have slight difference. Hence used scaled coefficients to match well with modeling values
        
        ## Used for Insights Evaluation
        self.R2_THRESHOLD = R2_THRESHOLD
        self.MAPE_THRESHOLD = MAPE_THRESHOLD
        self.SPEND_SHARE_THRESHOLD = SPEND_SHARE_THRESHOLD
        self.OPTIMAL_RANGE_THRESHOLD = OPTIMAL_RANGE_THRESHOLD
        self.BASE_R2_THRESHOLD = BASE_R2_THRESHOLD
        self.log_lines = []

        ## Input files
        self.original_stack_path = original_stack_path
        self.refresh_stack_path = refresh_stack_path
        self.final_solution_path = final_solution_path
        self.model_outputs_path = model_outputs_path
        self.iroas_iqr_path = iroas_iqr_path

        self.wmc_portfolio_dict = {}
        self.timeframes(refresh_start, refresh_end)
        self.generate_portfolio_dict(train_start,valid_end,refresh_start,refresh_end)
        #self.results_path = "../model_results/refresh_results"
        self.results_path = create_folder_with_version("../refresh_results/refresh_results")
        self.show_non_media_fit = show_non_media_fit    

    def load_data(self):
        # load data
        self.original_data = pd.read_csv(self.original_stack_path)
        cols_to_proper = ["MONTH_1","MONTH_2","MONTH_3","MONTH_4","MONTH_5","MONTH_6","MONTH_7","MONTH_8","MONTH_9","MONTH_10","MONTH_11","MONTH_12"]  
        #self.original_data = self.original_data.drop(columns=["Month_1","Month_2","Month_3","Month_4","Month_5","Month_6","Month_7","Month_8","Month_9","Month_10","Month_11","Month_12"])
        self.original_data["Date"] = pd.to_datetime(self.original_data["Date"])
        self.original_data = self.original_data[(self.original_data["Date"]>=self.train_start) & (self.original_data["Date"]<=self.valid_end)]
        self.original_modeling_end_date = self.original_data["Date"].max()
        self.final_solution_df = pd.read_csv(self.final_solution_path)
        self.iqr_df = pd.read_csv(self.iroas_iqr_path)
        self.transformation_df = pd.read_excel(self.model_outputs_path,sheet_name="Coefficient Summary")
        self.num_pred = len(self.transformation_df)
        #print(self.num_pred)
        self.refresh_data = pd.read_csv(self.refresh_stack_path) # placeholder
        self.refresh_data["Date"] = self.refresh_data["INDEX"]
        self.refresh_data["Date"] = pd.to_datetime(self.refresh_data["Date"])
        self.refresh_data.rename(columns={col: col.title() for col in cols_to_proper}, inplace=True)
        self.refresh_data = self.refresh_data[self.refresh_data["Date"]<=self.refresh_end]
              
        ###### generate media vars and coefficients
        self.media_variables = [x for x in self.final_solution_df["Media_tactic"].unique() if x.startswith("M_")]

        self.final_solution_df['media_transformation_string'] = self.final_solution_df['Media_transformation_hf_inf_sc_lg'].str.replace('[','_')
        self.final_solution_df['media_transformation_string'] = self.final_solution_df['media_transformation_string'].str.replace(',','_')
        self.final_solution_df['media_transformation_string'] = self.final_solution_df['media_transformation_string'].str.replace(']','')
        self.final_solution_df['media_transformation_string'] = self.final_solution_df['media_transformation_string'].str.replace(' ','')
        #self.final_solution_df['lambda_'] = self.final_solution_df["media_transformation_string"].apply(lambda x: (float(x.split('_')[-1]))) 
        self.final_solution_df["media_transformation_string"] = self.final_solution_df["media_transformation_string"].apply(lambda x: '_'.join([str(item) for item in x.split('_')[:-1]])) 
        self.final_solution_df['Variable Actual'] = self.final_solution_df["Media_tactic"].astype(str) + self.final_solution_df["media_transformation_string"] + "_" + self.final_solution_df["Coefficient"].astype(str) ## picked media_transformation_string instead of HL, Lag etc columns to match the decimal in "Base - Incremental" output sheet column names. 
        #self.final_solution_df["Variable Actual"] = self.final_solution_df["Media_tactic"] +  "_" + self.final_solution_df["Halflife"].astype(str)  +  "_" + self.final_solution_df["Inflection"].astype(str)  + "_" + self.final_solution_df["Scale"].astype(str)  + "_" + self.final_solution_df["Lag"].astype(str)  + "_"+ self.final_solution_df["Coefficient_unscaled"].astype(str) 
        self.media_transformations = [x for x in self.final_solution_df["Variable Actual"].unique() if x.startswith("M_")] 	
        self.final_solution_df["Variable Points"] = self.final_solution_df["Media_tactic"] +  "_" + self.final_solution_df["Threshold"].astype(str)  +  "_" + self.final_solution_df["Saturation"].astype(str)  + "_" + self.final_solution_df["Inflection_Point"].astype(str) 
        self.media_scurve_points = [x for x in  self.final_solution_df["Variable Points"].unique()]
        
        self.coeff_summary = self.transformation_df.copy()
        
        self.transformation_df["Variable Actual"] = self.transformation_df["Variable Actual"] +"_"+ self.transformation_df["Coefficient"].astype(str)
        # parse media transformations
        self.spend_variables = []
        self.solution = []
        self.non_media_coef = {}
        self.media_coef = {}
        for n in self.transformation_df["Variable Actual"].unique():
            if not n.startswith("M_"):
                var, value = n.rsplit("_", 1)
                self.non_media_coef[var] = float(value)
        
        for m in self.media_transformations:
            split_string = m.rsplit("_",5) 
            #self.media_variables.append(split_string[0])
            self.spend_variables.append(split_string[0][:-4]+"_SPEND")
            self.solution.extend([  
                float(split_string[5]), #coeff scaled
                float(split_string[1]), #HL
                float(split_string[2]), #inflection
                float(split_string[3]), #Scale
                float(split_string[4])  #Lag
            ])
            self.media_coef[split_string[0]+"_TF"] = float(split_string[5]) #dict for media vars & coeff
        
        self.train_price = (self.original_data[self.original_data["Date"] <= self.train_end].assign
                            (price=lambda df: np.where(df[self.outcome] != 0, df["O_SALE"] / df[self.outcome], np.nan))["price"].mean())
        
        print(f"Media Variables : {self.media_variables}")
        print(f"Solution Vector : {self.solution}")
        print(f"Non-media Coefficients : {self.non_media_coef}")
        print(f"Training Period Price : {self.train_price}")
        #print(f"Media Coeff : {self.media_coef}")
        #print(f"S cuvre Points : {self.media_scurve_points}")

        df = self.original_data.copy()
        df["Date"] = pd.to_datetime(df["Date"])
        df = df.drop(columns=['index'], errors='ignore') 
        df = df.rename(columns={"Date": "index"})

        self.spend_variables_wmc = [x for x in self.spend_variables if not (x.startswith("M_NAT") or x.startswith("M_WMT"))]
        
    #def prevQ(self, refresh_start, refresh_end):
    def timeframes(self, refresh_start, refresh_end):
        
        refresh_start = pd.to_datetime(refresh_start)
        refresh_end = pd.to_datetime(refresh_end)

        # Calculate latest 12 months including refresh period 
        self.ref_latest_12m_start = refresh_end - pd.DateOffset(months=11)
        self.ref_latest_12m_start = self.ref_latest_12m_start.replace(day=1)
        #ref_latest_12m_end = refresh_end

        # Calculate previous 12 months based on the latest 12 months including refresh
        self.ref_previous_12m_end = self.ref_latest_12m_start - pd.Timedelta(days=1)
        self.ref_previous_12m_start = self.ref_latest_12m_start.replace(year=self.ref_latest_12m_start.year - 1)

        # Calculate 32 months including refresh
        self.ref_32m_start = refresh_end - pd.DateOffset(months=31)
        self.ref_32m_start = self.ref_32m_start.replace(day=1)
        
        # Format as strings
        self.ref_latest_12m_start = self.ref_latest_12m_start.strftime("%Y-%m-%d")
        self.ref_previous_12m_start = self.ref_previous_12m_start.strftime("%Y-%m-%d")
        self.ref_previous_12m_end = self.ref_previous_12m_end.strftime("%Y-%m-%d")
        self.ref_32m_start = self.ref_32m_start.strftime("%Y-%m-%d")
        
        return self.ref_latest_12m_start, self.ref_previous_12m_start, self.ref_previous_12m_end,self.ref_32m_start
    
    def generate_portfolio_dict(self,train_start, valid_end,refresh_start,refresh_end):
            
        self.wmc_portfolio_dict["1"] = {
                "start_date": train_start,
                "end_date": valid_end,
                "Period": "Modeling Period"
            }
        self.wmc_portfolio_dict["4"] = {
                "start_date": refresh_start,
                "end_date": refresh_end,
                "Period": "Refresh Period (6 months)"
            }
        self.wmc_portfolio_dict["5"] = {
                "start_date": self.ref_latest_12m_start,
                "end_date": refresh_end,
                "Period": "Latest 12 months incl. Refresh"
            }
        self.wmc_portfolio_dict["6"] = {
                "start_date": self.ref_previous_12m_start,
                "end_date": self.ref_previous_12m_end,
                "Period": "Previous 12 months incl. Refresh"
            }
        self.wmc_portfolio_dict["7"] = {
                "start_date": self.ref_32m_start,
                "end_date": refresh_end,
                "Period": "32 months incl. Refresh"
            }

        print(f"Modeling Period : {train_start} to {valid_end}")
        print(f"Refresh Period : {refresh_start} to {refresh_end}")
        print(f"Latest 12 months incl. Refresh : {self.ref_latest_12m_start} to {refresh_end}")
        print(f"Previous 12 months incl. Refresh : {self.ref_previous_12m_start} to {self.ref_previous_12m_end}")
        print(f"32 months incl. Refresh : {self.ref_32m_start} to {refresh_end}")
        
    def combine_variables(self,combined_media_variables_dict):
        if combined_media_variables_dict:
            for combined_var, var_lst in combined_media_variables_dict.items():
                spend_var_lst = [var[:-4] + "_SPEND" for var in var_lst]
                self.refresh_data[combined_var] = self.refresh_data[var_lst].sum(axis=1)
                self.refresh_data[combined_var[:-4] + "_SPEND"] = self.refresh_data[spend_var_lst].sum(axis=1)
        
    def generate_seasonal_columns(self):
        print("Generating Seasonal Components for the refresh period:")
        # placeholder for generating seasonal columns
        all_seasonal_cols = [
            "INTERCEPT",
            "MV_trend_1", "MV_seasonality_1",
            "MV_trend_2", "MV_seasonality_2",
            "MV_trend_3", "MV_seasonality_3",
            "MV_trend_4", "MV_seasonality_4",
            "MV_trend_5", "MV_seasonality_5",
            "MV_trend_6", "MV_seasonality_6",
            "SARIMAX",
            "SARIMAX_LOG",
            f"{self.outcome}_TREND", f"{self.outcome}_SEASONALITY",
            f"{self.outcome}_TREND_LOG", f"{self.outcome}_SEASONALITY_LOG"
        ]

        essential_vars = [
            x for x in self.non_media_coef.keys() if x not in all_seasonal_cols
        ]
        
        essential_vars_all=self.essential_vars_all ##New Jun 29
        non_media_data = self.stitched_data[["Date",self.outcome]+essential_vars].copy()
        non_media_data["SBU"] = self.SBU
        # combined_data = get_non_media_matrix(              # NEW 5.29   -

        (                                   # NEW 5.29 + 
        _pre_processed_matrix_U_kj,
        _pre_processed_matrix_Y_kj,
        combined_data,
        _non_media_z_k,
        _non_media_coef,
        ) = get_non_media_matrix(           # NEW 5.29  +

            non_media_data,
            [],
            essential_vars,
            [self.brand_nm],
            [self.outcome],
            [],
            self.train_start,
            self.train_end,
            self.valid_start,
            self.valid_end,
            target_r2=0.8,
            essential_non_media_with_outliers = essential_vars_all ##New Jun 29
            #EDA_check=False, 
            #refresh_flag = True                           # NEW 5.28   -
        )
        combined_data.reset_index(inplace=True)            

        if self.show_non_media_fit:
            print("After stitching the non-media data:")
            for col in all_seasonal_cols:
                plt.figure(figsize=(8, 4))
                plt.plot(combined_data[col].values, label='stitched data', color='orange')
                plt.plot(self.stitched_data[col].values, label='original data', color='blue')
                plt.title(f'Line Plot for {col}')
                plt.xlabel('Index')
                plt.ylabel(col)
                plt.legend()
                plt.show()

        # slice and copy values into stitched data
        original_data = self.stitched_data.copy()
        mask = (self.stitched_data['Date'] >= self.refresh_start) & (self.stitched_data['Date'] <= self.refresh_end)

        for col in all_seasonal_cols:
            combined_data_mask = (combined_data['Date'] >= self.refresh_start) & (combined_data['Date'] <= self.refresh_end)

            self.stitched_data.loc[mask, col] = combined_data.loc[combined_data_mask, col].values
        if self.show_non_media_fit:

            for col in all_seasonal_cols:
                plt.figure(figsize=(8, 4))
                plt.plot(self.stitched_data[col].values, label='stitched data', color='orange')
                plt.plot(self.original_data[col].values, label='original data', color='blue')
                plt.title(f'Line Plot for {col}')
                plt.xlabel('Index')
                plt.ylabel(col)
                plt.legend()
                plt.show()
        

    def stitch_data(self, combined_media_variables_dict = {}):
        self.combine_variables(combined_media_variables_dict)

        self.essential_vars_all = list(self.non_media_coef.keys()) ##New Jun 29 to debug D92-Soups case
        
        # place holder. Should include all columns from original stack
        all_columns = ["Date",self.outcome,"O_SALE"]+self.media_variables + self.spend_variables  
        self.original_data["STACK_TYPE"] =["MODELING_STACK"] * len(self.original_data)     
        self.refresh_data["STACK_TYPE"] =["REFRESH_STACK"] * len(self.refresh_data) 
        self.stitched_data = pd.concat([self.original_data,self.refresh_data[self.refresh_data["Date"]>self.original_modeling_end_date]]).reset_index(drop=True)
        self.stitched_data.fillna(0,inplace=True)
        self.model_end_idx = self.stitched_data[self.stitched_data["Date"]==self.original_modeling_end_date].index[0]+1
        self.generate_seasonal_columns()
        self.stitched_data["M_TOTAL_MEDIA_SPEND"] = self.stitched_data[self.spend_variables_wmc].sum(axis=1)
        self.stitched_data.to_csv(f"{self.results_path}/modeling_stack_with_refresh.csv",index=False) ##New Jun 30
        print(f"Successfully generated modeling + refresh stack {self.SBU} - {self.outcome} to {self.results_path}/modeling_stack_with_refresh.csv")  ##New Jun 30
           
    def calculate_fit_metrics(self, type, df):
    
        if "Base" in type:
            # Calculate MAPE
            mape = np.mean(np.abs((df['Actual'] - df['Base_Predicted']) / df['Actual'])) * 100
            
            # Calculate R2
            r2 = r2_score(df['Actual'], df['Base_Predicted'])                                    

        else: 
             # Calculate MAPE
            mape = np.mean(np.abs((df['Actual'] - df['Predicted']) / df['Actual'])) * 100

            # Calculate R2
            r2 = r2_score(df['Actual'], df['Predicted'])       
        
        # Calculate Adjusted R2
        n = len(df)  
        p = self.num_pred        
        adj_r2 = 1 - (1 - r2) * (n - 1) / (n - p - 1)
        
        return [mape, r2, adj_r2]
    
    def generate_fit_metrics(self):
        transformed_media_df = self.transformed_media_df[["Date",self.outcome]+list(self.media_coef.keys())].copy()
        non_media_df = self.stitched_data[["Date",self.outcome]+list(self.non_media_coef.keys())].copy()
        
        act_vs_predicted = transformed_media_df[["Date",self.outcome]].copy()
        act_vs_predicted = act_vs_predicted.rename(columns={'Date': 'index',self.outcome:'Actual'})
        act_vs_predicted["Predicted"] = 0
        act_vs_predicted["Base_Predicted"] = 0
        
        for m in self.media_coef.keys():
            act_vs_predicted["Predicted"] += transformed_media_df[m]*self.media_coef[m]

        # NEW 6.1 +++
        # print("\n[DEBUG] Non-media coefficients used for Refresh Base (6 months) Fit")
        # non_media_coef_debug = (
        #     pd.DataFrame(
        #         list(self.non_media_coef.items()),
        #         columns=["Variable", "Coefficient Used"]
        #     )
        #     .sort_values("Variable")
        #     .reset_index(drop=True)
        # )
        # print(non_media_coef_debug.to_string(index=False))
        # NEW 6.1 +++

        for m in self.non_media_coef.keys():
            act_vs_predicted["Predicted"] += non_media_df[m]*self.non_media_coef[m]
            act_vs_predicted["Base_Predicted"] += non_media_df[m]*self.non_media_coef[m]
        if self.outcome == "O_UNIT":
            model = "OMNI Unit Sales Model"
            model_filter = 1
        else:
            model = "OMNI New Customer Count Model"
            model_filter = 2
        act_vs_predicted["Model"] = model
        act_vs_predicted["Model Filter"] = model_filter
        act_vs_predicted["Residual"] = (act_vs_predicted["Predicted"]/act_vs_predicted["Actual"]) - 1
        
        fit_metrics_dict = {
            "Model" : act_vs_predicted[act_vs_predicted["index"]<=self.train_end].copy(),
            "Validation" : act_vs_predicted[(act_vs_predicted["index"]>=self.valid_start) & (act_vs_predicted["index"]<=self.valid_end)].copy(),
            "Refresh (6 months)" : act_vs_predicted[act_vs_predicted["index"]>self.valid_end].copy(),
            "32m incl. Refresh": act_vs_predicted[(act_vs_predicted["index"]>=self.ref_32m_start) & (act_vs_predicted["index"]<=self.refresh_end)].copy(),
            "Lat 12m incl. Refresh": act_vs_predicted[(act_vs_predicted["index"]>=self.ref_latest_12m_start) & (act_vs_predicted["index"]<=self.refresh_end)].copy(),
            "Refresh Base (6 months)" : act_vs_predicted[act_vs_predicted["index"]>self.valid_end].copy(),
            "32m incl. Refresh Base": act_vs_predicted[(act_vs_predicted["index"]>=self.ref_32m_start) & (act_vs_predicted["index"]<=self.refresh_end)].copy(),
            "Lat 12m incl. Refresh Base": act_vs_predicted[(act_vs_predicted["index"]>=self.ref_latest_12m_start) & (act_vs_predicted["index"]<=self.refresh_end)].copy(),
        }

        self.sheet_fit_metrics_df = pd.DataFrame(
                                {
                                "Model Filter":[model_filter]*3,
                                "Model":[model]*3,
                                "Metric":["MAPE","R Square","Adjusted R Square"]
                                }
                            )
        
        for key,value in fit_metrics_dict.items():
            prefix = key
            self.sheet_fit_metrics_df[f"{key} Fit"] = (self.calculate_fit_metrics(key,value))
            if key!="Validation_Refresh":
                if key=="Model":
                    prefix = "Modeling"
                fit_metrics_dict[key] = fit_metrics_dict[key].rename(columns = {'Actual':f'{prefix} Actual','Predicted':f'{prefix} Predicted'})
        
        self.sheet_act_vs_predicted = pd.concat([v for k, v in fit_metrics_dict.items() if k not in ("32m incl. Refresh","Lat 12m incl. Refresh","Refresh Base (6 months)","32m incl. Refresh Base","Lat 12m incl. Refresh Base")])
        self.sheet_act_vs_predicted.drop(columns=["Base_Predicted","Model","Model Filter"], inplace=True)   
        self.sheet_act_vs_predicted = self.sheet_act_vs_predicted.rename(columns={"index":"Date"})
        self.sheet_act_vs_predicted = self.sheet_act_vs_predicted.pivot_table(index='Date', values=self.sheet_act_vs_predicted.columns.difference(['Date']).tolist(), aggfunc=['max'])
        self.sheet_act_vs_predicted.columns = self.sheet_act_vs_predicted.columns.get_level_values(1)  
        self.sheet_act_vs_predicted =  self.sheet_act_vs_predicted.reset_index()
        self.sheet_act_vs_predicted = self.sheet_act_vs_predicted.fillna('')


    def generate_final_dfs(self):

        self.transformed_media_df = pd.concat([self.stitched_data[["SBU","STACK_TYPE","Date",self.outcome,"O_SALE"]], self.transformed_media_df], axis=1)
        
        self.transformed_daily_sales = pd.DataFrame()
        self.transformed_daily_contribution = pd.DataFrame()

        for m in self.media_coef.keys():
            self.transformed_daily_contribution[m] = self.transformed_media_df[m]*self.media_coef[m]
            self.transformed_daily_sales[m] = self.transformed_media_df[m]*self.media_coef[m]*self.train_price
        
        self.transformed_daily_contribution.columns = self.transformed_daily_contribution.columns.str.replace('TF', 'Contri')
        self.transformed_daily_sales.columns = self.transformed_daily_sales.columns.str.replace('TF', 'Sales')
        contri_cols = self.transformed_daily_contribution.columns
        
        self.transformed_daily_contribution = pd.concat([self.stitched_data[["SBU","STACK_TYPE","Date",self.outcome,"O_SALE"]], self.transformed_daily_contribution], axis=1)
        self.transformed_daily_sales = pd.concat([self.stitched_data[["SBU","STACK_TYPE","Date",self.outcome,"O_SALE"]], self.transformed_daily_sales], axis=1)
        
        self.df_metrics_final = self.transformed_daily_contribution.copy()
        self.df_metrics_final["Base_Sales"] = self.df_metrics_final["O_UNIT"] - self.df_metrics_final[contri_cols].sum(axis=1)
        self.df_metrics_final["incremental_sales"] = self.df_metrics_final[contri_cols].sum(axis=1)
        self.df_metrics_final = self.df_metrics_final.loc[self.df_metrics_final["STACK_TYPE"]=="REFRESH_STACK"]

        ks = contri_cols
        #vs = self.final_solution_df["Media_tactic"] +  "_" + self.final_solution_df["Halflife"].astype(str)  +  "_" + self.final_solution_df["Inflection"].astype(str)  + "_" + self.final_solution_df["Scale"].astype(str)  + "_" + self.final_solution_df["Lag"].astype(str)
        vs =  self.final_solution_df["Media_tactic"].astype(str) + self.final_solution_df["media_transformation_string"]
        rename_dict = dict(zip(ks, vs))

        self.df_metrics_final = self.df_metrics_final.rename(columns=rename_dict)
        self.df_metrics_final_out = self.df_metrics_final.drop(columns=["O_SALE","SBU","STACK_TYPE","incremental_sales"], errors='ignore')
        self.df_metrics_final_out = self.df_metrics_final_out.rename(columns={"Date":"index","O_UNIT":"Total Sales","Base_Sales":"Baseline Sales"})
        new_order = list(rename_dict.values()) + ["Total Sales","Baseline Sales","index"]
        self.df_metrics_final_out = self.df_metrics_final_out.reindex(columns=new_order)   
        
    def contribution_cal(self):
            
        for key, value in self.wmc_portfolio_dict.items():

            start_date = value["start_date"]
            end_date = value["end_date"]
            period = value["Period"]

            print(f'Summary Statistics for {key} : {period}:')

            start_index = self.stitched_data[self.stitched_data['Date']==start_date].index[0]
            end_index = self.stitched_data[self.stitched_data['Date']==end_date].index[0] + 1
            
            self.transformed_media = self.transformed_media_df[list(self.media_coef.keys())]
            self.transformed_media = self.transformed_media.iloc[start_index:end_index,:]
            self.transformed_media = self.transformed_media.to_numpy()
            self.train_spend = np.asarray(self.stitched_data[self.spend_variables][start_index:end_index]).sum(axis=0)
            self.train_rawmedia= np.asarray(self.stitched_data[self.media_variables][start_index:end_index]).sum(axis=0)


            raw_units = self.stitched_data[(self.stitched_data['Date']>=start_date) & (self.stitched_data['Date']<=end_date)][['O_SALE', 'O_UNIT']].copy()

            media_stack_df = self.stitched_data[self.media_variables]
            
            wmc_result_data = {
                                "Timeframe": period,
                                "Start Date": start_date,
                                "End Date": end_date,
                                "Display Level" : self.media_variables,
                                "Total Contribution" : (np.array(list(self.media_coef.values())) * self.transformed_media.sum(axis=0)),
                                "Total Sales ($)" : (np.array(list(self.media_coef.values())) * self.transformed_media.sum(axis=0) * self.train_price),
                                "Total Spend ($)" : self.train_spend,
                                "Raw Media" : self.train_rawmedia,
                                #"Volume RoAS" : (np.array(list(self.media_coef.values())) * self.transformed_media.sum(axis=0)/ self.train_spend),
                                "Volume RoAS": np.divide(np.array(list(self.media_coef.values())) * self.transformed_media.sum(axis=0),self.train_spend,
                                                         out=np.zeros_like(self.train_spend, dtype=float),where=self.train_spend != 0),
                                #"Value RoAS ($)" : (np.array(list(self.media_coef.values())) * self.transformed_media.sum(axis=0) * self.train_price/ self.train_spend),
                                "Value RoAS ($)": np.divide(np.array(list(self.media_coef.values())) * self.transformed_media.sum(axis=0) * self.train_price,self.train_spend,
                                                         out=np.zeros_like(self.train_spend, dtype=float),where=self.train_spend != 0)
            }
            
            wmc_result_data_df = pd.DataFrame.from_dict(wmc_result_data)
        
            wmc_result_data_df['Contribution Share(%)'] = wmc_result_data_df['Total Contribution']/wmc_result_data_df['Total Contribution'].sum()
            wmc_result_data_df['Spend Share(%)'] = wmc_result_data_df['Total Spend ($)']/wmc_result_data_df['Total Spend ($)'].sum()
            wmc_result_data_df['Raw Media Share(%)'] = wmc_result_data_df['Raw Media']/wmc_result_data_df['Raw Media'].sum()
            wmc_result_data_df['Media Rate ($)'] = np.where(
                wmc_result_data_df['Display Level'].astype(str).str.contains('M_SP|M_SV|M_SBA', na=False),
                wmc_result_data_df['Total Spend ($)'] / wmc_result_data_df['Raw Media'],
                (wmc_result_data_df['Total Spend ($)'] / wmc_result_data_df['Raw Media']) * 1000)

            total_incremental = {"Timeframe": period,
                                    "Start Date": start_date,
                                    "End Date": end_date,
                                    "Display Level": "Total Incremental",
                                     "Total Contribution": wmc_result_data_df['Total Contribution'].sum(),
                                     "Total Sales ($)": wmc_result_data_df['Total Sales ($)'].sum(),
                                     "Total Spend ($)": wmc_result_data_df['Total Spend ($)'].sum(),
                                     "Raw Media": wmc_result_data_df['Raw Media'].sum(),
                                     "Volume RoAS": wmc_result_data_df['Total Contribution'].sum()/wmc_result_data_df['Total Spend ($)'].sum(),
                                     "Value RoAS ($)": wmc_result_data_df['Total Sales ($)'].sum()/wmc_result_data_df['Total Spend ($)'].sum(),
                                     "Contribution Share(%)": wmc_result_data_df['Total Contribution'].sum()/raw_units['O_UNIT'].sum(),
                                     "Spend Share(%)": 1,
                                     "Raw Media Share(%)": 1,
                                     "Media Rate ($)": wmc_result_data_df['Total Spend ($)'].sum()/wmc_result_data_df['Raw Media'].sum() *1000}

            base = {"Timeframe": period,
                        "Start Date": start_date,
                        "End Date": end_date, 
                        "Display Level": "Base",
                        "Total Contribution": raw_units['O_UNIT'].sum() - wmc_result_data_df['Total Contribution'].sum(),
                        "Total Sales ($)": raw_units['O_SALE'].sum() - wmc_result_data_df['Total Sales ($)'].sum(),
                        "Total Spend ($)": 0,
                        "Raw Media": 0,
                        "Volume RoAS": 0,
                        "Value RoAS ($)": 0,
                        "Contribution Share(%)": 1 - (wmc_result_data_df['Total Contribution'].sum()/raw_units['O_UNIT'].sum()),
                        "Spend Share(%)": 0,
                        "Raw Media Share(%)": 0,
                        "Media Rate ($)": 0}

            total = {"Timeframe": period,
                        "Start Date": start_date,
                        "End Date": end_date,
                        "Display Level": "Total",
                        "Total Contribution": raw_units['O_UNIT'].sum(),
                        "Total Sales ($)": raw_units['O_SALE'].sum(),
                        "Total Spend ($)": wmc_result_data_df['Total Spend ($)'].sum(),
                        "Raw Media": wmc_result_data_df['Raw Media'].sum(),
                        "Volume RoAS": 0,
                        "Value RoAS ($)": 0,
                        "Contribution Share(%)": 1,
                        "Spend Share(%)": 0,
                        "Raw Media Share(%)": 0,
                        "Media Rate ($)": wmc_result_data_df['Total Spend ($)'].sum()/wmc_result_data_df['Raw Media'].sum() *1000}

            wmc_result_data_df.loc[len(wmc_result_data_df)] = total_incremental
            wmc_result_data_df.loc[len(wmc_result_data_df)] = base
            wmc_result_data_df.loc[len(wmc_result_data_df)] = total

            #display(wmc_result_data_df)
            self.wmc_result_data_df = pd.concat([self.wmc_result_data_df, wmc_result_data_df], axis=0) 
        self.wmc_contrib = pd.DataFrame(self.wmc_result_data_df)
        self.wmc_contrib.fillna(0, inplace=True)

    def airing_analysis(self):
        filtered_portfolio_dict = {key : value for key, value in self.wmc_portfolio_dict.items() if key not in {'7'}}
        airing_df = []
        for key, value in filtered_portfolio_dict.items():

            start_date = value["start_date"]
            end_date = value["end_date"]
            period = value["Period"]
            
            start_index = self.stitched_data[self.stitched_data['Date']==start_date].index[0]
            end_index = self.stitched_data[self.stitched_data['Date']==end_date].index[0] + 1
            
            data_sub = self.stitched_data.iloc[start_index:end_index,:]
            
            print(f'Airing Analysis for {key} : {period}:') 
            for m in self.media_scurve_points:
                split_string1 = m.rsplit("_",3) 
                threshold = float(split_string1[1])
                saturation = float(split_string1[2]) 
                inflection = (threshold + saturation) / 2 if threshold is not None and saturation is not None else None #float(split_string1[3])  
                var = split_string1[0]
                
                data = data_sub[var]
                
                total_days = len(data)
                on_air_days = (data > 0).sum()
                
                timeframe = period
                days_above_saturation = (data > saturation).sum() if saturation is not None else None
                days_below_threshold = ((data < threshold) & (data > 0)).sum() if threshold is not None else None
                optimal_range_days = ((data >= threshold) & (data <= saturation)).sum() if threshold is not None and saturation is not None else None
                optimal_range_days_perc = (optimal_range_days / on_air_days * 100) if optimal_range_days is not None else None 
                days_above_saturation_perc = (days_above_saturation / on_air_days * 100) if days_above_saturation is not None else None
                days_below_threshold_perc = (days_below_threshold / on_air_days * 100) if days_below_threshold is not None else None
                on_air_days_perc = (on_air_days/total_days * 100) if on_air_days is not None else None
                
                actual_avg_point = data.mean()
                average = data[data > 0].mean() if on_air_days > 0 else 0
                
                airing_df.append([
                    timeframe, var, total_days, on_air_days,on_air_days_perc, optimal_range_days_perc,days_above_saturation_perc,
                    days_below_threshold_perc,optimal_range_days,  days_above_saturation, days_below_threshold,
                    actual_avg_point, average, threshold, inflection, saturation
                ])
        
            self.airing_df = pd.DataFrame(airing_df, columns=[
            "Timeframe","Variable", "Total Days", "On Air Days",  "On Air Days (%)","Optimal Range Days (%)",
            "Above Saturation Days (%)", "Below Threshold Days (%)","Optimal Range Days",
            "Days above Saturation", "Days below Threshold",
            "Actual Average Point", "Average", "Threshold point",
            "Inflection Point", "Saturation Point"
            ])
            self.airing_df.fillna(0, inplace=True)
    
    def insights_guardrails(self, df):
        #print(df)
        df_sub = df[(df["Display Level"] == "Total Incremental") & (df["Timeframe"].isin(["Latest 12 months incl. Refresh", "Previous 12 months incl. Refresh"]))]
        df_sub.drop(columns=["Display Level", "Spend Share(%)", "Raw Media Share(%)"], inplace=True, errors='ignore')
        numeric_cols = df_sub.select_dtypes(include=np.number).columns

        yoy_row = {}

        for col in df_sub.columns:
            if col in numeric_cols:
                val1 = df_sub.loc[df_sub["Timeframe"] == "Latest 12 months incl. Refresh", col].values[0]
                val2 = df_sub.loc[df_sub["Timeframe"] == "Previous 12 months incl. Refresh", col].values[0]

                # YoY % change
                if val2 != 0:
                    yoy_row[col] = (val1 / val2 - 1) * 100
                else:
                    yoy_row[col] = 0
            else:
                yoy_row[col] = "YoY"

        # Convert to DataFrame
        self.yoy_df = pd.DataFrame([yoy_row])
        self.yoy_df = pd.concat([df_sub, self.yoy_df], ignore_index=True)

        self.iqr_df = self.iqr_df.rename(columns={'Unnamed: 0':"Stats"})
        
        df_filtered = df[(~df["Display Level"].isin(["Total", "Base"])) & (df["Timeframe"].isin(["32 months incl. Refresh","Latest 12 months incl. Refresh"]))][["Timeframe","Display Level","Value RoAS ($)"]].copy()
        df_filtered['Display Level'] = df_filtered['Display Level'].replace('Total Incremental', 'Overall_iroas')

        df_filtered = df_filtered.pivot(index="Timeframe", columns="Display Level", values="Value RoAS ($)").reset_index()
        df_filtered.rename(columns={'Timeframe': 'Stats'}, inplace=True)
        self.iqr_final=pd.concat([self.iqr_df, df_filtered], ignore_index=True)

        self.iqr_final = self.iqr_final.set_index("Stats")
        l12_guardrail = (self.iqr_final.loc["Latest 12 months incl. Refresh"] >= self.iqr_final.loc["Q1"]) & (self.iqr_final.loc["Latest 12 months incl. Refresh"] <= self.iqr_final.loc["Q3"])
        m32_guardrail = (self.iqr_final.loc["32 months incl. Refresh"] >= self.iqr_final.loc["Q1"]) & (self.iqr_final.loc["32 months incl. Refresh"] <= self.iqr_final.loc["Q3"])
        new_rows = pd.DataFrame([l12_guardrail, m32_guardrail], index=["L12m - Within Guardrail", "32m - Within Guardrail"]).map(lambda x: "True" if x == 1 else "False")
        self.iqr_final = pd.concat([self.iqr_final, new_rows]).reset_index()
        self.iqr_final = self.iqr_final[~self.iqr_final["index"].isin(["L12m - Within Guardrail","Latest 12 months incl. Refresh"])]

    def write_final_excel(self):    
        with pd.ExcelWriter(self.file_name, engine='xlsxwriter') as WRITER:
            pd.DataFrame(self.log_lines).to_excel(WRITER, sheet_name="Log", index=False, header=False)
            #self.transformed_media_df.to_excel(WRITER, sheet_name = 'Transformed Media - Daily', index = False)
            #self.transformed_daily_contribution.to_excel(WRITER, sheet_name = 'Incr. Contri - Daily', index = False)
            #self.transformed_daily_sales.to_excel(WRITER, sheet_name = 'Incr. Sales - Daily', index = False)
            self.coeff_summary.to_excel(WRITER, sheet_name = 'Coefficient Summary', index = False)
            self.sheet_fit_metrics_df.to_excel(WRITER, sheet_name = 'Model Stats', index = False)
            self.wmc_contrib.to_excel(WRITER, sheet_name = 'Contribution', index = False)
            self.airing_df.to_excel(WRITER, sheet_name = 'Airing Analysis', index = False)
            self.sheet_act_vs_predicted.to_excel(WRITER, sheet_name = 'Act vs Pred Refresh-Included', index = False)
            self.df_metrics_final_out.to_excel(WRITER, sheet_name = 'Base - Incrmental Contribution', index = False)
            self.stitched_data.to_excel(WRITER, sheet_name = 'Stack with Refresh data', index = False)
            self.yoy_df.to_excel(WRITER, sheet_name = 'Insights Guardrails', index = False)
            self.iqr_final.to_excel(WRITER, sheet_name = 'Insights Guardrails', startrow=7, index = False)
            self.summary.to_excel(WRITER, sheet_name="Insights Summary", index=False)
        print(f"Refresh results saved to {self.file_name}") 

    def generate_report(self):
        
        self.transformed_media_df = create_missing_media_transformations_new(self.stitched_data.copy()[self.media_variables],self.media_transformations,model_end_idx=self.model_end_idx,refresh_flag=True)
        self.wmc_result_data_df=pd.DataFrame()
        self.generate_final_dfs()
        self.generate_fit_metrics()
        self.contribution_cal()
        self.airing_analysis()
        self.insights_guardrails(self.wmc_contrib)   
        #self.write_final_excel()  

######## The following code analyzes the reliability of the refresh results based on:
#            Base Model Fit metrics for Refresh, Latest 12m Fit Metrics, YoY Monotonicity 
#            Also Highlights if % Optimal airing days are within threshold & tactic levle YoY as a reference.

    # Fuction to Evaluate Fit metrics
    def compute_fit_flags(self) -> pd.DataFrame:
        COL_32M      = "32m incl. Refresh Fit"
        COL_L12      = "Lat 12m incl. Refresh Fit"
        COL_BASE_R6M = "Refresh Base (6 months) Fit"
        COL_METRIC   = "Metric"
        COL_MODEL    = "Model"

        records = []
        for model_name, grp in self.sheet_fit_metrics_df.groupby(COL_MODEL, sort=False):
            mape_row = grp[grp[COL_METRIC].str.upper() == "MAPE"]
            r2_row   = grp[grp[COL_METRIC].str.upper() == "R SQUARE"]
            if mape_row.empty or r2_row.empty:
                continue

            mape_32m    = mape_row[COL_32M].values[0]
            r2_32m      = r2_row[COL_32M].values[0]
            mape_L12    = mape_row[COL_L12].values[0]
            r2_L12      = r2_row[COL_L12].values[0]
            r2_base_r6m = r2_row[COL_BASE_R6M].values[0]

            records.append({
                "category"                 : self.SBU,
                "model"                    : model_name,
                "r2_32m"                   : round(r2_32m, 4),
                "mape_32m_pct"             : round(mape_32m, 4),
                "refresh_32m_fit_flag"     : bool(r2_32m > self.R2_THRESHOLD and mape_32m < self.MAPE_THRESHOLD),
                "r2_L12"                   : round(r2_L12, 4),
                "mape_L12_pct"             : round(mape_L12, 4),
                "refresh_L12_fit_flag"     : bool(r2_L12 > self.R2_THRESHOLD and mape_L12 < self.MAPE_THRESHOLD),
                "r2_base_refresh_6m"       : round(r2_base_r6m, 4),
                "refresh_nonmedia_fit_flag": bool(r2_base_r6m > self.BASE_R2_THRESHOLD),
            })
        return pd.DataFrame(records)

    # Fuction to Evaluate Optimal Range Days (on Air days between Threshold & Saturation)
    def compute_airing_flag(self) -> tuple:
        CONTRIBUTION_EXCLUDE = {"Total Incremental", "Base", "Total"}
        REFRESH_TF  = "Refresh Period (6 months)"
        MODELING_TF = "Modeling Period"
        L12M_TF     = "Latest 12 months incl. Refresh"
        PREV12M_TF  = "Previous 12 months incl. Refresh"

        COL_TF_C  = "Timeframe"
        COL_VAR_C = "Display Level"
        COL_SPEND = "Spend Share(%)"
        COL_TF_A  = "Timeframe"
        COL_VAR_A = "Variable"
        COL_OPT   = "Optimal Range Days (%)"

        contrib_refresh = self.wmc_contrib[
            (self.wmc_contrib[COL_TF_C] == REFRESH_TF) &
            (~self.wmc_contrib[COL_VAR_C].isin(CONTRIBUTION_EXCLUDE))
        ].set_index(COL_VAR_C)[COL_SPEND]

        high_spend_vars = contrib_refresh[contrib_refresh > self.SPEND_SHARE_THRESHOLD].index.tolist()

        def airing_index(tf):
            sub = self.airing_df[self.airing_df[COL_TF_A] == tf]
            return sub.set_index(COL_VAR_A)[COL_OPT] if not sub.empty else pd.Series(dtype=float)

        opt_refresh  = airing_index(REFRESH_TF)
        opt_L12m     = airing_index(L12M_TF)
        opt_prev12m  = airing_index(PREV12M_TF)
        opt_modeling = airing_index(MODELING_TF)

        def get_opt(series, var):
            v = series.get(var, None)
            return round(float(v), 2) if v is not None and not pd.isna(v) else None

        records = []
        for var in high_spend_vars:
            val_refresh = get_opt(opt_refresh, var)
            if val_refresh is not None and val_refresh < self.OPTIMAL_RANGE_THRESHOLD:
                records.append({
                    "category"                       : self.SBU,
                    "variable"                       : var,
                    "spend_share_refresh_pct"        : round(contrib_refresh[var] * 100, 2),
                    "optimal_range_days_refresh_pct" : val_refresh,
                    "optimal_range_days_L12m_pct"    : get_opt(opt_L12m,    var),
                    "optimal_range_days_prev12m_pct" : get_opt(opt_prev12m, var),
                    "optimal_range_days_modeling_pct": get_opt(opt_modeling, var),
                })

        refresh_nonoptimal_airing_flag = len(records) > 0
        detail_df = pd.DataFrame(records)
        return refresh_nonoptimal_airing_flag, detail_df

    # Fuction to Check YoY Monotonicity
    def compute_yoy_monotonicity_flag(self) -> tuple:
        """
        YOY_monotonicity_flag = True if Total Spend and Total Contribution
        move in the same direction from Previous 12m → Latest 12m.
        Source: Insights Guardrails sheet.
        """
        L12M_TF     = "Latest 12 months incl. Refresh"
        PREV12M_TF  = "Previous 12 months incl. Refresh"
        COL_TF      = "Timeframe"
        COL_SPEND   = "Total Spend ($)"
        COL_CONTRIB = "Total Contribution"

        row_L12m    = self.yoy_df[self.yoy_df[COL_TF] == L12M_TF]
        row_prev12m = self.yoy_df[self.yoy_df[COL_TF] == PREV12M_TF]

        if row_L12m.empty or row_prev12m.empty:
            return False, {}

        spend_L12m      = float(row_L12m[COL_SPEND].values[0])
        spend_prev12m   = float(row_prev12m[COL_SPEND].values[0])
        contrib_L12m    = float(row_L12m[COL_CONTRIB].values[0])
        contrib_prev12m = float(row_prev12m[COL_CONTRIB].values[0])

        spend_up   = spend_L12m   > spend_prev12m
        spend_down = spend_L12m   < spend_prev12m
        contrib_up = contrib_L12m > contrib_prev12m
        flag = bool(spend_up == contrib_up)
        
        if spend_down:  ## New: June 30 Added to avoid montonicity flag as False when spend is declining and contribution  not. 
            flag =True
        detail = {
            "spend_prev12m"    : round(spend_prev12m,   2),
            "spend_L12m"       : round(spend_L12m,      2),
            "spend_direction"  : "↑" if spend_up else "↓",
            "contrib_prev12m"  : round(contrib_prev12m, 2),
            "contrib_L12m"     : round(contrib_L12m,    2),
            "contrib_direction": "↑" if contrib_up else "↓",
        }
        return flag, detail

    # Fuction to if iroas YoY is Stable
    def compute_yoy_stable_iroas_flag(self) -> tuple:
        """
        YoY_stable_iroas = True if the YoY relative change in Value RoAS ($)
        is NOT more than 2× the YoY relative change in Total Spend ($).

            spend_yoy_pct  = (spend_L12m  - spend_prev12m)  / |spend_prev12m|
            iroas_yoy_pct  = (iroas_L12m  - iroas_prev12m)  / |iroas_prev12m|

            flag = abs(iroas_yoy_pct) <= 2 * abs(spend_yoy_pct)

        Source: Contribution sheet, 'Total Incremental' rows for
            'Latest 12 months incl. Refresh' and 'Previous 12 months incl. Refresh'.
        """
        L12M_TF    = "Latest 12 months incl. Refresh"
        PREV12M_TF = "Previous 12 months incl. Refresh"
        TOTAL_ROW  = "Total Incremental"
        COL_TF     = "Timeframe"
        COL_DL     = "Display Level"
        COL_SPEND  = "Total Spend ($)"
        COL_IROAS  = "Value RoAS ($)"

        row_L12m    = self.wmc_contrib[(self.wmc_contrib[COL_TF] == L12M_TF)    & (self.wmc_contrib[COL_DL] == TOTAL_ROW)]
        row_prev12m = self.wmc_contrib[(self.wmc_contrib[COL_TF] == PREV12M_TF) & (self.wmc_contrib[COL_DL] == TOTAL_ROW)]

        if row_L12m.empty or row_prev12m.empty:
            return False, {}

        spend_L12m    = float(row_L12m[COL_SPEND].values[0])
        spend_prev12m = float(row_prev12m[COL_SPEND].values[0])
        iroas_L12m    = float(row_L12m[COL_IROAS].values[0])
        iroas_prev12m = float(row_prev12m[COL_IROAS].values[0])

        # Guard against zero denominators
        if spend_prev12m == 0 or iroas_prev12m == 0:
            return False, {}

        spend_yoy_pct = (spend_L12m  - spend_prev12m)  / abs(spend_prev12m)
        iroas_yoy_pct = (iroas_L12m  - iroas_prev12m)   / abs(iroas_prev12m)

        flag = bool(abs(iroas_yoy_pct) <= 2 * abs(spend_yoy_pct))

        detail = {
            "spend_prev12m"  : round(spend_prev12m, 2),
            "spend_L12m"     : round(spend_L12m,    2),
            "spend_yoy_pct"  : round(spend_yoy_pct  * 100, 2),
            "iroas_prev12m"  : round(iroas_prev12m,  4),
            "iroas_L12m"     : round(iroas_L12m,     4),
            "iroas_yoy_pct"  : round(iroas_yoy_pct  * 100, 2),
        }
        return flag, detail
    
    
    def _p(self,msg=""):
        print(msg)
        self.log_lines.append(str(msg))

    def analyze_results(self):

        fit_results = self.compute_fit_flags()
        #all_fit_results.append(df_flags)

        refresh_nonoptimal_airing_flag, detail_df = self.compute_airing_flag()
        yoy_monotonicity_flag, yoy_detail         = self.compute_yoy_monotonicity_flag()
        yoy_stable_iroas_flag, iroas_detail       = self.compute_yoy_stable_iroas_flag()

        airing_flag_rows = ({
            "category"                      : self.SBU,
            "refresh_nonoptimal_airing_flag": refresh_nonoptimal_airing_flag,
            "YOY_monotonicity_flag"         : yoy_monotonicity_flag,
            "YoY_stable_iroas"              : yoy_stable_iroas_flag,
        })

        # Print Log highlighting all the evaluation done on Refresh Insights 
        W = 130
        self._p(f"\n{'='*W}")
        self._p(f"\nCategory : {self.SBU}")
        row = fit_results.iloc[0]
        self._p(f"Model : {row['model']}")
        self._p(f"\n Fit thresholds    → R² > {self.R2_THRESHOLD}  |  MAPE < {self.MAPE_THRESHOLD}%  |  Base R² > {self.BASE_R2_THRESHOLD}")

        self._p(f"    refresh_32m_fit_flag      = {str(row['refresh_32m_fit_flag']):<5}  "
            f"(R²={row['r2_32m']:.4f}, MAPE={row['mape_32m_pct']:.2f}%)")
        self._p(f"    refresh_L12_fit_flag      = {str(row['refresh_L12_fit_flag']):<5}  "
            f"(R²={row['r2_L12']:.4f}, MAPE={row['mape_L12_pct']:.2f}%)")
        self._p(f"    refresh_nonmedia_fit_flag = {str(row['refresh_nonmedia_fit_flag']):<5}  "
            f"(Base R²={row['r2_base_refresh_6m']:.4f}, threshold > {self.BASE_R2_THRESHOLD})")

        self._p(f"\n  YOY_monotonicity_flag = {yoy_monotonicity_flag}")
        if yoy_detail:
            d = yoy_detail
            self._p(f"    Total Spend      Prev12m={d['spend_prev12m']:>15,.2f}  →  L12m={d['spend_L12m']:>15,.2f}  {d['spend_direction']}")
            self._p(f"    Total Contrib.   Prev12m={d['contrib_prev12m']:>15,.2f}  →  L12m={d['contrib_L12m']:>15,.2f}  {d['contrib_direction']}")
            if not yoy_monotonicity_flag:
                self._p(f"    ⚠ Spend and Contribution moved in opposite directions.")

        self._p(f"\n  YoY_stable_iroas = {yoy_stable_iroas_flag}")
        if iroas_detail:
            d = iroas_detail
            self._p(f"    Total Spend   Prev12m={d['spend_prev12m']:>15,.2f}  →  L12m={d['spend_L12m']:>15,.2f}  "
                f"(YoY Δ={d['spend_yoy_pct']:>+7.2f}%)")
            self._p(f"    Value RoAS    Prev12m={d['iroas_prev12m']:>15.4f}  →  L12m={d['iroas_L12m']:>15.4f}  "
                f"(YoY Δ={d['iroas_yoy_pct']:>+7.2f}%)  |  2× spend Δ threshold = {2*abs(d['spend_yoy_pct']):>6.2f}%")
            if not yoy_stable_iroas_flag:
               self._p(f"    ⚠ iROAS changed more than 2× the YoY spend change.")

        self._p(f"\n  Airing thresholds → Spend Share (Refresh) > {self.SPEND_SHARE_THRESHOLD*100:.0f}%  |  Opt. Range Days (Refresh) < {self.OPTIMAL_RANGE_THRESHOLD:.0f}%")
        self._p(f"    refresh_nonoptimal_airing_flag = {refresh_nonoptimal_airing_flag}")
        
        if refresh_nonoptimal_airing_flag:
            def fmt(v): return f"{v:.2f}%" if v is not None else "  N/A "
            self._p(f"\n  {'Variable':<36} {'Spend(Refresh)':>15}  "
                f"{'OptRng(Refresh)':>16} {'OptRng(L12m)':>13} {'OptRng(Prev12m)':>15} {'OptRng(Modeling)':>17}")
            self._p(f"  {'-'*36} {'-'*15}  {'-'*16} {'-'*13} {'-'*15} {'-'*17}")
            for _, r in detail_df.iterrows():
                self._p(f"  {r['variable']:<36} {fmt(r['spend_share_refresh_pct']):>15}  "
                    f"{fmt(r['optimal_range_days_refresh_pct']):>16} "
                    f"{fmt(r['optimal_range_days_L12m_pct']):>13} "
                    f"{fmt(r['optimal_range_days_prev12m_pct']):>15} "
                    f"{fmt(r['optimal_range_days_modeling_pct']):>17}")
        else:
            self._p("    → No variables trigger the non-optimal airing flag.")

        if not detail_df.empty:
            self.airing_results = detail_df

        # Consolidate all Flags
        #fit_results    = pd.concat(all_fit_results, ignore_index=True)
        airing_flag_df = pd.DataFrame(airing_flag_rows, index=[0])
        self.summary = fit_results.merge(airing_flag_df, on="category", how="left")
        self.summary = self.summary[[
            "category", "model",
            "r2_32m", "mape_32m_pct", "refresh_32m_fit_flag",
            "r2_L12",  "mape_L12_pct", "refresh_L12_fit_flag",
            "r2_base_refresh_6m", "refresh_nonmedia_fit_flag",
            "YOY_monotonicity_flag",
            "YoY_stable_iroas",
            "refresh_nonoptimal_airing_flag",
        ]].copy()

        self.summary["refresh_insight_valid_flag"] = (
            #self.summary["refresh_nonmedia_fit_flag"] &
            self.summary["YOY_monotonicity_flag"]
            & self.summary["refresh_L12_fit_flag"]
        )

        def build_invalid_reasons(row):
            reasons = []
            if not row["refresh_nonmedia_fit_flag"]:   reasons.append("poor nonmedia fit")
            if not row["refresh_L12_fit_flag"]:        reasons.append("poor L12 fit")
            if not row["YOY_monotonicity_flag"]:       reasons.append("YoY monotonicity")
            if not row["YoY_stable_iroas"]:            reasons.append("non-stable iROAS")
            if row["refresh_nonoptimal_airing_flag"]:  reasons.append("nonoptimal airing")
            return reasons if reasons else ["—"]

        self.summary["invalid_insight_reason"] = self.summary.apply(build_invalid_reasons, axis=1)

        if not self.summary["refresh_insight_valid_flag"].all(): #iroas_valid.empty:
            self._p(f"\nRefresh insights are not valid for category {self.SBU}. The reasons are: {self.summary.loc[self.summary['category'] == self.SBU, 'invalid_insight_reason'].values[0]}")
            
            self.file_name = self.results_path + f"/{self.SBU}_refresh_results_DO_NOT_USE.xlsx"
            self.write_final_excel()
        else:
            self._p(f"\nRefresh insights are valid for category {self.SBU}.")

            self.file_name = self.results_path + f"/{self.SBU}_refresh_results.xlsx"
            self.write_final_excel()
            
        self._p(f"\n{'='*130}\n")
