### this script contains the default/advanced values for running the modeling pipeline
### this script was spun out from the previous config json to simplify the json

## modeling parameters

# shared modeling parameters
modeling_parameters_shared_media_dictionary = {
    "IMP": "Impression",
    "SPEND": "Spend",
    "VIEW_IMP": "Viewable Impression",
    "CLK": "Click",
}

modeling_parameters_shared_modeling_stack_path_raw = "../data/input_data/modeling_stack.csv"
modeling_parameters_shared_modeling_stack_path_processed = "../data/processed_input_data/modelling_stack_data_seasonality_autoselected.csv"
modeling_parameters_shared_data_dict_path = "../data/input_data/WMG WAMM Project Data Dictionary_v19.xlsx"
modeling_parameters_shared_media_hier_path = "../data/input_data/media_hierarchy.csv"
modeling_parameters_shared_joint_opt_apply_adstock = False
modeling_parameters_shared_num_cores_for_computing = 6

# modeling parameters for the sales unit model
modeling_parameters_sales_unit_apply_adstock = False
modeling_parameters_sales_unit_DE_params = {
    "strategy": "best1bin",
    "popsize": 15,
    "tol": 0.01,
    "atol": 0.0,
    "mutation": "(0.5, 1)",
    "recombination": 0.7,
    "updating": "immediate",
    "max_number_genetic_iterations": 3
}

GA_output_folder_path = "GA_output"
GA_output_sales_unit_version = ""           # specify version as "_v1", "_v2", etc
GA_output_new_customer_version = ""         # specify version as "_v1", "_v2", etc

modeling_parameters_sales_unit_folder_name = "sales_unit"
modeling_parameters_sales_unit_final_model_directory = "../models/sales_unit/"

# modeling parameters for the new customer model
modeling_parameters_new_customer_apply_adstock = False
modeling_parameters_new_customer_DE_params = {
    "strategy": "best1bin",
    "popsize": 15,
    "tol": 0.01,
    "atol": 0.0,
    "mutation": "(0.5, 1)",
    "recombination": 0.7,
    "updating": "immediate",
    "max_number_genetic_iterations": 3
}

modeling_parameters_new_customer_folder_name = "new_customer"
modeling_parameters_new_customer_final_model_directory = "../models/new_customer/"

# parameter for model insight deck
model_insights_deck_MODEL_DICT_sales_unit_Base_Scaler = 0.8
model_insights_deck_MODEL_DICT_new_customer_Base_Scaler = 0.8

model_insights_deck_MODEL_DICT_singleOpt_scenarios_singleOpt_log = "/Optimization_Log.xlsx"
model_insights_deck_MODEL_DICT_singleOpt_scenarios_singleOpt_df_new_file = "/df_new.csv"
model_insights_deck_MODEL_DICT_singleOpt_scenarios_singleOpt_contrib_df_file = "/contrib_df.csv"
model_insights_deck_MODEL_DICT_singleOpt_scenarios_singleOpt_roas_def_file = "/roas_df.csv"
model_insights_deck_MODEL_DICT_singleOpt_scenarios_headroom_anlaysis_file = "/headroom_analysis.csv"

model_insights_deck_JOINT_OPT_DICT_jointOpt_log = "/jointOpt_Log.xlsx"
model_insights_deck_JOINT_OPT_DICT_jointOpt_result_df_file = "/result_df.csv"
model_insights_deck_JOINT_OPT_DICT_jointOpt_result_contrib_file = "/result_contrib.csv"

model_insights_deck_TITLE_SIZE = 31
model_insights_deck_AXIS_SIZE = 30
model_insights_deck_four_point_size = 20
model_insights_deck_other_point_size = 10
model_insights_deck_model_count = 1
